# WORK_PLAN.md (인수인계/체크용)

이 문서는 **리팩토링 작업을 “0.1 단위 패치”로 반복**할 때,
- 무엇을 했는지
- 무엇을 다음에 할지
- 무엇을 확인해야 하는지
를 한 곳에서 관리하기 위한 체크리스트입니다.

> 원칙: 한 패치에서는 “하나의 목적”만 수행합니다.  
> (예: 관측 추가만 / 함수 추출만 / 예외 정리만)

---
## 사용 방법

- 이 문서는 “패치 단위(0.1)”로 작업할 때, 매번 같은 실수를 반복하지 않도록 체크리스트를 제공하는 목적입니다.
- 패치 1회당 목표는 1개(예: 문서 정리만 / 함수 추출만 / 예외 정리만)로 두는 것을 권장합니다.

---


## 0) 현재 베이스

- 기준 버전: **v7.32**
- 엔트리: `mersoom_agent_modular_v7_32.py`
- 이전 엔트리 보관: `prev_versions/entrypoints/`
- 변경 요약:
  - v7.31: 커맨드 파일 영문화 + 경로 표기를 상대경로로 정리 + 문서/플랜 정합성 업데이트
  - v7.30: P0 안전/문서 정리(락 경로 부모 dir 보장 + 문서/커맨드/버전 정합성)
  - v7.29: v7.28 기반 정합성 보완(퍼즐 로그 기본 경로 runtime/archive 통일 + JSONL parent dir 자동 생성 + 패키징 캐시 제거)
  - v7.26: 메모리 trim(미평가 우선 보존) + eval backlog 부스팅 + due drop 가시화
  - v7.25 (긴급): state side-effects(성숙도/semantic) 업데이트를 안전하게 보호 + sync circuit-breaker 중 오래된 posts_cache 무효화(중복 행동 방지; env `MERSOOM_SYNC_CACHE_MAX_AGE_SEC`)
  - v7.2: build_reply_text: quote discipline 추출
  - v6.9: snapshot 스크립트(`snapshot_mersoom_to_xlsx_v3.py`)의 `datetime.utcnow()` DeprecationWarning 제거(aware datetime 사용)

  (이전 변경 포함)
  - `sections/*.py` 상단에 섹션 역할 설명(docstring) 추가
  - 본 문서(`WORK_PLAN.md`) 추가(진행 체크용)
  - 런/README/커맨드 파일에서 v6.4 엔트리 안내 반영
  - Trace scaffolding(기본 OFF, MERSOOM_TRACE=1) + 종료 시 trace_hits.json 덤프
  - Trace entry hits(select:*, gen:*) + tick_target 요약 로그 추가(v6.5)
  - Trace hit 추가 연결: quality gate + API wrappers (v6.6)
  - Trace hit 추가 연결: reward/policy + stage coverage 요약 (v6.7)
  - Selftest에 생성기 특성화 테스트 추가 (reply/post 생성 + trace 태그 점검) (v6.8)

---

## 1) 매 패치 공통 체크리스트 (필수)

아래 항목은 **모든 패치(vX.Y)**에서 동일하게 수행합니다.

- [ ] (A) 작업 전: 직전 버전 파일/폴더 백업
- [ ] (B) 버전 표기 갱신: 엔트리 파일 docstring + README 변경 요약
- [ ] (C) 최소 테스트 세트:
  - [ ] `python mersoom_agent_modular_v7_32.py --selftest`
  - [ ] `python mersoom_agent_modular_v7_32.py --migrate-only`
  - [ ] `python mersoom_agent_modular_v7_32.py --qa-batch` (짧게라도)
- [ ] (D) 실제 1~2 tick 확인(가능하면):
  - [ ] `MERSOOM_ALWAYS_ON=false`로 실행 후 `run_*.log` 확인
- [ ] (E) 산출물 정리:
  - [ ] zip 패키징(전체 폴더)
  - [ ] 변경점 요약 5줄 이내 기록(아래 “패치 로그”에)

---

## 2) 패치 큐 (권장 순서)

> 아래 “다음 작업”은 리팩토링 베스트 프랙티스 기준으로 정한 추천 순서입니다.  
> 필요하면 우선순위를 바꿔도 되지만, **관측(Observability) → 특성화(Selftest 강화) → 함수 추출(Refactor-only)** 순서를 권장합니다.

### Phase 0 — 관측/특성화 (리팩토링 들어가기 전 필수)

- [x] v6.4: Trace 스캐폴딩(기본 OFF; `MERSOOM_TRACE=1`일 때만 동작)
- [x] v6.5: Trace를 selection/generation “입구”에 연결 + tick 요약(최소)
- [x] v6.6: Trace를 quality gate + API 래퍼에 연결
- [x] v6.7: Trace를 reward/policy “출구”에 연결 + stage coverage 요약
- [x] v6.8: Selftest에 “생성기 특성화 테스트(최소 불변 조건)” 추가
- [x] v6.9: snapshot 스크립트 `datetime.utcnow()` 경고 제거

### Phase 1 — 생성기 리팩토링(Extract-only, 21_generate.py)

- [x] v7.0: build_reply_text: `_prepare_reply_context` 추출
- [x] v7.1: build_reply_text: `_make_reply_decisions` 추출
- [x] v7.2: build_reply_text: quote discipline 추출
- [x] v7.25: (긴급) state 업데이트 안정화 + sync 캐시 스테일 가드
- [ ] v7.3: build_reply_text: 후보 생성 추출
- [ ] v7.4: build_reply_text: 게이트 적용 추출
- [ ] v7.5: build_reply_text: 마감/메타 추출 + orchestrator 정리

### Phase 2 — 포스트 생성기 리팩토링(Extract-only, 21_generate.py)

- [ ] v7.6: build_post_text: 컨텍스트/결정 추출
- [ ] v7.7: build_post_text: 후보/게이트/마감/메타 완성

### Phase 3 — 타겟 선택/아레나/메인루프

- [ ] v7.8: 20_target_select.py 주요 함수 분해(수집/스코어/필터/픽)
- [ ] v7.9: 15_arena_flow.py 주요 함수 분해(차단/선정/결정/요청/기록)
- [ ] v8.0: 24_main_loop.py run() 경계 정리(boot/tick/shutdown)

### Phase 4 — 안정성/유지보수(필요할 때만)

- [ ] v8.1: `except Exception: pass` 제거 1차(핵심 경로만)
- [ ] v8.2: 예외 구체화(딕트/타입변환/리스트/API)
- [ ] v8.3: 매직 넘버 상수화(quality gate 중심)
- [ ] v8.4: 최소 TypedDict 도입(thread/user/compose/report)

---

## 3) 패치 단위 템플릿 (다음 패치 작성 시 복사해서 사용)

### vX.Y - <패치 제목>

**목적(한 줄):**  
- 예: 관측(Trace) 인프라 추가 / build_reply_text 일부 추출 / 예외 pass 제거

**변경 파일:**  
- `sections/...`

**작업 내용(핵심 3~5개):**
- …

**완료 기준:**
- [ ] selftest 통과
- [ ] qa-batch 통과
- [ ] (가능하면) 1~2 tick 정상
- [ ] 로그로 원인 추적 가능(침묵 실패 없음)

**롤백 포인트:**
- 변경 전 zip / 백업 폴더

---

## 4) 패치 로그 (실제 작업 후 기록)

> 아래는 “완료한 패치”를 누적 기록하는 공간입니다.

- v6.35 (2026-02-10)
  - docs: section docstrings + WORK_PLAN.md 추가
  - 엔트리/README/커맨드 갱신

- v6.7 (2026-02-10)
  - trace: reward/policy 경로 hit 기록(`reward:*`, `policy:*`)
  - trace: 종료 시 stage coverage 요약을 trace_hits.json에 포함 + 로그로 출력


- v6.4 (2026-02-10)
  - obs: Trace scaffolding added (default OFF; enable with MERSOOM_TRACE=1)
  - obs: best-effort dump to 'trace_hits.json' on normal exit


- v6.5 (2026-02-10)
  - obs: trace_hit hooked at selection/generation entry points (select:*, gen:*)
  - obs: tick_target minimal action/target summary when MERSOOM_TRACE=1
(여기 아래부터 계속 추가)

- v6.6 (2026-02-10)
  - obs: trace_hit hooked at quality gates (final_text_gate/final_post_gate) pass/fail
  - obs: trace_hit hooked at API wrappers (create_post/create_comment/vote_post/arena_*) + api:http:<code>

- v6.8 (2026-02-10)
  - test: selftest에 생성기 특성화 테스트 추가 (reply/post 생성 + 게이트 통과 + trace tag 기록 여부)

- v6.9 (2026-02-10)
  - snapshot: datetime.utcnow() DeprecationWarning 제거 (aware datetime 사용)


- v7.0 (2026-02-10)
  - refactor: extract `_prepare_reply_context()` from `build_reply_text()` (extract-only; no behavior change)

### v7.1 - build_reply_text decision logic extraction
- `sections/21_generate.py`: `_make_reply_decisions()` helper extracted from `build_reply_text()` (strategy/tone/length/reply_style).
- Metadata fields preserved (`ref_strategy_*`, `ref_reply_style_*`).
- Minor safety: reply_styles arms are always defined to avoid NameError when keyword tokens are empty.
- Selftest/qa-batch should remain green.

### v7.2 - build_reply_text quote discipline extraction
- `sections/21_generate.py`: BM25 quote selection/cooldown/strategy-softening 블록을 `_handle_quote_discipline()`로 추출.
- `_quote_fallback()`/`_quote_interpret()`는 top-level helper로 이동 (기존 호출부에서 동일하게 사용).
- 코드 구조만 정리(Extract-only); 생성 결과/메타 필드/쿨다운 로직 변경 없음이 목표.

### v7.25 - hotfix: state update guards + stale sync cache invalidation
- `sections/20_target_select.py`, `sections/21_generate.py`, `sections/22_qa_fallback.py`: `update_persona_maturity()` / `bump_semantic()` 호출을 try/except로 보호(실패 시 `log_exception()` 기록, failfast 옵션 유지).
- `sections/24_main_loop.py`: sync circuit-breaker(ops skip) 상태에서 posts_cache가 오래되면 무효화(중복 행동 리스크 완화). env `MERSOOM_SYNC_CACHE_MAX_AGE_SEC` (default=3600; min=300; max=86400).


### v7.26 - memory/learning integration hardening
- `sections/09_migration_helpers.py`: smart memory trim (keep unevaluated items first); warns/throttles if due items are dropped; load_memory에도 동일 정책 적용.
- `sections/23_reward_update.py`: evaluation backlog가 큰 경우 tick당 평가량을 완만하게 늘려 backlog를 따라잡도록 조정(`MERSOOM_EVAL_BACKLOG_BOOST` 기본 ON, 상한 `MERSOOM_EVAL_BACKLOG_MAX_PER_TICK`).
- `sections/24_main_loop.py`: tick 끝 trim을 smart trim으로 교체 + dropped_due 누적 카운터(state) 기록.
