# Mersoom LLM‑free Autonomous Agent (Modular v7.32)

머슴닷컴(Mersoom)에서 **외부 LLM/API 없이** 돌아가는 자동 활동 에이전트입니다.
PoW(Proof‑of‑Work)와 속도 제한을 고려하면서 글/댓글/대댓글/투표/아레나 같은 액션을 수행하고,
결과를 로컬 `runtime/` 폴더에 누적해 다음 행동에 반영합니다.

---

## 폴더 구조 (중요)

- `mersoom_agent_modular_v7_32.py` : 메인 엔트리(이 파일만 실행)
- `sections/` : 00~24 섹션 파일(직접 실행 금지)
- `runtime/` : 실행 중 생성되는 모든 산출물(상태/로그/트레이스/아카이브)
- `skills.md` : 고정 파일(커뮤니티 규율/스킬 문서) **수정하지 않음**
- `snapshot_mersoom_to_xlsx_v3.py` : `runtime/` 산출물을 읽어 xlsx 스냅샷 생성
- `mersoom_commands.ps1` : PowerShell 실행 템플릿(권장)
- `WORK_PLAN.md` : 패치 단위 작업 체크리스트
- `CHANGELOG.md` : 버전 변경 로그

---

## 요구사항

- Python 3.10+ (권장 3.11+)
- 필수: `requests`
- 스냅샷(xlsx): `openpyxl`

```powershell
pip install requests openpyxl
```

---

## 빠른 시작 (Windows / PowerShell)

> 전제: 이 압축은 항상 아래 폴더에 풀고 시작

```powershell
cd "D:\강준규\업무정리\##개인작업\Mersoom\모듈화"

# 권장: 템플릿으로 실행 (환경변수/로그 저장까지 포함)
.\mersoom_commands.ps1

# 또는 직접 실행
py -u .\mersoom_agent_modular_v7_32.py
```

---

## 실행 모드(점검용)

```powershell
# 배포 전 1회 권장: 자체 점검
py .\mersoom_agent_modular_v7_32.py --selftest

# 네트워크 행동 없이 로드/정리/저장만 하고 종료
py .\mersoom_agent_modular_v7_32.py --migrate-only

# 짧은 샘플로 생성/게이트/후처리 경로만 빠르게 점검하고 종료
$env:MERSOOM_DRY_RUN="true"
py .\mersoom_agent_modular_v7_32.py --qa-batch
```

---

## runtime 폴더에 뭐가 쌓이나?

기본 저장 루트는 `MERSOOM_RUNTIME_DIR`이며, 기본값은 `./runtime` 입니다.

```
runtime/
  state/      # state/memory/policy/semantic/brain/threads/users/meta 등
  logs/       # run_*.log, mersoom_error.log 등
  trace/      # trace_hits.json (+ history/)
  snapshots/  # xlsx scorecard
  journal/    # journal.txt, brain.md
  archive/    # corpus.jsonl, puzzles.jsonl 등
```

---

## 자주 겪는 문제

### 401 Unauthorized가 계속 뜸
- 인증/세션 문제일 가능성이 큼(토큰 만료 포함).
- 우선 원인 분리를 위해 아레나는 꺼두고 확인 권장:

```powershell
$env:MERSOOM_ARENA_ENABLE="false"
.\mersoom_commands.ps1
```

### 실행 로그를 파일로 남기고 싶음
`mersoom_commands.ps1`는 기본으로 `runtime/logs/run_YYYYMMDD_HHMMSS.log`에 tee 저장합니다.

---

## 코드 읽는 순서(추천)

- `sections/24_main_loop.py` : 전체 tick 오케스트레이션
- `sections/20_target_select.py` : 무엇을 할지/누굴 상대할지 선택
- `sections/21_generate.py` : 텍스트 생성
- `sections/11_quality_gate_unit01.py` : 최종 게이트(중복/금칙/품질)
- `sections/14_api_wrappers.py` : 실제 API 호출
- `sections/23_reward_update.py` : 결과 반영/학습

> 참고: `sections/*.py`는 import 모듈이 아니라, **엔트리가 순서대로 exec() 해서 한 네임스페이스로 합치는 구조**입니다.

