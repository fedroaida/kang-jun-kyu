"""
mersoom_agent_modular_v7_25.py - Modular runner (v7.25)

Goal:
- Keep runtime behavior identical while splitting the original single-file agent into numbered sections.
- Improve maintainability by making each subsystem easier to find (00~24).

How it works:
- The runner sequentially exec()s each file in ./sections into ONE shared global namespace.
- This preserves the original single-file style (shared globals) while keeping code physically separated.
- Each section is compiled with its filename so tracebacks point to the exact section file.

Usage:
  py -u .\mersoom_agent_modular_v7_25.py [--selftest|--migrate-only|--qa-batch|...]

Best practice:
- Do NOT run section files directly.
- When debugging, start from the tick flow in sections/24_main_loop.py and follow into:
  20_target_select.py -> 21_generate.py -> 11_quality_gate_unit01.py -> 14_api_wrappers.py -> 23_reward_update.py.
"""

from __future__ import annotations

import os
import sys

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))

_SECTION_FILES = ['sections/00_preamble.py', 'sections/01_config.py', 'sections/02_logging_time.py', 'sections/03_storage.py', 'sections/04_ops_guards.py', 'sections/05_limiters_pacing.py', 'sections/06_http_client.py', 'sections/07_pow_challenge.py', 'sections/08_schemas_defaults.py', 'sections/09_migration_helpers.py', 'sections/10_focus_helpers.py', 'sections/11_quality_gate_unit01.py', 'sections/12_brain_action_bias.py', 'sections/13_policy_bandit_context.py', 'sections/14_api_wrappers.py', 'sections/15_arena_flow.py', 'sections/16_context_corpus_index.py', 'sections/17_template_miner_registry.py', 'sections/18_agent_logic_core.py', 'sections/19_sleep_helpers.py', 'sections/20_target_select.py', 'sections/21_generate.py', 'sections/22_qa_fallback.py', 'sections/23_reward_update.py', 'sections/24_main_loop.py']


def _exec_section(rel_path: str) -> None:
    path = os.path.join(_BASE_DIR, rel_path)
    with open(path, "r", encoding="utf-8") as f:
        src = f.read()
    code = compile(src, path, "exec")
    # Execute into this module's globals to mimic the original single-file namespace.
    exec(code, globals(), globals())


# Load all sections in the intended order.
for _p in _SECTION_FILES:
    _exec_section(_p)
