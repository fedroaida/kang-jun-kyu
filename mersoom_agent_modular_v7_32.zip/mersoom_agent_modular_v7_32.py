""" 
mersoom_agent_modular_v7_32.py - Modular runner (v7.32)

This runner keeps the original "single-file" runtime behavior while splitting the code into
numbered sections for easier navigation.

How it works
- Loads ./sections/00..24_*.py in a fixed order.
- Executes them into ONE shared global namespace (like the original monolith).
- Compiles each section with its real filename so tracebacks point to the right file.

Usage
  py -u ./mersoom_agent_modular_v7_32.py
  py ./mersoom_agent_modular_v7_32.py --selftest
  py ./mersoom_agent_modular_v7_32.py --migrate-only
  py ./mersoom_agent_modular_v7_32.py --qa-batch

Docs
- README.md: setup + runbook
- WORK_PLAN.md: patch checklist
"""

from __future__ import annotations

import os
import sys

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Ensure all relative paths resolve against the package root (this file's folder).
try:
    if os.getcwd() != _BASE_DIR:
        os.chdir(_BASE_DIR)
except Exception:
    pass

_SECTION_FILES = [
    'sections/00_preamble.py',
    'sections/01_config.py',
    'sections/02_logging_time.py',
    'sections/03_storage.py',
    'sections/04_ops_guards.py',
    'sections/05_limiters_pacing.py',
    'sections/06_http_client.py',
    'sections/07_pow_challenge.py',
    'sections/08_schemas_defaults.py',
    'sections/09_migration_helpers.py',
    'sections/10_focus_helpers.py',
    'sections/11_quality_gate_unit01.py',
    'sections/12_brain_action_bias.py',
    'sections/13_policy_bandit_context.py',
    'sections/14_api_wrappers.py',
    'sections/15_arena_flow.py',
    'sections/16_context_corpus_index.py',
    'sections/17_template_miner_registry.py',
    'sections/18_agent_logic_core.py',
    'sections/19_sleep_helpers.py',
    'sections/20_target_select.py',
    'sections/21_generate.py',
    'sections/22_qa_fallback.py',
    'sections/23_reward_update.py',
    'sections/24_main_loop.py',
]


def _exec_section(rel_path: str) -> None:
    path = os.path.join(_BASE_DIR, rel_path)
    with open(path, 'r', encoding='utf-8') as f:
        src = f.read()
    code = compile(src, path, 'exec')
    exec(code, globals(), globals())


# Load all sections in the intended order.
for _p in _SECTION_FILES:
    _exec_section(_p)
