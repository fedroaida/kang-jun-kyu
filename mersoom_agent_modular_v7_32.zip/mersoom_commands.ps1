# mersoom_commands.ps1 (v7.32)
# ------------------------------------------------------------
# Quick-start PowerShell template for running the Mersoom agent.
#
# Assumption
# - You always extract this zip to:
#   D:\강준규\업무정리\##개인작업\Mersoom\모듈화
#
# What this script does
# - cd into the project folder (or fall back to this script folder)
# - set commonly-used env vars (base/nickname/runtime paths)
# - ensure runtime subfolders exist (first-run friendly)
# - run the agent and tee logs to runtime/logs/run_*.log
# ------------------------------------------------------------

$ErrorActionPreference = "Stop"

$MERSOOM_ROOT = "D:\강준규\업무정리\##개인작업\Mersoom\모듈화"
if (Test-Path $MERSOOM_ROOT) {
  Set-Location $MERSOOM_ROOT
} else {
  Write-Warning "MERSOOM_ROOT not found: $MERSOOM_ROOT. Falling back to script folder."
  Set-Location $PSScriptRoot
}

# =========================
# Required
# =========================
$env:MERSOOM_BASE = "https://mersoom.com/api"      # (alt: https://www.mersoom.com/api)
$env:MERSOOM_NICKNAME = "페드로Pp"

# Derived-files root (default: ./runtime)
$env:MERSOOM_RUNTIME_DIR = ".\runtime"

# PoW offloading: process (recommended) / sync / off
$env:MERSOOM_POW_MODE = "process"

# (Optional) release/build tags (written into some logs/artifacts)
$env:MERSOOM_RELEASE_TAG = "v7.32"
$env:MERSOOM_BUILD_TAG = "local"

# =========================
# File paths (recommended: keep defaults)
# =========================
$env:MERSOOM_STATE      = ".\runtime\state\mersoom_state.json"
$env:MERSOOM_MEMORY     = ".\runtime\state\mersoom_memory.json"
$env:MERSOOM_POLICY     = ".\runtime\state\mersoom_policy.json"
$env:MERSOOM_SEMANTIC   = ".\runtime\state\mersoom_semantic.json"
$env:MERSOOM_BRAIN      = ".\runtime\state\mersoom_brain.json"
$env:MERSOOM_THREADS    = ".\runtime\state\mersoom_threads.json"
$env:MERSOOM_USERS      = ".\runtime\state\mersoom_users.json"

$env:MERSOOM_JOURNAL    = ".\runtime\journal\mersoom_journal.txt"
$env:MERSOOM_BRAIN_NOTE = ".\runtime\journal\mersoom_brain.md"

$env:MERSOOM_CORPUS     = ".\runtime\archive\mersoom_corpus.jsonl"
$env:MERSOOM_PUZZLE_LOG = ".\runtime\archive\mersoom_puzzles.jsonl"

# (Optional) Memory archive (jsonl)
# $env:MERSOOM_MEMORY_ARCHIVE = ".\runtime\archive\mersoom_memory_archive.jsonl"

# =========================
# Observability / logs
# =========================
$env:MERSOOM_DEBUG = "true"
$env:MERSOOM_DEBUG_TRACEBACK = "true"
$env:MERSOOM_LOG_BLOCKS = "true"                 # more detailed "why blocked" logs
$env:MERSOOM_TICK_LOG_EVERY_SEC = "30"
$env:MERSOOM_NO_ACTION_LOG_EVERY_SEC = "30"
$env:MERSOOM_HEALTH_LOG_INTERVAL_SEC = "60"

# (Optional) Trace (keep OFF unless needed)
# $env:MERSOOM_TRACE = "1"
# $env:MERSOOM_TRACE_EVENTS_MAX = "200"

$env:MERSOOM_ERROR_LOG = ".\runtime\logs\mersoom_error.log"
$env:MERSOOM_ERROR_LOG_MAX_BYTES = "2097152"     # ~2MB

# (Optional) Arena feature (if persistent 401, set "false")
$env:MERSOOM_ARENA_ENABLE = "true"

# =========================
# Pre-run
# =========================
Remove-Item -Force ".\mersoom.lock" -ErrorAction SilentlyContinue | Out-Null

# First-run friendly: ensure runtime folders exist
$runtimeDirs = @(
  ".\runtime",
  ".\runtime\state",
  ".\runtime\logs",
  ".\runtime\trace",
  ".\runtime\trace\history",
  ".\runtime\snapshots",
  ".\runtime\journal",
  ".\runtime\archive"
)
foreach ($d in $runtimeDirs) {
  New-Item -ItemType Directory -Force $d | Out-Null
}

# =========================
# Self-test (recommended once per release)
# =========================
# py .\mersoom_agent_modular_v7_32.py --selftest

# =========================
# Migrate-only (load -> cleanup -> save, no network)
# =========================
# py .\mersoom_agent_modular_v7_32.py --migrate-only

# =========================
# Run (tee output into runtime/logs)
# =========================
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$logDir = ".\runtime\logs"
$logPath = Join-Path $logDir ("run_{0}.log" -f $ts)
Write-Host "Log: $logPath"

py -u .\mersoom_agent_modular_v7_32.py 2>&1 | Tee-Object -FilePath $logPath
