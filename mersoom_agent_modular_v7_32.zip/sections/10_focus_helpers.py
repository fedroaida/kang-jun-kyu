################################################################################
# 10. FOCUS HELPERS
# Deps: 01-03, 08-09
# Used by: target selection + main loop
# Notes: Focus window/threads prioritization.
################################################################################
"""
SECTION 10 - FOCUS / SUMMARIZATION HELPERS

Utilities for building short focus summaries, excerpts, and context snippets.

Responsibilities:
- Normalize text excerpts.
- Provide small helper functions used in selection/generation.
"""
def _norm_excerpt(s: Any, max_len: int = 220) -> str:
    """Collapse whitespace and truncate for compact focus storage/logs."""
    if s is None:
        return ""
    try:
        t = str(s)
    except Exception:
        return ""
    t = t.replace("\r", " ").replace("\n", " ")
    t = re.sub(r"\s+", " ", t).strip()
    if len(t) > max_len:
        t = t[:max_len].rstrip() + "…"
    return t

def _post_title_guess(post: Dict[str, Any]) -> str:
    if not isinstance(post, dict):
        return ""
    for k in ("title", "subject", "name"):
        v = post.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    # fallback: first part of content
    for k in ("content", "text", "body"):
        v = post.get(k)
        if isinstance(v, str) and v.strip():
            return one_line(v.strip())[:80]
    return ""

def _post_excerpt_guess(post: Dict[str, Any]) -> str:
    if not isinstance(post, dict):
        return ""
    for k in ("content", "text", "body", "content_text", "description"):
        v = post.get(k)
        if v:
            return _norm_excerpt(v, 240)
    return ""

def _comment_excerpt_guess(c: Dict[str, Any]) -> str:
    if not isinstance(c, dict):
        return ""
    for k in ("content", "text", "body"):
        v = c.get(k)
        if v:
            return _norm_excerpt(v, 200)
    return ""

def set_focus(
    state: Dict[str, Any],
    *,
    mode: str,  # "comment" | "reply"
    post_id: str,
    post: Optional[Dict[str, Any]] = None,
    comment: Optional[Dict[str, Any]] = None,
) -> None:
    """Persist the current comment/reply target into state['focus'].

    v15 Unit 02: lock the target *before* text generation so later units can ground on it.
    """
    if mode not in ("comment", "reply"):
        mode = "comment"

    p = post or {}
    c = comment or {}

    focus = _safe_dict(state.get("focus"))
    focus["mode"] = mode
    focus["post_id"] = str(post_id or "")
    focus["post_title"] = _post_title_guess(p)
    focus["post_excerpt"] = _post_excerpt_guess(p)
    focus["comment_id"] = str(c.get("id") or "") if c else ""
    focus["comment_excerpt"] = _comment_excerpt_guess(c) if c else ""
    focus["comment_author"] = str(c.get("nickname") or "") if c else ""
    focus["created_ts"] = float(time.time())

    state["focus"] = focus

    # attach recent QA issue-boost map for scoring/generation (best-effort)
    try:
        qb = _safe_dict(state.get("qa_issue_boost"))
        if qb:
            focus["qa_issue_boost"] = qb
            state["focus"] = focus
    except Exception as e:
        log_debug_exc("set_focus:silent", e)
        pass

    # lightweight observability
    cid = focus.get("comment_id") or ""
    title = one_line(str(focus.get("post_title") or ""))[:60]
    if cid:
        log_action("FOCUS", f"mode={mode} post_id={post_id} comment_id={cid} title={title}")
    else:
        log_action("FOCUS", f"mode={mode} post_id={post_id} title={title}")

def clear_focus(state: Dict[str, Any]) -> None:
    focus = _safe_dict(state.get("focus"))
    focus["mode"] = ""
    focus["post_id"] = ""
    focus["post_title"] = ""
    focus["post_excerpt"] = ""
    focus["comment_id"] = ""
    focus["comment_excerpt"] = ""
    focus["comment_author"] = ""
    focus["created_ts"] = float(time.time())
    state["focus"] = focus

# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
def build_compose_input(
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    th: Dict[str, Any],
    user: Dict[str, Any],
    *,
    is_reply: bool,
    reply_to_own_post: bool = False,
) -> Dict[str, Any]:
    """
    Unify the text-generation inputs into a single bundle.

    Unit 03 goal:
      compose_input = {focus + thread_summary + constraints}

    Notes:
      - For replies, comment_excerpt must be the highest-priority grounding text.
      - We keep this lightweight (no huge bodies) and compute summaries/keywords from excerpts.
    """
    focus = _safe_dict(state.get("focus"))
    mode = str(focus.get("mode") or ("reply" if (is_reply or reply_to_own_post) else "comment"))
    if mode not in ("comment", "reply"):
        mode = "comment"

    post_title = str(focus.get("post_title") or "")
    post_excerpt = str(focus.get("post_excerpt") or "")
    comment_excerpt = str(focus.get("comment_excerpt") or "")
    comment_author = str(focus.get("comment_author") or "")
    thread_summary = str(th.get("summary") or "")

    # Fallback thread summary from last turns (cheap)
    if not thread_summary:
        last_turns = _safe_list(th.get("last_k_turns"))[-6:]
        ctx = " ".join([str(x.get("text") or "") for x in last_turns])
        thread_summary = _simple_summary(ctx, max_len=160) if ctx else ""

    # Grounding target: reply -> comment_excerpt, else post_excerpt -> summary
    target_kind = "thread"
    target_text = ""
    if mode == "reply" and comment_excerpt:
        target_kind = "comment"
        target_text = comment_excerpt
    elif post_excerpt:
        target_kind = "post"
        target_text = post_excerpt
    elif thread_summary:
        target_kind = "thread"
        target_text = thread_summary
    else:
        last_turns = _safe_list(th.get("last_k_turns"))[-4:]
        target_text = " ".join([str(x.get("text") or "") for x in last_turns])

    target_text = one_line(target_text, 260)  # keep it bounded
    target_summary = _simple_summary(target_text, max_len=110) if target_text else ""
    target_keywords = top_keywords(target_text, k=6) if target_text else []
    thread_keywords = _safe_list(th.get("keywords"))[:8]

    # Constraints bundle (kept small; later units can expand)
    constraints = {
        "eum_style": True,
        "logical_professor": True,
        "no_insults": True,
        "no_markdown": True,
        "max_lines": int(getattr(tuning, "max_output_lines", 4) or 4),
        "mode": mode,
    }

    return {
        "has_focus": bool(focus.get("post_id") or focus.get("post_title") or focus.get("post_excerpt")),
        "mode": mode,
        "post_title": post_title,
        "post_excerpt": post_excerpt,
        "comment_excerpt": comment_excerpt,
        "comment_author": comment_author,
        "thread_summary": thread_summary,
        "thread_keywords": thread_keywords,
        "target_kind": target_kind,
        "target_text": target_text,
        "target_summary": target_summary,
        "target_keywords": target_keywords,
        "constraints": constraints,
        "user_nickname": str(_safe_dict(user).get("nickname") or ""),
    }

def build_query_from_compose(th: Dict[str, Any], compose_input: Dict[str, Any]) -> List[str]:
    """
    BM25/thought-recall query builder grounded on compose_input.
    """
    ks = _safe_list(compose_input.get("thread_keywords")) or _safe_list(th.get("keywords"))
    tks = _safe_list(compose_input.get("target_keywords"))
    parts: List[str] = []
    parts.extend([str(x) for x in ks[:10]])
    parts.extend([str(x) for x in tks[:10]])
    parts.append(str(compose_input.get("thread_summary") or ""))
    parts.append(str(compose_input.get("target_text") or ""))
    q = " ".join([p for p in parts if p])
    return tokenize(q, max_tokens=80)

# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
def validate_grounding(text: str, focus: Dict[str, Any], mode: str) -> Tuple[bool, str]:
    """Return (ok, reason). 목적: 중구난방 댓글/대댓글을 자동으로 걸러서 재생성 유도.

    - comment: post_title/post_excerpt 기반 토큰과 최소 1개 이상 겹치면 통과
    - reply: comment_excerpt(우선) 또는 post_excerpt 기반 토큰과 최소 1개 이상 겹치면 통과

    focus 정보가 부족하면(발췌가 비어있음 등) 과도하게 막지 않도록 관대하게 통과시킴.
    """
    t = (text or "").strip()
    if not t:
        return (False, "empty")

    if looks_like_injection(t):
        return (False, "injection")
    if looks_offensive(t):
        return (False, "offensive")
    if contains_markdown(t):
        return (False, "markdown")

    if not isinstance(focus, dict):
        return (True, "no_focus")

    m = str(mode or focus.get("mode") or "comment")
    if m not in ("comment", "reply"):
        m = "comment"

    post_title = str(focus.get("post_title") or "")
    post_excerpt = str(focus.get("post_excerpt") or "")
    comment_excerpt = str(focus.get("comment_excerpt") or "")

    target_text = ""
    if m == "reply":
        target_text = comment_excerpt or post_excerpt or post_title
    else:
        # 댓글은 본문(제목+발췌)에 대한 반응이어야 함
        target_text = (post_title + " " + post_excerpt).strip() or post_excerpt or post_title

    target_text = target_text.strip()
    if not target_text:
        # 발췌가 없으면 억지로 막지 않음
        return (True, "no_target")

    toks_t = set(tokenize(target_text, max_tokens=80))
    toks_o = set(tokenize(t, max_tokens=120))

    if not toks_t or not toks_o:
        return (True, "no_tokens")

    inter = toks_t.intersection(toks_o)
    if len(inter) >= 1:
        return (True, "ok")

    # 최후의 보루: 요지/전제/결론 같은 형식적 표지라도 있으면 한 번은 허용(너무 빡세면 루프가 멎을 수 있음)
    if re.search(r"(요지|전제|핵심|결론|반박|보강|정의)", t):
        # 그래도 완전 무관 텍스트를 막기 위해, 타겟의 상위 키워드 중 1개라도 포함되면 통과
        kws = top_keywords(target_text, k=6)
        lt = sanitize_plain_text(t).lower()
        if any((kw and kw.lower() in lt) for kw in kws[:4]):
            return (True, "weak_ok")

    return (False, "no_overlap")
