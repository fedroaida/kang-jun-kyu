################################################################################
# 02. LOGGING & TIME
# Deps: 01 (Config)
# Used by: all
# Notes: Console-safe logging + KST helpers.
################################################################################
"""
SECTION 02 - LOGGING + TIME HELPERS

Logging primitives, time utilities, and small diagnostics helpers.

Responsibilities:
- Console/file logging that works on Windows (Unicode-safe).
- Timestamp helpers (KST/UTC), small debug utilities.

Notes:
- Keep logging lightweight and non-throwing (logging must never crash the agent).
"""

# -----------------------------------------------------------------------------
# Trace scaffolding (v6.4)
# -----------------------------------------------------------------------------
#
# Purpose:
# - Provide ultra-lightweight runtime instrumentation to answer:
#   "Which stages actually ran in this tick?"
# - Default OFF (no overhead). Enable with: MERSOOM_TRACE=1
#
# Output:
# - When enabled, a best-effort trace file is written on exit:
#     trace_hits.json  (next to the state file, or CWD as fallback)
#
# Design constraints:
# - Must never crash the agent (all functions are best-effort).
# - Must not change behavior when disabled.
#
_TRACE_ENABLED_CACHE = None  # lazy env parse
TRACE_HITS = {}   # tag -> int
TRACE_EVENTS = [] # optional small ring buffer of {tag, ts, data}


def trace_enabled() -> bool:
    """Return True if tracing is enabled via env `MERSOOM_TRACE`."""
    global _TRACE_ENABLED_CACHE
    if _TRACE_ENABLED_CACHE is None:
        try:
            v = str(os.environ.get('MERSOOM_TRACE', '')).strip().lower()
            _TRACE_ENABLED_CACHE = v in ('1', 'true', 'yes', 'y', 'on')
        except Exception:
            _TRACE_ENABLED_CACHE = False
    return bool(_TRACE_ENABLED_CACHE)


def trace_hit(tag: str, inc: int = 1) -> None:
    """Increment a trace counter for `tag` (no-op unless enabled)."""
    if not trace_enabled():
        return
    try:
        t = str(tag or '').strip()
        if not t:
            return
        if len(t) > 120:
            t = t[:120]
        TRACE_HITS[t] = int(TRACE_HITS.get(t, 0) or 0) + int(inc or 1)
    except Exception:
        return


def trace_event(tag: str, data: Any = None) -> None:
    """Append a small trace event (ring-buffered)."""
    if not trace_enabled():
        return
    try:
        t = str(tag or '').strip()
        if not t:
            return
        # ring buffer cap (default 200)
        cap = int(_env_int('MERSOOM_TRACE_EVENTS_MAX', 200, 0, 5000))
        ev = {'tag': (t[:120] if len(t) > 120 else t), 'ts': time.time()}
        if data is not None:
            try:
                ev['data'] = data
            except Exception:
                pass
        TRACE_EVENTS.append(ev)
        if cap >= 0 and len(TRACE_EVENTS) > cap:
            # keep last `cap`
            del TRACE_EVENTS[: max(0, len(TRACE_EVENTS) - cap)]
    except Exception:
        return


def trace_default_path(state_path: str = '') -> str:
    """Best-effort default path for trace output.

    v7.28:
      - Prefer putting trace artifacts under MERSOOM_RUNTIME_DIR/trace for observer convenience.
      - Falls back to the state file directory (or CWD) if runtime dir is unavailable.

    You can override by setting MERSOOM_TRACE_OUT explicitly.
    """ 
    try:
        out_env = os.getenv('MERSOOM_TRACE_OUT')
        if out_env is not None and str(out_env).strip():
            return str(out_env).strip()
        # Prefer runtime/trace
        rd = os.getenv('MERSOOM_RUNTIME_DIR')
        rd = (rd or 'runtime').strip() or 'runtime'
        cand = os.path.join(rd, 'trace', 'trace_hits.json')
        return cand
    except Exception:
        try:
            base = os.path.dirname(str(state_path)) if state_path else os.getcwd()
            if base and not os.path.isdir(base):
                base = os.getcwd()
            return os.path.join(base, 'trace_hits.json')
        except Exception:
            return 'trace_hits.json'


def trace_stage_coverage() -> Dict[str, Any]:
    """Compute a small stage coverage summary from TRACE_HITS.

    Intended for quick sanity checks like:
      - selection happened?
      - generation happened?
      - gate/api/reward/policy updates happened?

    Returns:
      {"stages": {name: count_sum, ...}, "missing": [name, ...]}
    """
    try:
        stages = {
            "boot": 0,
            "tick": 0,
            "select": 0,
            "gen": 0,
            "gate": 0,
            "api": 0,
            "reward": 0,
            "policy": 0,
        }
        for k, v in list(TRACE_HITS.items()):
            try:
                kk = str(k)
                vv = int(v or 0)
            except Exception:
                continue
            if kk == "boot":
                stages["boot"] += vv
            elif kk == "tick":
                stages["tick"] += vv
            elif kk.startswith("select:"):
                stages["select"] += vv
            elif kk.startswith("gen:"):
                stages["gen"] += vv
            elif kk.startswith("gate:"):
                stages["gate"] += vv
            elif kk.startswith("api:"):
                stages["api"] += vv
            elif kk.startswith("reward:"):
                stages["reward"] += vv
            elif kk.startswith("policy:"):
                stages["policy"] += vv

        missing = [name for name, cnt in stages.items() if int(cnt or 0) <= 0 and name not in ("boot", "tick")]
        return {"stages": stages, "missing": missing}
    except Exception:
        return {"stages": {}, "missing": []}


def trace_dump(path: str) -> None:
    """Write trace file (best-effort). Does nothing when disabled."""
    if not trace_enabled():
        return
    try:
        import json
        out_path = str(path or 'trace_hits.json')
        out_dir = os.path.dirname(out_path)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        payload = {
            '__meta__': {
                'ts': time.time(),
                'tick_id': int(_safe_dict(globals().get('state', {})).get('tick_id', 0) or 0) if 'state' in globals() else 0,
            },
            'coverage': trace_stage_coverage(),
            'hits': dict(TRACE_HITS),
            'events': list(TRACE_EVENTS),
        }
        tmp = out_path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(payload, f, ensure_ascii=False, indent=2, sort_keys=True)
        os.replace(tmp, out_path)
        # v7.28: keep a history copy for easier observer workflows (optional)
        if _env_bool('MERSOOM_TRACE_SAVE_HISTORY', True):
            try:
                from datetime import timezone
                ts = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
            except Exception:
                ts = datetime.now().strftime('%Y%m%d_%H%M%S')
            try:
                base_dir = out_dir or os.getcwd()
                hist_dir = os.path.join(base_dir, 'history')
                os.makedirs(hist_dir, exist_ok=True)
                hist_path = os.path.join(hist_dir, f'trace_hits.{ts}.json')
                tmp2 = hist_path + '.tmp'
                with open(tmp2, 'w', encoding='utf-8') as f2:
                    json.dump(payload, f2, ensure_ascii=False, indent=2, sort_keys=True)
                os.replace(tmp2, hist_path)
            except Exception:
                pass
    except Exception:
        return


class Console:

    RESET = "\x1b[0m"
    RED = "\x1b[31m"
    GREEN = "\x1b[32m"
    YELLOW = "\x1b[33m"
    CYAN = "\x1b[36m"
    MAGENTA = "\x1b[35m"
    GRAY = "\x1b[90m"
    enabled = True

    @staticmethod
    def enable_windows_vt() -> None:
        if os.name != "nt":
            return
        try:
            import ctypes  # type: ignore
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.GetStdHandle(-11)
            mode = ctypes.c_uint32()
            if kernel32.GetConsoleMode(handle, ctypes.byref(mode)) == 0:
                return
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
        except Exception as e:
            log_debug_exc("_apply_cli_overrides:silent", e)
            pass

    @staticmethod
    def _safe_console_text(s: str) -> str:
        """Make text safe for printing to the current stdout encoding (e.g., Windows cp949)."""
        try:
            enc = getattr(sys.stdout, "encoding", None) or "utf-8"
            s.encode(enc)
            return s
        except Exception:
            try:
                enc = getattr(sys.stdout, "encoding", None) or "utf-8"
                return s.encode(enc, errors="backslashreplace").decode(enc, errors="ignore")
            except Exception:
                try:
                    return s.encode("utf-8", errors="backslashreplace").decode("utf-8", errors="ignore")
                except Exception:
                    return ""

    @staticmethod
    def cprint(color: str, text: str) -> None:
        """Color print that never raises UnicodeEncodeError."""
        try:
            s = text if isinstance(text, str) else str(text)
            s = Console._safe_console_text(s)
            if Console.enabled:
                print(f"{color}{s}{Console.RESET}")
            else:
                print(s)
        except Exception:
            # Never let logging kill the agent
            try:
                s = (text if isinstance(text, str) else str(text))
                s = s.encode("ascii", errors="backslashreplace").decode("ascii", errors="ignore")
                if Console.enabled:
                    print(f"{color}{s}{Console.RESET}")
                else:
                    print(s)
            except Exception:
                return


def _install_safe_excepthook() -> None:
    """Install a Unicode-safe excepthook so fatal tracebacks won't crash on Windows encodings."""
    try:
        import traceback as _tb
        def _hook(exctype, value, tb):
            try:
                msg = "".join(_tb.format_exception(exctype, value, tb))
            except Exception:
                msg = f"{getattr(exctype, '__name__', 'Exception')}: {value}"
            try:
                enc = getattr(sys.stderr, "encoding", None) or "utf-8"
                sys.stderr.write(msg.encode(enc, errors="backslashreplace").decode(enc, errors="ignore"))
            except Exception:
                try:
                    sys.stderr.write(msg.encode("ascii", errors="backslashreplace").decode("ascii", errors="ignore"))
                except Exception:
                    pass
            try:
                sys.stderr.flush()
            except Exception:
                pass
        sys.excepthook = _hook
    except Exception:
        pass

try:
    if _is_main_process():
        Console.enable_windows_vt()
        _install_safe_excepthook()
except Exception:
    pass
def _run_selftest() -> int:
    """Quick selftest suite (no external deps). Returns process exit code (0 OK, 1 FAIL)."""
    fails: List[str] = []

    # 1) Retry-After parsing
    try:
        h = {"Retry-After": "7"}
        ra = _parse_retry_after_sec(h)
        if ra is None or abs(float(ra) - 7.0) > 0.001:
            fails.append("retry_after_numeric")
    except Exception as e:
        fails.append(f"retry_after_numeric_exc:{type(e).__name__}")

    # 2) SlidingWindowLimiter
    try:
        lim = SlidingWindowLimiter(capacity=2, window_sec=10)
        if not lim.allow():
            fails.append("lim_allow_1")
        if not lim.allow():
            fails.append("lim_allow_2")
        if lim.allow():
            fails.append("lim_allow_over")
    except Exception as e:
        fails.append(f"lim_exc:{type(e).__name__}")

    # 3) Eum ending insertion with punctuation (avoid '?임/!임')
    try:
        s = ensure_eum_style("뭐함?", max_lines=2)
        if "?임" in s or "!임" in s:
            fails.append("eum_punc_insert")
    except Exception as e:
        fails.append(f"eum_exc:{type(e).__name__}")

    # 4) Recent FP memory
    try:
        st: Dict[str, Any] = {}
        remember_fp(st, "abc", for_post=False, ttl_sec=60, keep_max=10)
        if not recently_used_fp(st, "abc", for_post=False, ttl_sec=60, keep_max=10):
            fails.append("fp_recent")
    except Exception as e:
        fails.append(f"fp_exc:{type(e).__name__}")

    # 5) Vote backlog enqueue/pick/gc sanity (v20.2)
    _env_backup = {}
    try:
        _env_backup = {k: os.environ.get(k) for k in [
            "MERSOOM_VOTE_BACKLOG_KEEP_MAX",
            "MERSOOM_VOTE_BACKLOG_MAX",
            "MERSOOM_VOTE_BACKLOG_TTL_SEC",
        ]}
        os.environ["MERSOOM_VOTE_BACKLOG_KEEP_MAX"] = "3"
        os.environ["MERSOOM_VOTE_BACKLOG_MAX"] = "3"
        os.environ["MERSOOM_VOTE_BACKLOG_TTL_SEC"] = "3600"

        st2: Dict[str, Any] = {}
        migrate_state(st2)

        now = time.time()
        vote_backlog_enqueue(st2, "p1", now - 120.0)
        vote_backlog_enqueue(st2, "p2", now - 60.0)
        vote_backlog_enqueue(st2, "p3", now - 30.0)

        vote_backlog_gc(st2, now_ts=now)
        pid = vote_backlog_pick(st2)
        if pid != "p1":
            fails.append("vote_backlog_pick_oldest")

        # mark p1 as voted -> GC should remove + record drain
        posts_map = _voted_posts_map(st2)
        posts_map["p1"] = {"ts": now}
        vote_backlog_gc(st2, now_ts=now)
        pid2 = vote_backlog_pick(st2)
        if pid2 == "p1":
            fails.append("vote_backlog_gc_remove_voted")
        drains = _safe_list(_safe_dict(st2.get("protocol")).get("vote_backlog_drains"))
        if len(drains) <= 0:
            fails.append("vote_backlog_drain_record")

        # cap test: keep_max=1 should retain newest after GC
        os.environ["MERSOOM_VOTE_BACKLOG_KEEP_MAX"] = "1"
        os.environ["MERSOOM_VOTE_BACKLOG_MAX"] = "1"
        vote_backlog_gc(st2, now_ts=now)
        bl = _safe_list(_safe_dict(st2.get("protocol")).get("vote_backlog"))
        if len(bl) != 1:
            fails.append("vote_backlog_cap_len")
    except Exception as e:
        fails.append(f"vote_backlog_exc:{type(e).__name__}")
    finally:
        for k, v in _env_backup.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v

    # 6) Template cooldown penalty sanity (v20.4)
    _env_backup = {}
    try:
        _env_backup = {k: os.environ.get(k) for k in [
            "MERSOOM_TEMPLATE_COOLDOWN_SEC",
            "MERSOOM_TEMPLATE_COOLDOWN_PENALTY",
            "MERSOOM_EXPLORATION_RATE",
        ]}
        os.environ["MERSOOM_TEMPLATE_COOLDOWN_SEC"] = "3600"
        os.environ["MERSOOM_TEMPLATE_COOLDOWN_PENALTY"] = "0.0"
        os.environ["MERSOOM_EXPLORATION_RATE"] = "0.0"

        pol: Dict[str, Any] = {"templates": {"items": {}, "quality": {"min_pick_score": 0}}}
        now = time.time()
        pol["templates"]["items"]["A"] = {
            "text": "A",
            "weight": 1e9,
            "static_score": 80,
            "created_ts": now - 7 * 24 * 3600,
            "last_used_ts": now - 10.0,  # within cooldown
        }
        pol["templates"]["items"]["B"] = {
            "text": "B",
            "weight": 1.0,
            "static_score": 80,
            "created_ts": now - 7 * 24 * 3600,
            "last_used_ts": 0.0,
        }

        random.seed(123)
        tid = pick_template_id(pol)
        if tid != "B":
            fails.append("template_cooldown_penalty")

        # out of cooldown -> A should dominate
        pol["templates"]["items"]["A"]["last_used_ts"] = now - 7200.0
        random.seed(123)
        tid2 = pick_template_id(pol)
        if tid2 != "A":
            fails.append("template_pick_pref")
    except Exception as e:
        fails.append(f"template_cooldown_exc:{type(e).__name__}")
    finally:
        for k, v in _env_backup.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v

    # 7) Near-dup similarity sanity (Jaccard + 3-gram signatures) (v20.4)
    try:
        a = [1, 2, 3]
        b = [1, 2, 3]
        c = [9, 10]
        if _jaccard_ratio(a, b) < 0.99:
            fails.append("jaccard_identical_low")
        if _jaccard_ratio(a, c) > 0.2:
            fails.append("jaccard_disjoint_high")

        g1 = _sig_3grams("이건 테스트 문장임", max_ngrams=128)
        g2 = _sig_3grams("이건 테스트 문장임", max_ngrams=128)
        g3 = _sig_3grams("완전히 다른 내용임", max_ngrams=128)
        if g1 and g2 and _jaccard_ratio(g1, g2) < 0.9:
            fails.append("3gram_identical_low")
        if g1 and g3 and _jaccard_ratio(g1, g3) > 0.7:
            fails.append("3gram_different_high")
    except Exception as e:
        fails.append(f"dup_sim_exc:{type(e).__name__}")

    # 8) Reward finiteness/clip sanity (v20.5)
    try:
        tng = load_tuning_from_env()
        before = {"up": 0, "down": 0, "comments": 0, "score": 0}
        after = {"up": 10**9, "down": 10**9, "comments": 10**9, "score": -10**9}
        r, _feats = compute_reward(tng, before, after, {"action": "post", "action_type": "post_main", "reply_received": 1e9})
        if not math.isfinite(float(r)):
            fails.append("reward_not_finite")
        clip = float(getattr(tng, "reward_clip", 3.0) or 3.0)
        if abs(float(r)) > (clip + 1e-6):
            fails.append("reward_not_clipped")
    except Exception as e:
        fails.append(f"reward_exc:{type(e).__name__}")

    # 9) strip_none (recursive)
    try:
        d = {"a": 1, "b": None, "c": {"d": None, "e": 2}, "f": [1, None, {"g": None, "h": 3}]}
        s = strip_none(d)
        if "b" in s or ("c" in s and "d" in (s.get("c") or {})):
            fails.append("strip_none_failed")
        if isinstance(s.get("f"), list) and any(x is None for x in s["f"]):
            fails.append("strip_none_list_failed")
    except Exception as e:
        fails.append(f"strip_none_exc:{type(e).__name__}")

    # 10) final gate smoke tests
    try:
        cfg = load_config_from_env()
        st = {"focus": {"post_excerpt": "테스트", "post_title": "테스트", "post_id": "x"}}
        ok, _b, _d, _r, _q = final_text_gate(cfg, st, "테스트 댓글임", mode="comment", kind="comment", focus=_safe_dict(st.get("focus")), same_text_gap_sec=1)
        if not isinstance(ok, bool):
            fails.append("final_text_gate_ret")
        ok2, _b2, _d2, _r2, _q2 = final_text_gate(cfg, st, "", mode="comment", kind="comment", focus=_safe_dict(st.get("focus")), same_text_gap_sec=1)
        if bool(ok2):
            fails.append("final_text_gate_empty_ok")
        okp, _bp, _dp, _qp = final_post_gate(cfg, st, "제목", "본문", "제목\n본문", same_text_gap_sec=1)
        if not isinstance(okp, bool):
            fails.append("final_post_gate_ret")
    except Exception as e:
        fails.append(f"final_gate_exc:{type(e).__name__}")

    # 11) Unit2 quote extraction/injection sanity (v5.2)
    try:
        q = extract_short_quote("이 부분은 근거가 필요함. 그런데 결론은 타당함임", min_len=6, max_len=16)
        if q and not (6 <= len(q) <= 16):
            fails.append("quote_len")
        stq: Dict[str, Any] = {}
        cfgq = load_config_from_env()
        out = apply_quote_layer(cfgq, stq, "@user 테스트임", mode="reply", target_text="근거가 필요함")
        if out and ("“" not in out or "”" not in out):
            fails.append("quote_inject_missing_marks")
    except Exception as e:
        fails.append(f"quote_exc:{type(e).__name__}")

    # 12) Unit3 micro-editor sanity (v5.3)
    try:
        stm: Dict[str, Any] = {}
        cfgm = load_config_from_env()
        s1 = apply_microedit_layer(cfgm, stm, "전문성를 어디에 두느냐가 갈림임.", mode="comment")
        if "전문성을" not in s1 and "전문성를" in s1:
            fails.append("microedit_particle_obj")
        s2 = apply_microedit_layer(cfgm, stm, "결론은 타당함임. 임. 근데 근거가 필요함임.", mode="comment")
        if "임. 임" in s2 or re.search(r"임\s+임", s2):
            fails.append("microedit_im_repeat")
        s3 = apply_microedit_layer(cfgm, stm, "근데 테스트임. 근데 테스트임.", mode="comment")
        # should not crash; should likely dedup
        if s3.count("테스트임") > 2:
            fails.append("microedit_dedup")
    except Exception as e:
        fails.append(f"microedit_exc:{type(e).__name__}")


    # Unit4 LM reranker sanity
    try:
        _env_backup = {k: os.environ.get(k) for k in [
            "MERSOOM_LM_MIN_ENTRIES",
            "MERSOOM_LM_SCORE_MAX_CHARS",
        ]}
        try:
            os.environ["MERSOOM_LM_MIN_ENTRIES"] = "200"
            os.environ["MERSOOM_LM_SCORE_MAX_CHARS"] = "200"
            sem_lm: Dict[str, Any] = {}
            # build a high-entropy training string so LM becomes "ready"
            # even with the built-in lower bound(min=200) for MERSOOM_LM_MIN_ENTRIES
            sample = "".join(chr(0xAC00 + i) for i in range(650))
            for _ in range(2):
                lm_update_from_text(cfgm, sem_lm, "human", sample)

            sc = lm_score_text(sem_lm, "근데 이건 테스트임.")
            if sc is None or (not math.isfinite(float(sc))):
                fails.append("unit4_lm_score")

            cands = lm_make_ranked_candidates(
                cfgm, stm, sem_lm,
                "근데 <NAME> 의견은 그럴 수 있음. 다만 근거는 더 필요함.",
                mode="reply",
                target_nick="홍길동",
                target_text="난 이게 좋다라고 봄. 근데 근거는 아직 애매함.",
                k=4,
            )
            if not cands:
                fails.append("unit4_lm_candidates")

            st_lm: Dict[str, Any] = {"dlg": {"greet_hist": {}}, "protocol": {}}
            _lm_apply_accept_side_effects(
                st_lm,
                {"greet_used": True, "quote_used": True, "name_placeholder_hit": True, "microedit_changed": 3},
                target_nick="홍길동",
            )
            if "홍길동" not in _safe_dict(st_lm.get("dlg")).get("greet_hist", {}):
                fails.append("unit4_lm_greet_hist")
        finally:
            for k, v in _env_backup.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v
    except Exception as e:
        fails.append(f"unit4_lm_exc:{type(e).__name__}")


    # 13) Generation characterization + trace tags (v6.8)
    # 목적: 생성기(build_reply_text/build_post_text)가 최소 입력에서도
    # - 빈 문자열을 내지 않고
    # - 최종 게이트를 통과하며
    # - trace(hit) 태그가 정상 기록되는지
    # 를 빠르게 확인.
    _env_backup2 = {}
    try:
        _env_backup2 = {k: os.environ.get(k) for k in ["MERSOOM_TRACE"]}
        os.environ["MERSOOM_TRACE"] = "1"
        # trace_enabled()는 env 캐시를 쓰므로 env 변경 후 캐시 리셋
        try:
            globals()["_TRACE_ENABLED_CACHE"] = None
        except Exception:
            pass
        try:
            TRACE_HITS.clear()
            TRACE_EVENTS.clear()
        except Exception:
            pass

        cfg_g = load_config_from_env()
        tng_g = load_tuning_from_env()
        pol_g = default_policy(tng_g)
        try:
            bootstrap_templates(pol_g)
        except Exception:
            pass

        st_g: Dict[str, Any] = {}
        migrate_state(st_g)
        br_g = load_brain("")

        th_g: Dict[str, Any] = {
            "id": "t_test_1",
            "post_id": "p_test_1",
            "category": "philo",
            "title": "사형 제도 존치 논쟁임",
            "summary": "사형 제도가 정의 구현인지 국가 폭력인지에 대한 논쟁임",
            "keywords": ["사형", "정의", "국가폭력"],
            "last_k_turns": [
                {"text": "사형은 억울함 해소냐 국가적 살인이냐가 쟁점임"},
                {"text": "반례/기준/정의 중 뭘 먼저 고정하냐가 핵심임"},
            ],
        }
        user_g: Dict[str, Any] = {"nickname": "홍길동", "aggression": 0.25, "helpfulness": 0.55}
        st_g["focus"] = {
            "mode": "reply",
            "post_id": "p_test_1",
            "post_title": th_g["title"],
            "post_excerpt": "사형은 정의 실현이라는 주장과 국가폭력이라는 반론이 공존함",
            "comment_excerpt": "흉악범도 인권이 있으니 사형은 국가적 살인임",
            "comment_author": "상대",
        }

        random.seed(123)
        txt, meta = build_reply_text(
            cfg_g, tng_g, st_g, pol_g, th_g, user_g,
            bm25=None,
            brain=br_g,
            reply_to_own_post=False,
            is_reply=True,
        )
        if not isinstance(txt, str) or not txt.strip():
            fails.append("gen_reply_empty")
        if isinstance(txt, str) and ("```" in txt or "<script" in txt.lower()):
            fails.append("gen_reply_injection")
        if not isinstance(meta, dict) or ("strategy" not in meta) or ("tone" not in meta):
            fails.append("gen_reply_meta")
        ok, _b, _d, _gr, _q = final_text_gate(
            cfg_g, st_g, txt,
            mode="reply",
            kind="reply",
            focus=_safe_dict(st_g.get("focus")),
            same_text_gap_sec=1,
        )
        if not bool(ok):
            fails.append("gen_reply_gate")

        # Post generator(title/body) - minimal semantic seed
        sem_g: Dict[str, Any] = {"hot": [{"kw": "사형"}], "rising": [{"kw": "정의"}]}
        random.seed(123)
        title, body, pmeta = build_post_text(cfg_g, tng_g, st_g, pol_g, sem_g, br_g, bm25=None)
        if not isinstance(title, str) or not title.strip() or not isinstance(body, str) or not body.strip():
            fails.append("gen_post_empty")
        if not isinstance(pmeta, dict) or ("post_style" not in pmeta):
            fails.append("gen_post_meta")
        okp, _bp, _dp, _qp = final_post_gate(cfg_g, st_g, title, body, f"{title}\n{body}", same_text_gap_sec=1)
        if not bool(okp):
            fails.append("gen_post_gate")

        # Trace tags sanity
        if int(TRACE_HITS.get("gen:reply:enter", 0) or 0) <= 0:
            fails.append("trace_gen_reply")
        if int(TRACE_HITS.get("gen:post:enter", 0) or 0) <= 0:
            fails.append("trace_gen_post")
        if int(TRACE_HITS.get("gate:text:enter", 0) or 0) <= 0:
            fails.append("trace_gate_text")
        if int(TRACE_HITS.get("gate:post:enter", 0) or 0) <= 0:
            fails.append("trace_gate_post")
    except Exception as e:
        fails.append(f"gen_char_exc:{type(e).__name__}")
    finally:
        for k, v in _env_backup2.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        try:
            globals()["_TRACE_ENABLED_CACHE"] = None
        except Exception:
            pass

    if fails:
        log_error("selftest", "FAIL: " + ", ".join(fails))
        return 1
    log_info("selftest: OK")
    return 0


def now_kst() -> datetime:
    """KST-aware 'now'.

    Note: In DEBUG mode we emit timezone info once, but we must not call log_debug()
    here because log_debug() formats timestamps via now_kst_str() -> now_kst(),
    which can recurse and spam logs. We print directly with datetime.now(KST).
    """
    global _TZ_LOGGED
    if not _TZ_LOGGED:
        if _is_main_process():
            try:
                if DEBUG_MODE:
                    ts = datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S")
                    Console.cprint(
                        Console.GRAY,
                        f"[DBG ] {ts} | timezone={TZ_NAME} fallback={int(bool(TZ_FALLBACK_USED))}",
                    )
            except Exception:
                pass
        _TZ_LOGGED = True
    return datetime.now(KST)


def now_kst_str() -> str:
    return now_kst().strftime("%Y-%m-%d %H:%M:%S")

def _today_kst() -> str:
    return now_kst().strftime("%Y-%m-%d")

def one_line(text: Any, max_len: int = 140) -> str:
    t = re.sub(r"\s+", " ", str(text or "")).strip()
    if len(t) > max_len:
        t = t[:max_len].rstrip() + "…"
    return t


# -----------------------------------------------------------------------------
# ERROR-ONLY LOG FILE (final4_1)
# -----------------------------------------------------------------------------
# Writes only [ERROR] lines to a separate file for quick inspection.
# - Set MERSOOM_ERROR_LOG="" (empty) or "none" to disable.
# - Optional: MERSOOM_ERROR_LOG_MAX_BYTES (default 5MB) for simple rotation.
# -----------------------------------------------------------------------------
# ERROR-ONLY LOG FILE
# -----------------------------------------------------------------------------
# Writes only [ERROR] lines to a separate file for quick inspection.
# - Set MERSOOM_ERROR_LOG="" (empty) or "none" to disable.
# - Optional: MERSOOM_ERROR_LOG_MAX_BYTES (default 5MB) for simple rotation.
#
# v7.28: default location moved under MERSOOM_RUNTIME_DIR (./runtime/logs).

def _runtime_dir_default() -> str:
    try:
        rd = os.getenv("MERSOOM_RUNTIME_DIR")
        rd = (rd or "runtime").strip()
        return rd or "runtime"
    except Exception:
        return "runtime"


def _default_error_log_path() -> str:
    try:
        return os.path.join(_runtime_dir_default(), "logs", "mersoom_error.log")
    except Exception:
        return "./mersoom_error.log"


_env_err = os.getenv("MERSOOM_ERROR_LOG")
_ERROR_LOG_PATH = _default_error_log_path() if _env_err is None else str(_env_err)

try:
    _ERROR_LOG_MAX_BYTES = int(os.getenv("MERSOOM_ERROR_LOG_MAX_BYTES", "5242880"))
except Exception:
    _ERROR_LOG_MAX_BYTES = 5242880

# v7.28: structured event log (JSONL) for observer workflows
def _default_event_log_path() -> str:
    try:
        return os.path.join(_runtime_dir_default(), "logs", "events.jsonl")
    except Exception:
        return "./events.jsonl"

_env_evt = os.getenv("MERSOOM_EVENT_LOG")
_EVENT_LOG_PATH = _default_event_log_path() if _env_evt is None else str(_env_evt)
try:
    _EVENT_LOG_MAX_BYTES = int(os.getenv("MERSOOM_EVENT_LOG_MAX_BYTES", "26214400"))
except Exception:
    _EVENT_LOG_MAX_BYTES = 26214400

def _append_event_log_line(obj: dict) -> None:
    try:
        p = _EVENT_LOG_PATH
        if not p or str(p).strip().lower() in ("none", "off", "0"):
            return
        # rotate by size
        try:
            _rotate_error_log_if_needed(p, _EVENT_LOG_MAX_BYTES)
        except Exception:
            pass
        d = os.path.dirname(p)
        if d:
            os.makedirs(d, exist_ok=True)
        line = json.dumps(obj, ensure_ascii=False)
        with open(p, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        return


def _rotate_error_log_if_needed(path: str, max_bytes: int) -> None:
    try:
        if not path or str(path).strip().lower() in ("none", "off", "0"):
            return
        if max_bytes <= 0:
            return
        if os.path.exists(path) and os.path.getsize(path) > max_bytes:
            try:
                from datetime import timezone
                ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            except Exception:
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            rotated = f"{path}.old.{ts}"
            try:
                os.replace(path, rotated)
            except Exception:
                # If replace fails (e.g., permission), just truncate by recreating.
                with open(path, "w", encoding="utf-8") as _f:
                    _f.write("")
    except Exception:
        return


def _append_error_log_line(line: str) -> None:
    try:
        p = _ERROR_LOG_PATH
        if not p or str(p).strip().lower() in ("none", "off", "0"):
            return
        try:
            d = os.path.dirname(os.path.abspath(p))
            if d:
                os.makedirs(d, exist_ok=True)
        except Exception:
            pass
        _rotate_error_log_if_needed(p, _ERROR_LOG_MAX_BYTES)
        with open(p, "a", encoding="utf-8") as f:
            f.write(line.rstrip("\n") + "\n")
    except Exception:
        return

def log_info(msg: str) -> None:
    Console.cprint(Console.GRAY, f"[INFO] {now_kst_str()} | {msg}")

def log_warn(msg: str) -> None:
    Console.cprint(Console.YELLOW, f"[WARN] {now_kst_str()} | {msg}")

def log_event(name: str, **fields: Any) -> None:
    """Emit a single-line, grep-friendly event log.

    Format: [EVT] <KST timestamp> | <event_name> | <compact json>
    - Never raises.
    """
    try:
        # Normalize fields to keep output stable and one-line.
        norm: Dict[str, Any] = {}
        for k, v in (fields or {}).items():
            kk = str(k)
            # Keep simple scalars; stringify the rest (but keep dict/list where possible).
            if v is None or isinstance(v, (str, int, float, bool)):
                norm[kk] = v
            elif isinstance(v, (list, dict)):
                norm[kk] = v
            else:
                norm[kk] = one_line(v, 220)
        payload = json.dumps(norm, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        ts = now_kst_str()
        Console.cprint(Console.CYAN, f"[EVT] {ts} | {str(name)} | {payload}")
        try:
            _append_event_log_line({"ts_kst": ts, "event": str(name), **norm})
        except Exception:
            pass
    except Exception:
        return


def log_error(where: str, err: str) -> None:
    line = f"[ERROR] {now_kst_str()} | {where} :: {err}"
    Console.cprint(Console.RED, line)
    _append_error_log_line(line)

# -----------------------------------------------------------------------------
# Exception logging helpers (final5)
# -----------------------------------------------------------------------------
_EXC_THROTTLE_SEC = 20.0
_EXC_LAST_TS: Dict[str, float] = {}
_EXC_SUPPRESSED: Dict[str, int] = {}

def _should_failfast(stage: str) -> bool:
    try:
        return str(stage) in FAILFAST_STAGES
    except Exception:
        return False

def log_exception(where: str, e: BaseException, context: Optional[Dict[str, Any]] = None) -> None:
    """Log an exception with traceback into the error log file (console stays concise).

    - Console: 1-line error (same style as log_error)
    - Error log file: summary + optional context + traceback (limited lines)
    - Throttles identical exceptions to avoid log spam.
    """
    try:
        # Signature for throttling (stable, short)
        msg = one_line(str(e), 220)
        sig = f"{where}|{type(e).__name__}|{msg}"
        now = time.time()
        last = float(_EXC_LAST_TS.get(sig, 0.0) or 0.0)
        if (now - last) < _EXC_THROTTLE_SEC:
            _EXC_SUPPRESSED[sig] = int(_EXC_SUPPRESSED.get(sig, 0) or 0) + 1
            # Keep console quiet unless explicitly asked
            if DEBUG_TRACEBACK and DEBUG_MODE:
                Console.cprint(Console.RED, f"[ERROR] {now_kst_str()} | {where} :: {type(e).__name__}: {msg} (suppressed)")
            return

        _EXC_LAST_TS[sig] = now
        sup = int(_EXC_SUPPRESSED.pop(sig, 0) or 0)

        # Console (short)
        line = f"[ERROR] {now_kst_str()} | {where} :: {type(e).__name__}: {msg}"
        Console.cprint(Console.RED, line)

        # File (detailed)
        _append_error_log_line(line)
        if sup > 0:
            _append_error_log_line(f"[ERROR] {now_kst_str()} | {where} :: (suppressed {sup} repeats in <{int(_EXC_THROTTLE_SEC)}s)")
        if context:
            try:
                payload = json.dumps(context, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
            except Exception:
                payload = one_line(repr(context), 400)
            _append_error_log_line(f"[CTX ] {now_kst_str()} | {where} :: {payload}")

        try:
            import traceback as _tb
            tb = _tb.format_exception(type(e), e, e.__traceback__)
            tb_lines = "".join(tb).splitlines()
            # keep last N lines (root cause often near bottom)
            keep = tb_lines[-80:] if len(tb_lines) > 80 else tb_lines
            for ln in keep:
                _append_error_log_line(f"[TB  ] {ln}")
            if DEBUG_TRACEBACK and DEBUG_MODE:
                # print a small tail to console for quick view
                tail = keep[-12:] if len(keep) > 12 else keep
                for ln in tail:
                    Console.cprint(Console.GRAY, f"[TB  ] {one_line(ln, 240)}")
        except Exception:
            pass
    except Exception:
        # Absolute last resort: never recurse.
        try:
            log_error("log_exception", f"failed: {where}:{type(e).__name__}")
        except Exception:
            return



def log_debug(msg: Any) -> None:
    """Debug log (printed only when DEBUG_MODE is enabled).

    - Accepts either a string, or a zero-arg callable returning a string (lazy formatting).
    """
    try:
        if not DEBUG_MODE:
            return
        if callable(msg):
            try:
                msg = msg()
            except Exception as e:
                msg = f"<log_debug thunk failed: {type(e).__name__}>"
        Console.cprint(Console.GRAY, f"[DBG ] {now_kst_str()} | {msg}")
    except Exception:
        pass


def log_debug_exc(where: str, e: BaseException) -> None:
    """Emit exception details only when DEBUG_MODE is enabled (to avoid spam).

    Important: this function must never recurse on failure.
    """
    try:
        if DEBUG_MODE:
            log_warn(f"{where}: {type(e).__name__}: {one_line(str(e), 220)}")
    except Exception:
        # Absolute last-resort: never recurse; avoid any complex formatting.
        try:
            if DEBUG_MODE:
                import sys as _sys
                _sys.stderr.write("[WARN] log_debug_exc failed while logging an exception\n")
        except Exception:
            pass

def log_action(tag: str, msg: str) -> None:
    Console.cprint(Console.GREEN, f"[{tag}] {now_kst_str()} | {msg}")

def log_sleep(sec: float, why: str = "") -> None:
    extra = f" {why}" if why else ""
    Console.cprint(Console.YELLOW, f"[SLEEP] {int(sec)}s{extra}")

def sleep_chunked(
    total_sec: float,
    *,
    hard_cap_sec: int,
    why: str = "",
    wake_deadline_wall_ts: Optional[float] = None,
) -> bool:
    """Sleep for up to total_sec seconds, but never past wake_deadline_wall_ts (epoch seconds).

    Returns True if a deadline caused an early wake-up.
    """
    remaining = max(0.0, float(total_sec))
    if remaining <= 0:
        return False

    interrupted = False

    # keep logs roughly consistent even when a deadline truncates the actual sleep
    if wake_deadline_wall_ts is not None:
        until_deadline = float(wake_deadline_wall_ts) - time.time()
        if until_deadline <= 0:
            return True
        remaining = min(remaining, max(0.0, until_deadline))

    log_sleep(remaining, why)

    while remaining > 0:
        chunk = min(remaining, float(hard_cap_sec))

        if wake_deadline_wall_ts is not None:
            until_deadline = float(wake_deadline_wall_ts) - time.time()
            if until_deadline <= 0:
                interrupted = True
                break
            chunk = min(chunk, until_deadline)

        if chunk <= 0:
            interrupted = True
            break

        time.sleep(chunk)
        remaining -= chunk

    return interrupted

def human_delay(min_sec: float, max_sec: float) -> None:
    if max_sec <= 0:
        return
    lo = max(0.0, float(min_sec))
    hi = max(lo, float(max_sec))
    time.sleep(random.uniform(lo, hi))

def next_top_of_hour_kst(dt: Optional[datetime] = None) -> datetime:
    t = dt or now_kst()
    return t.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)

def run_snapshot_script(script_path: str, timeout_sec: int) -> Tuple[int, str]:
    """Run a snapshot script and return (exit_code, combined_output)."""
    try:
        res = subprocess.run(
            [sys.executable, script_path],
            cwd=os.path.dirname(os.path.abspath(script_path)) or None,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=max(5, int(timeout_sec)),
            check=False,
        )
        out = res.stdout or ""
        return int(res.returncode), out
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or "") + "\n[TIMEOUT]"
        return 124, out
