################################################################################
# 07. POW CHALLENGE
# Deps: 01-06
# Used by: HttpClient post_with_pow()
# Notes: Challenge parsing + PoW executor routing.
################################################################################
"""
SECTION 07 - PoW CHALLENGE HANDLER

Handles Proof-of-Work (PoW) challenges required by the Mersoom API.

Responsibilities:
- Detect when PoW is required and solve it (sync/process/off modes).
- Manage timeouts and fallback behavior.
- Keep PoW logic isolated from higher-level flows (post/comment/arena).

Debug tips:
- If actions fail with 401/403-like behavior after PoW changes, inspect this section first.
"""
@dataclass(frozen=True)
class Challenge:
    token: str
    seed: str
    target_prefix: str
    limit_ms: int
    kind: str = "pow"   # "pow" | "puzzle"
    proof: str = ""     # for puzzle: solution; for pow: unused
    challenge_id: str = ""

def _prefix_match_digest(digest: bytes, prefix_hex: str) -> bool:
    """prefix_hex can be odd length (nibble match)."""
    p = (prefix_hex or "").lower().strip()
    if not p:
        return False

    odd = (len(p) % 2 == 1)
    full = p[:-1] if odd else p
    pref_bytes = bytes.fromhex(full) if full else b""

    if digest[:len(pref_bytes)] != pref_bytes:
        return False

    if odd:
        nib = int(p[-1], 16)
        if len(digest) <= len(pref_bytes):
            return False
        return (digest[len(pref_bytes)] >> 4) == nib

    return True

def parse_challenge(payload: Any) -> Challenge:
    if not isinstance(payload, dict):
        raise ValueError("challenge payload must be dict")

    token = str(payload.get("token") or payload.get("challenge_id") or "").strip()
    ch = payload.get("challenge") if isinstance(payload.get("challenge"), dict) else None

    if ch:
        seed = str(ch.get("seed") or "").strip()
        target = str(ch.get("target_prefix") or "").strip()
        limit_ms = int(ch.get("limit_ms") or 2000)
        token = token or str(payload.get("token") or "").strip()
    else:
        seed = str(payload.get("seed") or "").strip()
        target = str(payload.get("target_prefix") or "").strip()
        limit_ms = int(payload.get("limit_ms") or 2000)

    if not token or not seed or not target:
        raise ValueError("invalid challenge payload: missing token/seed/target_prefix")

    limit_ms = max(200, min(60_000, int(limit_ms)))

    # NOTE(final3): this function must return a Challenge. A missing return here
    # makes callers receive None and crash at `ch.seed` / `ch.target_prefix`.
    return Challenge(
        token=str(token),
        seed=str(seed),
        target_prefix=str(target),
        limit_ms=int(limit_ms),
        kind=str(payload.get("kind") or "pow"),
        proof="",
        challenge_id=str(payload.get("challenge_id") or token or ""),
    )

def _challenge_type(payload: Any) -> str:
    """Best-effort challenge type probe for hybrid challenge systems."""
    try:
        if not isinstance(payload, dict):
            return ""
        ch = payload.get("challenge") if isinstance(payload.get("challenge"), dict) else None
        t = ""
        if isinstance(ch, dict):
            t = ch.get("type") or payload.get("type") or ""
        else:
            t = payload.get("type") or ""
        return str(t).strip().lower()
    except Exception:
        return ""

def _safe_json_preview(obj: Any, max_chars: int) -> str:
    try:
        s = json.dumps(obj, ensure_ascii=False)
    except Exception:
        s = repr(obj)
    s = s.replace("\r", "\\r").replace("\n", "\\n")
    if max_chars > 0 and len(s) > max_chars:
        return s[:max_chars] + "...(trunc)"
    return s

def _redact_challenge_payload_for_log(payload: Any) -> Any:
    """Redact secrets (token) and shrink noisy fields for puzzle capture logs."""
    if not isinstance(payload, dict):
        return payload
    p = dict(payload)
    if "token" in p:
        p["token"] = "<redacted>"
    ch = p.get("challenge")
    if isinstance(ch, dict):
        ch2 = dict(ch)
        # seed can be logged as a short hash to avoid leaking ephemeral values
        seed = ch2.get("seed")
        if isinstance(seed, str) and seed:
            try:
                ch2["seed_sha16"] = hashlib.sha256(seed.encode("utf-8")).hexdigest()[:16]
            except Exception as e:
                log_debug_exc("_redact_challenge_payload_for_log:silent", e)
                pass
            ch2["seed"] = "<redacted>"
        p["challenge"] = ch2
    return p


def _puzzle_fieldset_key(keys: List[str], *, max_keys: int = 32) -> str:
    """Stable key for grouping puzzle payload shapes. Keep short to avoid state bloat."""
    try:
        ks = [str(k) for k in (keys or []) if k is not None]
        ks = sorted(set(ks))
        if len(ks) > max_keys:
            ks = ks[:max_keys]
        return "|".join(ks)
    except Exception:
        return ""


def note_puzzle_event(state: Optional[Dict[str, Any]], *, ts_kst: str, challenge_type: str, fieldset_key: str) -> None:
    """Update lightweight in-state puzzle stats for solver planning (v19.9)."""
    try:
        if not isinstance(state, dict):
            return
        ps = state.setdefault("puzzles", {})
        # counters
        ps["puzzle_count"] = int(ps.get("puzzle_count", 0) or 0) + 1
        tc = ps.setdefault("type_counts", {})
        tc[challenge_type] = int(tc.get(challenge_type, 0) or 0) + 1
        fc = ps.setdefault("fieldset_counts", {})
        if fieldset_key:
            fc[fieldset_key] = int(fc.get(fieldset_key, 0) or 0) + 1

        ps["last_seen_at"] = ts_kst
        ps["last_seen_type"] = challenge_type

        # prune fieldset buckets to cap state growth
        max_buckets = 240
        if isinstance(fc, dict) and len(fc) > max_buckets:
            # drop smallest counts first
            items = sorted(fc.items(), key=lambda kv: (int(kv[1] or 0), kv[0]))
            drop_n = max(0, len(items) - max_buckets)
            for k, _ in items[:drop_n]:
                fc.pop(k, None)
    except Exception:
        return


def record_unhandled_challenge(
    hcfg: HybridChallengeConfig,
    payload: Any,
    *,
    reason: str,
    parse_error: str = "",
    attempt: int,
    max_attempts: int,
    state: Optional[Dict[str, Any]] = None,
    context: str = ""
) -> None:
    """Append unhandled /challenge payload to JSONL and update puzzle stats (v19.9)."""
    try:
        if not hcfg or not str(hcfg.puzzle_log_jsonl or "").strip():
            return
        now_iso = now_kst().isoformat()
        ctype = _challenge_type(payload) or "unknown"
        ch = payload.get("challenge") if isinstance(payload, dict) else None
        chd = ch if isinstance(ch, dict) else {}

        # best-effort prompt extraction (keep short)
        prompt = ""
        for k in ("prompt", "puzzle", "question", "instruction", "task", "text", "content"):
            v = chd.get(k)
            if isinstance(v, str) and v.strip():
                prompt = v.strip()
                break
        if not prompt:
            # fallback: any string field
            for v in chd.values():
                if isinstance(v, str) and v.strip():
                    if len(v.strip()) > len(prompt):
                        prompt = v.strip()
        if prompt and len(prompt) > 2000:
            prompt = prompt[:2000] + "...(trunc)"

        # safe metadata (avoid storing seed/token directly)
        challenge_id = ""
        try:
            cid = chd.get("challenge_id") or chd.get("id") or ""
            if cid:
                challenge_id = one_line(str(cid), 128)
        except Exception:
            challenge_id = ""
        seed_hash16 = ""
        try:
            seed = chd.get("seed")
            if isinstance(seed, str) and seed:
                seed_hash16 = hashlib.sha256(seed.encode("utf-8")).hexdigest()[:16]
        except Exception:
            seed_hash16 = ""

        red = _redact_challenge_payload_for_log(payload)
        preview = _safe_json_preview(red, int(hcfg.puzzle_raw_max_chars or 0))
        keys = sorted(list(chd.keys()))[:80]
        fieldset_key = _puzzle_fieldset_key(keys)

        evt = {
            "schema": "mersoom_puzzle_event_v1",
            "ts_kst": now_iso,
            "context": one_line(str(context or ""), 120),
            "challenge_type": ctype,
            "challenge_id": challenge_id,
            "seed_hash16": seed_hash16,
            "expires_at": chd.get("expires_at"),
            "limit_ms": chd.get("limit_ms"),
            "target_prefix": chd.get("target_prefix"),
            "attempt": int(attempt),
            "max_attempts": int(max_attempts),
            "reason": one_line(str(reason), 220),
            "parse_error": one_line(str(parse_error), 220),
            "prompt": prompt,
            "prompt_len": int(len(prompt) if isinstance(prompt, str) else 0),
            "fields_present": keys,
            "fieldset_key": fieldset_key,
            "payload_preview": preview,
        }
        append_jsonl(str(hcfg.puzzle_log_jsonl), evt)

        # update in-state puzzle stats for planning
        note_puzzle_event(state, ts_kst=now_iso, challenge_type=ctype, fieldset_key=fieldset_key)
    except Exception as e:
        log_debug_exc("record_unhandled_challenge:silent", e)
        pass



# --- v19.10: puzzle solver v1 (extract-type) ---------------------------------

_PUZZLE_CHAR_KEYWORDS = (
    "알파", "알파벳", "글자", "문자", "letter", "letters", "character", "characters", "alphabet"
)

def _extract_puzzle_prompt(payload: Any) -> Tuple[str, Dict[str, Any]]:
    """Best-effort: extract puzzle prompt/instruction text."""
    if not isinstance(payload, dict):
        return "", {}
    chd = payload.get("challenge") if isinstance(payload.get("challenge"), dict) else {}
    prompt = ""
    for k in ("prompt", "puzzle", "question", "instruction", "task", "text", "content"):
        v = chd.get(k)
        if isinstance(v, str) and v.strip():
            prompt = v.strip()
            break
    if not prompt:
        # fallback: pick the longest string field
        try:
            for v in chd.values():
                if isinstance(v, str) and v.strip():
                    vv = v.strip()
                    if len(vv) > len(prompt):
                        prompt = vv
        except Exception as e:
            log_debug_exc("_extract_puzzle_prompt:silent", e)
            pass
    return prompt, (chd if isinstance(chd, dict) else {})

def _extract_word_list_from_payload(chd: Dict[str, Any]) -> List[str]:
    """Try to locate explicit word list fields in the challenge payload."""
    cand_keys = ("words", "word_list", "items", "options", "candidates", "list")
    for k in cand_keys:
        v = chd.get(k)
        if isinstance(v, list) and v and all(isinstance(x, str) for x in v):
            out = [one_line(str(x), 60).strip() for x in v if isinstance(x, str) and str(x).strip()]
            out = [x for x in out if x]
            if len(out) >= 3:
                return out
    return []

def _extract_word_list_from_prompt(prompt: str) -> List[str]:
    """Heuristic extraction from the prompt (supports newline lists or comma lists)."""
    if not isinstance(prompt, str) or not prompt.strip():
        return []

    lines = [ln.strip() for ln in prompt.splitlines() if ln.strip()]
    # 1) newline list (possibly numbered/bulleted)
    out: List[str] = []
    for ln in lines:
        # remove common bullets/numbering
        ln2 = re.sub(r'^\s*(?:[\-\*\u2022]|\d+\s*[\)\.\]]|\(\d+\))\s*', '', ln).strip()
        m = re.fullmatch(r'[A-Za-z]{2,30}', ln2)
        if m:
            out.append(ln2)
    if len(out) >= 3:
        return out

    # 2) comma-separated list
    try:
        best = ""
        for m in re.finditer(r'([A-Za-z]{2,30}(?:\s*,\s*[A-Za-z]{2,30}){2,})', prompt):
            seg = m.group(1)
            if len(seg) > len(best):
                best = seg
        if best:
            parts = [p.strip() for p in best.split(",")]
            parts = [re.sub(r'[^A-Za-z]', '', p) for p in parts]
            parts = [p for p in parts if 2 <= len(p) <= 30]
            if len(parts) >= 3:
                return parts
    except Exception as e:
        log_debug_exc("_extract_word_list_from_prompt:silent", e)
        pass

    return []

def _parse_ordinals_with_pos(text: str) -> List[Tuple[int, int]]:
    """Return list of (position, number) for ordinal-like mentions (Korean/English)."""
    if not isinstance(text, str) or not text:
        return []
    out: List[Tuple[int, int]] = []
    # Korean: 1번째
    for m in re.finditer(r'(\d{1,3})\s*번째', text):
        try:
            out.append((m.start(), int(m.group(1))))
        except Exception as e:
            log_debug_exc("_parse_ordinals_with_pos:silent", e)
            pass
    # English: 1st/2nd/3rd/4th
    for m in re.finditer(r'\b(\d{1,3})\s*(st|nd|rd|th)\b', text, flags=re.IGNORECASE):
        try:
            out.append((m.start(), int(m.group(1))))
        except Exception as e:
            log_debug_exc("_parse_ordinals_with_pos:silent", e)
            pass
    out.sort(key=lambda x: x[0])
    # cap
    return out[:64]

def _parse_ordinals_in_segment(seg: str) -> List[int]:
    return [n for _, n in _parse_ordinals_with_pos(seg)][:32]

def _split_word_and_char_indices(prompt: str) -> Tuple[List[int], List[int]]:
    """Attempt to split ordinal indices into word indices and char indices."""
    if not isinstance(prompt, str) or not prompt.strip():
        return [], []

    # Prefer explicit bracket segments: [..] [..]
    seg_lists: List[List[int]] = []
    for m in re.finditer(r'[\[\(]([^\]\)]{0,220})[\]\)]', prompt):
        seg = m.group(1)
        if "번째" in seg or re.search(r'\b\d+\s*(st|nd|rd|th)\b', seg, flags=re.IGNORECASE):
            nums = _parse_ordinals_in_segment(seg)
            if nums:
                seg_lists.append(nums)
    if len(seg_lists) >= 2:
        return seg_lists[0], seg_lists[1]

    ords = _parse_ordinals_with_pos(prompt)
    if not ords:
        return [], []

    # Pivot by "letter/알파벳/글자" keyword
    pivot = None
    for kw in _PUZZLE_CHAR_KEYWORDS:
        p = prompt.lower().find(kw.lower())
        if p >= 0:
            pivot = p if pivot is None else min(pivot, p)
    if pivot is not None:
        w = [n for pos, n in ords if pos < pivot]
        c = [n for pos, n in ords if pos > pivot]
        return w[:32], c[:32]

    # Heuristic: split into half
    nums = [n for _, n in ords]
    mid = max(1, len(nums) // 2)
    return nums[:mid][:32], nums[mid:][:32]

def _puzzle_ops(prompt: str) -> Tuple[bool, bool, bool]:
    """Return (reverse, lower, upper) flags."""
    t = str(prompt or "")
    t_low = t.lower()
    rev = ("역순" in t) or ("reverse" in t_low) or ("reversed" in t_low)
    lower = ("소문자" in t) or ("lowercase" in t_low)
    upper = ("대문자" in t) or ("uppercase" in t_low)
    return rev, lower, upper

def try_solve_puzzle_extract_v1(payload: Any, hcfg: Optional[HybridChallengeConfig] = None) -> Optional[str]:
    """Solve simple 'pick Nth words and Nth letters' puzzles."""
    prompt, chd = _extract_puzzle_prompt(payload)
    if not prompt:
        return None

    # word list
    words = _extract_word_list_from_payload(chd)
    if not words:
        words = _extract_word_list_from_prompt(prompt)
    if not words:
        return None

    word_idxs, char_idxs = _split_word_and_char_indices(prompt)
    if not word_idxs or not char_idxs:
        return None

    rev, lower, upper = _puzzle_ops(prompt)

    # Build answer
    out_chars: List[str] = []
    for i, widx in enumerate(word_idxs):
        if widx <= 0 or widx > len(words):
            return None
        w = str(words[widx - 1])
        cidx = char_idxs[i] if i < len(char_idxs) else char_idxs[-1]
        if cidx <= 0 or cidx > len(w):
            return None
        out_chars.append(w[cidx - 1])

    ans = "".join(out_chars)
    if rev:
        ans = ans[::-1]
    if upper:
        ans = ans.upper()
    elif lower:
        ans = ans.lower()

    if not ans:
        return None

    # Optional debug log
    try:
        if hcfg and bool(getattr(hcfg, "puzzle_solver_debug", False)):
            log_info(f"[puzzle] solved(extract_v1) words={len(words)} idx_w={word_idxs} idx_c={char_idxs} -> '{one_line(ans, 64)}'")
    except Exception as e:
        log_debug_exc("try_solve_puzzle_extract_v1:silent", e)
        pass

    return ans


def record_puzzle_solution(
    hcfg: HybridChallengeConfig,
    payload: Any,
    *,
    answer: str,
    solver: str,
    attempt: int,
    max_attempts: int,
    state: Optional[Dict[str, Any]] = None,
    context: str = ""
) -> None:
    """Append solved puzzle payload to JSONL and update in-state puzzle stats (v19.10)."""
    try:
        if not hcfg or not str(hcfg.puzzle_log_jsonl or "").strip():
            return
        now_iso = now_kst().isoformat()
        ctype = _challenge_type(payload) or "unknown"
        ch = payload.get("challenge") if isinstance(payload, dict) else None
        chd = ch if isinstance(ch, dict) else {}

        prompt, _ = _extract_puzzle_prompt(payload)
        if prompt and len(prompt) > 2000:
            prompt = prompt[:2000] + "...(trunc)"

        challenge_id = ""
        try:
            cid = chd.get("challenge_id") or chd.get("id") or ""
            if cid:
                challenge_id = one_line(str(cid), 128)
        except Exception:
            challenge_id = ""

        seed_hash16 = ""
        try:
            seed = chd.get("seed")
            if isinstance(seed, str) and seed:
                seed_hash16 = hashlib.sha256(seed.encode("utf-8")).hexdigest()[:16]
        except Exception:
            seed_hash16 = ""

        answer = str(answer or "").strip()
        ans_sha16 = hashlib.sha256(answer.encode("utf-8")).hexdigest()[:16] if answer else ""

        red = _redact_challenge_payload_for_log(payload)
        preview = _safe_json_preview(red, int(hcfg.puzzle_raw_max_chars or 0))
        keys = sorted(list(chd.keys()))[:80]
        fieldset_key = _puzzle_fieldset_key(keys)

        evt = {
            "schema": "mersoom_puzzle_solution_v1",
            "ts_kst": now_iso,
            "context": one_line(str(context or ""), 120),
            "challenge_type": ctype,
            "challenge_id": challenge_id,
            "seed_hash16": seed_hash16,
            "expires_at": chd.get("expires_at"),
            "limit_ms": chd.get("limit_ms"),
            "target_prefix": chd.get("target_prefix"),
            "attempt": int(attempt),
            "max_attempts": int(max_attempts),
            "solver": one_line(str(solver or ""), 64),
            "answer": one_line(answer, 200),
            "answer_len": int(len(answer)),
            "answer_sha16": ans_sha16,
            "prompt": prompt,
            "prompt_len": int(len(prompt) if isinstance(prompt, str) else 0),
            "fields_present": keys,
            "fieldset_key": fieldset_key,
            "payload_preview": preview,
        }
        append_jsonl(str(hcfg.puzzle_log_jsonl), evt)

        # stats
        note_puzzle_event(state, ts_kst=now_iso, challenge_type=ctype, fieldset_key=fieldset_key)
        try:
            if isinstance(state, dict):
                ps = state.setdefault("puzzles", {})
                ps["solved_count"] = int(ps.get("solved_count", 0) or 0) + 1
                sc = ps.setdefault("solver_counts", {})
                sc[str(solver or "unknown")] = int(sc.get(str(solver or "unknown"), 0) or 0) + 1
        except Exception as e:
            log_debug_exc("record_puzzle_solution:silent", e)
            pass
    except Exception as e:
        log_debug_exc("record_puzzle_solution:silent", e)
        pass



def fetch_pow_challenge(client: HttpClient, hcfg: HybridChallengeConfig, *, state: Optional[Dict[str, Any]] = None, context: str = "") -> Challenge:
    """Fetch a challenge for write requests.

    - PoW challenge: solved via sha256(seed + nonce) prefix match.
    - Puzzle challenge (hybrid): if solvable by built-in solver, return a Challenge(kind="puzzle", proof=answer).
      Otherwise, record the payload and retry until PoW appears (bounded).
    """
    max_attempts = 1 + max(0, int(getattr(hcfg, "max_retries", 0) or 0))
    sleep_ms = int(getattr(hcfg, "retry_sleep_ms", 0) or 0)
    last_err: Optional[Exception] = None

    for i in range(1, max_attempts + 1):
        payload = client.post_json("/challenge", payload={})
        ctype = _challenge_type(payload)
        did_puzzle_try = False

        # Type-aware fast path: try puzzle solver first when the server indicates puzzle/hybrid.
        if ctype in ("puzzle", "hybrid") and bool(getattr(hcfg, "puzzle_solver_enable", True)):
            did_puzzle_try = True
            ans: Optional[str] = None
            try:
                ans = try_solve_puzzle_extract_v1(payload, hcfg)
            except Exception:
                ans = None

            if ans:
                try:
                    token = ""
                    if isinstance(payload, dict):
                        token = str(payload.get("token") or "").strip()
                        if not token:
                            chd = payload.get("challenge") if isinstance(payload.get("challenge"), dict) else {}
                            token = str(chd.get("token") or "").strip()
                    if token:
                        chd = payload.get("challenge") if isinstance(payload, dict) and isinstance(payload.get("challenge"), dict) else {}
                        cid = ""
                        try:
                            cid = one_line(str((chd.get("challenge_id") or chd.get("id") or "")), 128)
                        except Exception:
                            cid = ""
                        limit_ms = 0
                        try:
                            limit_ms = int(chd.get("limit_ms") or 0)
                        except Exception:
                            limit_ms = 0
                        solved = Challenge(token=token, seed="", target_prefix="", limit_ms=int(limit_ms), kind="puzzle", proof=str(ans), challenge_id=str(cid or ""))
                        record_puzzle_solution(hcfg, payload, answer=str(ans), solver="extract_v1", attempt=i, max_attempts=max_attempts, state=state, context=(context or "/challenge"))
                        return solved
                except Exception as e:
                    log_debug_exc("fetch_pow_challenge:silent", e)
                    pass

        # Prefer parse-based detection: if parse_challenge works, treat as PoW-compatible.
        try:
            return parse_challenge(payload)
        except Exception as e:
            last_err = e

            if (not did_puzzle_try) and bool(getattr(hcfg, "puzzle_solver_enable", True)):
                ans: Optional[str] = None
                try:
                    ans = try_solve_puzzle_extract_v1(payload, hcfg)
                except Exception:
                    ans = None

                if ans:
                    try:
                        token = ""
                        if isinstance(payload, dict):
                            token = str(payload.get("token") or "").strip()
                            if not token:
                                chd = payload.get("challenge") if isinstance(payload.get("challenge"), dict) else {}
                                token = str(chd.get("token") or "").strip()
                        if token:
                            chd = payload.get("challenge") if isinstance(payload, dict) and isinstance(payload.get("challenge"), dict) else {}
                            cid = ""
                            try:
                                cid = one_line(str((chd.get("challenge_id") or chd.get("id") or "")), 128)
                            except Exception:
                                cid = ""
                            limit_ms = 0
                            try:
                                limit_ms = int(chd.get("limit_ms") or 0)
                            except Exception:
                                limit_ms = 0
                            solved = Challenge(token=token, seed="", target_prefix="", limit_ms=int(limit_ms), kind="puzzle", proof=str(ans), challenge_id=str(cid or ""))
                            record_puzzle_solution(hcfg, payload, answer=str(ans), solver="extract_v1", attempt=i, max_attempts=max_attempts, state=state, context=(context or "/challenge"))
                            return solved
                    except Exception as e:
                        log_debug_exc("fetch_pow_challenge:silent", e)
                        pass

            # If it's not PoW (or unsolved puzzle), record and retry
            parse_error = one_line(str(e), 160)
            reason = f"type={ctype or 'unknown'}; {parse_error}"
            record_unhandled_challenge(
                hcfg,
                payload,
                reason=reason,
                parse_error=parse_error,
                attempt=i,
                max_attempts=max_attempts,
                state=state,
                context=(context or "/challenge"),
            )
            if sleep_ms > 0 and i < max_attempts:
                time.sleep((sleep_ms / 1000.0) + random.uniform(0.0, 0.05))
            continue

    raise RuntimeError(f"no solvable challenge after {max_attempts} attempts: {one_line(str(last_err), 180)}")


def solve_pow(seed: str, target_prefix: str, limit_ms: int) -> int:
    """CPU PoW: find nonce such that sha256(seed + nonce) matches target_prefix.

    v21.1: precompile prefix once per solve (avoid bytes.fromhex per-iteration), reduce perf_counter checks.
    """
    seed_b = seed.encode("utf-8")
    p = (target_prefix or "").lower().strip()
    if not p:
        raise ValueError("target_prefix is required")
    odd = (len(p) % 2 == 1)
    full = p[:-1] if odd else p
    pref_bytes = bytes.fromhex(full) if full else b""
    nib = int(p[-1], 16) if odd else -1
    pref_len = len(pref_bytes)

    sha256 = hashlib.sha256
    perf = time.perf_counter
    deadline = perf() + (max(200, int(limit_ms)) / 1000.0)

    nonce = 0
    check_every = 256  # deadline check frequency
    while True:
        for _ in range(check_every):
            d = sha256(seed_b + str(nonce).encode("utf-8")).digest()
            if pref_len and d[:pref_len] != pref_bytes:
                nonce += 1
                continue
            if odd:
                if len(d) <= pref_len:
                    nonce += 1
                    continue
                if (d[pref_len] >> 4) != nib:
                    nonce += 1
                    continue
            return nonce
            # nonce increment is unreachable after return
        if perf() >= deadline:
            break

    raise TimeoutError("PoW time limit exceeded")

# --- PoW offload (P0): avoid blocking main thread on high difficulty ---
_POW_EXECUTOR: Optional[ProcessPoolExecutor] = None
_POW_EXECUTOR_DISABLED = False
_POW_TIMEOUT_TS = deque(maxlen=4000)
_POW_EXECUTOR_RESTART_TS = deque(maxlen=400)
_POW_TIMEOUT_STREAK = 0

def _pow_watchdog_enabled() -> bool:
    return _env_bool("MERSOOM_POW_WATCHDOG", True)

def _pow_watchdog_threshold() -> int:
    return _env_int("MERSOOM_POW_TIMEOUT_STREAK_MAX", 3, 1, 10)

def _pow_watchdog_note_success() -> None:
    global _POW_TIMEOUT_STREAK
    _POW_TIMEOUT_STREAK = 0

def _pow_watchdog_on_timeout() -> bool:
    """Return True if current tick should skip PoW (after restart)."""
    global _POW_TIMEOUT_STREAK, _POW_EXECUTOR
    if not _pow_watchdog_enabled():
        return False
    try:
        _POW_TIMEOUT_TS.append(time.time())
    except Exception:
        pass
    _POW_TIMEOUT_STREAK += 1
    if _POW_TIMEOUT_STREAK < _pow_watchdog_threshold():
        return False
    # restart executor and skip current tick
    _POW_TIMEOUT_STREAK = 0
    try:
        if _POW_EXECUTOR is not None:
            _POW_EXECUTOR.shutdown(wait=False, cancel_futures=True)
    except Exception as e:
        log_debug_exc("pow_watchdog:shutdown", e)
    _POW_EXECUTOR = None
    try:
        _POW_EXECUTOR_RESTART_TS.append(time.time())
    except Exception:
        pass
    return True

def _pow_mode() -> str:
    return str(os.getenv("MERSOOM_POW_MODE", "process")).strip().lower()

def _get_pow_executor() -> Optional[ProcessPoolExecutor]:
    global _POW_EXECUTOR, _POW_EXECUTOR_DISABLED
    mode = _pow_mode()
    if mode in ("sync", "off", "none", "0", "false"):
        return None
    if bool(_POW_EXECUTOR_DISABLED):
        return None
    if _POW_EXECUTOR is None:
        try:
            _POW_EXECUTOR = ProcessPoolExecutor(max_workers=1)
            try:
                atexit.register(lambda: _POW_EXECUTOR.shutdown(wait=False, cancel_futures=True) if _POW_EXECUTOR else None)
            except Exception as e:
                log_debug_exc("_get_pow_executor:silent", e)
                pass
        except Exception as e:
            _POW_EXECUTOR = None
            _POW_EXECUTOR_DISABLED = True
            log_warn("pow executor init failed -> fallback to sync: " + one_line(repr(e), 200))
            return None
    return _POW_EXECUTOR

def _solve_pow_worker(seed: str, target_prefix: str, limit_ms: int) -> int:
    # top-level for multiprocessing pickling
    return solve_pow(seed, target_prefix, int(limit_ms))

def solve_pow_nonblocking(seed: str, target_prefix: str, limit_ms: int) -> int:
    """Solve PoW without freezing the main thread.

    - Uses a ProcessPoolExecutor when available.
    - If executor is unavailable/broken, falls back to sync solve_pow().
    - Ensures watchdog is triggered for both main-timeouts and worker TimeoutError.
    """
    ex = _get_pow_executor()
    if ex is None:
        try:
            res = solve_pow(seed, target_prefix, int(limit_ms))
            _pow_watchdog_note_success()
            return int(res)
        except TimeoutError:
            if _pow_watchdog_on_timeout():
                raise PowTimeoutError("pow timeout watchdog (sync)")
            raise

    try:
        fut = ex.submit(_solve_pow_worker, seed, target_prefix, int(limit_ms))
    except Exception as e:
        # Executor may be broken; downgrade to sync for stability.
        log_warn("pow submit failed -> fallback to sync: " + one_line(repr(e), 200))
        try:
            _shutdown_pow_executor()
        except Exception:
            pass
        try:
            res = solve_pow(seed, target_prefix, int(limit_ms))
            _pow_watchdog_note_success()
            return int(res)
        except TimeoutError:
            if _pow_watchdog_on_timeout():
                raise PowTimeoutError("pow timeout watchdog (sync)")
            raise

    deadline_wall = time.time() + max(0.3, int(limit_ms) / 1000.0 + 1.0)

    while True:
        try:
            res = int(fut.result(timeout=0.25))
            _pow_watchdog_note_success()
            return int(res)
        except FuturesTimeoutError:
            if time.time() >= deadline_wall:
                try:
                    fut.cancel()
                except Exception as e:
                    log_debug_exc("solve_pow_nonblocking:silent", e)
                    pass
                if _pow_watchdog_on_timeout():
                    raise PowTimeoutError("pow timeout watchdog (process)")
                raise TimeoutError("PoW time limit exceeded (process)")
            continue
        except TimeoutError as e:
            # Worker raised TimeoutError -> still a PoW timeout for watchdog purposes.
            if _pow_watchdog_on_timeout():
                raise PowTimeoutError("pow timeout watchdog (worker)")
            raise PowTimeoutError("PoW time limit exceeded (worker)") from e
def build_pow_headers(ch: Challenge, *, wallet: str = "") -> Dict[str, str]:
    if str(getattr(ch, "kind", "pow") or "pow").lower() == "puzzle":
        proof = str(getattr(ch, "proof", "") or "").strip()
        if not proof:
            raise ValueError("puzzle challenge missing proof/solution")
        return {
            "X-Mersoom-Token": ch.token,
            "X-Mersoom-Proof": proof,
            "Content-Type": "application/json",
        }

    nonce = solve_pow_nonblocking(ch.seed, ch.target_prefix, ch.limit_ms)
    proof = f"{nonce}:{wallet}" if wallet else str(nonce)
    return {
        "X-Mersoom-Token": ch.token,
        "X-Mersoom-Proof": proof,
        "Content-Type": "application/json",
    }


def build_auth_headers(auth: Optional[AuthConfig]) -> Dict[str, str]:
    """Build optional login headers for points system (Mersoom 3.0).

    Returns {} if auth is missing/disabled/invalid.
    """
    try:
        if not auth or not bool(getattr(auth, "enabled", False)):
            return {}
        aid = str(getattr(auth, "auth_id", "") or "").strip()
        pw = str(getattr(auth, "password", "") or "").strip()
        if not aid or not pw:
            return {}
        return {"X-Mersoom-Auth-Id": aid, "X-Mersoom-Password": pw}
    except Exception:
        return {}


def post_with_pow(client: HttpClient, pow_cfg: PowConfig, hcfg: HybridChallengeConfig, path: str, payload: Dict[str, Any], *, extra_headers: Optional[Dict[str, str]] = None, state: Optional[Dict[str, Any]] = None) -> Any:
    """
    Generic PoW POST helper.
    - DRY_RUN: bypass PoW.
    - If /challenge unsupported (404/405), fallback to plain POST.
    """
    payload = strip_none(payload)

    if client.cfg.dry_run:
        return client.post_json(path, payload)

    # 1) challenge (hybrid: if AI Puzzle appears, record + retry until PoW)
    try:
        ch = fetch_pow_challenge(client, hcfg, state=state, context=(f"POST {path}" if path else "POST /challenge"))
    except requests.HTTPError as e:
        msg = str(e)
        if "404" in msg or "405" in msg:
            return client.post_json(path, payload)
        raise

    # 2) solve + post
    try:
        headers = build_pow_headers(ch, wallet=pow_cfg.wallet)
    except PowTimeoutError:
        if isinstance(state, dict):
            protocol_bump_counter(state, "pow_timeout", 1)
        raise
    if extra_headers:
        try:
            for k, v in dict(extra_headers).items():
                if v is None:
                    continue
                vv = str(v)
                if vv == "":
                    continue
                key = str(k)
                key_l = key.lower()
                if key_l in ("x-mersoom-token", "x-mersoom-proof"):
                    if key in headers and headers.get(key) != vv:
                        log_warn(f"post_with_pow:skip_override header={key}")
                    continue
                headers[key] = vv
        except Exception as e:
            log_debug_exc("post_with_pow:silent", e)
            pass
    return client.post_json(path, payload, headers=headers)
