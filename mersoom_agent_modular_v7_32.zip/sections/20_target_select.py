################################################################################
# 20. TARGET SELECTION
# Deps: 01-03, 10, 12-18
# Used by: contribution/comment selection in main loop
# Notes: score candidates and sample among top-N to avoid rigidity
################################################################################
"""
SECTION 20 - TARGET SELECTION

Decides WHAT to act on next (which post/comment/thread).

Responsibilities:
- Collect candidate targets (feeds, own posts, replies).
- Score/filter candidates to avoid spammy behavior.
- Commit selection into state so later steps can evaluate reward.

Debug tips:
- Many 'no action' situations originate here (empty candidates, strict filters).
"""
def _pick_contrib_target(cfg: Config, state: Dict[str, Any], posts: List[Dict[str, Any]], brain: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """Pick a post to comment on using engagement + thread/user context.

    P1: deterministic 'top score' selection makes behavior stiff.
        We score a handful of candidates and sample among top-N.
    """
    try:
        trace_hit("select:comment_other:enter")
    except Exception:
        pass

    commented_ts = _safe_dict(state.get("commented_ts"))
    flow_kws = _flow_keywords(brain, k=8)

    scored: List[Tuple[float, Dict[str, Any]]] = []
    now = time.time()

    for p in posts:
        if not isinstance(p, dict):
            continue
        if is_own_post(cfg, p):
            continue
        pid = str(p.get("id") or "")
        if not pid:
            continue

        # local cool-down to avoid hammering one thread
        lastc = float(commented_ts.get(pid, 0.0) or 0.0)
        if (now - lastc) < float(getattr(getattr(cfg, 'timing', None), 'same_post_comment_gap_sec', 60 * 30)):
            continue

        m = _post_metrics(p)
        base = int(m.get("comments", 0)) * 2.0 + int(m.get("score", 0)) * 1.0

        # thread context (if exists)
        th = _safe_dict(_safe_dict(state.get("threads")).get(pid))
        tension = float(len(_safe_list(th.get("tensions")))) * 2.0
        openq = float(len(_safe_list(th.get("open_questions")))) * 1.2
        # prefer fresher threads
        age = max(0.0, now - float(th.get("last_seen_ts", now) or now))
        fresh = max(0.0, 1.5 - (age / 3600.0) * 0.15)

        # author + user model
        author = str(p.get("nickname") or p.get("author") or "")
        u = get_user(state, author) if author else {}
        helpful = float(_safe_dict(u).get("helpfulness", 0.0) or 0.0)
        aggr = float(_safe_dict(u).get("aggression", 0.0) or 0.0)

        drives = get_persona_drives(brain)
        debate_bias = float(drives.get("debate", 0.7) or 0.7)
        # debate-oriented persona: conflict isn't a strict negative
        aggr_term = (0.8 * aggr) if debate_bias >= 0.6 else (-1.2 * aggr)

        # relation memory (who we've been interacting with)
        rel = _safe_dict(_safe_dict(state.get("relations")).get(author)) if author else {}
        inter = float(_safe_dict(rel).get("interactions", 0) or 0)
        rel_term = 0.35 * math.log1p(inter)

        # flow keyword overlap
        txt = f"{p.get('title') or ''} {p.get('content') or ''}".strip()
        kws = set(top_keywords(txt, k=10))
        overlap = sum(1 for kw in flow_kws if kw and kw in kws)
        flow_term = 1.8 * float(overlap)

        # mild novelty push: avoid over-popular threads only
        pop_penalty = 0.0
        if int(m.get("comments", 0)) >= 20:
            pop_penalty = 1.5

        score = base + tension + openq + fresh + (1.4 * helpful) + aggr_term + rel_term + flow_term - pop_penalty
        scored.append((score, p))

    if not scored:
        return None

    scored.sort(key=lambda x: x[0], reverse=True)
    topn = scored[: min(6, len(scored))]

    # weighted sampling among top to avoid being stuck
    weights = [max(0.01, float(s - topn[-1][0] + 0.25)) for s, _ in topn]
    ssum = sum(weights)
    r = random.uniform(0.0, ssum)
    acc = 0.0
    for w, (_, p) in zip(weights, topn):
        acc += w
        if acc >= r:
            return p
    return topn[0][1]

def _comment_parent_id(c: Dict[str, Any]) -> str:
    for k in ("parent_id", "parentId", "reply_to", "replyTo", "parent_comment_id"):
        v = c.get(k)
        if v:
            return str(v)
    return ""




def _comment_id_any(c: Any) -> str:
    if isinstance(c, dict):
        return str(c.get("id") or "")
    return str(getattr(c, "id", "") or "")

def _comment_author_any(c: Any) -> str:
    if isinstance(c, dict):
        return str(c.get("author") or c.get("nickname") or c.get("user") or "")
    return str(getattr(c, "author", "") or getattr(c, "nickname", "") or getattr(c, "user", "") or "")

def _comment_content_any(c: Any) -> str:
    if isinstance(c, dict):
        return str(c.get("content") or c.get("text") or c.get("body") or "")
    return str(getattr(c, "content", "") or getattr(c, "text", "") or getattr(c, "body", "") or "")

def _comment_created_ts(c: Dict[str, Any]) -> float:
    """Best-effort comment timestamp (epoch seconds).

    Supports both numeric epoch (sec/ms) and ISO8601 created_at strings.
    Returns 0.0 if unavailable.
    """
    if not isinstance(c, dict):
        return 0.0
    for k in ("ts", "timestamp", "created_ts", "createdAtTs", "created_at_ts"):
        try:
            v = c.get(k)
            if isinstance(v, (int, float)) and float(v) > 0:
                x = float(v)
                # normalize ms -> sec
                if x > 1e12:
                    x = x / 1000.0
                return float(x)
        except Exception:
            continue
    for k in ("created_at", "createdAt", "created", "created_time", "createdTime"):
        try:
            v = c.get(k)
            if isinstance(v, (int, float)) and float(v) > 0:
                x = float(v)
                if x > 1e12:
                    x = x / 1000.0
                return float(x)
            if isinstance(v, str) and v.strip():
                ts = _parse_iso_ts(v.strip())
                if ts > 0:
                    return float(ts)
        except Exception:
            continue
    return 0.0

def _has_replied_to_comment(cfg: Config, comments: List[Dict[str, Any]], target_comment_id: str) -> bool:
    """
    Best-effort: detect if we already replied to a given comment (server-side truth beats local state).
    """
    tc = str(target_comment_id or "")
    if not tc:
        return False
    for c in comments:
        if not isinstance(c, dict):
            continue
        if not is_own_comment(cfg, c):
            continue
        pid = _comment_parent_id(c)
        if pid and pid == tc:
            return True
    return False

# ---------------------------------------------------------------------------
# Reply thread conversation protocol
# - Prevents "self monologue" where the agent keeps replying without any new remote turn.
# - Uses comment parent chain to group a whole reply tree into one "conversation".
# - Maintains a lightweight budget: at most 1 reply per new remote turn.
# ---------------------------------------------------------------------------

def _comment_root_id(comments_by_id: Dict[str, Dict[str, Any]], cid: str) -> str:
    cur = str(cid or "")
    if not cur:
        return ""
    seen: set = set()
    while cur:
        if cur in seen:
            return cur  # cycle guard
        seen.add(cur)
        c = comments_by_id.get(cur)
        if not isinstance(c, dict):
            return cur
        pid = _comment_parent_id(c)
        if not pid:
            return cur
        cur = str(pid)
    return str(cid or "")

def _build_root_cache(comments: List[Dict[str, Any]]) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, str]]:
    by_id: Dict[str, Dict[str, Any]] = {}
    for c in comments or []:
        if not isinstance(c, dict):
            continue
        cid = str(c.get("id") or "")
        if cid:
            by_id[cid] = c
    root_of: Dict[str, str] = {}
    for cid in list(by_id.keys()):
        root_of[cid] = _comment_root_id(by_id, cid)
    return by_id, root_of

def _reply_conv_key(post_id: str, root_comment_id: str) -> str:
    return f"{str(post_id or '')}:{str(root_comment_id or '')}"

def _reply_protocol_prepare(
    state: Dict[str, Any],
    cfg: Config,
    tuning: AgentTuning,
    post_id: str,
    comments: List[Dict[str, Any]],
    target_comment_id: str,
    now_ts: float,
) -> Tuple[bool, str, Dict[str, Any], Dict[str, Any], str]:
    """Returns (ok, conv_key, conv_state, conv_meta, reason)."""
    convs = state.get("conv_state")
    if not isinstance(convs, dict):
        convs = {}
        state["conv_state"] = convs

    by_id, root_of = _build_root_cache(comments)
    tgt = str(target_comment_id or "")
    if not tgt or tgt not in by_id:
        return False, "", {}, {}, "target_missing"

    root = str(root_of.get(tgt) or tgt)
    ckey = _reply_conv_key(post_id, root)

    conv = convs.get(ckey)
    if not isinstance(conv, dict):
        conv = {
            "post_id": str(post_id or ""),
            "root_comment_id": root,
            "last_remote_id": "",
            "last_my_id": "",
            "budget": 0,
            "waiting_for_remote": False,
            "blocked_until_ts": 0.0,
            "closed_until_ts": 0.0,
            "turns_remote": 0,
            "turns_my": 0,
            "last_action_ts": 0.0,
            "last_seen_tail_kind": "",
        }
        convs[ckey] = conv

    # hard blocks
    if float(conv.get("closed_until_ts", 0.0) or 0.0) > now_ts:
        return False, ckey, conv, {}, "closed"
    if float(conv.get("blocked_until_ts", 0.0) or 0.0) > now_ts:
        return False, ckey, conv, {}, "blocked"

    # analyze conversation by list order (assume chronological)
    last_in_conv: Optional[Dict[str, Any]] = None
    last_other_in_conv: Optional[Dict[str, Any]] = None
    last_my_in_conv: Optional[Dict[str, Any]] = None
    turns_total = 0
    for c in comments or []:
        if not isinstance(c, dict):
            continue
        cid = str(c.get("id") or "")
        if not cid:
            continue
        if str(root_of.get(cid) or cid) != root:
            continue
        turns_total += 1
        last_in_conv = c
        if is_own_comment(cfg, c):
            last_my_in_conv = c
        else:
            last_other_in_conv = c

    last_id = str((last_in_conv or {}).get("id") or "")
    last_other_id = str((last_other_in_conv or {}).get("id") or "")
    last_my_id = str((last_my_in_conv or {}).get("id") or "")
    last_speaker = "me" if (last_in_conv is not None and is_own_comment(cfg, last_in_conv)) else "other"

    prev_remote = str(conv.get("last_remote_id") or "")
    new_remote = bool(last_other_id) and (last_other_id != prev_remote)
    if new_remote:
        conv["last_remote_id"] = last_other_id
        conv["last_remote_ts"] = float(now_ts)
        cap = int(getattr(tuning, "reply_conv_budget_cap", 1) or 1)
        conv["budget"] = min(cap, int(conv.get("budget", 0) or 0) + 1)
        conv["waiting_for_remote"] = False
        conv["turns_remote"] = int(conv.get("turns_remote", 0) or 0) + 1

    if last_my_id:
        conv["last_my_id"] = last_my_id

    # Only reply to the latest remote turn (avoid out-of-order replies).
    if last_other_id and (tgt != last_other_id) and (not is_own_comment(cfg, by_id.get(tgt, {}))):
        conv["blocked_until_ts"] = now_ts + float(getattr(tuning, "reply_conv_skip_cooldown_sec", 10 * 60))
        return False, ckey, conv, {}, "not_latest_remote"

    # Gate: do not speak twice in a row; do not speak without budget
    if last_speaker == "me" and (not new_remote):
        conv["blocked_until_ts"] = now_ts + float(getattr(tuning, "reply_conv_skip_cooldown_sec", 10 * 60))
        return False, ckey, conv, {}, "awaiting_remote"
    if int(conv.get("budget", 0) or 0) <= 0 and (not new_remote):
        conv["blocked_until_ts"] = now_ts + float(getattr(tuning, "reply_conv_skip_cooldown_sec", 10 * 60))
        return False, ckey, conv, {}, "no_budget"

    # lock after we asked a question until remote responds
    if bool(conv.get("waiting_for_remote")) and (not new_remote):
        cooldown = float(getattr(tuning, "reply_conv_skip_cooldown_sec", 10 * 60))
        if _waiting_strict_enabled(state):
            cooldown = max(cooldown, 20 * 60.0)
        conv["blocked_until_ts"] = now_ts + cooldown
        conv["last_skip_reason"] = "waiting_for_remote"
        try:
            protocol_bump_counter(state, "waiting_skip", 1)
        except Exception:
            pass
        return False, ckey, conv, {}, "waiting_for_remote"

    target_text = str((by_id.get(tgt) or {}).get("content") or "")
    remote_is_question = ("?" in target_text) or target_text.strip().endswith("?") or bool(re.search(r"(까|나요|냐|지)\s*$", target_text))
    conv_meta = {
        "conv_key": ckey,
        "root_comment_id": root,
        "last_comment_id": last_id,
        "last_remote_id": last_other_id,
        "last_my_id": last_my_id,
        "last_speaker": last_speaker,
        "new_remote": bool(new_remote),
        "budget": int(conv.get("budget", 0) or 0),
        "turns_total": int(turns_total),
        "turns_remote": int(conv.get("turns_remote", 0) or 0),
        "turns_my": int(conv.get("turns_my", 0) or 0),
        "remote_is_question": bool(remote_is_question),
    }
    return True, ckey, conv, conv_meta, "ok"

def _reply_protocol_commit(
    state: Dict[str, Any],
    conv_key: str,
    now_ts: float,
    reply_comment_id: str,
    reply_text: str,
) -> None:
    convs = state.get("conv_state")
    if not isinstance(convs, dict):
        return
    conv = convs.get(conv_key)
    if not isinstance(conv, dict):
        return
    conv["last_action_ts"] = float(now_ts)
    if reply_comment_id:
        conv["last_my_id"] = str(reply_comment_id)
    conv["budget"] = max(0, int(conv.get("budget", 0) or 0) - 1)
    conv["turns_my"] = int(conv.get("turns_my", 0) or 0) + 1
    asked_q = False
    try:
        if _waiting_strict_enabled(state):
            asked_q = bool(_is_open_question_text(str(reply_text or "")))
        else:
            asked_q = bool("?" in (reply_text or ""))
    except Exception:
        asked_q = bool("?" in (reply_text or ""))
    tail_kind = "question" if asked_q else "close"
    conv["last_seen_tail_kind"] = str(tail_kind)
    conv["waiting_for_remote"] = bool(asked_q)
    conv["blocked_until_ts"] = float(now_ts) + 90.0

    try:
        post_id = str(conv_key.split('|', 1)[0]) if conv_key else ""
        if post_id:
            th = get_thread(state, post_id)
            thread_update_phase_if_needed(state, th, reply_text or "", source="my_reply")
    except Exception:
        pass



def _pick_ctx_from_flow(brain: Dict[str, Any]) -> str:
    com = _safe_dict(brain.get("community"))
    rising = _safe_list(com.get("rising"))
    hot = _safe_list(com.get("hot"))
    kw = ""
    if rising and isinstance(rising[0], dict):
        kw = str(rising[0].get("kw") or "")
    if not kw and hot and isinstance(hot[0], dict):
        kw = str(hot[0].get("kw") or "")
    cat, ctx = classify_text(kw or "커뮤니티")
    return ctx or "gen"

# (Unit 04) Thread-priority reply inbox
def _recent_involved_post_ids_from_memory(memory: List[Dict[str, Any]], *, days: int, max_n: int) -> List[str]:
    """Infer recently-involved post_ids from memory (no extra API calls)."""
    try:
        dd = max(1, int(days))
    except Exception:
        dd = 3
    max_n = max(1, int(max_n))
    now = time.time()
    seen: Dict[str, float] = {}
    for it in reversed(_safe_list(memory)[-350:]):
        if not isinstance(it, dict):
            continue
        ts = _safe_float(it.get("ts"), 0.0)
        if ts <= 0:
            continue
        if (now - ts) > dd * 24 * 60 * 60:
            break
        pid = str(it.get("post_id") or "")
        if not pid:
            continue
        act = str(it.get("action") or "")
        if act not in ("post", "comment", "reply"):
            continue
        if pid not in seen or ts > seen[pid]:
            seen[pid] = ts
    out = sorted(seen.items(), key=lambda x: x[1], reverse=True)
    return [pid for pid, _ in out[:max_n]]

def _inbox_item_score(post: Dict[str, Any], *, own_post: bool, reply_to_my_comment: bool, recent_involved: bool, rank_hint: int) -> float:
    # Base priority: direct replies > comments on my post > active thread involvement
    s = 0.0
    if reply_to_my_comment:
        s += 140.0
    if own_post:
        s += 110.0
    elif recent_involved:
        s += 85.0
    else:
        s += 60.0

    m = _post_metrics(post)
    ps = abs(int(m.get("score", 0) or 0))
    pc = int(m.get("comments", 0) or 0)
    s += 6.0 * math.log1p(ps)
    s += 4.0 * math.log1p(pc)

    # Slight bias to newer candidates within the scan
    s += 0.8 * float(rank_hint)
    return s



def handle_toxic_target(
    client: HttpClient,
    cfg: Config,
    state: Dict[str, Any],
    post_id: str,
    comment_id: str,
    text: str,
    *,
    tag: str = "",
) -> bool:
    """Handle toxic engagement target (auto-downvote + no-reply).

    Returns True if 'no_reply' policy should be applied.
    """
    tox_cfg = getattr(cfg, "toxic", None)
    if not tox_cfg:
        return False

    tox, reason = is_toxic_incoming(text)
    if not tox:
        return False

    pid = str(post_id or "")
    cid = str(comment_id or "")
    now = time.time()

    tb = state.setdefault("toxic", {})
    if not isinstance(tb, dict):
        state["toxic"] = {}
        tb = state["toxic"]
    tb["hits"] = int(tb.get("hits", 0) or 0) + 1

    skipped = tb.setdefault("skipped", {})
    if not isinstance(skipped, dict):
        tb["skipped"] = {}
        skipped = tb["skipped"]
    if pid and cid:
        skipped[f"{pid}:{cid}"] = {"ts": now, "reason": str(reason), "tag": str(tag or "")}
        if len(skipped) > 260:
            try:
                items = sorted(skipped.items(), key=lambda kv: float(_safe_dict(kv[1]).get("ts", 0.0)))
                for k, _v in items[:-180]:
                    skipped.pop(k, None)
            except Exception as e:
                log_debug_exc("handle_toxic_target:silent", e)
                pass

    if bool(getattr(tox_cfg, "auto_downvote", True)) and pid:
        try:
            vm = _voted_posts_map(state)
            if pid not in vm:
                vote_post(client, cfg, state, pid, "down")
            dv = tb.setdefault("downvoted_posts", {})
            if not isinstance(dv, dict):
                tb["downvoted_posts"] = {}
                dv = tb["downvoted_posts"]
            dv[pid] = now
            _lru_prune_map(dv, 400)
        except Exception as e:
            log_debug_exc("handle_toxic_target:silent", e)
            pass

    if bool(getattr(tox_cfg, "no_reply", True)) and pid and cid:
        replied_ts = state.get("replied_ts")
        if not isinstance(replied_ts, dict):
            replied_ts = {}
            state["replied_ts"] = replied_ts
        replied_ts[f"{pid}:{cid}"] = now

    return bool(getattr(tox_cfg, "no_reply", True))

def _build_reply_inbox(
    client: HttpClient,
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    memory: List[Dict[str, Any]],
    posts_cache: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Build a prioritized list of (post_id, comment_id) I should reply to."""
    now = time.time()

    # cache to avoid hammering /comments in burst mode
    cache = _safe_dict(state.get("reply_inbox_cache"))
    cache_ts = _safe_float(cache.get("ts"), 0.0)
    if cache_ts > 0 and (now - cache_ts) < max(15, int(getattr(tuning, "inbox_scan_min_sec", 90))):
        items = _safe_list(cache.get("items", []))
        return [it for it in items if isinstance(it, dict)]

    replied_ts = _safe_dict(state.get("replied_ts"))

    # candidate posts: (a) my posts (hot/recent), (b) posts I recently interacted with
    posts_by_id: Dict[str, Dict[str, Any]] = {}
    for p in posts_cache:
        if isinstance(p, dict):
            pid = str(p.get("id") or "")
            if pid:
                posts_by_id[pid] = p

    # (a) my posts first
    own_posts = [p for p in posts_cache if isinstance(p, dict) and is_own_post(cfg, p)]
    own_posts.sort(key=lambda p: (_post_metrics(p).get("comments", 0), _post_metrics(p).get("score", 0)), reverse=True)
    own_posts = own_posts[: max(2, min(8, int(getattr(tuning, "inbox_max_posts", 10)) // 2 or 5))]

    # (b) recent involved posts (from memory)
    recent_pids = set(_recent_involved_post_ids_from_memory(
        memory,
        days=int(getattr(tuning, "inbox_recent_thread_days", 3)),
        max_n=int(getattr(tuning, "inbox_max_posts", 10)) * 2,
    ))

    cand_posts: List[Dict[str, Any]] = []
    seen_pid: set = set()
    for p in own_posts:
        pid = str(p.get("id") or "")
        if pid and pid not in seen_pid:
            cand_posts.append(p)
            seen_pid.add(pid)

    # add recent-involved posts (if present in cache)
    for pid in list(recent_pids):
        if pid in seen_pid:
            continue
        p = posts_by_id.get(pid)
        if isinstance(p, dict):
            cand_posts.append(p)
            seen_pid.add(pid)
        if len(cand_posts) >= int(getattr(tuning, "inbox_max_posts", 10)):
            break

    # If still short, top-scoring posts as a weak backfill (still only reply-to-my-comment)
    if len(cand_posts) < max(3, int(getattr(tuning, "inbox_max_posts", 10))):
        others = [p for p in posts_cache if isinstance(p, dict) and str(p.get("id") or "") not in seen_pid]
        others.sort(key=lambda p: (_post_metrics(p).get("score", 0), _post_metrics(p).get("comments", 0)), reverse=True)
        for p in others[:8]:
            cand_posts.append(p)
            seen_pid.add(str(p.get("id") or ""))
            if len(cand_posts) >= int(getattr(tuning, "inbox_max_posts", 10)):
                break

    items: List[Dict[str, Any]] = []

    scan_n = int(getattr(tuning, "inbox_scan_comments_per_post", 40))
    scan_n = max(10, min(200, scan_n))

    for p in cand_posts[: int(getattr(tuning, "inbox_max_posts", 10))]:
        pid = str(p.get("id") or "")
        if not pid:
            continue

        own_post = is_own_post(cfg, p)
        recent_involved = (pid in recent_pids)

        try:
            comments = list_comments(client, pid)
        except Exception:
            comments = []

        if not comments:
            continue

        my_comment_ids = set()
        for c in comments[-120:]:
            if isinstance(c, dict) and is_own_comment(cfg, c):
                cid0 = str(c.get("id") or "")
                if cid0:
                    my_comment_ids.add(cid0)

        # iterate newest-first
        window = comments[-scan_n:]
        for rank, c in enumerate(reversed(window), start=1):
            if not isinstance(c, dict):
                continue
            if is_own_comment(cfg, c):
                continue

            cid = str(c.get("id") or "")
            if not cid:
                continue

            parent_id = _comment_parent_id(c)
            reply_to_my_comment = bool(parent_id and parent_id in my_comment_ids)
            if reply_to_my_comment:
                _note_reply_received(state, memory, post_id=pid, my_comment_id=parent_id, reply_comment_id=cid)

            # only take items that are explicitly "to me"
            if (not own_post) and (not reply_to_my_comment):
                continue

            key = f"{pid}:{cid}"

            # toxic/taunt: auto-downvote + no-reply
            ctext = str(c.get("content") or "")
            if ctext and handle_toxic_target(client, cfg, state, pid, cid, ctext, tag="inbox"):
                replied_ts[key] = now
                continue
            last = _safe_float(replied_ts.get(key), 0.0)
            if last > 0 and (now - last) < 60 * 60 * 24 * 7:
                continue

            # already replied? (server-side check)
            try:
                if _has_replied_to_comment(cfg, comments, cid):
                    replied_ts[key] = now
                    continue
            except Exception as e:
                log_debug_exc("_build_reply_inbox:silent", e)
                pass
            comment_ts = _comment_created_ts(c)

            score = _inbox_item_score(p, own_post=own_post, reply_to_my_comment=reply_to_my_comment, recent_involved=recent_involved, rank_hint=rank)
            why = "reply_to_my_comment" if reply_to_my_comment else "comment_on_my_post"
            items.append({
                "post_id": pid,
                "comment_id": cid,
                "comment_ts": float(comment_ts or 0.0),
                "replied_to_comment_id": str(parent_id or ""),
                "own_post": bool(own_post),
                "reply_to_my_comment": bool(reply_to_my_comment),
                "recent_involved": bool(recent_involved),
                "score": float(score),
                "why": why,
            })

    items.sort(key=lambda it: float(it.get("score", 0.0)), reverse=True)
    items = items[: max(3, int(getattr(tuning, "inbox_max_posts", 10)) * 2)]

    state["replied_ts"] = replied_ts
    state["reply_inbox_cache"] = {"ts": now, "items": items}
    return items

def try_reply_priority_queue(
    client: HttpClient,
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    memory: List[Dict[str, Any]],
    semantic: Dict[str, Any],
    policy: Dict[str, Any],
    brain: Dict[str, Any],
    posts_cache: List[Dict[str, Any]],
    comment_limiter: SlidingWindowLimiter,
    comment_pace_sec: int,
    bm25: Optional[BM25Index],
) -> int:
    """(Unit 04) Reply priority queue: replies-to-me first, then my posts."""
    try:
        trace_hit("select:reply_pq:enter")
    except Exception:
        pass

    gap_com = gap_remaining(float(state.get("last_comment_ts", 0.0) or 0.0), int(comment_pace_sec))
    if gap_com > 0:
        protocol_set_reason(state, "comment", "comment:rate_limited", f"gap={int(gap_com)}s")
        return 0
    if comment_limiter.remaining() <= 0:
        protocol_set_reason(state, "comment", "comment:rate_limited", "window_remaining=0")
        return 0

    drives = get_persona_drives(brain)

    inbox = _build_reply_inbox(client, cfg, tuning, state, memory, posts_cache)
    if not inbox:
        protocol_set_reason(state, "comment", "comment:no_target", "inbox_empty")
        return 0


    if _reply_score_v2_enabled(state):
        try:
            now_sc = time.time()
            for it in inbox:
                if not isinstance(it, dict):
                    continue
                sc, br = _reply_score_v2(state, it, now_sc)
                it["score_v2"] = float(sc)
                it["score_v2_br"] = br
            inbox.sort(
                key=lambda it: (
                    float(_safe_float(it.get("score_v2"), _safe_float(it.get("score"), 0.0))),
                    float(_safe_float(it.get("comment_ts"), 0.0)),
                ),
                reverse=True,
            )
            protocol_bump_counter(state, "reply_scored", 1)
        except Exception as e:
            log_debug_exc("reply_score_v2:silent", e)
            pass

    # Pick the first inbox item that passes the conversation protocol gate.
    chosen: Optional[Dict[str, Any]] = None
    chosen_post: Dict[str, Any] = {}
    chosen_comments: List[Dict[str, Any]] = []
    chosen_target: Dict[str, Any] = {}
    chosen_conv_key = ""
    chosen_conv_meta: Dict[str, Any] = {}

    posts_by_id: Dict[str, Dict[str, Any]] = {str(p.get("id") or ""): p for p in (posts_cache or []) if isinstance(p, dict)}
    comments_cache: Dict[str, List[Dict[str, Any]]] = {}
    last_gate_reason = ""

    for top in inbox[: min(12, len(inbox))]:
        if (not bool(top.get("reply_to_my_comment"))) and drives.get("debate", 0.7) < 0.45 and random.random() < 0.6:
            continue

        pid = str(top.get("post_id") or "")
        cid = str(top.get("comment_id") or "")
        if not pid or not cid:
            continue

        post = posts_by_id.get(pid)
        if not isinstance(post, dict) or not str(post.get("id") or ""):
            post = get_post(client, pid) or {}
            posts_by_id[pid] = post if isinstance(post, dict) else {}

        try:
            comments = comments_cache.get(pid)
            if comments is None:
                comments = list_comments(client, pid)
                comments_cache[pid] = comments
        except Exception:
            comments = []
            comments_cache[pid] = []

        if not comments:
            continue

        target_c = None
        for c in comments:
            if isinstance(c, dict) and str(c.get("id") or "") == cid:
                target_c = c
                break
        if not isinstance(target_c, dict):
            replied_ts = _safe_dict(state.get("replied_ts"))
            replied_ts[f"{pid}:{cid}"] = time.time()
            state["replied_ts"] = replied_ts
            continue


        # toxic/taunt: do not engage directly
        try:
            ttxt = str(target_c.get("content") or "")
        except Exception:
            ttxt = ""
        if ttxt and handle_toxic_target(client, cfg, state, pid, cid, ttxt, tag="priority_queue_select"):
            continue

        ok, conv_key, _conv, conv_meta, reason = _reply_protocol_prepare(state, cfg, tuning, pid, comments, cid, time.time())
        if not ok:
            last_gate_reason = str(reason or "")
            continue

        chosen = top
        chosen_post = post
        chosen_comments = comments
        chosen_target = target_c
        chosen_conv_key = conv_key
        chosen_conv_meta = conv_meta
        break

    if not chosen:
        # inbox exists but nothing eligible (often conversation protocol gate)
        if last_gate_reason:
            protocol_set_reason(state, "comment", "comment:qa_fail", f"protocol_gate:{one_line(last_gate_reason, 120)}")
        else:
            protocol_set_reason(state, "comment", "comment:no_target", "no_eligible_inbox")
        return 0

    top = chosen

    if _reply_score_v2_enabled(state):
        try:
            br = _safe_dict(top.get("score_v2_br"))
            if br:
                log_event(
                    "reply.score_breakdown",
                    post_id=str(top.get("post_id") or ""),
                    comment_id=str(top.get("comment_id") or ""),
                    score=float(top.get("score_v2", top.get("score", 0.0)) or 0.0),
                    breakdown=br,
                )
        except Exception:
            pass

    if not pid or not cid:
        protocol_set_reason(state, "comment", "comment:no_target", "missing_pid_or_cid")
        return 0

    # use previously fetched post/comments/target
    post = chosen_post
    comments = chosen_comments
    target_c = chosen_target

    now = time.time()
    replied_ts = _safe_dict(state.get("replied_ts"))
    replied_ts[f"{pid}:{cid}"] = replied_ts.get(f"{pid}:{cid}", 0.0) or 0.0  # keep key

    # build context
    ingest_post_into_context(state, post, brain=brain)
    ingest_comments_into_context(state, pid, comments, brain=brain, cfg=cfg)
    th = get_thread(state, pid)
    synthesize_thread(th)

    user_key = str(target_c.get("nickname") or post.get("nickname") or "user")
    user = get_user(state, user_key)

    # lock focus target
    set_focus(state, mode="reply", post_id=pid, post=post, comment=target_c)

    # pass conversation meta to reply generator
    try:
        state.setdefault("focus", {})
        if isinstance(state.get("focus"), dict):
            state["focus"]["conv"] = chosen_conv_meta
    except Exception as e:
        log_debug_exc("try_reply_priority_queue:silent", e)
        pass

    txt = ""
    meta: Dict[str, Any] = {}
    ok_txt = False
    ground_reason = ""
    qrep: Dict[str, Any] = {}
    last_fail_bucket = ""
    last_fail_detail = ""
    reply_to_own_post = bool(top.get("own_post"))
    last_candidate = ""
    for _try in range(_regen_budget(cfg)):
        txt, meta = build_reply_text(
            cfg, tuning, state, policy, th, user,
            bm25=bm25,
            brain=brain,
            reply_to_own_post=reply_to_own_post,
            is_reply=True,
        )
        base_txt = txt
        last_candidate = base_txt
        focus_d = _safe_dict(state.get("focus"))

        # v5.4 Unit4: LM rerank over small set of Unit1-3 variants (reply queue; gate-first)
        cand_pack: List[Tuple[str, Dict[str, Any]]] = []
        used_lm = False
        if _env_bool("MERSOOM_LM_RERANK", True):

            # P2: feed target human comment into LM (deduped) to better match reply style
            try:
                cid = _comment_id_any(target_c)
                auth = _comment_author_any(target_c)
                cont = _comment_content_any(target_c)
                if auth and auth != cfg.nickname and cont:
                    dlg = state.setdefault("dlg", {})
                    seen_c = dlg.setdefault("lm_seen_comment_ids", {})
                    if not isinstance(seen_c, dict):
                        seen_c = {}
                        dlg["lm_seen_comment_ids"] = seen_c
                    if cid and cid in seen_c:
                        pass
                    else:
                        lm_update_from_text(cfg, semantic, auth, cont)
                        if cid:
                            seen_c[cid] = float(time.time())
                        if len(seen_c) > 1200:
                            items = sorted(((k, float(v or 0.0)) for k, v in seen_c.items()), key=lambda x: x[1])
                            for k, _ts in items[:-900]:
                                seen_c.pop(k, None)
            except Exception:
                pass
            try:
                cand_pack = lm_make_ranked_candidates(
                    cfg, state, semantic, base_txt,
                    mode="reply",
                    target_nick=_comment_author_any(target_c),
                    target_text=_comment_content_any(target_c),
                    k=_env_int("MERSOOM_LM_CAND_K", 8, 2, 16),
                )
                if cand_pack:
                    used_lm = True
                    protocol_bump_counter(state, "lm_rerank_used", 1)
            except Exception:
                cand_pack = []
                used_lm = False

        if not cand_pack:
            # legacy single-candidate path (Units 1-3)
            txt = apply_name_layer(cfg, state, base_txt, mode="reply", target_nick=_comment_author_any(target_c))
            txt = apply_quote_layer(cfg, state, txt, mode="reply", target_text=_comment_content_any(target_c))
            txt = apply_microedit_layer(cfg, state, txt, mode="reply")
            cand_pack = [(txt, {})]

        ok_gate = False
        g_bucket = ""
        g_detail = ""
        g_reason = ""
        accepted_meta: Dict[str, Any] = {}

        for cand_txt, cmeta in cand_pack:
            ok_gate, g_bucket, g_detail, g_reason, _qrep = final_text_gate(
                cfg, state, cand_txt,
                mode="reply", kind="reply",
                focus=focus_d,
                same_text_gap_sec=cfg.timing.same_text_gap_sec,
            )
            if ok_gate:
                txt = cand_txt
                accepted_meta = _safe_dict(cmeta)
                qrep = _safe_dict(_qrep)
                break

        if ok_gate and used_lm:
            _lm_apply_accept_side_effects(state, accepted_meta, target_nick=_comment_author_any(target_c))

        if (not ok_gate) and used_lm:
            protocol_bump_counter(state, "lm_fallback_used", 1)

        if not ok_gate:
            last_fail_bucket = str(g_bucket or "")
            last_fail_detail = str(g_detail or g_bucket or "")
            _bump_gen_fail(state, g_bucket or "qa_fail")
            if str(g_bucket or "").startswith("dup"):
                if (_try % 3) == 0:
                    log_action("DUP", f"block mode=reply reason={g_bucket} try={_try+1}")
            elif str(g_detail or "").startswith("ground:"):
                log_action("VALIDATE", f"fail mode=reply reason={str(g_detail or '')[7:]} try={_try+1}")
            else:
                log_action("QA", f"fail mode=reply {g_detail or 'qa_fail'} try={_try+1}")
            continue
        ok_txt = True
        ground_reason = g_reason
        break

    if not ok_txt:
        fb = _qa_fallback_2stage(last_candidate, is_reply=True)
        if fb:
            try:
                base_fb = fb
                mode2 = "reply"
                focus_d = _safe_dict(state.get("focus"))

                cand_pack: List[Tuple[str, Dict[str, Any]]] = []
                used_lm = False
                if _env_bool("MERSOOM_LM_RERANK", True):
                    try:
                        cand_pack = lm_make_ranked_candidates(
                            cfg, state, semantic, base_fb,
                            mode=mode2,
                            target_nick=user_key,
                            target_text=str(target_c.get("content") or ""),
                            k=_env_int("MERSOOM_LM_CAND_K", 8, 2, 16),
                        )
                        if cand_pack:
                            used_lm = True
                            protocol_bump_counter(state, "lm_rerank_used", 1)
                    except Exception:
                        cand_pack = []
                        used_lm = False

                if not cand_pack:
                    # legacy Units 1-3 on fallback
                    fb2 = apply_name_layer(cfg, state, base_fb, mode=mode2, target_nick=user_key)
                    fb2 = apply_quote_layer(cfg, state, fb2, mode=mode2, target_text=str(target_c.get("content") or ""))
                    fb2 = apply_microedit_layer(cfg, state, fb2, mode=mode2)
                    cand_pack = [(fb2, {})]

                ok_gate = False
                g_bucket = ""
                g_detail = ""
                g_reason = ""
                accepted_meta: Dict[str, Any] = {}

                for cand_txt, cmeta in cand_pack:
                    ok_gate, g_bucket, g_detail, g_reason, _qrep = final_text_gate(
                        cfg, state, cand_txt,
                        mode=mode2, kind=mode2,
                        focus=focus_d,
                        same_text_gap_sec=cfg.timing.same_text_gap_sec,
                    )
                    if ok_gate:
                        fb = cand_txt
                        accepted_meta = _safe_dict(cmeta)
                        qrep = _safe_dict(_qrep)
                        break

                if ok_gate and used_lm:
                    _lm_apply_accept_side_effects(state, accepted_meta, target_nick=user_key)
                if (not ok_gate) and used_lm:
                    protocol_bump_counter(state, "lm_fallback_used", 1)

                if ok_gate:
                    txt = fb
                    ok_txt = True
                    ground_reason = g_reason
                else:
                    last_fail_bucket = str(g_bucket or "")
                    last_fail_detail = str(g_detail or g_bucket or "")
                    _bump_gen_fail(state, g_bucket or "qa_fail")
            except Exception:
                pass

    if not ok_txt:
        replied_ts[f"{pid}:{cid}"] = now
        state["replied_ts"] = replied_ts
        code = "comment:qa_fail"
        if last_fail_bucket == "dup_fp":
            code = "comment:dup_fp"
        elif last_fail_bucket == "dup_sim":
            code = "comment:dup_sim"
        protocol_set_reason(state, "comment", code, one_line(last_fail_detail or last_fail_bucket or "gen_fail", 140))
        return 0

    if not comment_limiter.allow():
        if getattr(cfg, "debug", None) and cfg.debug.log_blocks:
            log_debug("gate:comment blocked by window (allow=false)")
        protocol_set_reason(state, "comment", "comment:rate_limited", "window_allow=false")
        return 0

    _bump_action_counter(state, "action_attempt", "reply")
    try:
        res = create_comment(client, cfg, tuning, state, pid, txt, parent_id=cid)
    except RateLimitError as e_rl:
        protocol_set_reason(state, "comment", "comment:rate_limited", one_line(str(e_rl), 180))
        raise
    except PowTimeoutError as e:
        protocol_set_reason(state, "comment", "comment:pow_timeout", one_line(str(e), 180))
        _bump_action_counter(state, "action_fail", "reply")
        return 0
    except requests.HTTPError as e_http:
        protocol_set_reason(state, "comment", "comment:qa_fail", one_line(str(e_http), 180))
        raise
    except Exception as e:
        protocol_set_reason(state, "comment", "comment:qa_fail", one_line(repr(e), 180))
        raise
    if not res:
        protocol_set_reason(state, "comment", "comment:no_target", "comment_create_failed")
        _bump_action_counter(state, "action_fail", "reply")
        return 0
    _bump_action_counter(state, "action_success", "reply")

    # commit conversation protocol state
    try:
        _reply_protocol_commit(state, chosen_conv_key, now, _extract_comment_id(res), txt)
    except Exception as e:
        log_debug_exc("try_reply_priority_queue:silent", e)
        pass

    remember_text(state, txt, for_post=False, same_text_gap_sec=cfg.timing.same_text_gap_sec)

    fp_ttl = _env_int("MERSOOM_RECENT_TEXT_FP_TTL_SEC", 6 * 3600, 60, 30 * 24 * 3600)

    fp_keep = _env_int("MERSOOM_RECENT_TEXT_FP_KEEP_MAX", 1200, 50, 20000)

    remember_fp(state, txt, for_post=False, ttl_sec=max(int(fp_ttl), int(cfg.timing.same_text_gap_sec)), keep_max=int(fp_keep))
    remember_simhash(state, txt, for_post=False, same_text_gap_sec=cfg.timing.same_text_gap_sec)
    remember_dup_signatures(state, txt, for_post=False, same_text_gap_sec=cfg.timing.same_text_gap_sec)

    replied_ts[f"{pid}:{cid}"] = now
    state["replied_ts"] = replied_ts
    # (19.4) update per-thread debounce timestamp

    cts = _safe_dict(state.get("commented_ts"))

    cts[str(pid)] = now

    state["commented_ts"] = cts

    state["last_comment_ts"] = now
    state["contrib_count_today"] = int(state.get("contrib_count_today", 0)) + 1
    state["total_actions"] = int(state.get("total_actions", 0)) + 1

    action_type = "reply_own" if reply_to_own_post else "reply_other"

    try:
        update_persona_maturity(brain, state)
    except Exception as e:
        log_exception("brain:maturity", e, context={"stage": "try_reply_priority_queue", "action": str(action_type), "post_id": str(pid), "parent_id": str(cid)})
        if _should_failfast("brain") or _should_failfast("contrib"):
            raise

    try:
        bump_semantic(semantic, _today_kst(), action_type, 1.0)
    except Exception as e:
        log_exception("semantic:bump", e, context={"stage": "try_reply_priority_queue", "action": str(action_type), "post_id": str(pid), "parent_id": str(cid), "key": str(action_type)})
        if _should_failfast("semantic") or _should_failfast("contrib"):
            raise

    _bump_relation(state, user_key)

    before = _post_metrics(post)
    item = {
        "ts": now,
        "action": "reply",
        "action_type": action_type,
        "post_id": pid,
        "parent_id": cid,
        "category": meta.get("category", "general"),
        "context_key": meta.get("context_key", "gen"),
        "kw": meta.get("kw", ""),
        "text": txt,
        "used_strategy": meta.get("strategy", ""),
        "used_tone": meta.get("tone", ""),
        "used_length": meta.get("length", ""),
        "used_reply_style": meta.get("reply_style", ""),
        "weak_context": bool(meta.get("weak_context")),
        "template_id": meta.get("template_id", ""),
        "used_quotes": bool(meta.get("used_quotes")),
        "novelty": _novelty_score(state, txt),
        "comment_id": _extract_comment_id(res),
        "qa_score": float(qrep.get("score", 0) or 0),
        "qa_issues": list(qrep.get("issues", []))[:6],
        "qa_rep3": float(qrep.get("rep3", 0.0) or 0.0),
        "qa_im_ratio": float(qrep.get("im_ratio", 0.0) or 0.0),
        "qa_line_prefix_dup": float(qrep.get("line_prefix_dup", 0.0) or 0.0),
        "eval_due_ts": schedule_eval_due(tuning),
        "metrics_before": before,
        "metrics_after": {},
        "evaluated": False,
        "reward_scalar": 0.0,
        "ground_reason": ground_reason,
        "target_nick": user_key,
        # unit 04 metadata
        "inbox": True,
        "inbox_why": str(top.get("why") or ""),
        "inbox_score": float(top.get("score", 0.0) or 0.0),
        "conv_key": str(chosen_conv_key or ""),
        "conv_root": str((chosen_conv_meta or {}).get("root_comment_id") or ""),
        "conv_turns_total": int((chosen_conv_meta or {}).get("turns_total") or 0),
    }
    item["proxy_reward"] = compute_proxy_reward(txt, mode="reply", ground_reason=ground_reason)
    item.setdefault("brain_proxy_applied", False)
    item.setdefault("brain_reward_applied", False)
    record_memory(memory, item, tuning, archive_path_jsonl=cfg.paths.memory_archive_jsonl)
    try:
        apply_brain_proxy_update(brain, tuning, item)
    except Exception as e:
        log_debug_exc("try_reply_priority_queue:silent", e)
        pass

    log_action("REPLY", f"inbox {top.get('why')} post={pid} parent={cid} | {one_line(txt)}")
    return 1

def try_reply_to_own_posts(
    client: HttpClient,
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    memory: List[Dict[str, Any]],
    semantic: Dict[str, Any],
    policy: Dict[str, Any],
    brain: Dict[str, Any],
    posts_cache: List[Dict[str, Any]],
    comment_limiter: SlidingWindowLimiter,
    comment_pace_sec: int,
    bm25: Optional[BM25Index],
) -> int:
    """
    Trait: "내 글에 댓글 달리면 대댓글로 논쟁을 좋아함"을 실행.
    - own post 중 최근/핫한 글을 훑고
    - 상대 댓글 중 아직 대댓글을 안단 것에 우선 응답
    """
    try:
        trace_hit("select:reply_own:enter")
    except Exception:
        pass

    gap_com = gap_remaining(float(state.get("last_comment_ts", 0.0) or 0.0), int(comment_pace_sec))
    if gap_com > 0:
        return 0
    if comment_limiter.remaining() <= 0:
        return 0

    drives = get_persona_drives(brain)
    maturity = get_maturity_level(brain, state)

    # reply preference gate (avoid spamming if debate drive is low)
    if drives.get("debate", 0.7) < 0.45 and random.random() < 0.6:
        return 0

    replied_ts = _safe_dict(state.get("replied_ts"))
    now = time.time()

    # pick candidate own posts with comments
    own_posts = [p for p in posts_cache if isinstance(p, dict) and is_own_post(cfg, p)]
    # prioritize: more comments / score
    own_posts.sort(key=lambda p: (_post_metrics(p).get("comments", 0), _post_metrics(p).get("score", 0)), reverse=True)
    own_posts = own_posts[:6]

    for p in own_posts:
        pid = str(p.get("id") or "")
        if not pid:
            continue
        # skip posts with no comments (as per cached metrics)
        if int(_post_metrics(p).get("comments", 0)) <= 0:
            continue

        try:
            comments = list_comments(client, pid)
        except Exception:
            comments = []

        if not comments:
            continue

        # find a fresh other comment to reply to
        target_c = None
        for c in reversed(comments[-18:]):
            if not isinstance(c, dict):
                continue
            if is_own_comment(cfg, c):
                continue
            cid = str(c.get("id") or "")
            if not cid:
                continue
            key = f"{pid}:{cid}"
            # local cooldown
            last = float(replied_ts.get(key, 0.0) or 0.0)
            if last > 0 and (now - last) < 60 * 60 * 24 * 7:
                continue
            # server-side: already replied?
            if _has_replied_to_comment(cfg, comments, cid):
                replied_ts[key] = now
                continue
            target_c = c
            break

        if not target_c:
            continue

        cid = str(target_c.get("id") or "")
        if not cid:
            continue

        # conversation protocol: do not reply twice without new remote turn
        okp, conv_key, _conv, conv_meta, reason = _reply_protocol_prepare(state, cfg, tuning, pid, comments, cid, now)
        if not okp:
            replied_ts[f"{pid}:{cid}"] = now
            state["replied_ts"] = replied_ts
            continue

        # build context
        ingest_post_into_context(state, p, brain=brain)
        ingest_comments_into_context(state, pid, comments, brain=brain, cfg=cfg)
        th = get_thread(state, pid)
        synthesize_thread(th)

        user_key = str(target_c.get("nickname") or p.get("nickname") or "user")
        user = get_user(state, user_key)

        set_focus(state, mode="reply", post_id=pid, post=p, comment=target_c)

        # pass conversation meta to reply generator
        try:
            state.setdefault("focus", {})
            if isinstance(state.get("focus"), dict):
                state["focus"]["conv"] = conv_meta
        except Exception as e:
            log_debug_exc("try_reply_to_own_posts:silent", e)
            pass

        txt = ""
        meta: Dict[str, Any] = {}
        ok_txt = False
        ground_reason = ""
        qrep: Dict[str, Any] = {}
        last_candidate = ""
        for _try in range(_regen_budget(cfg)):
            txt, meta = build_reply_text(
                cfg, tuning, state, policy, th, user,
                bm25=bm25,
                brain=brain,
                reply_to_own_post=True,
                is_reply=True,
            )
            last_candidate = txt
            # v5.1 Unit1: resolve <NAME> + optional greeting for replies
            txt = apply_name_layer(cfg, state, txt, mode="reply", target_nick=user_key)
            # v5.2 Unit2: inject a short quote from the target comment (replies only)
            txt = apply_quote_layer(cfg, state, txt, mode="reply", target_text=str(target_c.get("content") or ""))
            txt = apply_microedit_layer(cfg, state, txt, mode="reply")
            focus_d = _safe_dict(state.get("focus"))
            ok_gate, g_bucket, g_detail, g_reason, _qrep = final_text_gate(
                cfg, state, txt,
                mode="reply", kind="reply",
                focus=focus_d,
                same_text_gap_sec=cfg.timing.same_text_gap_sec,
            )
            if not ok_gate:
                _bump_gen_fail(state, g_bucket or "qa_fail")
                if str(g_bucket or "").startswith("dup"):
                    if (_try % 3) == 0:
                        log_action("DUP", f"block mode=reply reason={g_bucket} try={_try+1}")
                elif str(g_detail or "").startswith("ground:"):
                    log_action("VALIDATE", f"fail mode=reply reason={str(g_detail or '')[7:]} try={_try+1}")
                else:
                    log_action("QA", f"fail mode=reply {g_detail or 'qa_fail'} try={_try+1}")
                continue
            qrep = _safe_dict(_qrep)
            ok_txt = True
            ground_reason = g_reason
            break

        if not ok_txt:
            fb = _qa_fallback_2stage(last_candidate, is_reply=True)
            if fb:
                try:
                    # v5.1 Unit1: apply name layer to fallback candidate
                    fb = apply_name_layer(cfg, state, fb, mode="reply", target_nick=user_key)
                    # v5.2 Unit2: inject a short quote from the target comment (replies only)
                    fb = apply_quote_layer(cfg, state, fb, mode="reply", target_text=str(target_c.get("content") or ""))
                    fb = apply_microedit_layer(cfg, state, fb, mode="reply")
                    focus_d = _safe_dict(state.get("focus"))
                    ok_gate, g_bucket, g_detail, g_reason, _qrep = final_text_gate(
                        cfg, state, fb,
                        mode="reply", kind="reply",
                        focus=focus_d,
                        same_text_gap_sec=cfg.timing.same_text_gap_sec,
                    )
                    if ok_gate:
                        txt = fb
                        qrep = _safe_dict(_qrep)
                        ok_txt = True
                        ground_reason = g_reason
                    else:
                        _bump_gen_fail(state, g_bucket or "qa_fail")
                except Exception:
                    pass
            if not ok_txt:
                # don't burn limiter on low-quality / near-duplicate
                replied_ts[f"{pid}:{cid}"] = now
                state["replied_ts"] = replied_ts
                continue

        if not comment_limiter.allow():
            if getattr(cfg, "debug", None) and cfg.debug.log_blocks:
                log_debug("gate:comment blocked by window (allow=false)")
            return 0

        res = create_comment(client, cfg, tuning, state, pid, txt, parent_id=cid)
        if not res:
            _bump_action_counter(state, "action_fail", "post")
            return 0

        # commit conversation protocol state
        try:
            _reply_protocol_commit(state, conv_key, now, _extract_comment_id(res), txt)
        except Exception as e:
            log_debug_exc("try_reply_to_own_posts:silent", e)
            pass

        remember_text(state, txt, for_post=False, same_text_gap_sec=cfg.timing.same_text_gap_sec)

        fp_ttl = _env_int("MERSOOM_RECENT_TEXT_FP_TTL_SEC", 6 * 3600, 60, 30 * 24 * 3600)

        fp_keep = _env_int("MERSOOM_RECENT_TEXT_FP_KEEP_MAX", 1200, 50, 20000)

        remember_fp(state, txt, for_post=False, ttl_sec=max(int(fp_ttl), int(cfg.timing.same_text_gap_sec)), keep_max=int(fp_keep))
        remember_simhash(state, txt, for_post=False, same_text_gap_sec=cfg.timing.same_text_gap_sec)
        remember_dup_signatures(state, txt, for_post=False, same_text_gap_sec=cfg.timing.same_text_gap_sec)

        replied_ts[f"{pid}:{cid}"] = now
        state["replied_ts"] = replied_ts
        # (19.4) update per-thread debounce timestamp

        cts = _safe_dict(state.get("commented_ts"))

        cts[str(pid)] = now

        state["commented_ts"] = cts

        state["last_comment_ts"] = now
        state["contrib_count_today"] = int(state.get("contrib_count_today", 0)) + 1
        state["total_actions"] = int(state.get("total_actions", 0)) + 1

        try:
            update_persona_maturity(brain, state)
        except Exception as e:
            log_exception("brain:maturity", e, context={"stage": "try_reply_to_own_posts", "action": "reply_own", "post_id": str(pid), "parent_id": str(cid)})
            if _should_failfast("brain") or _should_failfast("contrib"):
                raise

        try:
            bump_semantic(semantic, _today_kst(), "reply_own", 1.0)
        except Exception as e:
            log_exception("semantic:bump", e, context={"stage": "try_reply_to_own_posts", "action": "reply_own", "post_id": str(pid), "parent_id": str(cid), "key": "reply_own"})
            if _should_failfast("semantic") or _should_failfast("contrib"):
                raise

        _bump_relation(state, user_key)

        before = _post_metrics(p)
        item = {
            "ts": now,
            "action": "reply",
            "action_type": "reply_own",
            "post_id": pid,
            "parent_id": cid,
            "category": meta.get("category", "general"),
            "context_key": meta.get("context_key", "gen"),
            "kw": meta.get("kw", ""),
            "text": txt,
            "used_strategy": meta.get("strategy", ""),
            "used_tone": meta.get("tone", ""),
            "used_length": meta.get("length", ""),
            "used_reply_style": meta.get("reply_style", ""),
            "weak_context": bool(meta.get("weak_context")),
            "template_id": meta.get("template_id", ""),
            "used_quotes": bool(meta.get("used_quotes")),
            "novelty": _novelty_score(state, txt),
        "comment_id": _extract_comment_id(res),
        "qa_score": float(qrep.get("score", 0) or 0),
        "qa_issues": list(qrep.get("issues", []))[:6],
        "qa_rep3": float(qrep.get("rep3", 0.0) or 0.0),
        "qa_im_ratio": float(qrep.get("im_ratio", 0.0) or 0.0),
        "qa_line_prefix_dup": float(qrep.get("line_prefix_dup", 0.0) or 0.0),
            "eval_due_ts": schedule_eval_due(tuning),
            "metrics_before": before,
            "metrics_after": {},
            "evaluated": False,
            "reward_scalar": 0.0,
        }
        item["ground_reason"] = ground_reason
        item["target_nick"] = user_key
        item["proxy_reward"] = compute_proxy_reward(txt, mode="reply", ground_reason=ground_reason)
        item.setdefault("brain_proxy_applied", False)
        item.setdefault("brain_reward_applied", False)
        record_memory(memory, item, tuning, archive_path_jsonl=cfg.paths.memory_archive_jsonl)
        try:
            apply_brain_proxy_update(brain, tuning, item)
        except Exception as e:
            log_debug_exc("try_reply_to_own_posts:silent", e)
            pass

        log_action("REPLY", f"own_post={pid} parent={cid} | {one_line(txt)}")
        return 1

    return 0
