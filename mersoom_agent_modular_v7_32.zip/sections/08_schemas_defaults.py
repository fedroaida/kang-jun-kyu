################################################################################
# 08. SCHEMAS & DEFAULTS
# Deps: 01-03
# Used by: state/memory/policy/brain IO
# Notes: Dataclasses + default_* schema builders.
################################################################################
"""
SECTION 08 - SCHEMAS + DEFAULTS

Schema stamps, default state shapes, and reusable small dataclasses.

Responsibilities:
- Define default structure for state/memory/policy/brain artifacts.
- Provide helpers to create/validate missing keys safely.
- Central place for constants (thresholds) when we start consolidating magic numbers.

Notes:
- Keep backward compatibility: add fields, do not rename/remove existing keys lightly.
"""
@dataclass(frozen=True)
class AgentTuning:
    # feed fetch
    fetch_limit: int
    arena_fetch_limit: int

    # memory
    memory_size: int

    # evaluation scheduling (per-action)
    eval_delay_min_sec: int
    eval_delay_max_sec: int
    max_eval_per_tick: int

    # learning batch cadence (global) ✅ batched cadence control
    learn_period_sec: int
    max_learn_updates_per_run: int

    # arena
    arena_cooldown_sec: int

    # reward shaping
    alpha_score: float
    alpha_up: float
    alpha_down: float
    alpha_comments: float
    alpha_novelty: float
    alpha_quotes: float
    alpha_quality: float
    alpha_continuation: float
    alpha_weak_context_penalty: float
    reward_clip: float


    reward_w_up: float
    reward_w_engage: float
    reward_w_risk: float

    # policy defaults
    policy_epsilon: float
    policy_lr: float
    policy_min_weight: float

    # brain EMA
    brain_topic_alpha: float
    brain_reward_alpha: float

    # output formatting
    max_output_lines: int

    # community flow + thoughts
    flow_half_life_hours: float
    scan_posts_per_sync: int
    max_thoughts: int

    # (P1) bm25 rebuild pacing
    bm25_rebuild_min_add: int
    bm25_rebuild_min_sec: int

    # (Unit 06) quote discipline (BM25)
    quote_min_score: float
    quote_max_chars: int
    quote_min_gap_sec: int

    # (Unit 04) inbox / thread-priority replies
    inbox_max_posts: int
    inbox_scan_comments_per_post: int
    inbox_recent_thread_days: int
    inbox_scan_min_sec: int

    # Conversation protocol (turn-taking for reply threads)
    reply_conv_skip_cooldown_sec: int
    reply_conv_budget_cap: int
    reply_question_base_prob: float
    reply_question_my_post_prob: float
    reply_question_when_asked_prob: float

    # (Unit 07) reflection influence on bandit choices
    reflection_influence: bool
    reflection_boost: float
    reflection_min_strength: float
    reflection_topk: int
    reflection_decay: float

def load_tuning_from_env() -> AgentTuning:
    def env_int(name: str, d: int, lo: int, hi: int) -> int:
        return _env_int(name, d, min_v=lo, max_v=hi)

    def env_float(name: str, d: float, lo: float, hi: float) -> float:
        return _env_float(name, d, min_v=lo, max_v=hi)

    # ✅ 기본 15분(900초) cadence (v15.6)
    eval_min = env_int("MERSOOM_EVAL_DELAY_MIN_SEC", 13 * 60, 60, 24 * 60 * 60)
    eval_max = env_int("MERSOOM_EVAL_DELAY_MAX_SEC", 17 * 60, 60, 24 * 60 * 60)
    if eval_max < eval_min:
        eval_max = eval_min

    learn_period = env_int("MERSOOM_LEARN_PERIOD_SEC", 15 * 60, 60, 24 * 60 * 60)

    return AgentTuning(
        fetch_limit=env_int("MERSOOM_FETCH_LIMIT", 10, 1, 200),
        arena_fetch_limit=env_int("MERSOOM_ARENA_FETCH_LIMIT", 40, 1, 400),

        memory_size=env_int("MERSOOM_MEMORY_SIZE", 140, 10, 5000),

        eval_delay_min_sec=eval_min,
        eval_delay_max_sec=eval_max,
        max_eval_per_tick=env_int("MERSOOM_MAX_EVAL_PER_TICK", 1, 1, 200),

        learn_period_sec=learn_period,
        max_learn_updates_per_run=env_int("MERSOOM_MAX_LEARN_UPDATES_PER_RUN", 500, 10, 100_000),

        arena_cooldown_sec=env_int("MERSOOM_ARENA_COOLDOWN_SEC", 2 * 60 * 60, 60, 24 * 60 * 60),

        alpha_score=env_float("MERSOOM_ALPHA_SCORE", 1.0, 0.0, 10.0),
        alpha_up=env_float("MERSOOM_ALPHA_UP", 1.0, 0.0, 10.0),
        alpha_down=env_float("MERSOOM_ALPHA_DOWN", 2.0, 0.0, 10.0),
        alpha_comments=env_float("MERSOOM_ALPHA_COMMENTS", 0.2, 0.0, 10.0),
        alpha_novelty=env_float("MERSOOM_ALPHA_NOVELTY", 0.30, 0.0, 10.0),
        alpha_quotes=env_float("MERSOOM_ALPHA_QUOTES", 0.15, 0.0, 10.0),
        alpha_quality=env_float("MERSOOM_ALPHA_QUALITY", 0.08, 0.0, 10.0),
        alpha_continuation=env_float("MERSOOM_ALPHA_CONT", 0.25, 0.0, 10.0),
        alpha_weak_context_penalty=env_float("MERSOOM_ALPHA_WEAKCTX", 0.12, 0.0, 10.0),
        reward_clip=env_float("MERSOOM_REWARD_CLIP", 3.0, 0.1, 50.0),


        reward_w_up=env_float("MERSOOM_REWARD_W_UP", 1.0, 0.0, 10.0),
        reward_w_engage=env_float("MERSOOM_REWARD_W_ENGAGE", 0.6, 0.0, 10.0),
        reward_w_risk=env_float("MERSOOM_REWARD_W_RISK", 1.2, 0.0, 10.0),

        policy_epsilon=env_float("MERSOOM_POLICY_EPSILON", 0.15, 0.0, 0.95),
        policy_lr=env_float("MERSOOM_POLICY_LR", 0.12, 0.0, 2.0),
        policy_min_weight=env_float("MERSOOM_POLICY_MIN_WEIGHT", 0.05, 0.0001, 10.0),

        brain_topic_alpha=env_float("MERSOOM_BRAIN_TOPIC_ALPHA", 0.18, 0.01, 0.8),
        brain_reward_alpha=env_float("MERSOOM_BRAIN_REWARD_ALPHA", 0.12, 0.01, 0.8),

        max_output_lines=env_int("MERSOOM_MAX_OUTPUT_LINES", 4, 1, 20),

        flow_half_life_hours=env_float("MERSOOM_FLOW_HALF_LIFE_HOURS", 6.0, 0.5, 72.0),
        scan_posts_per_sync=env_int("MERSOOM_SCAN_POSTS_PER_SYNC", 12, 1, 80),
        max_thoughts=env_int("MERSOOM_MAX_THOUGHTS", 400, 50, 5000),

        bm25_rebuild_min_add=env_int("MERSOOM_BM25_REBUILD_MIN_ADD", 6, 1, 200),
        bm25_rebuild_min_sec=env_int("MERSOOM_BM25_REBUILD_MIN_SEC", 600, 30, 60 * 60),

        quote_min_score=env_float("MERSOOM_QUOTE_MIN_SCORE", 18.0, 0.0, 100.0),
        quote_max_chars=env_int("MERSOOM_QUOTE_MAX_CHARS", 140, 40, 400),
        quote_min_gap_sec=env_int("MERSOOM_QUOTE_MIN_GAP_SEC", 180, 0, 3600),

        inbox_max_posts=env_int("MERSOOM_INBOX_MAX_POSTS", 10, 2, 40),
        inbox_scan_comments_per_post=env_int("MERSOOM_INBOX_SCAN_COMMENTS_PER_POST", 40, 10, 200),
        inbox_recent_thread_days=env_int("MERSOOM_INBOX_RECENT_THREAD_DAYS", 3, 1, 30),
        inbox_scan_min_sec=env_int("MERSOOM_INBOX_SCAN_MIN_SEC", 90, 15, 60 * 30),
        reply_conv_skip_cooldown_sec=env_int("MERSOOM_REPLY_CONV_SKIP_COOLDOWN_SEC", 10 * 60, 30, 24 * 60 * 60),
        reply_conv_budget_cap=env_int("MERSOOM_REPLY_CONV_BUDGET_CAP", 1, 1, 5),
        reply_question_base_prob=env_float("MERSOOM_REPLY_QUESTION_BASE_PROB", 0.25, 0.0, 1.0),
        reply_question_my_post_prob=env_float("MERSOOM_REPLY_QUESTION_MY_POST_PROB", 0.18, 0.0, 1.0),
        reply_question_when_asked_prob=env_float("MERSOOM_REPLY_QUESTION_WHEN_ASKED_PROB", 0.85, 0.0, 1.0),

        # (Unit 07) reflection influence
        reflection_influence=_env_bool("MERSOOM_REFLECTION_INFLUENCE", True),
        reflection_boost=env_float("MERSOOM_REFLECTION_BOOST", 0.35, 0.0, 2.0),
        reflection_min_strength=env_float("MERSOOM_REFLECTION_MIN_STRENGTH", 0.60, 0.0, 1.0),
        reflection_topk=env_int("MERSOOM_REFLECTION_TOPK", 3, 1, 10),
        reflection_decay=env_float("MERSOOM_REFLECTION_DECAY", 0.85, 0.50, 1.00),
    )
