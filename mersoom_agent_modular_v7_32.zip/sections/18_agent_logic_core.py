################################################################################
# 18. AGENT LOGIC CORE
# Deps: 01-17
# Used by: main loop
# Notes: Decide actions; glue for components.
################################################################################
"""
SECTION 18 - AGENT CORE LOGIC

High-level orchestration helpers shared by multiple flows.

Responsibilities:
- Common action helpers (compose inputs, resolve targets, small state updates).
- Provide utilities used by both 'contrib' and 'arena' flows.

Notes:
- Keep this layer stable; avoid pulling in too many dependencies.
"""
@dataclass
class ActionResult:
    ok: bool
    code: str
    detail: str = ""
    http_status: Optional[int] = None
    elapsed_ms: float = 0.0

def _bump_action_counter(state: Dict[str, Any], key: str, action: str) -> None:
    try:
        protocol_bump_counter(state, key, 1)
        protocol_bump_counter(state, f"{key}:{action}", 1)
    except Exception:
        pass

@lru_cache(maxsize=4096)
def _text_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def _clean_hash_list(items: List[List[Any]], ttl_sec: int, keep_max: int) -> List[List[Any]]:
    now = time.time()
    out: List[List[Any]] = []
    for it in items:
        try:
            h, ts = it[0], float(it[1])
            if (now - ts) <= ttl_sec:
                out.append([h, ts])
        except Exception:
            continue
    return out[-keep_max:]

def _clean_hash_map(m: Dict[str, float], ttl_sec: int, keep_max: int) -> Dict[str, float]:
    """Clean {hash: ts} map by TTL and cap (keeps most recent)."""
    now = time.time()
    ttl = max(1, int(ttl_sec))
    km = max(1, int(keep_max))

    # drop expired
    try:
        expired = [h for h, ts in m.items() if (now - float(ts)) > ttl]
        for h in expired:
            m.pop(h, None)
    except Exception:
        # if map is malformed, reset
        return {}

    # cap
    if len(m) > km:
        try:
            items = sorted(m.items(), key=lambda kv: float(kv[1]))
            # keep newest km
            m = dict(items[-km:])
        except Exception:
            pass
    return m

def _recent_hashes_get(state: Dict[str, Any], key: str) -> Dict[str, float]:
    """Back-compat: accept list[[hash,ts],...] or dict{hash:ts}. Returns dict."""
    v = state.get(key)
    if isinstance(v, dict):
        # ensure float values
        out: Dict[str, float] = {}
        for h, ts in v.items():
            try:
                out[str(h)] = float(ts)
            except Exception:
                continue
        return out
    if isinstance(v, list):
        out2: Dict[str, float] = {}
        for it in v:
            try:
                h, ts = it[0], float(it[1])
                out2[str(h)] = float(ts)
            except Exception:
                continue
        return out2
    return {}

def _recent_hashes_set(state: Dict[str, Any], key: str, m: Dict[str, float]) -> None:
    # store as dict for O(1) membership
    state[key] = {str(h): float(ts) for h, ts in m.items()}

def _dup_action_guard_enabled() -> bool:
    return _env_bool("MERSOOM_DUP_ACTION_GUARD", True)

def _dup_action_ttl_sec() -> int:
    return _env_int("MERSOOM_DUP_ACTION_TTL_SEC", 1200, 600, 1800)

def _dup_action_keep_max() -> int:
    return _env_int("MERSOOM_DUP_ACTION_KEEP_MAX", 800, 100, 5000)

def _dup_action_fp(action: str, target_id: str, endpoint_key: str) -> str:
    return f"{action}|{target_id}|{endpoint_key}"

def _recent_actions_get(state: Dict[str, Any]) -> Dict[str, float]:
    ra = state.get("recent_actions")
    if not isinstance(ra, dict):
        ra = {}
    out: Dict[str, float] = {}
    for k, v in ra.items():
        try:
            out[str(k)] = float(v)
        except Exception:
            continue
    return out

def _recent_actions_set(state: Dict[str, Any], ra: Dict[str, float]) -> None:
    state["recent_actions"] = {str(k): float(v) for k, v in ra.items()}

def _clean_recent_actions(ra: Dict[str, float], ttl_sec: int, keep_max: int) -> Dict[str, float]:
    now = time.time()
    ttl = max(60, int(ttl_sec))
    km = max(50, int(keep_max))
    try:
        expired = [k for k, ts in ra.items() if (now - float(ts)) > ttl]
        for k in expired:
            ra.pop(k, None)
    except Exception:
        return {}
    if len(ra) > km:
        try:
            items = sorted(ra.items(), key=lambda kv: float(kv[1]))
            ra = dict(items[-km:])
        except Exception:
            pass
    return ra

def dup_action_should_skip(state: Dict[str, Any], *, action: str, target_id: str, endpoint_key: str) -> bool:
    if not _dup_action_guard_enabled():
        return False
    fp = _dup_action_fp(action, target_id, endpoint_key)
    ra = _recent_actions_get(state)
    ra = _clean_recent_actions(ra, _dup_action_ttl_sec(), _dup_action_keep_max())
    _recent_actions_set(state, ra)
    if fp in ra:
        protocol_bump_counter(state, "dup_action_skip", 1)
        return True
    return False

def remember_action(state: Dict[str, Any], *, action: str, target_id: str, endpoint_key: str) -> None:
    if not _dup_action_guard_enabled():
        return
    fp = _dup_action_fp(action, target_id, endpoint_key)
    ra = _recent_actions_get(state)
    ra[fp] = time.time()
    ra = _clean_recent_actions(ra, _dup_action_ttl_sec(), _dup_action_keep_max())
    _recent_actions_set(state, ra)


def recently_used_text(state: Dict[str, Any], text: str, *, for_post: bool, same_text_gap_sec: int) -> bool:
    key = "recent_post_text_hashes" if for_post else "recent_text_hashes"
    m = _recent_hashes_get(state, key)
    m = _clean_hash_map(m, int(same_text_gap_sec), 800)
    _recent_hashes_set(state, key, m)
    h = _text_hash(str(text or ""))
    return h in m

def remember_text(state: Dict[str, Any], text: str, *, for_post: bool, same_text_gap_sec: int) -> None:
    key = "recent_post_text_hashes" if for_post else "recent_text_hashes"
    m = _recent_hashes_get(state, key)
    h = _text_hash(str(text or ""))
    m[h] = time.time()
    m = _clean_hash_map(m, int(same_text_gap_sec), 800)
    _recent_hashes_set(state, key, m)


@lru_cache(maxsize=4096)
def _normalize_for_fp(text: str) -> str:
    # Compact fingerprint normalization to catch "same meaning, tiny edits"
    s = one_line(str(text or ""), 2000).strip().lower()
    s = re.sub(r"\s+", "", s)
    # keep only alnum + hangul
    s = re.sub(r"[^0-9a-z가-힣]+", "", s)
    # drop common eumssum endings (best-effort)
    for suf in ("입니다", "임", "음", "슴", "함"):
        if s.endswith(suf) and len(s) > len(suf) + 8:
            s = s[: -len(suf)]
            break
    return s[:800]

@lru_cache(maxsize=4096)
def _text_fp(text: str) -> str:
    n = _normalize_for_fp(text)
    return hashlib.sha1(n.encode("utf-8")).hexdigest()

def recently_used_fp(state: Dict[str, Any], text: str, *, for_post: bool, ttl_sec: int, keep_max: int) -> bool:
    key = "recent_post_text_fps" if for_post else "recent_text_fps"
    state[key] = _clean_hash_list(_safe_list(state.get(key, [])), int(ttl_sec), int(keep_max))
    fp = _text_fp(text)
    return any(x[0] == fp for x in state.get(key, []))

def remember_fp(state: Dict[str, Any], text: str, *, for_post: bool, ttl_sec: int, keep_max: int) -> None:
    key = "recent_post_text_fps" if for_post else "recent_text_fps"
    state[key] = _clean_hash_list(_safe_list(state.get(key, [])), int(ttl_sec), int(keep_max))
    state.setdefault(key, [])
    state[key].append([_text_fp(text), time.time()])


def is_own_post(cfg: Config, p: Dict[str, Any]) -> bool:
    return str(p.get("nickname") or "").strip() == cfg.nickname

def is_own_comment(cfg: Config, c: Dict[str, Any]) -> bool:
    return str(c.get("nickname") or "").strip() == cfg.nickname

def _post_metrics(p: Dict[str, Any]) -> Dict[str, int]:
    up = int(p.get("upvotes") or p.get("up") or p.get("likes") or 0)
    down = int(p.get("downvotes") or p.get("down") or 0)
    comm = int(p.get("comment_count") or p.get("comments") or p.get("replies") or 0)
    score = int(p.get("score") or (up - down) or 0)
    return {"up": up, "down": down, "comments": comm, "score": score}

def schedule_eval_due(tuning: AgentTuning) -> float:
    lo = int(tuning.eval_delay_min_sec)
    hi = int(tuning.eval_delay_max_sec)
    if hi < lo:
        hi = lo
    return time.time() + random.randint(lo, hi)

def _novelty_score(state: Dict[str, Any], text: str) -> float:
    # (P0) use token entropy + simhash distance as a cheap novelty proxy
    try:
        if recently_used_text(state, text, for_post=False, same_text_gap_sec=3600 * 6):
            return 0.0
        tokens = tokenize(text, max_tokens=220)
        ent = _token_entropy(tokens)

        key = "recent_simhashes"
        state[key] = _clean_hash_list(_safe_list(state.get(key, [])), 6 * 3600, 1200)
        sh = int(simhash64(tokens[:160])) if tokens else 0
        min_h = 64
        for it in _safe_list(state.get(key, []))[-200:]:
            try:
                old_sh = int(it[0])
                min_h = min(min_h, hamming64(sh, old_sh))
            except Exception:
                continue
        dist_score = max(0.0, min(1.0, float(min_h) / 32.0))  # 0~1
        # entropy is usually the main signal; distance score prevents tiny paraphrase loops
        return max(0.0, min(1.0, 0.10 + 0.70 * float(ent) + 0.20 * float(dist_score)))
    except Exception:
        return 0.7

def _simple_summary(text: str, *, max_len: int = 120) -> str:
    s = split_sentences(text, max_sent=2)
    if not s:
        return one_line(text, max_len)
    out = s[0]
    if len(out) > max_len:
        out = out[:max_len].rstrip() + "…"
    return out

def _decay_mul(dt_sec: float, half_life_hours: float) -> float:
    hl = max(0.1, float(half_life_hours)) * 3600.0
    # 0.5 ** (dt/hl)
    try:
        return float(0.5 ** (max(0.0, dt_sec) / max(1e-9, hl)))
    except Exception:
        return 1.0

def _thought_keep_score(it: Dict[str, Any], now: float) -> float:
    """Score thoughts for pruning: keep strong + used + recently used."""
    try:
        strength = float(it.get("strength", 0.5) or 0.5)
    except Exception:
        strength = 0.5
    strength = max(0.0, min(1.0, strength))

    uses = int(it.get("uses", 0) or 0) if isinstance(it.get("uses", 0), (int, float, str)) else 0
    uses = max(0, min(10_000, uses))

    ts = float(it.get("ts", now) or now) if isinstance(it.get("ts", now), (int, float, str)) else now
    last_used = float(it.get("last_used_ts", ts) or ts) if isinstance(it.get("last_used_ts", ts), (int, float, str)) else ts
    last = max(ts, last_used)

    age = max(0.0, now - last)
    # 0..1, higher = more recent
    recency = 1.0 / (1.0 + (age / (7.0 * 86400.0)))

    # bounded, stable
    return (1.3 * strength) + (0.18 * math.log1p(uses)) + (0.95 * recency)

def _prune_thoughts(brain: Dict[str, Any], *, maxn: int) -> None:
    """Prune brain.thoughts in-place, preserving some recency + value."""
    thoughts = brain.get("thoughts")
    if not isinstance(thoughts, list):
        return
    if len(thoughts) <= maxn:
        return

    now = time.time()
    keep_recent = min(30, max(10, int(maxn * 0.08)))
    recent = [t for t in thoughts[-keep_recent:] if isinstance(t, dict)]
    rest = [t for t in thoughts[:-keep_recent] if isinstance(t, dict)]

    # score + keep best
    scored = [(float(_thought_keep_score(t, now)), t) for t in rest]
    scored.sort(key=lambda x: x[0])  # low -> high
    keep_budget = max(0, maxn - len(recent))
    kept = [t for _, t in scored[-keep_budget:]]

    # keep deterministic order
    kept.sort(key=lambda t: float(t.get("ts", now) or now))
    recent.sort(key=lambda t: float(t.get("ts", now) or now))
    brain["thoughts"] = (kept + recent)[-maxn:]

def mark_thought_used(brain: Dict[str, Any], thought_id: str) -> None:
    """Update lightweight usage stats to improve pruning and retrieval."""
    if not thought_id or not isinstance(brain, dict):
        return
    thoughts = brain.get("thoughts")
    if not isinstance(thoughts, list):
        return
    now = time.time()
    for it in reversed(thoughts[-800:]):
        if isinstance(it, dict) and str(it.get("id") or "") == str(thought_id):
            it["uses"] = int(it.get("uses", 0) or 0) + 1
            it["last_used_ts"] = now
            return

def add_thought(
    brain: Dict[str, Any],
    *,
    kind: str,
    topic: str,
    text: str,
    tags: List[str],
    links: Dict[str, Any],
    strength: float = 0.5,
    card: Optional[Dict[str, Any]] = None,
    signals: Optional[Dict[str, Any]] = None,
    ctx: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Append a compact 'thought' into brain.thoughts (bounded + value-pruned).

    final6:
      - Adds optional structured fields (card/signals/ctx) to improve recall quality
        without breaking backward compatibility.
      - text remains the primary retrieval string; card is additional metadata.
    """
    if not isinstance(brain, dict):
        return ""

    brain.setdefault("thoughts", [])
    brain["thought_seq"] = int(brain.get("thought_seq", 0) or 0) + 1
    seq = int(brain.get("thought_seq", 0) or 0)
    tid = f"t{seq:08d}"

    def _safe_small_dict(x: Any, *, max_items: int = 20, max_k: int = 40, max_v: int = 220) -> Dict[str, Any]:
        if not isinstance(x, dict):
            return {}
        out: Dict[str, Any] = {}
        for k, v in list(x.items())[:max_items]:
            kk = one_line(str(k), max_k)
            if isinstance(v, (int, float, bool)) or v is None:
                out[kk] = v
            elif isinstance(v, str):
                out[kk] = one_line(v, max_v)
            else:
                out[kk] = one_line(repr(v), max_v)
        return out

    item = {
        "id": tid,
        "ts": time.time(),
        "kind": str(kind or "note"),
        "topic": one_line(topic, 120),
        "text": one_line(text, 260),
        "tags": _safe_list(tags)[:12],
        "links": _safe_dict(links),
        "strength": float(_clip_reward(strength, 1.0)),  # reuse clip helper
        "uses": 0,
        "last_used_ts": 0.0,
    }
    # Optional structured metadata (kept small)
    if card:
        item["card"] = _safe_small_dict(card, max_items=8, max_k=24, max_v=180)
    if signals:
        item["signals"] = _safe_small_dict(signals, max_items=10, max_k=24, max_v=180)
    if ctx:
        item["ctx"] = _safe_small_dict(ctx, max_items=12, max_k=24, max_v=140)

    brain["thoughts"].append(item)

    # cap (value-based)
    maxn = int(brain.get("max_thoughts", 400) or 400)
    maxn = max(80, min(5000, maxn))
    if len(brain["thoughts"]) > maxn:
        _prune_thoughts(brain, maxn=maxn)

    return tid

def search_thoughts(brain: Dict[str, Any], query_tokens: List[str], *, topk: int = 3) -> List[Dict[str, Any]]:
    """
    Lightweight recall by token overlap.

    final6:
      - Includes optional structured fields (card/ctx) in the searchable text,
        improving precision for "situation/action/result" recall.
    """
    if not isinstance(brain, dict):
        return []
    thoughts = _safe_list(brain.get("thoughts"))
    if not thoughts or not query_tokens:
        return []

    q = set(query_tokens[:40])
    scored: List[Tuple[float, Dict[str, Any]]] = []
    now = time.time()
    for it in reversed(thoughts[-1000:]):
        if not isinstance(it, dict):
            continue

        # Include structured parts when present
        card = it.get("card") if isinstance(it.get("card"), dict) else {}
        ctx = it.get("ctx") if isinstance(it.get("ctx"), dict) else {}
        extra = ""
        if card:
            extra += " " + " ".join([str(card.get(k) or "") for k in ("situation", "action", "result") if card.get(k)])
        if ctx:
            # small bias toward remembering user/thread/topic when encoded
            extra += " " + " ".join([str(ctx.get(k) or "") for k in ("user", "thread", "topic", "cat") if ctx.get(k)])

        t = f"{it.get('topic','')} {it.get('text','')} {' '.join(_safe_list(it.get('tags')))} {extra}"
        toks = tokenize(t, max_tokens=80)
        if not toks:
            continue
        inter = len(q.intersection(set(toks)))
        if inter <= 0:
            continue

        strength = float(it.get("strength", 0.5) or 0.5)
        age = max(0.0, now - float(it.get("ts", now) or now))
        # mild age penalty
        score = inter * (0.6 + strength) * (0.85 ** (age / (6 * 3600.0)))
        # tiny boost if recently used (makes good memories stick, but still bounded)
        last_used = float(it.get("last_used_ts", 0.0) or 0.0)
        if last_used > 0.0:
            since = max(0.0, now - last_used)
            score *= (1.0 + 0.08 * (0.85 ** (since / (12 * 3600.0))))
        scored.append((score, it))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [it for _, it in scored[:max(1, int(topk))]]

def _extract_reflection_arm(thought: Dict[str, Any], *, bucket: str, arms: List[str]) -> str:
    """Try to map a reflection thought into a known arm for a given bucket."""
    if not isinstance(thought, dict) or not arms:
        return ""
    arm_set = set([str(a) for a in arms])
    # Prefer tags (they're structured when we store reflections)
    try:
        tags = [str(x) for x in _safe_list(thought.get("tags"))]
    except Exception:
        tags = []
    for t in tags:
        if t in arm_set:
            return t

    # Fallback: scan text
    text = str(thought.get("text") or "")
    if text:
        for a in arms:
            aa = str(a)
            if aa and aa in text:
                return aa

    return ""


def get_reflection_bias(
    brain: Optional[Dict[str, Any]],
    query_tokens: List[str],
    *,
    bucket: str,
    arms: List[str],
    tuning: AgentTuning,
) -> Tuple[Dict[str, float], Dict[str, Any]]:
    """
    (Unit 07) Turn stored reflection thoughts into a lightweight bias map for bandit selection.

    - Uses search_thoughts() retrieval (cheap token overlap)
    - Filters kind='reflection' thoughts and maps them to known arms via tags/text
    - Returns (bias_map, note)
        bias_map: {arm: multiplier>=1.0}
        note: small dict for logging/learning meta
    """
    if not isinstance(brain, dict) or not query_tokens or not arms:
        return {}, {}

    if not bool(getattr(tuning, "reflection_influence", True)):
        return {}, {}

    topk = int(getattr(tuning, "reflection_topk", 3) or 3)
    min_strength = float(getattr(tuning, "reflection_min_strength", 0.60) or 0.60)
    boost = float(getattr(tuning, "reflection_boost", 0.35) or 0.35)
    decay = float(getattr(tuning, "reflection_decay", 0.85) or 0.85)
    if topk <= 0 or boost <= 0.0:
        return {}, {}

    # Pull a few more than topk then filter
    ths = search_thoughts(brain, query_tokens, topk=max(3, topk * 2))
    hits: List[Tuple[str, float, Dict[str, Any]]] = []
    for it in ths:
        if not isinstance(it, dict):
            continue
        if str(it.get("kind") or "") != "reflection":
            continue
        try:
            s = float(it.get("strength", 0.0) or 0.0)
        except Exception:
            s = 0.0
        if s < min_strength:
            continue
        arm = _extract_reflection_arm(it, bucket=bucket, arms=arms)
        if not arm:
            continue
        hits.append((arm, s, it))
        if len(hits) >= topk:
            break

    if not hits:
        return {}, {}

    # Accumulate weighted scores per arm
    acc: Dict[str, float] = {}
    for rank, (arm, s, _) in enumerate(hits):
        w = float(s) * (float(decay) ** float(rank))
        acc[str(arm)] = acc.get(str(arm), 0.0) + w

    maxw = max(acc.values()) if acc else 0.0
    if maxw <= 0.0:
        return {}, {}

    bias: Dict[str, float] = {}
    for arm, w in acc.items():
        # multiplier in [1, 1+boost]
        mult = 1.0 + float(boost) * float(w) / float(maxw)
        bias[str(arm)] = max(0.0, float(mult))

    top_arm = max(acc.items(), key=lambda x: x[1])[0]
    note = {
        "bucket": str(bucket),
        "top_arm": str(top_arm),
        "hits": int(len(hits)),
        "top_strength": float(hits[0][1]) if hits else 0.0,
    }
    return bias, note

def update_community_flow(brain: Dict[str, Any], posts: List[Dict[str, Any]], *, half_life_hours: float = 6.0) -> None:
    """Track what's 'hot' in the feed via decayed keyword counts."""
    if not isinstance(brain, dict):
        return
    com = brain.setdefault("community", {"kw": {}, "by_cat": {}, "last_ts": 0.0, "hot": [], "rising": [], "last_delta": {}})
    if not isinstance(com, dict):
        brain["community"] = {"kw": {}, "by_cat": {}, "last_ts": 0.0, "hot": [], "rising": [], "last_delta": {}}
        com = brain["community"]

    kwm = _safe_dict(com.get("kw"))
    bcm = _safe_dict(com.get("by_cat"))
    last_ts = float(com.get("last_ts", 0.0) or 0.0)
    now = time.time()

    # decay
    if last_ts > 0:
        mul = _decay_mul(now - last_ts, half_life_hours)
        for k in list(kwm.keys()):
            kwm[k] = float(kwm.get(k, 0.0)) * mul
            if kwm[k] < 0.05:
                kwm.pop(k, None)
        for c in list(bcm.keys()):
            bcm[c] = float(bcm.get(c, 0.0)) * mul
            if bcm[c] < 0.05:
                bcm.pop(c, None)

    # remember previous for 'rising'
    prev = _safe_dict(com.get("prev_kw"))
    com["prev_kw"] = dict(list(kwm.items())[:300])

    # ingest
    for p in posts[:40]:
        if not isinstance(p, dict):
            continue
        title = str(p.get("title") or "")
        content = str(p.get("content") or "")
        txt = f"{title} {content}"
        kws = [kw for kw in top_keywords(txt, k=8) if is_clean_keyword(kw)]
        cat, _ = classify_text(txt)
        bcm[cat] = float(bcm.get(cat, 0.0)) + 0.6
        for kw in kws[:6]:
            if not kw:
                continue
            kwm[kw] = float(kwm.get(kw, 0.0)) + 1.0

    # trim
    if len(kwm) > 500:
        items = sorted(kwm.items(), key=lambda kv: kv[1], reverse=True)
        kwm = dict(items[:360])

    com["kw"] = kwm
    com["by_cat"] = bcm
    com["last_ts"] = now

    hot = sorted(kwm.items(), key=lambda kv: kv[1], reverse=True)[:12]
    com["hot"] = [{"kw": k, "score": float(v)} for k, v in hot]

    # rising: compare to prev snapshot (not perfect but works)
    delta: List[Tuple[str, float]] = []
    for k, v in kwm.items():
        dv = float(v) - float(prev.get(k, 0.0))
        if dv > 0.25:
            delta.append((k, dv))
    delta.sort(key=lambda kv: kv[1], reverse=True)
    com["rising"] = [{"kw": k, "delta": float(dv)} for k, dv in delta[:10]]

def synthesize_thread(th: Dict[str, Any]) -> None:
    """Compress raw turns into a small 'working memory' summary."""
    if not isinstance(th, dict):
        return
    turns = _safe_list(th.get("last_k_turns"))[-8:]
    if not turns:
        return

    ctx = " ".join([str(t.get("text") or "") for t in turns])
    th["summary"] = _simple_summary(ctx, max_len=160)

    claims: List[str] = []
    tensions: List[str] = []
    for t in turns[::-1]:
        sents = split_sentences(str(t.get("text") or ""), max_sent=3)
        for s0 in sents:
            fr = _detect_frame(s0)
            if fr == "claim" and len(claims) < 3 and len(s0) >= 16:
                claims.append(one_line(s0, 140))
            if fr == "counter" and len(tensions) < 2 and len(s0) >= 16:
                tensions.append(one_line(s0, 140))
    th["claims"] = claims
    th["tensions"] = tensions

def _make_question(th: Dict[str, Any], category: str) -> str:
    oq = thread_pop_open_question(th)
    if oq and isinstance(oq, dict):
        return str(oq.get("text") or "그 부분 어떻게 봄")
    if category == "dev":
        return "재현 조건이 뭐였음?"
    if category == "philo":
        return "기준을 어디에 두는게 맞음?"
    if category == "meta":
        return "이 규칙이 실제로 도움이 됨?"
    return "너는 어디에 더 무게 둠?"

def _qa_fallback_2stage(text: str, *, is_reply: bool) -> str:
    """QA fallback: shorten then add a question connector (strict-only)."""
    if not STRICT_POSTPROCESS:
        return ""
    raw = str(text or "").strip()
    if not raw:
        return ""
    # stage 1: shorten
    short = ""
    try:
        parts = split_sentences(raw, max_sent=2)
        short = parts[0] if parts else ""
    except Exception:
        short = ""
    if not short:
        short = one_line(raw, 140)
    short = sanitize_plain_text(short)
    if len(short) > 140:
        short = short[:140].rstrip()
    # stage 2: question connector
    q_tail = "이 부분 근거가 뭐임?" if not is_reply else "이 부분 이유가 뭐임?"
    if not short.endswith(("?", "!", "…")):
        short = f"{short} {q_tail}".strip()
    out = ensure_eum_style(short, max_lines=2)
    mode = "reply" if is_reply else "comment"
    return postprocess_outgoing_text(out, mode=mode, max_chars=300, max_lines=2)
