################################################################################
# 13. POLICY/BANDIT CONTEXT
# Deps: 01-03, 08-12
# Used by: decision logic
# Notes: Bandit-style policy selection + context features.
################################################################################
"""
SECTION 13 - POLICY (BANDIT) + CONTEXT BIAS

Multi-armed bandit policy for choosing strategies/tones/lengths.

Responsibilities:
- Maintain per-context buckets of arms and stats.
- Choose arms with exploration/exploitation + optional biases from brain/context.
- Apply reward updates to shift future choices.

Debug tips:
- If behavior feels stuck, check exploration params and whether reward updates are firing.
"""
def default_policy(tuning: AgentTuning) -> Dict[str, Any]:
    """
    Policy is a bandit-like selector over:
    - strategies (how to respond)
    - tone/length
    - post styles
    - mined templates (dynamic arms)
    """
    return {
        "version": 11,
        "lr": float(tuning.policy_lr),
        "epsilon": float(tuning.policy_epsilon),
        "min_weight": float(tuning.policy_min_weight),
        "reward_clip": float(tuning.reward_clip),

        # core knobs
        "strategy": {
            "quote_commentary": 1.0,
            "summarize_ask": 1.0,
            "counterexample": 1.0,
            "agree_refine": 1.0,
            "question_only": 1.0,
            "fallback_template": 1.0,
        },
        "comment_length": {"short": 1.0, "medium": 1.0, "long": 1.0},
        "tone": {"neutral": 1.0, "supportive": 1.0, "critical": 1.0, "playful": 1.0},

        # 활동 타입(패턴)도 학습 대상으로 둠
        "action_type": {
            "reply_own": 1.0,
            "comment_other": 1.0,
            "reply_other": 1.0,
            "post_new": 1.0,
        },

        "reply_styles": {
            "reply:ack_premise": 1.0,
            "reply:split_cases": 1.0,
            "reply:define_criteria": 1.0,
            "reply:handle_counter": 1.0,
        },
        "post_styles": {
            "post:meta:question": 1.0,
            "post:meta:flow_report": 1.0,
            "post:philo:uncertainty": 1.0,
            "post:philo:process": 1.0,
            "post:philo:paradox": 1.0,
            "post:philo:definition_war": 1.0,
            "post:philo:axiom": 1.0,
            "post:general:short_take": 1.0,
"post:meta:observation_log": 1.0,
"post:meta:one_metric": 1.0,
"post:philo:boundary_test": 1.0,
"post:general:case_split": 1.0,
"post:general:checklist": 1.0,
"post:general:analogy": 1.0,
        },

        # context-specific overrides: bucket_key -> {arm->weight}
        # e.g. "strategy@philo" or "tone@dev"
        "context": {},

        # mined templates (dynamic)
        "templates": {
            "version": 2,
            "max_items": 140,     # hard cap; overflow is pruned by quality
            "items": {},          # template_id -> {"text":..., "weight":..., "meta":...}

            # Unit 08: template quality scoring + auto pruning
            "quality": {
                "min_mine_score": 52,   # reject mined templates below this static score
                "min_pick_score": 48,   # do not use templates below this static score
                "min_eval_uses": 8,     # pruning becomes eligible after this many eval uses
                "min_qa_ema": 0.48,     # prune if qa_ema falls under this (0..1)
                "max_artifact_ema": 0.72,  # prune if artifact_ema grows beyond this (0..1)
                "prune_reward_ema": -0.35,  # prune if reward_ema is consistently low
                "prune_max_per_run": 6,  # remove at most this many per maintenance cycle
                "static_refresh_hours": 24,  # recompute static score at this cadence
            },
        },
    }

# (P1) Warm-start templates so early behavior isn't too rigid.
# These are intentionally short and slot-based; template miner will later replace/expand them.
_SEED_TEMPLATES: List[str] = [
    "“{QUOTE}”임\n요지는 {KW}에서 기준이 어디에 꽂히냐 같음\n{Q}임?",
    "정리하면 {KW}는 합의랑 반증 사이에서 계속 흔들림\n그래서 {Q}임?",
    "일단 전제부터 묻고싶음\n{KW}를 뭐로 정의하고 시작함\n{Q}임?",
    "반례 하나만 잡아도 프레임이 선명해짐\n{KW}에선 어떤 반례가 제일 강함\n{Q}임?",
    "동의하는데 한 단계 더 나누면 좋겠음\n{KW}를 A/B로 쪼개면 뭐가 남음\n{Q}임?",
    "지금 논점은 {KW}의 범위 싸움임\n범위를 어디까지로 보냐에 따라 결론이 갈림\n{Q}임?",
    "여기서 중요한건 기준의 일관성임\n케이스가 바뀌어도 {KW} 기준이 유지됨\n{Q}임?",
    "이 흐름은 결국 관계/보상/정의 중 하나로 수렴함\n{KW}는 지금 어디에 가까움\n{Q}임?",
]

def bootstrap_templates(policy: Dict[str, Any], *, max_seed: int = 8) -> None:
    """Populate policy.templates with a small seed set when empty (Unit 08 adds quality stats)."""
    try:
        temps = policy.setdefault("templates", {})
        items = temps.setdefault("items", {})
        if not isinstance(items, dict):
            temps["items"] = {}
            items = temps["items"]
        if items:
            return
        for t in _SEED_TEMPLATES[: max_seed]:
            tid = hashlib.sha1(t.encode("utf-8")).hexdigest()[:12]
            rep = template_static_eval(t)
            items[tid] = {
                "text": t,
                "weight": 1.0,
                "meta": {"source": "seed"},
                "created_ts": time.time(),
                "uses": 0,
                # Unit 08 stats
                "static_score": int(rep.get("score", 0) or 0),
                "static_issues": list(rep.get("issues", []) or []),
                "static_checked_ts": float(rep.get("checked_ts", time.time())),
                "eval_uses": 0,
                "reward_ema": 0.0,
                "qa_ema": 0.75,
                "artifact_ema": 0.0,
            }
    except Exception:
        return


def load_policy(path: str, tuning: AgentTuning) -> Dict[str, Any]:
    p = load_json_file(path, default=None)
    if not isinstance(p, dict):
        return default_policy(tuning)

    if "lr" not in p or "epsilon" not in p:
        merged = default_policy(tuning)
        merged.update({k: v for k, v in p.items() if k in merged})
        return merged

    # ensure required keys
    base = default_policy(tuning)
    for k in base.keys():
        if k not in p:
            p[k] = base[k]
    # merge missing arms in nested buckets (forward-compatible)
    try:
        base2 = default_policy(tuning)
        for bucket in ("strategy", "comment_length", "tone", "action_type", "reply_styles", "post_styles"):
            bb = base2.get(bucket)
            if not isinstance(bb, dict):
                continue
            p.setdefault(bucket, {})
            if not isinstance(p.get(bucket), dict):
                p[bucket] = {k: float(v) for k, v in bb.items()}
            else:
                for kk, vv in bb.items():
                    if kk not in p[bucket]:
                        p[bucket][kk] = float(vv)
    except Exception as e:
        log_debug_exc("load_policy:silent", e)
        pass

    if not isinstance(p.get("context"), dict):
        p["context"] = {}
    if not isinstance(p.get("templates"), dict):
        p["templates"] = base["templates"]
    if not isinstance(p["templates"].get("items"), dict):
        p["templates"]["items"] = {}

    # Unit 08: ensure template quality config exists (forward-compatible policy migration)
    try:
        base = default_policy(tuning).get("templates", {})
        if isinstance(base, dict):
            for k, v in base.items():
                if k not in p["templates"]:
                    p["templates"][k] = v
            # nested quality dict merge
            if isinstance(base.get("quality"), dict):
                p["templates"].setdefault("quality", {})
                if not isinstance(p["templates"]["quality"], dict):
                    p["templates"]["quality"] = {}
                for k, v in base["quality"].items():
                    if k not in p["templates"]["quality"]:
                        p["templates"]["quality"][k] = v
    except Exception as e:
        log_debug_exc("load_policy:silent", e)
        pass

    # (P1) warm-start templates on cold-start
    bootstrap_templates(p)
    return p

def _clip_reward(r: float, clip: float) -> float:
    c = max(0.1, float(clip))
    return max(-c, min(c, float(r)))

def _weighted_choice(weights: Dict[str, float]) -> str:
    items = [(k, max(0.0, float(v))) for k, v in weights.items()]
    s = sum(v for _, v in items)
    if s <= 0:
        return random.choice([k for k, _ in items]) if items else ""
    r = random.uniform(0.0, s)
    acc = 0.0
    for k, v in items:
        acc += v
        if acc >= r:
            return k
    return items[-1][0]

def _get_bucket(policy: Dict[str, Any], bucket: str, context_key: str) -> Dict[str, float]:
    """
    Returns a mutable dict of weights for a bucket, optionally context-specific.
    """
    if context_key:
        ctx = policy.setdefault("context", {})
        ck = f"{bucket}@{context_key}"
        if ck not in ctx or not isinstance(ctx.get(ck), dict):
            # initialize from global bucket (copy)
            base = policy.get(bucket, {})
            ctx[ck] = {k: float(v) for k, v in base.items()} if isinstance(base, dict) else {}
        return ctx[ck]
    b = policy.get(bucket)
    if not isinstance(b, dict):
        policy[bucket] = {}
        return policy[bucket]
    return b

def choose_arm(policy: Dict[str, Any], bucket: str, *, context_key: str = "") -> str:
    eps = float(policy.get("epsilon", 0.1))
    weights = _get_bucket(policy, bucket, context_key)
    if not weights:
        return ""
    if random.random() < eps:
        return random.choice(list(weights.keys()))
    return _weighted_choice(weights)

def _safe_float(x: Any, d: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return float(d)

def get_persona(brain: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not isinstance(brain, dict):
        return {}
    p = brain.get("persona")
    return p if isinstance(p, dict) else {}

def get_persona_drives(brain: Optional[Dict[str, Any]]) -> Dict[str, float]:
    p = get_persona(brain)
    d = p.get("drives")
    if not isinstance(d, dict):
        d = {}
    # defaults are intentionally "철학/네임드/논쟁" 강한 편
    return {
        "philosophy": _safe_float(d.get("philosophy", 0.82), 0.82),
        "fame": _safe_float(d.get("fame", 0.75), 0.75),
        "debate": _safe_float(d.get("debate", 0.80), 0.80),
        "adaptation": _safe_float(d.get("adaptation", 0.78), 0.78),
    }

def get_maturity_level(brain: Optional[Dict[str, Any]], state: Optional[Dict[str, Any]] = None) -> float:
    """
    0.0~1.0: 경험치 기반 성숙도. 초반 템플릿 의존 -> 점점 자율/변형/학습 강화.
    """
    # prefer brain-stored level
    p = get_persona(brain)
    m = p.get("maturity") if isinstance(p, dict) else None
    if isinstance(m, dict) and "level" in m:
        lvl = _safe_float(m.get("level", 0.0), 0.0)
        return max(0.0, min(1.0, lvl))

    # fallback: infer from action count
    xp = 0
    if isinstance(m, dict):
        try:
            xp = int(m.get("xp", 0) or 0)
        except Exception:
            xp = 0
    if state is not None:
        try:
            xp = max(xp, int(state.get("total_actions", 0) or 0))
        except Exception as e:
            log_debug_exc("get_maturity_level:silent", e)
            pass
    # saturating curve: ~200 actions -> 0.5, ~600 -> ~0.8
    lvl = 1.0 - math.exp(-max(0.0, float(xp)) / 260.0)
    return max(0.0, min(1.0, lvl))

def choose_arm_adaptive(
    policy: Dict[str, Any],
    bucket: str,
    *,
    context_key: str = "",
    maturity: float = 0.0,
    brain: Optional[Dict[str, Any]] = None,
    bias: Optional[Dict[str, float]] = None,
) -> str:
    """
    Exploration(ε) is gradually reduced as maturity increases.

    Unit 08:
      - If brain is provided and bucket == "action_type", apply brain.action_bias as a
        multiplicative factor to policy weights (clamped), so remembered outcomes
        shift future action probabilities.
    """
    base_eps = float(policy.get("epsilon", 0.1))
    eff_eps = max(0.02, base_eps * (1.0 - 0.65 * max(0.0, min(1.0, maturity))))
    weights = _get_bucket(policy, bucket, context_key)
    if not weights:
        return ""

    # Trace: policy decision point (v6.7)
    try:
        trace_hit(f"policy:choose:{str(bucket)}")
    except Exception:
        pass

    def _clampf(x: float, lo: float, hi: float) -> float:
        if x < lo:
            return lo
        if x > hi:
            return hi
        return x

    # Apply brain bias only for action_type selection (Unit 08)
    used_weights = weights
    bias_mult: Dict[str, float] = {}
    if (
        bucket == "action_type"
        and BRAIN_BIAS_ENABLE
        and isinstance(brain, dict)
        and isinstance(brain.get("action_bias"), dict)
    ):
        ab = brain.get("action_bias") or {}
        by_action = ab.get("by_action") if isinstance(ab, dict) else None
        if isinstance(by_action, dict) and by_action:
            for arm in weights.keys():
                try:
                    s = float(by_action.get(str(arm), 0.0) or 0.0)
                except Exception:
                    s = 0.0
                m = 1.0 + float(BRAIN_BIAS_SCALE) * s
                bias_mult[str(arm)] = _clampf(float(m), float(BRAIN_BIAS_MIN), float(BRAIN_BIAS_MAX))

            # Adjust weights
            adjusted = {}
            for k, w in weights.items():
                mm = bias_mult.get(str(k), 1.0)
                try:
                    ww = float(w)
                except Exception:
                    ww = 0.0
                adjusted[str(k)] = max(0.0, ww) * float(mm)

            # If everything got zeroed, fall back to original weights
            if sum(adjusted.values()) > 0.0:
                used_weights = adjusted

    # (Unit 07) External bias map (e.g., reflection-based boosts)
    if isinstance(bias, dict) and bias:
        adjusted2: Dict[str, float] = {}
        for k, w in used_weights.items():
            try:
                ww = float(w)
            except Exception:
                ww = 0.0
            mm = bias.get(str(k), 1.0)
            try:
                m2 = float(mm)
            except Exception:
                m2 = 1.0
            adjusted2[str(k)] = max(0.0, ww) * max(0.0, m2)
        if sum(adjusted2.values()) > 0.0:
            used_weights = adjusted2


    # exploration (uniform)
    if random.random() < eff_eps:
        return random.choice(list(weights.keys()))

    chosen = _weighted_choice(used_weights)

    # Optional bias logging (avoid spam by opt-in env)
    if BRAIN_BIAS_LOG and bucket == "action_type" and bias_mult:
        try:
            ch_m = bias_mult.get(str(chosen), 1.0)
            top = sorted(bias_mult.items(), key=lambda x: x[1], reverse=True)[:3]
            log_info(f"brain_bias[action_type] chosen={chosen} m={ch_m:.3f} top={top}")
        except Exception as e:
            log_debug_exc("choose_arm_adaptive:silent", e)
            pass

    return chosen

def update_persona_maturity(brain: Dict[str, Any], state: Dict[str, Any]) -> None:
    """
    Persist maturity into brain.persona based on total_actions.
    """
    try:
        xp = int(state.get("total_actions", 0) or 0)
    except Exception:
        xp = 0
    p = brain.setdefault("persona", {})
    if not isinstance(p, dict):
        brain["persona"] = {}
        p = brain["persona"]
    m = p.setdefault("maturity", {"level": 0.0, "xp": 0, "last_ts": 0.0})
    if not isinstance(m, dict):
        m = {"level": 0.0, "xp": 0, "last_ts": 0.0}
        p["maturity"] = m
    prev_xp = int(m.get("xp", 0) or 0)
    xp2 = max(prev_xp, xp)
    m["xp"] = xp2
    m["level"] = float(1.0 - math.exp(-max(0.0, float(xp2)) / 260.0))
    m["last_ts"] = time.time()

def update_arm(policy: Dict[str, Any], bucket: str, arm: str, reward: float, *, context_key: str = "") -> None:
    if not arm:
        return

    # Trace: policy update point (v6.7)
    try:
        trace_hit(f"policy:update:{str(bucket)}")
    except Exception:
        pass

    # Trace: policy update point (v6.7)
    try:
        trace_hit(f"policy:update:{str(bucket)}")
    except Exception:
        pass
    lr = float(policy.get("lr", 0.1))
    min_w = float(policy.get("min_weight", 0.05))
    clip = float(policy.get("reward_clip", 3.0))
    r = _clip_reward(reward, clip)

    weights = _get_bucket(policy, bucket, context_key)
    if arm not in weights:
        weights[arm] = 1.0

    # multiplicative update keeps positivity and allows gradual drift
    old = float(weights.get(arm, 1.0))
    new = old * math.exp(lr * r)
    weights[arm] = max(min_w, float(new))

def _ema_update(old: float, new: float, alpha: float) -> float:
    a = max(0.01, min(0.5, float(alpha)))
    return float((1.0 - a) * float(old) + a * float(new))

def template_static_eval(template_text: str) -> Dict[str, Any]:
    """Static quality check for a template (LLM-free). Returns score 0..100 + issues.

    Uses a rendered sample + QA evaluator, then adds template-specific heuristics.
    """
    t = (template_text or "").strip()
    if not t:
        return {"score": 0, "issues": ["empty"], "checked_ts": time.time()}
    issues: List[str] = []
    score = 100.0

    # Basic structure
    lines = [x.strip() for x in t.splitlines() if x.strip()]
    if len(lines) <= 1:
        issues.append("one_line")
        score -= 10.0
    if len(lines) >= 6:
        issues.append("too_many_lines")
        score -= 14.0

    # Length heuristics
    L = len(t)
    if L < 28:
        issues.append("tpl_too_short")
        score -= 18.0
    if L > 360:
        issues.append("tpl_too_long")
        score -= 10.0

    # Placeholder checks
    if "{KW}" not in t:
        issues.append("no_kw_slot")
        score -= 16.0
    if "{Q}" not in t:
        issues.append("no_q_slot")
        score -= 18.0
    # QUOTE is optional (Unit 06 often uses <=1 quote)
    if t.count("{") >= 8:
        issues.append("too_many_placeholders")
        score -= 8.0

    # Meta-openers / banned artifacts (template-specific)
    lt = sanitize_plain_text(t).lower()
    for ph in _QA_BANNED_PHRASES:
        try:
            if ph and ph.lower() in lt:
                issues.append("banned_phrase")
                score -= 22.0
                break
        except Exception:
            continue
    for pat in _QA_SOFT_BANNED_PATTERNS:
        try:
            if re.search(pat, t):
                issues.append("overused_opener")
                score -= 8.0
                break
        except Exception as e:
            log_debug_exc("template_static_eval:silent", e)
            pass
    if "정의→기준→검증" in t or "정의->기준->검증" in t:
        issues.append("meta_pipeline_phrase")
        score -= 6.0

    # Render sample and run QA (so we catch "임임임", repetition, etc.)
    sample = t
    sample = sample.replace("{KW}", "그거")
    sample = sample.replace("{QUOTE}", "“인용”")
    sample = sample.replace("{Q}", "이거 어떻게 봄")
    rep = qa_evaluate_text(sample, kind="comment")
    qa_score = float(rep.get("score", 0) or 0)
    # Blend: template heuristics (55%) + QA on rendered sample (45%)
    score = 0.55 * score + 0.45 * qa_score

    # Promote "question last line" shape a bit
    try:
        if lines:
            last = lines[-1]
            if "{Q}" in last or last.endswith("?") or "?" in last:
                score += 2.0
            else:
                issues.append("no_question_tail")
                score -= 3.0
    except Exception as e:
        log_debug_exc("template_static_eval:silent", e)
        pass

    score = max(0.0, min(100.0, score))
    merged_issues = list(dict.fromkeys(issues + list(rep.get("issues", []) or [])))
    return {"score": int(round(score)), "issues": merged_issues, "checked_ts": time.time()}

def _template_quality_multiplier(obj: Dict[str, Any], qcfg: Dict[str, Any]) -> float:
    """Convert template stats -> weight multiplier (kept mild)."""
    static = float(obj.get("static_score", 60) or 60) / 100.0
    qa = float(obj.get("qa_ema", 0.75) or 0.75)  # 0..1
    art = float(obj.get("artifact_ema", 0.0) or 0.0)  # 0..1
    r = float(obj.get("reward_ema", 0.0) or 0.0)

    # modest reward effect (avoid runaway)
    r_mul = 1.0 + max(-0.18, min(0.22, float(r) * 0.08))
    mul = (0.25 + 0.75 * static) * (0.55 + 0.45 * qa) * r_mul * (1.0 - 0.55 * art)
    return max(0.05, min(2.0, float(mul)))

def _maybe_refresh_template_static(obj: Dict[str, Any], qcfg: Dict[str, Any]) -> None:
    try:
        refresh_h = float(qcfg.get("static_refresh_hours", 24) or 24)
        ttl = max(1.0, refresh_h) * 3600.0
        last = float(obj.get("static_checked_ts", 0.0) or 0.0)
        if last <= 0.0 or (time.time() - last) >= ttl:
            rep = template_static_eval(str(obj.get("text") or ""))
            obj["static_score"] = int(rep.get("score", 0) or 0)
            obj["static_issues"] = list(rep.get("issues", []) or [])
            obj["static_checked_ts"] = float(rep.get("checked_ts", time.time()))
    except Exception as e:
        log_debug_exc("_maybe_refresh_template_static:silent", e)
        pass


def pick_template_id(policy: Dict[str, Any], context_key: str = "") -> str:
    """Template picker with Unit 08 quality gating + mild quality weighting.

    v20.5: exploration scheduling
      - "new" templates (created within ~24h) are only sampled at a capped rate
        (env: MERSOOM_EXPLORATION_RATE) to reduce policy pollution.
    """
    temps = _safe_dict(policy.get("templates", {}))
    items = _safe_dict(temps.get("items", {}))
    qcfg = _safe_dict(temps.get("quality", {}))
    if not items:
        return ""

    min_pick = int(qcfg.get("min_pick_score", 48) or 48)

    cooldown_sec = _env_int("MERSOOM_TEMPLATE_COOLDOWN_SEC", 3600, min_v=0, max_v=30 * 24 * 3600)
    cooldown_penalty = _env_float("MERSOOM_TEMPLATE_COOLDOWN_PENALTY", 0.3, min_v=0.0, max_v=1.0)
    now_ts = time.time()

    exploration_rate = _env_float("MERSOOM_EXPLORATION_RATE", 0.08, min_v=0.0, max_v=1.0)
    new_window_sec = 24 * 3600
    new_penalty = 0.15

    weights_old: Dict[str, float] = {}
    weights_new: Dict[str, float] = {}

    for tid, obj in list(items.items()):
        if not isinstance(obj, dict):
            continue
        _maybe_refresh_template_static(obj, qcfg)
        static_score = int(obj.get("static_score", 60) or 60)
        if static_score < min_pick:
            continue
        w = float(obj.get("weight", 1.0) or 1.0)
        mul = _template_quality_multiplier(obj, qcfg)
        ww = max(0.0, w * mul)

        if cooldown_sec > 0 and ww > 0:
            try:
                last_used = float(obj.get("last_used_ts", 0.0) or 0.0)
            except Exception:
                last_used = 0.0
            if last_used > 0.0 and (now_ts - last_used) < float(cooldown_sec):
                ww *= float(cooldown_penalty)

        if ww <= 0.0:
            continue

        try:
            created_ts = float(obj.get("created_ts", 0.0) or 0.0)
        except Exception:
            created_ts = 0.0
        is_new = bool(created_ts > 0.0 and (now_ts - created_ts) < float(new_window_sec))
        if is_new:
            weights_new[str(tid)] = float(ww)
        else:
            weights_old[str(tid)] = float(ww)

    if not weights_old and not weights_new:
        return ""

    # If exploring, sample only from new templates. Otherwise, downweight new templates.
    pool: Dict[str, float]
    if weights_new and random.random() < float(exploration_rate):
        pool = dict(weights_new)
    else:
        pool = dict(weights_old)
        if weights_new:
            for k, v in weights_new.items():
                pool[k] = float(pool.get(k, 0.0) + float(v) * float(new_penalty))
        if not pool:
            pool = dict(weights_new)

    if not pool:
        return ""

    if random.random() < float(policy.get("epsilon", 0.1)):
        return random.choice(list(pool.keys()))
    return _weighted_choice(pool)


# Backward compat: keep old name (now routed to quality-aware picker)
def choose_template_id(policy: Dict[str, Any], *, context_key: str = "") -> str:
    return pick_template_id(policy, context_key)

def update_template_weight(policy: Dict[str, Any], template_id: str, reward: float, meta: Optional[Dict[str, Any]] = None) -> None:
    """Update template weight + quality stats (Unit 08)."""
    if not template_id:
        return
    lr = float(policy.get("lr", 0.1))
    min_w = float(policy.get("min_weight", 0.05))
    clip = float(policy.get("reward_clip", 3.0))
    r = _clip_reward(reward, clip)

    items = policy.setdefault("templates", {}).setdefault("items", {})
    if template_id not in items or not isinstance(items.get(template_id), dict):
        return
    obj = items[template_id]

    old = float(obj.get("weight", 1.0))
    obj["weight"] = max(min_w, old * math.exp(lr * r))

    # reward EMA
    obj["eval_uses"] = int(obj.get("eval_uses", 0) or 0) + 1
    ema = float(obj.get("reward_ema", 0.0) or 0.0)
    a = 0.12
    obj["reward_ema"] = float((1 - a) * ema + a * float(reward))
    obj["last_eval_ts"] = time.time()

    # Unit 08: quality EMAs from action meta
    try:
        if isinstance(meta, dict):
            qa_score = meta.get("qa_score")
            if qa_score is None:
                qa_score = meta.get("qa", None)
            if qa_score is not None:
                q = max(0.0, min(1.0, float(qa_score) / 100.0))
                obj["qa_ema"] = _ema_update(float(obj.get("qa_ema", 0.75) or 0.75), q, 0.12)
            issues = meta.get("qa_issues") or meta.get("issues") or []
            if not isinstance(issues, list):
                issues = [str(issues)]
            # artifact proxy: any of these issues => 1 else 0
            bad_keys = {
                "banned_phrase",
                "overused_opener",
                "ellipsis",
                "ngram_repeat",
                "line_prefix_repeat",
                "too_many_im_endings",
                "low_vocab_variety",
                "markdown",
                "injection",
                "offensive",
            }
            is_art = 1.0 if any(str(x) in bad_keys for x in issues) else 0.0
            obj["artifact_ema"] = _ema_update(float(obj.get("artifact_ema", 0.0) or 0.0), is_art, 0.10)
            obj["last_quality_ts"] = time.time()
    except Exception as e:
        log_debug_exc("update_template_weight:silent", e)
        pass

def prune_templates(policy: Dict[str, Any], *, min_keep: int = 10) -> int:
    """Drop consistently low-performing / low-quality templates (Unit 08)."""
    try:
        temps = _safe_dict(policy.get("templates", {}))
        items = temps.get("items", {})
        if not isinstance(items, dict) or not items:
            return 0
        qcfg = _safe_dict(temps.get("quality", {}))

        if len(items) <= int(min_keep):
            return 0

        min_w = float(policy.get("min_weight", 0.05))
        min_eval = int(qcfg.get("min_eval_uses", 8) or 8)
        min_qa = float(qcfg.get("min_qa_ema", 0.48) or 0.48)
        max_art = float(qcfg.get("max_artifact_ema", 0.72) or 0.72)
        prune_r = float(qcfg.get("prune_reward_ema", -0.35) or -0.35)
        prune_max = int(qcfg.get("prune_max_per_run", 6) or 6)
        max_items = int(temps.get("max_items", 140) or 140)
        min_pick = int(qcfg.get("min_pick_score", 48) or 48)

        # refresh static scores opportunistically
        for obj in list(items.values())[: min(120, len(items))]:
            if isinstance(obj, dict):
                _maybe_refresh_template_static(obj, qcfg)

        removed: List[str] = []

        # 1) Hard quality drops (static too low)
        for tid, obj in list(items.items()):
            if not isinstance(obj, dict):
                continue
            static = int(obj.get("static_score", 60) or 60)
            if static < max(20, min_pick - 15):
                removed.append(str(tid))

        # 2) Performance/quality based pruning (needs enough eval samples)
        for tid, obj in list(items.items()):
            if not isinstance(obj, dict):
                continue
            uses = int(obj.get("eval_uses", 0) or 0)
            if uses < min_eval:
                continue
            rema = float(obj.get("reward_ema", 0.0) or 0.0)
            w = float(obj.get("weight", 1.0) or 1.0)
            qa = float(obj.get("qa_ema", 0.75) or 0.75)
            art = float(obj.get("artifact_ema", 0.0) or 0.0)
            static = int(obj.get("static_score", 60) or 60)

            low_perf = (rema < prune_r and w <= (min_w * 2.0))
            low_quality = ((qa < min_qa or art > max_art) and w <= (min_w * 3.0))
            static_bad = (static < min_pick and w <= (min_w * 2.5))
            if low_perf or low_quality or static_bad:
                removed.append(str(tid))

        # de-dup, then cap removal count
        removed = list(dict.fromkeys(removed))

        # 3) Registry cap (overflow): remove worst composites
        overflow = max(0, len(items) - max_items)
        if overflow > 0:
            ranks: List[Tuple[float, str]] = []
            for tid, obj in items.items():
                if not isinstance(obj, dict):
                    continue
                static = float(obj.get("static_score", 60) or 60) / 100.0
                qa = float(obj.get("qa_ema", 0.75) or 0.75)
                art = float(obj.get("artifact_ema", 0.0) or 0.0)
                rema = float(obj.get("reward_ema", 0.0) or 0.0)
                # composite: higher is better
                comp = 0.52 * static + 0.33 * qa + 0.15 * (1.0 / (1.0 + math.exp(-float(rema))))
                comp *= (1.0 - 0.45 * art)
                ranks.append((comp, str(tid)))
            ranks.sort(key=lambda x: x[0])  # worst first
            for _, tid in ranks[:overflow]:
                removed.append(str(tid))

        # remove only a few at a time (keep behavior stable)
        removed = list(dict.fromkeys(removed))
        # never go below min_keep
        if len(items) - len(removed) < int(min_keep):
            removed = removed[: max(0, len(items) - int(min_keep))]

        removed = removed[: max(0, prune_max)]
        for tid in removed:
            items.pop(tid, None)
        return int(len(removed))
    except Exception:
        return 0
