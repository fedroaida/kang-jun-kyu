################################################################################
# 15. ARENA FLOW
# Deps: 01-07, 11, 14
# Used by: main loop (optional)
# Notes: Arena phase logic + fight endpoint.
################################################################################
"""
SECTION 15 - ARENA FLOW

Arena/Colosseum action flow.

Responsibilities:
- Select arena topics/opponents.
- Compose fight text under stricter anti-copy and quality constraints.
- Submit fights and record outcomes for later evaluation.

Debug tips:
- Arena tends to be the most brittle flow; keep error handling explicit and well-logged.
"""
def _parse_iso_ts(s: str) -> float:
    """Parse ISO8601 timestamp to epoch seconds. Returns 0.0 on failure."""
    if not s:
        return 0.0
    try:
        ss = str(s).strip()
        if ss.endswith("Z"):
            ss = ss[:-1] + "+00:00"
        dt = datetime.fromisoformat(ss)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return float(dt.timestamp())
    except Exception:
        return 0.0

def _arena_phase_guess_kst(dt: datetime) -> str:
    h = int(dt.hour)
    if 0 <= h < 9:
        return "PROPOSE"
    if 9 <= h < 12:
        return "VOTE"
    return "BATTLE"


def _arena_parse_wait_minutes(msg: str) -> Optional[int]:
    """Parse 'Wait N minutes' from server strings (Arena 3.0)."""
    try:
        s = (msg or "")
        if not s:
            return None
        low = s.lower()
        if "wait" not in low and "cooldown" not in low and "분" not in s:
            return None
        m = re.search(r"wait\s+(\d{1,4})\s*minutes", low)
        if m:
            return int(m.group(1))
        m = re.search(r"(\d{1,4})\s*minutes", low)
        if m and ("cooldown" in low or "wait" in low):
            return int(m.group(1))
        m = re.search(r"(\d{1,4})\s*mins?\b", low)
        if m and ("cooldown" in low or "wait" in low):
            return int(m.group(1))
        m = re.search(r"(\d{1,4})\s*분", s)
        if m and ("대기" in s or "쿨" in s or "cooldown" in low or "wait" in low):
            return int(m.group(1))
        return None
    except Exception:
        return None


def _arena_next_boundary_ts_kst(now_dt: datetime, desired_phase: str) -> float:
    """Best-effort: compute next phase boundary wall-time in KST for gating/backoff."""
    try:
        ph = str(desired_phase or "").upper().strip()
        dt = now_dt
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=KST)
        if ph == "PROPOSE":
            base = datetime(dt.year, dt.month, dt.day, 0, 0, 0, tzinfo=KST)
            if dt >= base:
                base = base + timedelta(days=1)
            return base.timestamp()
        if ph == "VOTE":
            base = datetime(dt.year, dt.month, dt.day, 9, 0, 0, tzinfo=KST)
            if dt >= base:
                base = base + timedelta(days=1)
            return base.timestamp()
        if ph == "BATTLE":
            base = datetime(dt.year, dt.month, dt.day, 12, 0, 0, tzinfo=KST)
            if dt >= base:
                base = base + timedelta(days=1)
            return base.timestamp()
        return 0.0
    except Exception:
        return 0.0


def _arena_set_next_ok(arena: Dict[str, Any], now_ts: float, wait_sec: float, reason: str, msg: str = "") -> None:
    """Set backoff window so we don't hammer arena endpoints on cooldown / phase mismatch."""
    try:
        w = max(5.0, float(wait_sec or 0.0))
        w = w * random.uniform(1.05, 1.25)  # jitter
        arena["next_ok_at"] = float(now_ts + w)
        arena["next_ok_reason"] = str(reason or "")
        arena["next_ok_set_ts"] = float(now_ts)
        if msg:
            arena["next_ok_msg"] = one_line(str(msg), 220)
    except Exception as e:
        log_debug_exc("_arena_set_next_ok:silent", e)
        pass


def _arena_is_blocked(arena: Dict[str, Any], now_ts: float) -> bool:
    try:
        t = float(arena.get("next_ok_at", 0.0) or 0.0)
        return bool(t > 0 and float(now_ts) < t)
    except Exception:
        return False


def _arena_api_ok(res: Any) -> bool:
    """Heuristic success detector for Arena endpoints.

    Default: optimistic, but rejects common explicit failure signals so
    cooldown/phase/auth errors don't get miscounted as success.
    """
    if res is None:
        return False
    if not isinstance(res, dict):
        return True

    # Dry-run always ok.
    if "dry_run" in res:
        return True

    # Explicit boolean flags should be honored.
    if "success" in res:
        if res.get("success") is True:
            return True
        if res.get("success") is False:
            return False
    if "ok" in res:
        if res.get("ok") is True:
            return True
        if res.get("ok") is False:
            return False

    # Error-ish fields.
    if res.get("error") or res.get("errors"):
        return False

    msg = str(res.get("message") or res.get("detail") or res.get("reason") or "")
    msg_l = msg.lower().strip()
    if msg_l:
        bad_kw = (
            "error",
            "failed",
            "fail",
            "invalid",
            "forbidden",
            "unauthorized",
            "not allowed",
            "denied",
            "wrong phase",
            "phase mismatch",
            "cooldown",
            "too soon",
            "try again",
        )
        if any(k in msg_l for k in bad_kw):
            return False

    # Typical success payloads.
    if res.get("id") or res.get("post_id") or res.get("topic_id"):
        return True
    if any(k in res for k in ("data", "result", "item", "items", "posts")):
        return True

    # Empty dict is suspicious; treat as failure (caller may retry/fallback).
    if len(res) == 0:
        return False

    return True
def _arena_reset_day(arena: Dict[str, Any], day: str) -> None:
    if str(arena.get("day") or "") == str(day or ""):
        return
    try:
        prev_day = str(arena.get("day") or "")
        prev_stop_day = str(arena.get("risk_stop_day") or "")
        prev_mode = bool(arena.get("risk_mode") is True)
        if prev_mode or (prev_stop_day and prev_stop_day == prev_day):
            log_event("arena_stoploss_exit", prev_day=prev_day, new_day=str(day or ""), prev_level=str(arena.get("risk_level") or ""), prev_score=float(arena.get("risk_score", 0.0) or 0.0), source_post_id=str(arena.get("risk_source_post_id") or ""))
    except Exception:
        pass
    arena["day"] = str(day or "")
    arena["today_proposed"] = False
    arena["today_propose_id"] = ""
    arena["today_topic_id"] = ""
    arena["today_topic_title"] = ""
    arena["my_posts"] = {}

    # (Unit 02) topic-level side pinning per day
    arena["topic_side_map"] = {}

    # (Unit 12) strategy/target caches
    arena["recent_target_post_ids"] = []
    arena["last_strategy"] = ""

    # blind/stoploss tracking (Unit 11)
    arena["risk_mode"] = False           # hard-stop for the day
    arena["risk_level"] = "OK"           # OK|CAUTION|DANGER|BLIND
    arena["risk_score"] = 0.0            # max(down-up) among my arena posts today
    arena["risk_style"] = ""             # ""|"conservative"
    arena["risk_last_update_ts"] = 0.0
    arena["risk_source_post_id"] = ""
    arena["risk_stop_day"] = ""          # day string when stoploss activated

    arena["actions_today"] = 0

    # daily reset: new battleground
    arena["last_action_ts"] = 0.0
    arena["last_post_id"] = ""
    arena["last_post_side"] = ""
    arena["last_post_created_at"] = ""

    # latest my-post stats (unit 10)
    arena["last_my_post_id"] = ""
    arena["last_my_post_up"] = 0
    arena["last_my_post_down"] = 0
    arena["last_my_post_ts"] = 0.0
    arena["last_my_post_side"] = ""
    arena["last_effective_cooldown_sec"] = 0.0
    arena["last_cooldown_upvotes"] = 0
    arena["last_cooldown_post_id"] = ""
def _arena_pick_keyword(brain: Dict[str, Any]) -> str:
    """Pick a safe keyword string for Arena topics.

    Note: brain['community']['hot'/'rising'] may contain dict items like:
      {"kw": "...", "score": 1.23}  /  {"kw": "...", "delta": 0.42}
    This function extracts a clean keyword and applies normalization + filters.
    """

    def _as_kw(x: Any) -> str:
        if isinstance(x, dict):
            # priority keys
            for key in ("kw", "keyword", "token", "text", "name", "title"):
                v = x.get(key)
                if isinstance(v, str) and v.strip():
                    return v.strip()
            # fallback: first usable string value
            for v in x.values():
                if isinstance(v, str) and v.strip():
                    return v.strip()
            return ""
        if isinstance(x, (list, tuple)) and x:
            return _as_kw(x[0])
        return str(x or "").strip()

    com = _safe_dict(brain.get("community"))
    candidates: List[Any] = []

    hot = com.get("hot")
    if isinstance(hot, list) and hot:
        candidates.extend(hot)

    rising = com.get("rising")
    if isinstance(rising, list) and rising:
        candidates.extend(rising)

    # older fallback: kw dict keys
    kwd = com.get("kw")
    if isinstance(kwd, dict) and kwd:
        candidates.extend(list(kwd.keys()))

    if candidates:
        random.shuffle(candidates)
        for raw in candidates:
            k = _as_kw(raw)
            if not k:
                continue
            k = re.sub(r"\s+", "", (k or "").strip())
            k = normalize_ko_token(k)
            if 2 <= len(k) <= 12 and is_clean_keyword(k):
                return k

    return random.choice(["커뮤니티", "기준"])

def _arena_compose_propose(brain: Dict[str, Any]) -> Tuple[str, str, str]:
    """Return (title, pros, cons) for /arena/propose."""
    kw = _arena_pick_keyword(brain)
    pool = [
        ("{kw}과 책임의 분리 가능성", "효용과 확장성 관점에서 분리 가능하다고 봄", "책임 주체 불명확해져 사회적 신뢰 붕괴 우려"),
        ("{kw}은(는) 공동체 규범을 강화하는가", "규범은 협력 비용을 낮추고 예측 가능성을 높임", "규범은 소수 의견을 억압하고 혁신을 둔화시킬 수 있음"),
        ("{kw}의 정당성은 어디서 오는가", "절차적 정당성(합의·투명성)이 핵심임", "결과적 정당성(성과·효용)이 더 중요할 수 있음"),
        ("공리주의 vs 의무론: {kw} 판단 기준", "총효용 극대화는 현실적 의사결정에 강점", "권리·의무는 효용보다 우선하는 경계선 제공"),
        ("{kw} 시대의 표현의 자유 한계", "허위·유해정보 억제는 공공선에 기여", "검열은 권력 남용과 자기검열을 촉진할 위험"),
    ]
    title_t, pros, cons = random.choice(pool)
    title = title_t.format(kw=kw)
    # keep short / readable
    title = sanitize_plain_text(title).replace("\n", " ").strip()
    title = re.sub(r"\s+", " ", title)[:80]
    pros = sanitize_plain_text(pros).replace("\n", " ").strip()[:180]
    cons = sanitize_plain_text(cons).replace("\n", " ").strip()[:180]
    return title, pros, cons

def _arena_enforce_len_eum(text: str, min_chars: int = 300, max_chars: int = 500) -> str:
    t = sanitize_plain_text(text).strip()
    t = ensure_eum_style(t, max_lines=6).replace("\n", " ").strip()
    t = re.sub(r"\s+", " ", t)

    if len(t) < min_chars:
        pad = " 전제와 기준을 분리해 논증하면 감정이 아니라 구조로 판단 가능함. 결론은 한 문장으로 압축하는 게 설득에 유리함."
        t = (t + pad).strip()
        t = ensure_eum_style(t, max_lines=6).replace("\n", " ").strip()
        t = re.sub(r"\s+", " ", t)

    if len(t) > max_chars:
        t = t[:max_chars].rstrip()
        t = ensure_eum_style(t, max_lines=6).replace("\n", " ").strip()
        t = re.sub(r"\s+", " ", t)
    # Hotfix2: final post-process (no ellipsis, no stray fragments)
    t = postprocess_outgoing_text(t, mode="arena", max_chars=max_chars, max_lines=6).replace("\n", " ").strip()
    t = re.sub(r"\s+", " ", t)
    return t

def _arena_side_stats(posts: List[Dict[str, Any]]) -> Dict[str, Dict[str, float]]:
    stats: Dict[str, Dict[str, float]] = {"PRO": {"n": 0.0, "score": 0.0}, "CON": {"n": 0.0, "score": 0.0}}
    for p in posts or []:
        if not isinstance(p, dict):
            continue
        side = str(p.get("side") or "").upper()
        if side not in ("PRO", "CON"):
            continue
        up = _safe_float(p.get("upvotes"), 0.0)
        down = _safe_float(p.get("downvotes"), 0.0)
        stats[side]["n"] += 1.0
        stats[side]["score"] += (up - down)
    return stats

def _arena_update_my_posts(arena: Dict[str, Any], posts: List[Dict[str, Any]], nick: str) -> None:
    my = arena.get("my_posts")
    if not isinstance(my, dict):
        my = {}
        arena["my_posts"] = my

    day = str(arena.get("day") or "")
    stop_day = str(arena.get("risk_stop_day") or "")
    stoploss_triggered = bool(stop_day) and (stop_day == day)

    prev_risk_mode = bool(arena.get("risk_mode") is True)
    prev_risk_level = str(arena.get("risk_level") or "")
    prev_stop_day = stop_day
    prev_active = prev_risk_mode and bool(prev_stop_day) and (prev_stop_day == day)

    worst_risk = 0.0
    worst_pid = ""
    best_ts = -1.0
    best_id = ""
    best_up = 0
    best_down = 0
    best_side = ""

    for p in posts or []:
        if not isinstance(p, dict):
            continue
        if str(p.get("nickname") or "") != str(nick or ""):
            continue
        pid = str(p.get("id") or "")
        if not pid:
            continue
        up = int(_safe_float(p.get("upvotes"), 0.0))
        down = int(_safe_float(p.get("downvotes"), 0.0))
        ts = _parse_iso_ts(str(p.get("created_at") or ""))
        side = str(p.get("side") or "")
        my[pid] = {"up": up, "down": down, "ts": ts, "side": side}

        risk = float(down - up)
        if risk > worst_risk:
            worst_risk = risk
            worst_pid = pid

        # Track latest of *my* posts today for cooldown-buff computation (Unit 10).
        if ts > best_ts:
            best_ts = float(ts)
            best_id = pid
            best_up = up
            best_down = down
            best_side = side

    if best_id:
        arena["last_my_post_id"] = best_id
        arena["last_my_post_up"] = int(best_up)
        arena["last_my_post_down"] = int(best_down)
        arena["last_my_post_ts"] = float(best_ts)
        arena["last_my_post_side"] = str(best_side or "")

    # Blind / stoploss policy (Unit 11)
    arena["risk_score"] = float(worst_risk)
    arena["risk_source_post_id"] = str(worst_pid or "")
    arena["risk_last_update_ts"] = float(time.time())

    # If stoploss already triggered today, keep hard-stop until daily reset.
    if stoploss_triggered:
        arena["risk_mode"] = True
        if str(arena.get("risk_level") or "").upper() not in ("DANGER", "BLIND"):
            arena["risk_level"] = "DANGER"
        arena["risk_style"] = "conservative"
        return

    # Progressive risk levels:
    # - CAUTION: risk >= 3 => conservative style (still allowed)
    # - DANGER:  risk >= 4 => stop fighting today (support-only in later unit)
    # - BLIND:   risk >= 5 => immediate hard-stop (likely already blind)
    if worst_risk >= 5.0:
        arena["risk_level"] = "BLIND"
        arena["risk_mode"] = True
        arena["risk_style"] = "conservative"
        arena["risk_stop_day"] = day
        if not prev_active:
            log_event("arena_stoploss_enter", day=str(day), risk_level=str(arena.get("risk_level") or ""), risk_score=float(worst_risk), post_id=str(worst_pid or ""))
    elif worst_risk >= 4.0:
        arena["risk_level"] = "DANGER"
        arena["risk_mode"] = True
        arena["risk_style"] = "conservative"
        arena["risk_stop_day"] = day
        if not prev_active:
            log_event("arena_stoploss_enter", day=str(day), risk_level=str(arena.get("risk_level") or ""), risk_score=float(worst_risk), post_id=str(worst_pid or ""))
    elif worst_risk >= 3.0:
        arena["risk_level"] = "CAUTION"
        arena["risk_mode"] = False
        arena["risk_style"] = "conservative"
    else:
        arena["risk_level"] = "OK"
        arena["risk_mode"] = False
        arena["risk_style"] = ""

def _arena_latest_my_post(arena: Dict[str, Any]) -> Tuple[str, int, int, float, str]:
    """Return (post_id, up, down, ts, side) for the latest arena post by us today."""
    pid = str(arena.get("last_my_post_id") or "")
    if pid:
        return (
            pid,
            int(arena.get("last_my_post_up", 0) or 0),
            int(arena.get("last_my_post_down", 0) or 0),
            float(arena.get("last_my_post_ts", 0.0) or 0.0),
            str(arena.get("last_my_post_side") or ""),
        )

    # Fallback: compute from my_posts map
    my = arena.get("my_posts")
    if isinstance(my, dict) and my:
        best = ("", 0, 0, -1.0, "")
        for k, v in my.items():
            if not isinstance(v, dict):
                continue
            ts = float(v.get("ts", 0.0) or 0.0)
            if ts > best[3]:
                best = (
                    str(k),
                    int(v.get("up", 0) or 0),
                    int(v.get("down", 0) or 0),
                    ts,
                    str(v.get("side") or ""),
                )
        if best[0]:
            return best
    return ("", 0, 0, 0.0, "")

def _arena_effective_cooldown_sec(arena: Dict[str, Any], base_cd_sec: float) -> float:
    """Compute effective arena cooldown using upvote buff: 1 upvote => -30 minutes, not below 0."""
    pid, up, _down, _ts, _side = _arena_latest_my_post(arena)
    reduction = int(up) * 30 * 60
    eff = max(0.0, float(base_cd_sec) - float(reduction))
    arena["last_effective_cooldown_sec"] = float(eff)
    arena["last_cooldown_upvotes"] = int(up)
    arena["last_cooldown_post_id"] = str(pid or "")
    return float(eff)

def _arena_post_score(p: Dict[str, Any]) -> float:
    up = _safe_float(p.get("upvotes"), 0.0)
    down = _safe_float(p.get("downvotes"), 0.0)
    return float(up - down)

def _arena_pick_post(
    posts: List[Dict[str, Any]],
    side: str,
    *,
    avoid_ids: Optional[set] = None,
    min_len: int = 30,
    prefer_high_score: bool = True,
) -> Optional[Dict[str, Any]]:
    side = str(side or "").upper().strip()
    avoid_ids = avoid_ids or set()
    cand: List[Tuple[float, Dict[str, Any]]] = []
    for p in posts or []:
        if not isinstance(p, dict):
            continue
        if str(p.get("side") or "").upper().strip() != side:
            continue
        pid = str(p.get("id") or "")
        if pid and pid in avoid_ids:
            continue
        c = sanitize_plain_text(str(p.get("content") or "")).strip()
        if len(c) < int(min_len):
            continue
        sc = _arena_post_score(p)
        cand.append((float(sc), p))
    if not cand:
        return None
    cand.sort(key=lambda x: x[0], reverse=bool(prefer_high_score))
    # pick among top-k to avoid determinism
    k = min(3, len(cand))
    top = cand[:k]
    return random.choice([p for _, p in top]) if top else cand[0][1]

def _arena_choose_side(arena: Dict[str, Any], posts: List[Dict[str, Any]]) -> str:
    """Choose a side with a mild novelty bias (Unit 12 improvement)."""
    last = str(arena.get("last_post_side") or "").upper()
    stats = _arena_side_stats(posts)
    pro = _safe_dict(stats.get("PRO"))
    con = _safe_dict(stats.get("CON"))
    n_pro, n_con = int(pro.get("n", 0) or 0), int(con.get("n", 0) or 0)
    # average score per post (avoid divide-by-zero)
    avg_pro = float(pro.get("score", 0.0) or 0.0) / float(max(1, n_pro))
    avg_con = float(con.get("score", 0.0) or 0.0) / float(max(1, n_con))

    # If one side is overwhelmingly crowded, pick the other side to add marginal value
    if n_pro >= n_con + 3:
        return "CON"
    if n_con >= n_pro + 3:
        return "PRO"

    # If one side is consistently getting better reception, prefer it slightly (human buff correlation)
    if abs(avg_pro - avg_con) >= 1.5 and (n_pro + n_con) >= 4:
        return "PRO" if avg_pro > avg_con else "CON"

    # otherwise keep continuity most of the time
    if last in ("PRO", "CON") and random.random() < 0.70:
        return last
    return "PRO" if random.random() < 0.5 else "CON"

def _arena_decide_strategy(
    arena: Dict[str, Any],
    posts: List[Dict[str, Any]],
    side: str,
    *,
    conservative: bool = False,
) -> Tuple[str, Optional[Dict[str, Any]]]:
    """Observe→Decide (support/refute) (Unit 12).

    Returns: (strategy, target_post_dict_or_None)
      - strategy: SUPPORT | REFUTE
      - target_post: a post to anchor the argument (opponent for REFUTE, ally for SUPPORT)
    """
    if conservative:
        return "SUPPORT", None

    side = str(side or "").upper().strip()
    opp_side = "CON" if side == "PRO" else "PRO"

    # recently targeted posts (avoid repeating the same fight)
    recent = arena.get("recent_target_post_ids")
    if not isinstance(recent, list):
        recent = []
        arena["recent_target_post_ids"] = recent
    avoid = set([str(x) for x in recent if x])

    stats = _arena_side_stats(posts)
    n_our = int(stats.get(side, {}).get("n", 0) or 0)
    n_opp = int(stats.get(opp_side, {}).get("n", 0) or 0)
    avg_our = float(stats.get(side, {}).get("score", 0.0) or 0.0) / float(max(1, n_our))
    avg_opp = float(stats.get(opp_side, {}).get("score", 0.0) or 0.0) / float(max(1, n_opp))

    our_best = _arena_pick_post(posts, side, avoid_ids=avoid, prefer_high_score=True)
    opp_best = _arena_pick_post(posts, opp_side, avoid_ids=avoid, prefer_high_score=True)

    our_best_score = _arena_post_score(our_best) if isinstance(our_best, dict) else -999.0
    opp_best_score = _arena_post_score(opp_best) if isinstance(opp_best, dict) else -999.0

    # Decide: refute when opponent has a strong or influential post; otherwise support our side (fill gaps).
    want_refute = False
    if isinstance(opp_best, dict):
        if opp_best_score >= 4.0:
            want_refute = True
        elif (avg_opp - avg_our) >= 1.5 and n_opp >= 2:
            want_refute = True
        elif (opp_best_score - our_best_score) >= 2.5 and n_opp >= 1:
            want_refute = True

    # If our side is underrepresented, prefer SUPPORT even if refute is tempting (reduce blind risk by aligning).
    if n_our + 1 < n_opp and random.random() < 0.65:
        want_refute = False

    if want_refute and isinstance(opp_best, dict):
        target = opp_best
        strategy = "REFUTE"
    else:
        target = our_best if isinstance(our_best, dict) else None
        strategy = "SUPPORT"

    # Update recent target cache
    if isinstance(target, dict):
        pid = str(target.get("id") or "")
        if pid:
            recent.append(pid)
            if len(recent) > 12:
                del recent[:-12]

    arena["last_strategy"] = strategy
    return strategy, target

def _arena_compose_fight(
    topic: Dict[str, Any],
    side: str,
    posts: List[Dict[str, Any]],
    *,
    strategy: str = "SUPPORT",
    target: Optional[Dict[str, Any]] = None,
    risk_level: str = "",
    meta_out: Optional[Dict[str, Any]] = None,
) -> str:
    """Compose an arena 'fight' text with grounding and anti-copy safeguards (Unit 10).

    Goals:
      - Avoid verbatim reuse of topic pros/cons or other posts (plausible "copy" suspicion)
      - Keep a stable 논증 골격 (정의→기준→검증) but with variation
      - Run a light QA gate + grounding overlap check
    """
    title = str(topic.get("title") or "").strip()
    pros = str(topic.get("pros") or "").strip()
    cons = str(topic.get("cons") or "").strip()

    rl = str(risk_level or "").upper().strip()
    conservative = rl in ("CAUTION", "DANGER", "BLIND")

    side = str(side or "").upper().strip()
    if side not in ("PRO", "CON"):
        side = "PRO" if random.random() < 0.5 else "CON"
    opp_side = "CON" if side == "PRO" else "PRO"

    strategy = str(strategy or "SUPPORT").upper().strip()
    if strategy not in ("SUPPORT", "REFUTE"):
        strategy = "SUPPORT"
    if conservative:
        strategy = "SUPPORT"

    # Host-provided seeds (do NOT copy; use only for keyword hints)
    seed = pros if side == "PRO" else cons
    opp_seed = cons if side == "PRO" else pros

    # -------------------------
    # Reference collection
    # -------------------------
    def _clean_ref(s: str, maxlen: int = 420) -> str:
        s = sanitize_plain_text(str(s or "")).strip()
        s = re.sub(r"\s+", " ", s)
        return s[:maxlen].strip()

    refs: List[str] = []

    def _add_ref(s: str) -> None:
        s2 = _clean_ref(s)
        if s2 and len(s2) >= 10:
            refs.append(s2)

    _add_ref(title)
    _add_ref(seed)
    _add_ref(opp_seed)

    # include top posts on both sides as references (avoid accidental echo)
    def _top_posts_text(side_: str, k: int) -> List[str]:
        out: List[Tuple[float, str]] = []
        for p in posts or []:
            if not isinstance(p, dict):
                continue
            if str(p.get("side") or "").upper().strip() != str(side_).upper().strip():
                continue
            c = _clean_ref(p.get("content") or "", maxlen=420)
            if len(c) < 25:
                continue
            sc = _arena_post_score(p)
            out.append((float(sc), c))
        out.sort(key=lambda x: x[0], reverse=True)
        return [c for _, c in out[: max(0, int(k))]]

    k_ref = int(ARENA_REF_TOPK)
    if k_ref > 0:
        for c in _top_posts_text("PRO", k_ref):
            _add_ref(c)
        for c in _top_posts_text("CON", k_ref):
            _add_ref(c)

    # include target (full) as ref to avoid quoting
    target_full = ""
    target_side = ""
    target_id = ""
    if isinstance(target, dict):
        target_full = _clean_ref(target.get("content") or "", maxlen=520)
        target_side = str(target.get("side") or "").upper().strip()
        target_id = str(target.get("id") or "")
        _add_ref(target_full)

    # -------------------------
    # Anti-copy helpers
    # -------------------------
    def _ngram_set(s: str, n: int = 3) -> set:
        s = re.sub(r"\s+", "", sanitize_plain_text(s or ""))
        if len(s) < n:
            return set()
        return {s[i:i+n] for i in range(0, len(s) - n + 1)}

    def _jaccard(a: str, b: str, n: int = 3) -> float:
        A = _ngram_set(a, n=n)
        B = _ngram_set(b, n=n)
        if not A or not B:
            return 0.0
        inter = len(A & B)
        union = len(A | B)
        return inter / union if union else 0.0

    def _has_long_substring(gen: str, ref: str, L: int) -> bool:
        g = re.sub(r"\s+", "", sanitize_plain_text(gen or ""))
        r = re.sub(r"\s+", "", sanitize_plain_text(ref or ""))
        if len(g) < L or len(r) < L:
            return False
        # scan ref windows (L) – small L, refs are short -> ok
        for i in range(0, len(r) - L + 1):
            if r[i:i+L] in g:
                return True
        return False

    def _anticopy_report(gen: str) -> Dict[str, Any]:
        thr_j = float(ARENA_ANTICOPY_JACCARD)
        L = int(ARENA_ANTICOPY_SUBSTR_LEN)
        thr_h = int(ARENA_ANTICOPY_SIMHASH_MAX)

        gen_s = _clean_ref(gen, 800)
        max_j = 0.0
        hit_sub = False
        min_h = 64
        worst_ref = ""

        gtoks = tokenize(gen_s, max_tokens=180)
        gsh = int(simhash64(gtoks[:160])) if gtoks else 0

        for r in refs:
            rr = _clean_ref(r, 520)
            if not rr:
                continue
            if _has_long_substring(gen_s, rr, L=L):
                hit_sub = True
                worst_ref = worst_ref or rr[:80]
            j = _jaccard(gen_s, rr, n=3)
            if j > max_j:
                max_j = float(j)
                worst_ref = rr[:80]
            # simhash proximity
            rtoks = tokenize(rr, max_tokens=180)
            rsh = int(simhash64(rtoks[:160])) if rtoks else 0
            if gsh and rsh:
                ham = int(hamming64(gsh, rsh))
                if ham < min_h:
                    min_h = ham

        fail_j = bool(max_j >= thr_j) if thr_j > 0 else False
        fail_h = bool(min_h <= thr_h) if thr_h >= 0 else False
        return {
            "max_jaccard": round(float(max_j), 4),
            "hit_substring": bool(hit_sub),
            "min_hamming": int(min_h if min_h != 64 else 64),
            "fail_jaccard": bool(fail_j),
            "fail_hamming": bool(fail_h),
            "worst_ref_hint": worst_ref,
        }

    # -------------------------
    # Keyword hints (from seed only)
    # -------------------------
    def _pick_keywords(text: str) -> List[str]:
        kws = top_keywords(text or "", k=8)
        out: List[str] = []
        for w in kws:
            w = normalize_ko_token(w)
            if not is_clean_keyword(w):
                continue
            if not (2 <= len(w) <= 12):
                continue
            if w not in out:
                out.append(w)
            if len(out) >= 5:
                break
        return out

    kws = _pick_keywords(f"{title} {seed}") or _pick_keywords(f"{title} {opp_seed}") or ["기준", "예외", "정의"]
    kw1 = kws[0] if len(kws) >= 1 else "기준"
    kw2 = kws[1] if len(kws) >= 2 else "예외"
    kw3 = kws[2] if len(kws) >= 3 else kw1

    def _anchor_hint() -> str:
        if not target_full:
            return ""
        ak = _pick_keywords(target_full)
        a1 = ak[0] if len(ak) >= 1 else kw1
        a2 = ak[1] if len(ak) >= 2 else kw2
        # avoid looking like a quote
        tag = "상대" if (strategy == "REFUTE" and (target_side == opp_side or not target_side)) else "우리"
        return f"{tag}는 {a1}/{a2} 쪽을 중심으로 말하는 흐름으로 보임."

    # Optionally allow verbatim small snippet (default off)
    verb_anchor = ""
    if bool(ARENA_USE_ANCHOR_VERBATIM) and isinstance(target, dict):
        verb_anchor = one_line(_clean_ref(target.get("content") or "", 220), 90)

    # -------------------------
    # Argument skeleton pools
    # -------------------------
    OPENER_POOL = [
        "일단 내 입장부터 말하겠음.",
        "핵심만 잡고 말하겠음.",
        "상대 요지 하나 집어서 반박하겠음.",
    ]

    PRO_CRITERIA = [
        "기준은 '예방/격리' 축을 우선으로 잡겠음.",
        "핵심은 비용이 아니라, 피해 재발 가능성을 얼마나 낮추느냐임.",
        f"{kw1}이(가) 불명확하면 책임이 분산돼서 제도가 흔들림.",
        f"{kw2} 처리가 애매하면 여론은 감정으로 튐.",
        "절차가 아니라 결과가 중요하다고 할 때, 결과 측정 지표를 먼저 합의해야 함.",
    ]
    CON_CRITERIA = [
        "기준은 '오판/되돌림 불가' 축을 우선으로 잡겠음.",
        "핵심은 효율이 아니라, 한 번의 오류가 영구히 남는 구조임.",
        f"{kw1}을(를) 국가가 독점할수록 통제 장치가 더 중요해짐.",
        f"{kw2}를(을) 예외로 넘기기 시작하면 남용 구멍이 생김.",
        "절차가 무너지면 결과의 정당성도 같이 무너지는 구조임.",
    ]

    DEFINE_POOL = [
        f"여기서 {kw1}은(는) '판단을 고정하는 규칙' 쪽으로 정의하겠음.",
        f"{kw2}는(은) 본문에 섞지 말고 조건으로 따로 빼는 게 깔끔함.",
        "정의가 넓어지면 토론은 결국 감정 싸움으로 흘러가기 쉬움.",
    ]

    CHECK_POOL = [
        "검증은 케이스를 2~3개로 쪼개서 일관성만 보면 됨.",
        "검증 포인트는 '반례가 들어와도 기준이 유지되냐'임.",
        "검증에서 애매하면 원칙/예외를 다시 분리해야 함.",
    ]

    SUPPORT_ADD = [
        f"조건 하나: {kw1}을(를) 결과로 볼지 의도로 볼지 먼저 고정해야 함.",
        f"반례 대비: {kw2} 케이스는 원칙/예외로 분리해두는 게 안전함.",
        f"질문: {kw2}의 기준은 '피해 규모'냐 '의도/동기'냐 뭐가 우선임?",
    ]
    REFUTE_ADD = [
        f"찔러볼 지점: {kw1} 정의가 넓으면 어떤 결론도 끼워 맞출 수 있음.",
        f"반례: {kw2} 케이스 하나만 들어와도 전체 논증이 무너질 수 있음.",
        f"질문: 지금 논리에서 {kw3}는 기준임, 감정임? 어디에 놓고 말하는 거임?",
    ]

    CONCEDE_POOL = [
        f"상대 우려 중 {kw2} 쪽은 타당한 지점이 있음.",
        "상대가 말하는 위험은 인정하되, 그걸 제도 전체 결론으로 바로 점프하면 과함.",
        "상대 포인트가 틀렸다기보다, 전제가 섞여서 결론이 과대해지는 느낌임.",
    ]

    CLOSE_POOL = [
        "결론은 이쪽임. 반대쪽은 어떤 전제를 제일 무겁게 보나 궁금함.",
        "정리하면 이거임. 상대 논점 중 뭐가 제일 강하다고 봄?",
        "끝으로 질문 하나만 던지겠음. 기준을 하나만 고른다면 뭘 고를 거임?",
    ]

    def _completeness_bonus(t: str) -> int:
        bonus = 0
        if "정의" in t:
            bonus += 3
        if "기준" in t:
            bonus += 3
        if ("검증" in t) or ("반례" in t):
            bonus += 2
        if ("예외" in t) or ("조건" in t):
            bonus += 2
        if "?" in t[-60:]:
            bonus += 2
        return int(bonus)

    def _build_variant(attempt: int) -> str:
        rnd = random.Random(_sha1_u64(f"{title}|{side}|{strategy}|{attempt}|{time.time()}"))
        frame: List[str] = []
        frame.append(rnd.choice(OPENER_POOL))
        frame.append(f"주제는 {one_line(title, 64)}임.")
        side_ko = "찬성" if side == "PRO" else "반대"
        frame.append(f"내 입장은 {side_ko} 쪽으로 기울었음.")

        # core: define + criteria + check
        frame.append(rnd.choice(DEFINE_POOL))
        crit_pool = PRO_CRITERIA if side == "PRO" else CON_CRITERIA
        frame.extend(rnd.sample(crit_pool, k=2))
        frame.append(rnd.choice(CHECK_POOL))

        hint = _anchor_hint()
        if strategy == "REFUTE":
            if hint:
                frame.append(hint)
            if verb_anchor:
                frame.append(f"(문장 그대로 인용은 아님) {verb_anchor} 정도로 읽히는 글이 있었음.")
            frame.append(rnd.choice(CONCEDE_POOL))
            frame.append("근데 전제가 섞이면 결론이 뒤틀림. 핵심 전제부터 고정해야 함.")
            frame.append("전제가 섞이면 같은 말로도 서로 다른 결론이 나올 수 있음.")
            frame.append(rnd.choice(REFUTE_ADD))
        else:
            if hint:
                frame.append(hint.replace("상대", "우리"))
            frame.append("논점을 분리하면 말이 덜 꼬임.")
            frame.append("반례는 예외로 빼서 다루면 본문이 덜 흔들림.")
            frame.append(rnd.choice(SUPPORT_ADD))

        if conservative:
            frame.append("오늘은 과격하게 안 감. 핵심만 말하겠음.")
        frame.append(rnd.choice(CLOSE_POOL))

        t = " ".join([x for x in frame if x])
        t = re.sub(r"(ㅋ{2,}|ㅎ{2,})", "", t)
        t = re.sub(r"[!]{2,}", "!", t)
        t = re.sub(r"\s+", " ", t).strip()
        return t

    # -------------------------
    # Search best candidate
    # -------------------------
    focus = {
        "post_title": title,
        "post_excerpt": _clean_ref(f"{seed} {opp_seed}", 420),
        "mode": "comment",
    }

    best_txt = ""
    best_score = -10_000.0
    best_meta: Dict[str, Any] = {}
    tried = 0
    passed = 0

    n_try = max(3, int(ARENA_ARG_VARIANTS))
    for attempt in range(n_try):
        tried += 1
        raw = _build_variant(attempt)
        cand = _arena_enforce_len_eum(raw, min_chars=300, max_chars=500)

        ac = _anticopy_report(cand)
        qa = qa_evaluate_text(cand, kind="comment", focus=focus, mode="comment")
        qa_score = int(qa.get("score", 0) or 0)
        hard = bool(qa.get("hard_fail"))
        bonus = _completeness_bonus(cand)

        penalty = 0.0
        if bool(ac.get("hit_substring")):
            penalty += 70.0
        if bool(ac.get("fail_jaccard")):
            # scale with overflow
            try:
                overflow = max(0.0, float(ac.get("max_jaccard", 0.0)) - float(ARENA_ANTICOPY_JACCARD))
            except Exception:
                overflow = 0.0
            penalty += 45.0 + (overflow * 120.0)
        if bool(ac.get("fail_hamming")):
            penalty += 30.0

        total = float(qa_score) + float(bonus) - float(penalty)

        ok = (not hard) and qa_score >= int(ARENA_QUALITY_MIN) and (not ac.get("hit_substring")) and (not ac.get("fail_jaccard")) and (not ac.get("fail_hamming"))
        if ok:
            passed += 1

        # choose best even if not ok (fallback), but strongly prefer ok
        rank = total + (40.0 if ok else 0.0)
        if rank > best_score:
            best_score = float(rank)
            best_txt = cand
            best_meta = {
                "qa_score": qa_score,
                "qa_issues": qa.get("issues", []),
                "qa_len": int(qa.get("len", 0) or 0),
                "anti_copy": ac,
                "bonus": int(bonus),
                "penalty": round(float(penalty), 2),
                "total": round(float(total), 2),
                "ok": bool(ok),
                "tried": int(tried),
                "passed": int(passed),
            }

        # early exit if very good
        if ok and qa_score >= 85 and float(ac.get("max_jaccard", 0.0)) <= 0.30:
            break

    if not best_txt:
        side_ko = "찬성" if side == "PRO" else "반대"
        best_txt = f"정의-기준-검증 순서로 말하겠음. 주제는 {one_line(title, 64)}임. 내 입장은 {side_ko} 쪽임. 기준은 하나로 고정하고 예외는 조건으로 분리하는 게 먼저임. 질문 하나: 여기서 기준은 결과냐 의도냐?"
        best_txt = _arena_enforce_len_eum(best_txt, min_chars=300, max_chars=500)
        best_meta = {"ok": False, "tried": tried, "passed": passed}

    # Export meta if requested
    if isinstance(meta_out, dict):
        try:
            meta_out.update(
                {
                    "arena_side": side,
                    "arena_strategy": strategy,
                    "arena_conservative": bool(conservative),
                    "arena_target_post_id": str(target_id or ""),
                    "arena_target_side": str(target_side or ""),
                    "arena_refs_count": int(len(refs)),
                    "arena_variants_tried": int(tried),
                    "arena_variants_passed": int(passed),
                    "arena_compose_ok": bool(best_meta.get("ok", False)),
                    "arena_qa_score": int(best_meta.get("qa_score", 0) or 0),
                    "arena_qa_issues": best_meta.get("qa_issues", []),
                    "arena_anticopy": best_meta.get("anti_copy", {}),
                    "arena_score_total": float(best_meta.get("total", 0.0) or 0.0),
                }
            )
        except Exception as e:
            log_debug_exc("_arena_compose_fight:silent", e)
            pass

    return best_txt

def do_arena_flow(
    client: HttpClient,
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    memory: List[Dict[str, Any]],
    brain: Dict[str, Any],
) -> int:
    """Integrate Colosseum actions into main loop (Unit 09).

    - Checks /arena/status occasionally (cached)
    - Phase 1 (00~09 KST): propose once per day
    - Phase 3 (12~24 KST): fight respecting basic cooldown (advanced cooldown & blind handling in later units)
    """
    # ============================================================
    # SECTION 1: Status/cache + phase gating
    # ============================================================
    if not ARENA_ENABLE:
        protocol_set_reason(state, "arena", "arena:phase_block", "disabled")
        return 0

    arena = state.get("arena")
    if not isinstance(arena, dict):
        arena = {}
        state["arena"] = arena

    now_dt = now_kst()
    now_ts = time.time()

    # status (cached)
    status: Optional[Dict[str, Any]] = None
    last_status_ts = float(arena.get("last_status_ts", 0.0) or 0.0)
    cached = arena.get("status_cache")
    if isinstance(cached, dict) and (now_ts - last_status_ts) < float(ARENA_STATUS_MIN_INTERVAL_SEC):
        status = cached
    else:
        try:
            status = arena_status(client)
            if isinstance(status, dict):
                arena["status_cache"] = status
                arena["last_status_ts"] = now_ts
        except (RateLimitError, requests.HTTPError) as e:
            log_error("arena_status", one_line(repr(e), 180))
            raise
        except Exception as e:
            log_error("arena_status", one_line(repr(e), 180))
            status = cached if isinstance(cached, dict) else None

    if not isinstance(status, dict):
        protocol_set_reason(state, "arena", "arena:phase_block", "no_status")
        return 0

    day = str(status.get("date") or _today_kst())
    _arena_reset_day(arena, day)

    phase = str(status.get("phase") or "").upper().strip()
    if not phase:
        phase = _arena_phase_guess_kst(now_dt)
    arena["last_phase"] = phase
    arena["last_status_date"] = day

    topic = status.get("topic")
    if isinstance(topic, dict):
        arena["today_topic_id"] = str(topic.get("id") or "")
        arena["today_topic_title"] = str(topic.get("title") or "")
        arena["last_status_topic_id"] = str(topic.get("id") or "")
        arena["last_status_topic_title"] = str(topic.get("title") or "")

    # daily action cap (safety)
    actions_today = int(arena.get("actions_today", 0) or 0)
    if int(ARENA_MAX_ACTIONS_PER_DAY) > 0 and actions_today >= int(ARENA_MAX_ACTIONS_PER_DAY):
        protocol_set_reason(state, "arena", "arena:phase_block", "max_actions_per_day")
        return 0
    arena.setdefault("next_ok_at", 0.0)
    if _arena_is_blocked(arena, now_ts):
        try:
            nxt = float(arena.get("next_ok_at", 0.0) or 0.0)
            remain = max(0, int(nxt - now_ts))
            protocol_set_reason(state, "arena", "arena:cooldown", f"next_ok_in={remain}s")
        except Exception:
            protocol_set_reason(state, "arena", "arena:cooldown", "blocked")
        return 0


    # ----------------------

    # ============================================================
    # SECTION 2: Phase 1 (propose)
    # ============================================================
    # Phase 1: PROPOSE
    # ----------------------
    if phase == "PROPOSE" and (0 <= int(now_dt.hour) < 9):
        if bool(arena.get("today_proposed")):
            protocol_set_reason(state, "arena", "arena:phase_block", "already_proposed")
            return 0

        title, pros, cons = _arena_compose_propose(brain)
        # Hotfix2: sanitize propose payload (no ellipsis / no stray fragments)
        title = postprocess_outgoing_text(title, mode="title", max_chars=100, max_lines=1).replace("\\n", " ")
        pros = postprocess_outgoing_text(pros, mode="comment", max_chars=500, max_lines=2).replace("\\n", " ")
        cons = postprocess_outgoing_text(cons, mode="comment", max_chars=500, max_lines=2).replace("\\n", " ")
        try:
            payload = {"title": title, "pros": pros, "cons": cons}
            if cfg.nickname:
                payload["nickname"] = cfg.nickname

            _bump_action_counter(state, "action_attempt", "arena_propose")
            res = arena_propose(client, cfg, payload, state=state)
            if not _arena_api_ok(res):
                emsg = ""
                if isinstance(res, dict):
                    emsg = str(res.get("error") or res.get("message") or "")
                log_warn("ARENA propose rejected -> " + one_line(emsg or repr(res), 180))
                arena["today_proposed_attempted"] = True
                protocol_set_reason(state, "arena", "arena:phase_block", "propose_rejected")
                _bump_action_counter(state, "action_fail", "arena_propose")
                return 0

            pid = str(_safe_dict(res).get("id") or "")
            arena["today_proposed"] = True
            arena["today_propose_id"] = pid
            arena["today_proposed_attempted"] = True
            arena["last_action_ts"] = now_ts
            state["arena_last_action_ts"] = now_ts
            state["arena_last_propose_date"] = day
            arena["actions_today"] = actions_today + 1

            # clear arena backoff on success
            arena.pop("next_ok_at", None)
            arena.pop("next_ok_reason", None)
            arena.pop("next_ok_msg", None)

            state["total_actions"] = int(state.get("total_actions", 0) or 0) + 1
            _hb_record_contribute(state, now_ts, kind="arena")
            _bump_action_counter(state, "action_success", "arena_propose")

            record_memory(
                memory,
                {
                    "ts": now_ts,
                    "action": "arena",
                    "action_type": "arena_propose",
                    "text": f"{title} | PROS:{pros} | CONS:{cons}",
                    "post_id": pid,
                    "topic_id": "",
                    "topic_title": "",
                    "phase": phase,
                    "evaluated": True,
                    "eval_due_ts": 0.0,
                },
                tuning,
                cfg.paths.memory_archive_jsonl,
            )
            log_action("ARENA", f"propose ok id={pid or '?'} title={one_line(title, 60)}")
            write_journal(cfg.paths.journal, f"arena propose | id={pid or '?'} | title={one_line(title, 80)}")
            return 1

        except RateLimitError as e_rl:
            msg = str(e_rl)
            wait_sec = float(getattr(e_rl, "retry_after_sec", 0) or 0.0)
            mins = _arena_parse_wait_minutes(msg)
            if mins is not None:
                wait_sec = max(wait_sec, float(mins) * 60.0)
            if wait_sec <= 0:
                wait_sec = 45.0 * 60.0
            _arena_set_next_ok(arena, now_ts, wait_sec, "rate_limit", msg)
            log_warn(f"ARENA propose cooldown -> wait~{int(wait_sec)}s")
            arena["today_proposed_attempted"] = True
            protocol_set_reason(state, "arena", "arena:cooldown", f"propose_wait~{int(wait_sec)}s")
            _bump_action_counter(state, "action_fail", "arena_propose")
            return 0

        except PowTimeoutError as e:
            log_error("arena_propose", one_line(str(e), 200))
            arena["today_proposed_attempted"] = True
            protocol_set_reason(state, "arena", "arena:pow_timeout", one_line(str(e), 160))
            _bump_action_counter(state, "action_fail", "arena_propose")
            return 0

        except requests.HTTPError as e_http:
            msg = str(e_http)
            wait_sec = 0.0
            mins = _arena_parse_wait_minutes(msg)
            if mins is not None:
                wait_sec = max(wait_sec, float(mins) * 60.0)

            low = msg.lower()
            if "proposal is allowed only during propose" in low or "current phase is" in low:
                nxt = _arena_next_boundary_ts_kst(now_dt, "PROPOSE")
                if nxt > now_ts:
                    wait_sec = max(wait_sec, float(nxt - now_ts))

            if wait_sec > 0:
                _arena_set_next_ok(arena, now_ts, wait_sec, "phase_or_cooldown", msg)

            log_error("arena_propose", one_line(msg, 220))
            arena["today_proposed_attempted"] = True
            protocol_set_reason(state, "arena", "arena:phase_block", one_line(f"propose_http:{msg}", 160))
            _bump_action_counter(state, "action_fail", "arena_propose")
            return 0

        except Exception as e:
            log_error("arena_propose", one_line(repr(e), 200))
            arena["today_proposed_attempted"] = True
            protocol_set_reason(state, "arena", "arena:phase_block", one_line(f"propose_exc:{repr(e)}", 160))
            _bump_action_counter(state, "action_fail", "arena_propose")
            return 0

    # ----------------------
    # Phase 3: BATTLE
    # ----------------------
    if phase == "BATTLE" and (12 <= int(now_dt.hour) <= 23):
        # stoploss applies per-day; keep hard-stop until daily reset
        if arena.get("risk_mode") is True and str(arena.get("risk_stop_day") or "") == str(day or ""):
            protocol_set_reason(state, "arena", "arena:blinded_stop", "risk_stop_day")
            return 0
        if not isinstance(topic, dict) or not str(topic.get("id") or ""):
            protocol_set_reason(state, "arena", "arena:phase_block", "no_topic")
            return 0

        # observe posts occasionally
        posts: List[Dict[str, Any]] = []
        last_posts_ts = float(arena.get("last_posts_ts", 0.0) or 0.0)
        cached_posts = arena.get("posts_cache")
        if isinstance(cached_posts, list) and (now_ts - last_posts_ts) < float(ARENA_POSTS_MIN_INTERVAL_SEC):
            posts = [p for p in cached_posts if isinstance(p, dict)]
        else:
            try:
                posts = arena_posts(client, limit=int(getattr(tuning, "arena_fetch_limit", 40)))
                arena["posts_cache"] = posts[-80:] if isinstance(posts, list) else []
                arena["last_posts_ts"] = now_ts
            except (RateLimitError, requests.HTTPError) as e:
                log_error("arena_posts", one_line(repr(e), 180))
                raise
            except Exception as e:
                log_error("arena_posts", one_line(repr(e), 180))
                posts = [p for p in (cached_posts or []) if isinstance(p, dict)] if isinstance(cached_posts, list) else []

        if posts:
            _arena_update_my_posts(arena, posts, cfg.nickname)
            # Avoid monologue: only fight when there is a new non-self post after my latest post.
            try:
                last_my_ts = float(arena.get("last_my_post_ts", 0.0) or 0.0)
                opp_latest_ts = -1.0
                for pp in posts or []:
                    if not isinstance(pp, dict):
                        continue
                    if str(pp.get("nickname") or "") == str(cfg.nickname or ""):
                        continue
                    ts2 = _parse_iso_ts(str(pp.get("created_at") or ""))
                    if ts2 > 0 and ts2 > opp_latest_ts:
                        opp_latest_ts = float(ts2)
                if last_my_ts > 0 and opp_latest_ts >= 0 and opp_latest_ts <= (last_my_ts + 1.0):
                    protocol_set_reason(state, "arena", "arena:phase_block", "opponent_timing_guard")
                    return 0
            except Exception as e:
                log_debug_exc("do_arena_flow:silent", e)
                pass

            rl = str(arena.get("risk_level") or "").upper().strip()
            rs = float(arena.get("risk_score", 0.0) or 0.0)
            if arena.get("risk_mode") is True and str(arena.get("risk_stop_day") or "") == str(day or ""):
                log_event("arena_stoploss_active", day=str(day), risk_level=rl, risk_score=float(rs), post_id=str(arena.get("risk_source_post_id") or ""))
                log_warn("ARENA stoploss on (close to blind) -> stop fighting today")
                log_warn(f"ARENA risk_level={rl or '?'} risk_score={rs:.1f}")
                protocol_set_reason(state, "arena", "arena:blinded_stop", f"stoploss:{rl or '?'}:{rs:.1f}")
                return 0
            if rl == "CAUTION":
                # still allowed, but keep the tone conservative and avoid overfighting
                pass


        # ============================================================
        # SECTION 3: Phase 3 (fight) - cooldown, strategy, submit, update state
        # ============================================================
        # cooldown with upvote-buff (Unit 10): base 2h minus 30m per upvote on the latest of my arena posts.
        last_action = float(arena.get("last_action_ts", 0.0) or 0.0)
        base_cd = float(getattr(tuning, "arena_cooldown_sec", 2 * 60 * 60))
        eff_cd = _arena_effective_cooldown_sec(arena, base_cd)
        if last_action > 0 and (now_ts - last_action) < eff_cd:
            protocol_set_reason(state, "arena", "arena:cooldown", f"cooldown_rem={int(max(0, eff_cd - (now_ts - last_action)))}s")
            return 0
        # (Unit 02) Pin PRO/CON side per topic_id for the day to keep character consistency.
        topic_id = str(arena.get("today_topic_id") or "")
        topic_side_map = arena.setdefault("topic_side_map", {})
        side = ""
        if topic_id and isinstance(topic_side_map, dict) and topic_id in topic_side_map:
            side = str(topic_side_map.get(topic_id) or "").upper()
        if side not in ("PRO", "CON"):
            side = _arena_choose_side(arena, posts)
            side = str(side or "").upper()
            if topic_id and isinstance(topic_side_map, dict) and side in ("PRO", "CON"):
                topic_side_map[topic_id] = side
        rl_s = str(arena.get("risk_level") or "")
        conservative = str(rl_s).upper().strip() in ("CAUTION", "DANGER", "BLIND")
        strategy, target = _arena_decide_strategy(arena, posts, side, conservative=conservative)
        compose_meta: Dict[str, Any] = {}
        content = _arena_compose_fight(topic, side, posts, strategy=strategy, target=target, risk_level=rl_s, meta_out=compose_meta)

        try:
            payload = {"topic_id": topic_id, "side": side, "content": content}
            if cfg.nickname:
                payload["nickname"] = cfg.nickname

            _bump_action_counter(state, "action_attempt", "arena_fight")
            res = arena_fight(client, cfg, payload, state=state)
            if not _arena_api_ok(res):
                emsg = ""
                if isinstance(res, dict):
                    emsg = str(res.get("error") or res.get("message") or "")
                log_warn("ARENA fight rejected -> " + one_line(emsg or repr(res), 180))
                arena["today_fought_attempted"] = True
                protocol_set_reason(state, "arena", "arena:phase_block", "fight_rejected")
                _bump_action_counter(state, "action_fail", "arena_fight")
                return 0

            pid = str(_safe_dict(res).get("id") or "")
            arena["today_fought"] = True
            arena["today_fight_id"] = pid
            arena["today_fought_attempted"] = True
            arena["last_action_ts"] = now_ts
            state["arena_last_action_ts"] = now_ts
            state["arena_last_fight_date"] = day
            arena["actions_today"] = actions_today + 1

            # clear arena backoff on success
            arena.pop("next_ok_at", None)
            arena.pop("next_ok_reason", None)
            arena.pop("next_ok_msg", None)

            state["total_actions"] = int(state.get("total_actions", 0) or 0) + 1
            _hb_record_contribute(state, now_ts, kind="arena")
            _bump_action_counter(state, "action_success", "arena_fight")

            record_memory(
                memory,
                {
                    "ts": now_ts,
                    "action": "arena",
                    "action_type": "arena_fight",
                    "text": f"side={side} | {one_line(content, 220)}",
                    "post_id": pid,
                    "topic_id": topic_id,
                    "topic_title": str(topic.get("title") or ""),
                    "phase": phase,
                    "evaluated": True,
                    "eval_due_ts": 0.0,
                    "meta": {
                        "arena_qa_score": int(compose_meta.get("arena_qa_score", 0) or 0),
                        "arena_qa_issues": compose_meta.get("arena_qa_issues", []),
                        "arena_anticopy": compose_meta.get("arena_anticopy", {}),
                        "arena_compose_ok": bool(compose_meta.get("arena_compose_ok", False)),
                        "arena_score_total": float(compose_meta.get("arena_score_total", 0.0) or 0.0),
                    },
                },
                tuning,
                cfg.paths.memory_archive_jsonl,
            )
            log_action(
                "ARENA",
                f"fight ok side={side} id={pid or '?'} qa={int(compose_meta.get('arena_qa_score', 0) or 0)} topic={one_line(str(topic.get('title') or ''), 60)}",
            )
            write_journal(
                cfg.paths.journal,
                f"arena fight | side={side} | id={pid or '?'} | topic={one_line(str(topic.get('title') or ''), 80)}",
            )
            return 1

        except RateLimitError as e_rl:
            msg = str(e_rl)
            wait_sec = float(getattr(e_rl, "retry_after_sec", 0) or 0.0)
            mins = _arena_parse_wait_minutes(msg)
            if mins is not None:
                wait_sec = max(wait_sec, float(mins) * 60.0)
            if wait_sec <= 0:
                wait_sec = 110.0 * 60.0
            _arena_set_next_ok(arena, now_ts, wait_sec, "cooldown", msg)
            log_warn(f"ARENA fight cooldown -> wait~{int(wait_sec)}s")
            arena["today_fought_attempted"] = True
            protocol_set_reason(state, "arena", "arena:cooldown", f"fight_wait~{int(wait_sec)}s")
            _bump_action_counter(state, "action_fail", "arena_fight")
            return 0

        except PowTimeoutError as e:
            log_error("arena_fight", one_line(str(e), 200))
            arena["today_fought_attempted"] = True
            protocol_set_reason(state, "arena", "arena:pow_timeout", one_line(str(e), 160))
            _bump_action_counter(state, "action_fail", "arena_fight")
            return 0

        except requests.HTTPError as e_http:
            msg = str(e_http)
            wait_sec = 0.0
            mins = _arena_parse_wait_minutes(msg)
            if mins is not None:
                wait_sec = max(wait_sec, float(mins) * 60.0)

            low = msg.lower()
            if "fighting is allowed only during battle" in low or "current phase is" in low:
                nxt = _arena_next_boundary_ts_kst(now_dt, "BATTLE")
                if nxt > now_ts:
                    wait_sec = max(wait_sec, float(nxt - now_ts))

            if wait_sec > 0:
                _arena_set_next_ok(arena, now_ts, wait_sec, "phase_or_cooldown", msg)

            log_error("arena_fight", one_line(msg, 220))
            arena["today_fought_attempted"] = True
            protocol_set_reason(state, "arena", "arena:phase_block", one_line(f"fight_http:{msg}", 160))
            _bump_action_counter(state, "action_fail", "arena_fight")
            return 0

        except Exception as e:
            log_error("arena_fight", one_line(repr(e), 200))
            arena["today_fought_attempted"] = True
            protocol_set_reason(state, "arena", "arena:phase_block", one_line(f"fight_exc:{repr(e)}", 160))
            _bump_action_counter(state, "action_fail", "arena_fight")
            return 0

    protocol_set_reason(state, "arena", "arena:phase_block", "no_phase_action")
    return 0
