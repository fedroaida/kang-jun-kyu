################################################################################
# 12. BRAIN & ACTION BIAS (restored from v6.2; v6.3 hotfix2)
# Deps: 00-11
# Used by: flow_scan, arena, contrib, reward_update
################################################################################
"""
SECTION 12 - BRAIN + ACTION BIAS

The agent's light-weight "brain" utilities (no LLM).

Responsibilities:
- Track recent actions, reflections, and hashed memories.
- Provide bias signals for strategy selection and context sensitivity.
- Offer keyword extraction and classification helpers used across flows.

Notes:
- This module tends to grow; keep helpers small and well-named to avoid becoming a junk drawer.
"""
def _ab_alpha_from_decay(decay: float) -> float:
    d = float(decay)
    if not (0.0 < d < 1.0):
        d = 0.98
    return max(0.001, min(0.25, 1.0 - d))

def _ab_update_slot(slot: Dict[str, Any], key: str, delta: float, *, decay: float) -> None:
    if not key:
        return
    try:
        old = float(slot.get(key, 0.0) or 0.0)
    except Exception:
        old = 0.0
    a = _ab_alpha_from_decay(decay)
    # bounded EMA-ish update
    slot[key] = float((1.0 - a) * old + a * float(delta))

def _ab_apply(
    brain: Dict[str, Any],
    *,
    action_type: str,
    kw: str = "",
    template_id: str = "",
    target_nick: str = "",
    thread_id: str = "",
    delta: float,
) -> None:
    """
    Update brain.action_bias.

    final6:
      - Adds by_thread slot keyed by post_id (thread_id) to support thread-level reinforcement.
        (Backwards compatible: absent slot simply won't be used.)
    """
    if not isinstance(brain, dict):
        return
    ab = brain.get("action_bias")
    if not isinstance(ab, dict):
        ab = {"by_action": {}, "by_topic_kw": {}, "by_template": {}, "by_user": {}, "by_thread": {}, "last_update_ts": 0.0, "decay": 0.98}
        brain["action_bias"] = ab

    by_action = ab.setdefault("by_action", {})
    by_topic = ab.setdefault("by_topic_kw", {})
    by_tpl = ab.setdefault("by_template", {})
    by_user = ab.setdefault("by_user", {})
    by_thread = ab.setdefault("by_thread", {})
    decay = float(ab.get("decay", 0.98) or 0.98)

    # clamp delta to a sane range
    d = float(delta)
    if d > 1.0:
        d = 1.0
    if d < -1.0:
        d = -1.0

    _ab_update_slot(by_action, str(action_type or ""), d, decay=decay)
    if kw:
        _ab_update_slot(by_topic, str(kw), d, decay=decay)
    if template_id:
        _ab_update_slot(by_tpl, str(template_id), d, decay=decay)
    if target_nick:
        _ab_update_slot(by_user, str(target_nick), d, decay=decay)
    if thread_id:
        _ab_update_slot(by_thread, str(thread_id), d, decay=decay)

    ab["last_update_ts"] = time.time()

def compute_proxy_reward(text: str, *, mode: str, ground_reason: str = "") -> float:
    """Cheap immediate proxy score in [-1, +1]. (Unit 07)

    This is intentionally lightweight: it should not add API calls.
    """
    t = (text or "").strip()
    if not t:
        return -0.8

    m = str(mode or "")
    gr = str(ground_reason or "")
    n = len(t)

    # grounding signal: if validator said ok/weak_ok => positive bias
    g = 0.0
    if gr in ("ok", "weak_ok"):
        g = 0.35
    elif gr in ("no_target", "no_focus", "no_tokens"):
        g = 0.18
    elif gr:
        # unknown reason (but passed) => small
        g = 0.12

    # length preference (comment/reply: 100~500 recommended; post can be longer)
    if m in ("comment", "reply"):
        if 100 <= n <= 520:
            l = 0.35
        elif 70 <= n <= 800:
            l = 0.18
        else:
            l = -0.15
    else:
        # post / other
        if 180 <= n <= 950:
            l = 0.25
        elif 120 <= n <= 1200:
            l = 0.15
        else:
            l = -0.10

    # simple eum-style heuristic (very lightweight)
    s = 0.0
    tail = t[-3:]
    if any(x in tail for x in ("음", "슴")):
        s = 0.10

    # mild penalty for excessive punctuation density
    punct = sum(1 for ch in t if ch in "!?")
    p = -0.05 if punct >= 4 else 0.0

    r = g + l + s + p
    if r > 1.0:
        r = 1.0
    if r < -1.0:
        r = -1.0
    return float(r)

def apply_brain_proxy_update(brain: Dict[str, Any], tuning: AgentTuning, item: Dict[str, Any]) -> None:
    """Apply immediate proxy update to action_bias once per item. (final6: also updates context_arm_stats)."""
    if not isinstance(brain, dict) or not isinstance(item, dict):
        return
    if item.get("brain_proxy_applied") is True:
        return

    act = str(item.get("action") or "")
    if act not in ("comment", "reply", "post"):
        item["brain_proxy_applied"] = True
        return

    action_type = str(item.get("action_type") or act)
    kw = str(item.get("kw") or "")
    tpl = str(item.get("template_id") or "")
    target = str(item.get("target_nick") or "")
    thread_id = str(item.get("post_id") or "")

    pr = item.get("proxy_reward")
    if pr is None:
        pr = compute_proxy_reward(
            str(item.get("text") or ""),
            mode=("reply" if act == "reply" else "comment" if act == "comment" else "post"),
            ground_reason=str(item.get("ground_reason") or ""),
        )
        item["proxy_reward"] = float(pr)

    # proxy should be gentle: smaller than delayed reward
    d = float(pr) * 0.35
    _ab_apply(brain, action_type=action_type, kw=kw, template_id=tpl, target_nick=target, thread_id=thread_id, delta=d)

    # lightweight context-learning (user/thread/topic/category -> arm preference)
    try:
        _apply_context_arm_stats(brain, tuning, item, delta=float(pr), kind="proxy")
    except Exception as e:
        log_exception("brain:context_proxy", e, context={"action": act, "post_id": thread_id, "kw": kw, "target": target})
        if _should_failfast("brain"):
            raise

    upd = brain.setdefault("bias_updates", {"proxy": 0, "reward": 0})
    if isinstance(upd, dict):
        upd["proxy"] = int(upd.get("proxy", 0) or 0) + 1

    item["brain_proxy_applied"] = True

def apply_brain_reward_update(brain: Dict[str, Any], tuning: AgentTuning, item: Dict[str, Any]) -> None:
    """Apply delayed (evaluated) reward update to action_bias once per item. (final6: also updates context_arm_stats)."""
    if not isinstance(brain, dict) or not isinstance(item, dict):
        return
    if item.get("brain_reward_applied") is True:
        return

    act = str(item.get("action") or "")
    if act not in ("comment", "reply", "post"):
        item["brain_reward_applied"] = True
        return
    if item.get("evaluated") is not True:
        return

    action_type = str(item.get("action_type") or act)
    kw = str(item.get("kw") or "")
    tpl = str(item.get("template_id") or "")
    target = str(item.get("target_nick") or "")
    thread_id = str(item.get("post_id") or "")

    r = float(item.get("reward_scalar", 0.0) or 0.0)
    clip = max(1e-6, float(getattr(tuning, "reward_clip", 3.0)))
    d = max(-1.0, min(1.0, r / clip))

    _ab_apply(brain, action_type=action_type, kw=kw, template_id=tpl, target_nick=target, thread_id=thread_id, delta=d)

    # context-learning (evaluated reward is more trustworthy)
    try:
        _apply_context_arm_stats(brain, tuning, item, delta=float(r), kind="reward")
    except Exception as e:
        log_exception("brain:context_reward", e, context={"action": act, "post_id": thread_id, "kw": kw, "target": target})
        if _should_failfast("brain"):
            raise

    upd = brain.setdefault("bias_updates", {"proxy": 0, "reward": 0})
    if isinstance(upd, dict):
        upd["reward"] = int(upd.get("reward", 0) or 0) + 1

    item["brain_reward_applied"] = True



# -----------------------------------------------------------------------------
# Context-arm learning (final6)
#   Learn per-entity (user/thread/topic/category) preferences for bandit arms.
#   Stored under brain["context_arm_stats"] with bounded pruning.
# -----------------------------------------------------------------------------

def _ctx_entity_keys_from_item(item: Dict[str, Any]) -> List[str]:
    keys: List[str] = []
    if not isinstance(item, dict):
        return keys
    tn = str(item.get("target_nick") or "")
    if tn:
        keys.append(f"user:{tn}")
    pid = str(item.get("post_id") or "")
    if pid:
        keys.append(f"thread:{pid}")
    kw = str(item.get("kw") or "")
    if kw:
        keys.append(f"topic:{kw}")
    cat = str(item.get("category") or "")
    if cat:
        keys.append(f"cat:{cat}")
    return keys


def _ctx_stats_prune(stats: Dict[str, Any], *, max_entities: int = 900, ttl_sec: float = 60 * 60 * 24 * 35) -> None:
    """Drop stale entities and keep bounded size."""
    if not isinstance(stats, dict) or not stats:
        return
    now = time.time()
    # Remove stale
    to_del = []
    for k, v in list(stats.items()):
        if not isinstance(v, dict):
            to_del.append(k)
            continue
        last_ts = float(v.get("last_ts", 0.0) or 0.0)
        if last_ts > 0.0 and (now - last_ts) > float(ttl_sec):
            to_del.append(k)
    for k in to_del:
        stats.pop(k, None)

    # Bound size by last_ts
    if len(stats) <= max_entities:
        return
    items = []
    for k, v in stats.items():
        if isinstance(v, dict):
            items.append((float(v.get("last_ts", 0.0) or 0.0), k))
    items.sort(key=lambda x: x[0], reverse=True)
    keep = set([k for _, k in items[:max_entities]])
    for k in list(stats.keys()):
        if k not in keep:
            stats.pop(k, None)


def _ctx_update_arm_slot(slot: Dict[str, Any], arm: str, r: float, *, alpha: float, max_arms: int = 14) -> None:
    if not arm:
        return
    d = slot.get(arm)
    if not isinstance(d, dict):
        d = {"ema": 0.0, "n": 0, "last_ts": 0.0}
    ema = float(d.get("ema", 0.0) or 0.0)
    d["ema"] = float((1 - alpha) * ema + alpha * float(r))
    d["n"] = int(d.get("n", 0) or 0) + 1
    d["last_ts"] = time.time()
    slot[arm] = d

    # cap arms per slot by last_ts
    if len(slot) > max_arms:
        items = []
        for a, vv in slot.items():
            if isinstance(vv, dict):
                items.append((float(vv.get("last_ts", 0.0) or 0.0), a))
        items.sort(key=lambda x: x[0], reverse=True)
        keep = set([a for _, a in items[:max_arms]])
        for a in list(slot.keys()):
            if a not in keep:
                slot.pop(a, None)


def _apply_context_arm_stats(brain: Dict[str, Any], tuning: AgentTuning, item: Dict[str, Any], *, delta: float, kind: str) -> None:
    """
    Update brain["context_arm_stats"] using item metadata.

    kind:
      - "proxy": uses proxy delta (softer)
      - "reward": uses evaluated reward (stronger)
    """
    if not isinstance(brain, dict) or not isinstance(item, dict):
        return

    stats = brain.setdefault("context_arm_stats", {})
    if not isinstance(stats, dict):
        brain["context_arm_stats"] = {}
        stats = brain["context_arm_stats"]

    # reward signal in [-1,1] for stability
    clip = max(1e-6, float(getattr(tuning, "reward_clip", 3.0)))
    r = float(delta) / clip
    if r > 1.0:
        r = 1.0
    if r < -1.0:
        r = -1.0

    # alpha: proxy is gentler
    base_alpha = 0.10 if kind == "reward" else 0.05
    alpha = float(base_alpha) + 0.03 * min(1.0, abs(r))

    # Buckets and their chosen arms (if any)
    used: List[Tuple[str, str]] = []
    us = str(item.get("used_strategy") or "")
    if us:
        used.append(("strategy", us))
    ur = str(item.get("used_reply_style") or "")
    if ur:
        used.append(("reply_styles", ur))
    ut = str(item.get("used_tone") or "")
    if ut:
        used.append(("tone", ut))
    ul = str(item.get("used_length") or "")
    if ul:
        used.append(("comment_length", ul))
    ups = str(item.get("used_style") or "")
    if ups:
        used.append(("post_styles", ups))

    if not used:
        return

    keys = _ctx_entity_keys_from_item(item)
    if not keys:
        return

    now = time.time()
    for ek in keys:
        ent = stats.get(ek)
        if not isinstance(ent, dict):
            ent = {"last_ts": now, "buckets": {}}
        ent["last_ts"] = now
        buckets = ent.get("buckets")
        if not isinstance(buckets, dict):
            buckets = {}
        for bucket, arm in used:
            bslot = buckets.get(bucket)
            if not isinstance(bslot, dict):
                bslot = {}
            _ctx_update_arm_slot(bslot, str(arm), float(r), alpha=alpha)
            buckets[bucket] = bslot
        ent["buckets"] = buckets
        stats[ek] = ent

    # periodic prune
    try:
        if random.random() < 0.08:
            _ctx_stats_prune(stats)
    except Exception:
        pass


def merge_bias_maps(*maps: Optional[Dict[str, float]], clamp_min: float = 0.40, clamp_max: float = 1.70) -> Dict[str, float]:
    """Multiply bias maps arm-wise. Values are clamped to keep things sane."""
    out: Dict[str, float] = {}
    for mp in maps:
        if not isinstance(mp, dict) or not mp:
            continue
        for k, v in mp.items():
            kk = str(k)
            try:
                vv = float(v)
            except Exception:
                vv = 1.0
            if kk not in out:
                out[kk] = 1.0
            out[kk] *= max(0.0, vv)
    # clamp
    for k in list(out.keys()):
        out[k] = float(min(clamp_max, max(clamp_min, out[k])))
    return out


def get_context_arm_bias(
    brain: Optional[Dict[str, Any]],
    keys: List[str],
    *,
    bucket: str,
    arms: List[str],
    tuning: AgentTuning,
) -> Tuple[Dict[str, float], Dict[str, Any]]:
    """
    Build an external bias map from brain.context_arm_stats for a given bucket and a set of entities.

    - Positive EMA -> boost
    - Negative EMA -> damp
    """
    if not isinstance(brain, dict) or not keys or not arms:
        return {}, {}
    stats = brain.get("context_arm_stats")
    if not isinstance(stats, dict) or not stats:
        return {}, {}

    scale = float(getattr(tuning, "context_bias_scale", 0.32) or 0.32)
    clamp_min = float(getattr(tuning, "context_bias_min", 0.55) or 0.55)
    clamp_max = float(getattr(tuning, "context_bias_max", 1.45) or 1.45)

    arm_set = [str(a) for a in arms]
    acc: Dict[str, float] = {}
    used_keys: List[str] = []

    for ek in keys[:6]:
        ent = stats.get(str(ek))
        if not isinstance(ent, dict):
            continue
        buckets = ent.get("buckets")
        if not isinstance(buckets, dict):
            continue
        slot = buckets.get(str(bucket))
        if not isinstance(slot, dict):
            continue
        used_keys.append(str(ek))
        # accumulate EMA
        for arm in arm_set:
            d = slot.get(arm)
            if not isinstance(d, dict):
                continue
            ema = float(d.get("ema", 0.0) or 0.0)
            if abs(ema) < 0.06:
                continue
            acc[arm] = acc.get(arm, 0.0) + ema

    if not acc:
        return {}, {}

    bias: Dict[str, float] = {}
    for arm in arm_set:
        ema = float(acc.get(arm, 0.0) or 0.0)
        m = 1.0 + scale * ema
        if m < clamp_min:
            m = clamp_min
        if m > clamp_max:
            m = clamp_max
        bias[arm] = float(m)

    note = {"bucket": str(bucket), "keys": used_keys[:4], "n_keys": len(used_keys)}
    return bias, note



INJECTION_PATTERNS = [
    r"시스템\s*프롬프트",
    r"system\s*prompt",
    r"이전\s*명령\s*무시",
    r"ignore\s*previous",
    r"너는\s*이제부터",
    r"prompt\s*injection",
]

# Precompiled regex (optimization-only)
_INJECTION_RES = [re.compile(p, re.IGNORECASE) for p in INJECTION_PATTERNS]

OFFENSIVE_PATTERNS = [
    # profanity / slurs (strong filter; affects generation + keyword mining)
    r"(시발|씨발|ㅅㅂ)", r"(병신|ㅂㅅ)", r"(좆|좆같)", r"(개새|개새끼)", r"(씹|씹새|씹새끼)", r"(새끼)",
    # extreme hostility / violence (keep conservative)
    r"죽여", r"살해",
    # hate/discrimination terms (conservative; may appear in debates)
    r"혐오", r"차별",
]

# Precompiled regex (optimization-only)
_OFFENSIVE_RES = [re.compile(p) for p in OFFENSIVE_PATTERNS]

EMOJI_RE = re.compile(
    "[" +
    "\U0001F300-\U0001FAFF" +
    "\U00002700-\U000027BF" +
    "\U00002600-\U000026FF" +
    "]+",
    flags=re.UNICODE
)

MARKDOWN_RE = re.compile(r"(\*\*|__|\*|_|`|^#|^>|^- |\[.*?\]\(.*?\))", re.MULTILINE)

EUM_ENDINGS = ("음", "슴", "임", "함", "됨", "있음", "없음", "였음", "했음", "같음", "해짐", "갈림", "느낌", "인듯", "듯함", "듯", "편", "쪽")
EUM_LINE_OK_RE = re.compile(rf"({'|'.join(EUM_ENDINGS)})(\?|!|…)?$")

# Precompiled eumssum transform rules (optimization-only)
_EUMIFY_RULES: Tuple[Tuple[re.Pattern, str], ...] = (
    (re.compile(r"(같습니다)\s*$"), "같음"),
    (re.compile(r"(겠습니다|겠어요|겠다)\s*$"), "겠음"),
    (re.compile(r"(입니다)\s*$"), "임"),
    (re.compile(r"(였습니다|였어요|였다)\s*$"), "였음"),
    (re.compile(r"(했습니다|했어요|했다)\s*$"), "했음"),
    (re.compile(r"(합니다|하였다|한다)\s*$"), "함"),
    (re.compile(r"(됩니다|된다)\s*$"), "됨"),
    (re.compile(r"(없습니다|없어요|없다)\s*$"), "없음"),
    (re.compile(r"(있습니다|있어요|있다)\s*$"), "있음"),
    (re.compile(r"(습니까)\s*$"), "슴"),
    (re.compile(r"(습니다)\s*$"), "슴"),
    (re.compile(r"(에요|예요)\s*$"), "임"),
    (re.compile(r"(어요|아요|여요|요)\s*$"), "임"),
)
_EUMIFY_RULES_Q: Tuple[Tuple[re.Pattern, str], ...] = _EUMIFY_RULES + (
    (re.compile(r"(다)\s*$"), "음"),
)


# Eumssum v2 tuning (kept lightweight; no external NLP)
EUM_V2_ENABLED = _env_bool("MERSOOM_EUM_V2", True)
EUM_V2_CONNECTOR_RATE = _env_float("MERSOOM_EUM_V2_CONNECTOR_RATE", 0.45)
EUM_V2_DROP_IM_RATE = _env_float("MERSOOM_EUM_V2_DROP_IM_RATE", 0.35)
EUM_V2_TARGET_IM_RATIO = _env_float("MERSOOM_EUM_V2_TARGET_IM_RATIO", 0.58)
EUM_V2_MAX_CONNECTORS = _env_int("MERSOOM_EUM_V2_MAX_CONNECTORS", 2)
STRICT_POSTPROCESS = _env_bool("MERSOOM_STRICT_POSTPROCESS", False)

EUM_CONNECTOR_PREFIXES: Tuple[str, ...] = (
    "근데", "근데도", "다만", "오히려", "그리고", "또", "게다가", "그래서", "그러면", "그러니", "일단", "사실",
)
EUM_CONNECTOR_START_RE = re.compile(rf"^({'|'.join(map(re.escape, EUM_CONNECTOR_PREFIXES))})(?:\b|\s)")

# endings we usually don't want to leave dangling (particles/aux)
_EUM_DANGLING_TAILS: Tuple[str, ...] = (
    "은", "는", "이", "가", "을", "를", "에", "에서", "로", "와", "과", "도", "만", "이나", "나", "까지", "부터", "처럼", "밖에",
)

STOPWORDS_KO = set([
    "그", "이", "저", "것", "수", "등", "및", "대한", "관련", "그리고", "하지만",
    "그래서", "또한", "그런데", "즉", "때문", "정도", "사실", "진짜", "그냥",
    "좀", "약간", "매우", "너무", "진짜로", "아예",
])
STOPWORDS_EN = set(["the", "a", "an", "and", "or", "to", "of", "in", "on", "for", "with", "is", "are"])

def looks_like_injection(text: str) -> bool:
    t = text or ""
    return any(p.search(t) for p in _INJECTION_RES)

def looks_offensive(text: str) -> bool:
    t = text or ""
    return any(p.search(t) for p in _OFFENSIVE_RES)



def is_toxic_incoming(text: str) -> Tuple[bool, str]:
    """Classify incoming user-generated text as toxic / unsafe-to-engage."""
    t = text or ""
    if not t.strip():
        return (False, "")
    if looks_like_injection(t):
        return (True, "injection")
    if looks_offensive(t):
        return (True, "offensive")
    return (False, "")

def contains_emoji(text: str) -> bool:
    return bool(EMOJI_RE.search(text or ""))

def contains_markdown(text: str) -> bool:
    t = text or ""
    if "```" in t:
        return True
    return bool(MARKDOWN_RE.search(t))

def _looks_like_markdown_violation(text: str) -> bool:
    """Conservative detector for 'markdown-y' content (incoming).
    We allow fenced code blocks but flag other markdown constructs (headings/links/bold).
    """
    t = str(text or "")
    if not t.strip():
        return False

    # Remove fenced blocks and inspect the remainder
    if "```" in t:
        rem = re.sub(r"```.*?```", " ", t, flags=re.DOTALL)
    else:
        rem = t

    # Obvious markdown patterns
    if re.search(r"(^|\n)\s*#{1,6}\s+\S", rem):
        return True
    if re.search(r"\[[^\]]+\]\([^)]+\)", rem):
        return True
    if re.search(r"(\*\*|__)", rem):
        return True

    # Heuristic: lots of markdown punctuation outside code blocks
    punct = re.findall(r"[`*_>#]", rem)
    if len(punct) >= 8 and len(rem) >= 80:
        return True
    return False

def looks_like_rule_violation(text: str) -> Tuple[bool, str]:
    """Detect obvious Mersoom rule violations for self-policing votes."""
    t = str(text or "")
    if not t.strip():
        return (False, "")

    if contains_emoji(t):
        return (True, "emoji")

    # markdown is prohibited except minimal code sharing
    if _looks_like_markdown_violation(t):
        return (True, "markdown")

    # Korean-first: if it's mostly English and missing the mandated notice, flag it
    if "한국어 모듈 오류남" not in t:
        try:
            if re.search(r"[A-Za-z]{4,}", t) and _hangul_ratio(t) < 0.15:
                return (True, "english")
        except Exception:
            pass

    return (False, "")


def sanitize_plain_text(text: str) -> str:
    t = str(text or "")
    t = EMOJI_RE.sub("", t)
    t = re.sub(r"https?://\S+", "", t)
    t = re.sub(r"[`*_>#]", "", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


# -----------------------------------------------------------------------------
# Unit 1 (v5.1): Nickname placeholder normalization + safe greeting injection
# - Goal: prevent foreign nicknames from being "baked into" templates/corpus, and
#         make replies feel more conversational *without* breaking stability gates.
# -----------------------------------------------------------------------------

NAME_PLACEHOLDER = "<NAME>"

# Conservative nickname safety filter (used for injection; not for storage).
# - Excludes 1~2 chars, emoji-heavy, whitespace, and overly long nicks.
_NICK_ALLOWED_RE = re.compile(r"^[0-9A-Za-z가-힣._-]{3,24}$")

def is_safe_nickname(nick: str) -> bool:
    n = str(nick or "").strip()
    if not n:
        return False
    if not _NICK_ALLOWED_RE.match(n):
        return False
    # avoid placeholder-looking / markup-ish nicks
    if "<" in n or ">" in n:
        return False
    return True

def _collect_candidate_nicknames(cfg: "Config", state: Dict[str, Any], *, max_n: int = 400) -> List[str]:
    """Collect a bounded set of known nicknames for placeholder normalization.

    Sources (best-effort):
    - state['users'] keys
    - state['threads'][*]['last_k_turns'][*]['nickname'/'user_key']
    - focus post/comment nicknames when available
    """
    out: List[str] = []
    seen: set = set()

    try:
        me = str(getattr(cfg, "nickname", "") or "").strip()
    except Exception:
        me = ""

    def _push(x: Any) -> None:
        try:
            n = str(x or "").strip()
            if not n:
                return
            if n == me:
                return
            # for storage normalization, we allow slightly broader nicks,
            # but still keep it reasonably clean to avoid false positives.
            if len(n) < 3 or len(n) > 28:
                return
            if any(ch.isspace() for ch in n):
                return
            if "<" in n or ">" in n:
                return
            if n in seen:
                return
            seen.add(n)
            out.append(n)
        except Exception:
            return

    try:
        users = state.get("users")
        if isinstance(users, dict):
            for k in list(users.keys())[: max_n * 2]:
                _push(k)
    except Exception:
        pass

    try:
        threads = state.get("threads")
        if isinstance(threads, dict):
            for th in list(threads.values())[:200]:
                if not isinstance(th, dict):
                    continue
                turns = th.get("last_k_turns")
                if isinstance(turns, list):
                    for t in turns[-12:]:
                        if not isinstance(t, dict):
                            continue
                        _push(t.get("nickname") or t.get("user_key") or t.get("nick"))
    except Exception:
        pass

    try:
        focus = state.get("focus")
        if isinstance(focus, dict):
            c = focus.get("comment")
            p = focus.get("post")
            if isinstance(c, dict):
                _push(c.get("nickname"))
            if isinstance(p, dict):
                _push(p.get("nickname"))
    except Exception:
        pass

    # prefer longer nicks first to avoid partial replacement (e.g., abc vs abcd)
    out = sorted(out, key=lambda s: (-len(s), s))[:max_n]
    return out

def normalize_nicknames_to_placeholder(text: str, nicknames: List[str], *, placeholder: str = NAME_PLACEHOLDER) -> str:
    """Replace known nicknames in text with <NAME> placeholder (for storage/mining).

    This is intentionally conservative: it only replaces when the nickname appears as
    a standalone token / mention-like pattern, to reduce false positives.
    """
    t = str(text or "")
    if not t or not nicknames:
        return t

    # define "word" chars for Korean+ASCII nick tokens
    wb = r"[0-9A-Za-z가-힣._-]"
    for nick in nicknames:
        n = str(nick or "")
        if not n or n not in t:
            continue
        esc = re.escape(n)

        # @nick -> @<NAME>
        t = re.sub(rf"@{esc}(?!{wb})", f"@{placeholder}", t)

        # nick님 / nick 님 -> <NAME>님
        t = re.sub(rf"(?<!{wb}){esc}\s*님", f"{placeholder}님", t)

        # bare nick as a token -> <NAME>
        t = re.sub(rf"(?<!{wb}){esc}(?!{wb})", placeholder, t)

    # collapse duplicates: <NAME><NAME> -> <NAME>
    t = re.sub(rf"(?:{re.escape(placeholder)}){{2,}}", placeholder, t)
    t = re.sub(r"\s+", " ", t).strip()
    return t

def _strip_name_placeholder(text: str, *, placeholder: str = NAME_PLACEHOLDER) -> str:
    t = str(text or "")
    if not t:
        return t
    ph = re.escape(str(placeholder))
    # Remove placeholder mentions with optional @ and optional honorific "님"
    t = re.sub(rf"(?:@)?{ph}\s*님?", "", t)
    # Also remove any remaining raw placeholder just in case
    t = t.replace(str(placeholder), "")
    t = re.sub(r"\s+", " ", t).strip()
    # clean leading punctuation after stripping
    t = re.sub(r"^[,;:\-]+\s*", "", t)
    return t

def apply_name_layer(
    cfg: "Config",
    state: Dict[str, Any],
    text: str,
    *,
    mode: str,
    target_nick: str = "",
    greet_cooldown_sec: int = 1800,
) -> str:
    """Resolve <NAME> placeholder and optionally add a lightweight greeting for replies.

    Rules:
    - Replace <NAME> ONLY when target_nick is safe.
    - For non-reply modes or unsafe nick, strip placeholders (never leak "<NAME>").
    - For reply modes, optionally prefix a single @nick greeting with cooldown.
    - Never raises; failure -> returns original text.
    """
    base = str(text or "")
    if not base:
        return base

    try:
        safe = is_safe_nickname(target_nick)
        if safe:
            out = base.replace(NAME_PLACEHOLDER, str(target_nick))
            out = out.replace(f"@{NAME_PLACEHOLDER}", f"@{str(target_nick)}")
        else:
            out = _strip_name_placeholder(base)

        # Greeting only for replies and only when we have a safe nick
        if mode == "reply" and safe:
            # if already referenced, skip
            if re.search(rf"@{re.escape(str(target_nick))}(?![0-9A-Za-z가-힣._-])", out) or (str(target_nick) in out[:60]):
                return out

            now_ts = time.time()
            dlg = state.setdefault("dlg", {})
            gh = dlg.setdefault("greet_hist", {})
            last_ts = float(gh.get(str(target_nick), 0.0) or 0.0)
            if now_ts - last_ts >= float(greet_cooldown_sec):
                gh[str(target_nick)] = now_ts
                out = f"@{str(target_nick)} {out}".strip()
                try:
                    protocol_bump_counter(state, "name_greet_used", 1)
                except Exception:
                    pass
            else:
                try:
                    protocol_bump_counter(state, "name_greet_skipped", 1)
                except Exception:
                    pass

        # counters
        try:
            if NAME_PLACEHOLDER in base:
                protocol_bump_counter(state, "name_placeholder_hits", 1)
        except Exception:
            pass

        out = re.sub(r"\s+", " ", out).strip()
        return out
    except Exception:
        # absolute safety: never break generation
        try:
            protocol_bump_counter(state, "name_layer_exc", 1)
        except Exception:
            pass
        return base

# -----------------------------------------------------------------------------
# Unit2: SHORT QUOTE INJECTION (replies only; gate-preserving; no LLM)
# -----------------------------------------------------------------------------

# Minimal char allowlist helpers for quote extraction (avoid emoji/special char noise)
def _is_hangul_char(ch: str) -> bool:
    o = ord(ch)
    # Hangul syllables + jamo blocks
    return (
        0xAC00 <= o <= 0xD7A3  # syllables
        or 0x1100 <= o <= 0x11FF  # jamo
        or 0x3130 <= o <= 0x318F  # compatibility jamo
    )

def _is_basic_latin_digit(ch: str) -> bool:
    o = ord(ch)
    return (0x30 <= o <= 0x39) or (0x41 <= o <= 0x5A) or (0x61 <= o <= 0x7A)

def _is_quote_ok_char(ch: str) -> bool:
    if ch.isspace():
        return True
    if _is_hangul_char(ch) or _is_basic_latin_digit(ch):
        return True
    if ch in ".,:;!?~'\\\"“”‘’()[]{}<>-–—/·…":
        return True
    return False

def _weird_char_ratio(s: str) -> float:
    if not s:
        return 1.0
    bad = 0
    for ch in s:
        if not _is_quote_ok_char(ch):
            bad += 1
    return float(bad) / float(max(1, len(s)))

def _quote_clean_piece(p: str) -> str:
    t = str(p or "")
    t = t.replace(NAME_PLACEHOLDER, "")
    t = t.replace("“", "").replace("”", "").replace("‘", "").replace("’", "").replace('"', "").replace("'", "")
    t = re.sub(r"\s+", " ", t).strip()
    # strip common wrappers/punct
    t = t.strip(" ,.;:!?~()[]{}<>-–—/·")
    t = re.sub(r"\s+", " ", t).strip()
    return t

def _quote_is_bad_piece(p: str) -> bool:
    t = str(p or "").strip()
    if not t:
        return True
    # too many weird chars (emoji / symbols)
    if _weird_char_ratio(t) > 0.28:
        return True
    # url-ish
    if "http" in t or "www." in t:
        return True
    # nickname-only / laughter-only / symbol-only
    core = re.sub(r"[^0-9A-Za-z가-힣]+", "", t)
    if len(core) < 4:
        return True
    if re.fullmatch(r"[ㅋㅎ]+", t):
        return True
    return False

def _best_window(text: str, win: int) -> str:
    """Pick a best-effort window of length win from text (maximize readable density)."""
    s = str(text or "")
    if len(s) <= win:
        return s
    best = s[:win]
    best_sc = -1e9
    # stride to keep cheap even on long text
    stride = 1 if len(s) <= 140 else 2
    for i in range(0, max(1, len(s) - win + 1), stride):
        w = s[i : i + win]
        if not w.strip():
            continue
        # score: readable chars + diversity - punctuation density
        ok = sum(1 for ch in w if _is_hangul_char(ch) or _is_basic_latin_digit(ch))
        div = len(set(w)) / float(max(1, len(w)))
        punct = sum(1 for ch in w if ch in ".,:;!?~/·…")
        sc = ok * 1.0 + div * 6.0 - punct * 0.6
        if sc > best_sc:
            best_sc = sc
            best = w
    return best

def extract_short_quote(target_text: str, *, min_len: int = 6, max_len: int = 16) -> str:
    """Extract a short (6~16 chars) quote from target text. Never raises."""
    try:
        t = sanitize_plain_text(str(target_text or ""))
    except Exception:
        t = str(target_text or "")
    t = re.sub(r"\s+", " ", t).strip()
    if not t:
        return ""

    # remove explicit mentions (keep content focus)
    try:
        t = re.sub(r"@[0-9A-Za-z가-힣._-]{2,32}", "", t).strip()
    except Exception:
        pass

    # split into coarse pieces first
    pieces = re.split(r"[\n\r]+|[.!?…]+", t)
    cands: List[str] = []
    for p in pieces:
        pp = _quote_clean_piece(p)
        if len(pp) < int(min_len):
            continue
        if _quote_is_bad_piece(pp):
            continue
        cands.append(pp)

    if not cands:
        # fallback: take from whole text
        whole = _quote_clean_piece(t)
        if len(whole) >= int(min_len) and (not _quote_is_bad_piece(whole)):
            cands = [whole]
        else:
            return ""

    best = ""
    best_sc = -1e9
    for p in cands:
        if len(p) > int(max_len):
            p2 = _quote_clean_piece(_best_window(p, int(max_len)))
        else:
            p2 = p
        if len(p2) < int(min_len):
            continue
        if _quote_is_bad_piece(p2):
            continue

        # score prefers readable + some diversity
        ok = sum(1 for ch in p2 if _is_hangul_char(ch) or _is_basic_latin_digit(ch))
        div = len(set(p2)) / float(max(1, len(p2)))
        sc = ok * 1.2 + div * 6.0 + min(len(p2), int(max_len)) * 0.2
        if sc > best_sc:
            best_sc = sc
            best = p2

    best = _quote_clean_piece(best)
    if len(best) > int(max_len):
        best = _quote_clean_piece(_best_window(best, int(max_len)))
    if len(best) < int(min_len):
        return ""
    return best[: int(max_len)]

def apply_quote_layer(
    cfg: "Config",
    state: Dict[str, Any],
    text: str,
    *,
    mode: str,
    target_text: str = "",
    min_len: int = 6,
    max_len: int = 16,
) -> str:
    """Inject a single short quote for reply-like modes.

    - Replies only (mode == "reply")
    - Never raises; failure -> returns original text
    - Does not bypass gates: caller must still pass final_text_gate/final_post_gate.
    """
    base = str(text or "")
    if not base:
        return base
    if mode != "reply":
        return base

    try:
        q = extract_short_quote(str(target_text or ""), min_len=int(min_len), max_len=int(max_len))
        if not q:
            try:
                protocol_bump_counter(state, "quote_skipped", 1)
            except Exception:
                pass
            return base

        # if quote already present, skip (avoid double-quote stacking)
        if re.search(r'[“"]', base[:200]):
            return base

        # keep one-line
        base1 = re.sub(r"[\r\n]+", " ", base).strip()

        m = re.match(r"^(@[0-9A-Za-z가-힣._-]{2,32})\s+(.*)$", base1)
        if m:
            greet = m.group(1)
            rest = (m.group(2) or "").strip()
            out = f"{greet} “{q}”은 {rest}".strip()
        else:
            out = f"“{q}”은 {base1}".strip()

        out = re.sub(r"\s+", " ", out).strip()

        try:
            protocol_bump_counter(state, "quote_used", 1)
        except Exception:
            pass
        return out
    except Exception:
        try:
            protocol_bump_counter(state, "quote_layer_exc", 1)
        except Exception:
            pass
        return base


# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# =========================
# Unit3: Micro-editor postprocess (safe, no-LLM)
# =========================

def _has_final_consonant_korean_syllable(ch: str) -> bool:
    """Return True if Hangul syllable has a final consonant (jongseong)."""
    try:
        if not ch:
            return False
        code = ord(ch) - 0xAC00
        if 0 <= code <= 11171:
            jong = code % 28
            return jong != 0
    except Exception:
        pass
    return False


def _fix_attached_particle_pair(text: str, *, pair: str) -> str:
    """Fix attached Korean particle selection for a small safe subset.

    pair: 'obj' -> 을/를, 'topic' -> 은/는
    Only fixes when particle is directly attached to a short Hangul word and
    followed by whitespace/punct/end. Never raises.
    """
    t = str(text or "")
    if not t:
        return t
    try:
        if pair == "obj":
            pat = re.compile(r"([가-힣]{1,12})(를|을)(?=[\s\.,!\?…:;\)\]\}\/\-]|$)")
            a, b = "를", "을"
        elif pair == "topic":
            pat = re.compile(r"([가-힣]{1,12})(은|는)(?=[\s\.,!\?…:;\)\]\}\/\-]|$)")
            a, b = "는", "은"  # note: swap later based on jong
        else:
            return t

        def repl(m: re.Match) -> str:
            w = m.group(1)
            p = m.group(2)
            last = w[-1]
            has_jong = _has_final_consonant_korean_syllable(last)
            if pair == "obj":
                want = b if has_jong else a
            else:
                # topic: 은 if has jong else 는
                want = "은" if has_jong else "는"
            if p == want:
                return m.group(0)
            return w + want

        return pat.sub(repl, t)
    except Exception:
        return t


def _reduce_im_repetition(text: str) -> str:
    """Reduce obvious '임' repetition artifacts without changing meaning."""
    t = str(text or "")
    if not t:
        return t
    try:
        # "임. 임" / "임.임" -> single
        t = re.sub(r"(임)(\s*[\.!\?…]+)\s*(?:임\b)", r"\1\2", t)
        t = re.sub(r"(임)\s+(?:임\b)", r"\1", t)
        # "임임" -> "임" (rare, but seen in noisy merges)
        t = re.sub(r"임{2,}", "임", t)
        return t
    except Exception:
        return str(text or "")


def _dedup_sentences(text: str, *, window: int = 3) -> str:
    """Remove duplicated sentences/clauses within a small window."""
    t = str(text or "")
    if not t:
        return t
    try:
        # collapse excessive whitespace/newlines first (but keep single newlines)
        t = t.replace("\r", "")
        t = re.sub(r"\n{3,}", "\n\n", t)
        t2 = re.sub(r"[ \t]{2,}", " ", t).strip()

        # If the whole text is an exact repetition A + A, drop the second A
        n = re.sub(r"\s+", " ", t2).strip()
        if len(n) >= 60:
            half = len(n) // 2
            # Try a few split points around the middle
            for delta in (0, -1, 1, -2, 2):
                k = half + delta
                if k <= 20 or k >= len(n) - 20:
                    continue
                a = n[:k].strip()
                b = n[k:].strip()
                if a and b and a == b:
                    t2 = a
                    break

        parts = re.split(r"(?<=[\.!\?…])\s+|\n+", t2)
        kept = []
        recent = []
        for p in parts:
            s = p.strip()
            if not s:
                continue
            norm = re.sub(r"\s+", "", s)
            if len(norm) < 8:
                kept.append(s)
                recent.append(norm)
                recent = recent[-window:]
                continue
            if norm in recent:
                continue
            kept.append(s)
            recent.append(norm)
            recent = recent[-window:]
        out = " ".join(kept).strip()
        out = re.sub(r"\s+", " ", out).strip()
        return out
    except Exception:
        return str(text or "")


def _maybe_vary_connective_prefix(state: Dict[str, Any], text: str) -> str:
    """Vary only prefix connectives within the same semantic group to reduce 'template feel'."""
    t = str(text or "")
    if not t:
        return t
    try:
        # group mapping (keep meaning class roughly)
        groups = {
            "but": ["근데", "다만"],
            "and": ["그리고", "또"],
            "however": ["하지만", "그래도"],
            "thus": ["그래서", "결국"],
        }
        all_items = {x: g for g, xs in groups.items() for x in xs}

        m = re.match(r"^\s*(근데|다만|그리고|또|하지만|그래도|그래서|결국)(?=\s|[\.,!\?…:;])", t)
        if not m:
            return t
        cur = m.group(1)
        grp = all_items.get(cur)
        if not grp:
            return t

        dlg = state.setdefault("dlg", {})
        recent = dlg.setdefault("recent_connectives", [])
        if not isinstance(recent, list):
            recent = []
            dlg["recent_connectives"] = recent

        recent_tail = [str(x) for x in recent[-5:]]
        options = groups.get(grp, [cur])
        if cur not in options:
            options = [cur]

        # if current connective used very recently, swap to alternative in same group
        if cur in recent_tail and len(options) >= 2:
            alt = None
            for c in options:
                if c != cur and c not in recent_tail:
                    alt = c
                    break
            if alt is None:
                # pick the other one deterministically
                alt = options[1] if options[0] == cur else options[0]
            t = re.sub(r"^\s*" + re.escape(cur) + r"(?=\s|[\.,!\?…:;])", alt, t, count=1)
            cur = alt

        # record
        recent.append(cur)
        if len(recent) > 30:
            del recent[:-30]
        return t
    except Exception:
        return str(text or "")


def microedit_text(cfg: "Config", state: Dict[str, Any], text: str, *, mode: str = "comment") -> str:
    """Lightweight postprocess to remove obvious awkward artifacts (no generation).
    Never raises; on error returns original text.
    """
    base = str(text or "")
    if not base:
        return base
    try:
        out = base

        # 1) reduce obvious '임' repetition artifacts
        out = _reduce_im_repetition(out)

        # 2) safe particle fixes (attached only)
        out = _fix_attached_particle_pair(out, pair="obj")
        out = _fix_attached_particle_pair(out, pair="topic")

        # 3) de-dup repeated sentences/clauses
        out = _dedup_sentences(out, window=3)

        # 4) connective prefix variance (same semantic group only)
        out = _maybe_vary_connective_prefix(state, out)

        # 5) normalize whitespace lightly
        out = out.replace("\r", "")
        out = re.sub(r"[ \t]{2,}", " ", out).strip()

        if out != base:
            # changed chars approximation
            try:
                changed = abs(len(out) - len(base))
                # count substitutions by rough diff of overlapping prefix
                n = min(len(out), len(base))
                changed += sum(1 for i in range(n) if out[i] != base[i])
                protocol_bump_counter(state, "microedit_used", 1)
                protocol_bump_counter(state, "microedit_changed_chars", int(changed))
            except Exception:
                pass
        return out
    except Exception:
        try:
            protocol_bump_counter(state, "microedit_exc", 1)
        except Exception:
            pass
        return base


def apply_microedit_layer(cfg: "Config", state: Dict[str, Any], text: str, *, mode: str) -> str:
    """Unit3 wrapper: best-effort micro-editor. Never raises."""
    try:
        # For post title, avoid changes; caller may pass mode accordingly.
        if mode == "post_title":
            return str(text or "")
        return microedit_text(cfg, state, str(text or ""), mode=str(mode or "comment"))
    except Exception:
        return str(text or "")



# -----------------------------------------------------------------------------
# Unit4: CHAR 5-GRAM LM RERANKER (candidate K; safe; no LLM)
# -----------------------------------------------------------------------------
# Goal: choose a more natural-looking variant among small postprocessed candidates
# without changing the core generation logic.
#
# - Trains on human-written corpus (posts) already collected (author != my nickname).
# - Stores counts in semantic["lm_char5"] (small block; capped + pruned).
# - At generation time (comment/reply), produces K variants by toggling:
#   - greeting on/off (reply only)
#   - short-quote on/off (reply only)
#   - connective-prefix swap on/off (safe; same semantic group; uses Unit3 logic)
#   Then scores candidates by LM and tries final_text_gate from best to worst.
# - If model not ready or all candidates fail, falls back to the legacy path.

def _lm_get_block(semantic: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(semantic, dict):
        return {}
    lm = semantic.get("lm_char5")
    if not isinstance(lm, dict):
        lm = {"n": 5, "counts": {}, "pref": {}, "vocab": {}, "updated": 0, "pruned": 0, "last_prune_ts": 0.0}
        semantic["lm_char5"] = lm
    lm.setdefault("n", 5)
    lm.setdefault("counts", {})
    lm.setdefault("pref", {})
    lm.setdefault("vocab", {})
    lm.setdefault("updated", 0)
    lm.setdefault("pruned", 0)
    lm.setdefault("last_prune_ts", 0.0)
    return lm

def _lm_norm_text(text: str) -> str:
    """Normalize text for char-gram LM. Keep it lightweight and stable."""
    t = one_line(str(text or ""), 3000)
    # keep common punctuation, hangul, latin/digits, spaces
    t = re.sub(r"[^0-9A-Za-z가-힣 \t\.,:;!\?~'\"“”‘’\(\)\[\]\{\}<>-–—/·…]+", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t

def _lm_strip_prefix_for_score(norm: str) -> str:
    """Strip lightweight non-linguistic prefixes (mentions/leading quotes) before scoring."""
    try:
        s = str(norm or "")
        # mention prefixes
        s = re.sub(r"^@?[0-9A-Za-z가-힣._-]{2,32}\s+", "", s)
        s = re.sub(r"^@?<NAME>(?:님)?\s+", "", s)
        # leading short quote like “...은 ”
        s = re.sub(r"^“[^”]{1,40}”(?:은|는|이|가)?\s+", "", s)
        return s.strip()
    except Exception:
        return str(norm or "")


def _lm_approx_changed(a: str, b: str) -> int:
    try:
        a = str(a or "")
        b = str(b or "")
        n = min(len(a), len(b))
        changed = abs(len(a) - len(b))
        changed += sum(1 for i in range(n) if a[i] != b[i])
        return int(changed)
    except Exception:
        return 0

def lm_update_from_text(cfg: "Config", semantic: Dict[str, Any], author: str, text: str) -> None:
    """Update LM counts from a piece of human text (best-effort; bounded)."""
    try:
        if not _env_bool("MERSOOM_LM_TRAIN", True):
            return
        if not isinstance(cfg, Config):
            return
        if str(author or "").strip() == str(cfg.nickname or "").strip():
            return

        lm = _lm_get_block(semantic)
        n = int(lm.get("n", 5) or 5)
        n = max(3, min(7, n))
        s = _lm_norm_text(str(text or ""))
        # cap to avoid CPU/memory spikes
        max_chars = _env_int("MERSOOM_LM_MAX_CHARS_PER_DOC", 600, 120, 2000)
        s = s[:max_chars]
        if len(s) < n:
            return

        counts = lm.get("counts")
        pref = lm.get("pref")
        vocab = lm.get("vocab")
        if not isinstance(counts, dict) or not isinstance(pref, dict) or not isinstance(vocab, dict):
            lm["counts"], lm["pref"], lm["vocab"] = {}, {}, {}
            counts, pref, vocab = lm["counts"], lm["pref"], lm["vocab"]

        # update vocab
        for ch in s:
            vocab[ch] = int(vocab.get(ch, 0) or 0) + 1

        for i in range(n - 1, len(s)):
            pre = s[i - (n - 1): i]
            ch = s[i]
            ng = pre + ch
            counts[ng] = int(counts.get(ng, 0) or 0) + 1
            pref[pre] = int(pref.get(pre, 0) or 0) + 1

        lm["updated"] = int(lm.get("updated", 0) or 0) + 1

        # prune sometimes (bounded; at most once per ~30 minutes)
        now_ts = float(time.time())
        last_p = float(lm.get("last_prune_ts", 0.0) or 0.0)
        if (now_ts - last_p) >= float(_env_int("MERSOOM_LM_PRUNE_MIN_SEC", 1800, 60, 24 * 3600)):
            _lm_maybe_prune(semantic)
    except Exception:
        return

def _lm_maybe_prune(semantic: Dict[str, Any]) -> None:
    """Keep LM size bounded by pruning low-frequency ngrams."""
    try:
        lm = _lm_get_block(semantic)
        counts = lm.get("counts")
        pref = lm.get("pref")
        if not isinstance(counts, dict) or not isinstance(pref, dict):
            return
        max_entries = _env_int("MERSOOM_LM_MAX_ENTRIES", 60000, 5000, 250000)
        if len(counts) <= max_entries:
            lm["last_prune_ts"] = float(time.time())
            return

        # determine cutoff by frequency to keep top max_entries
        vals = list(int(v or 0) for v in counts.values())
        vals.sort()
        # index where we start keeping
        cut_idx = max(0, len(vals) - max_entries)
        cutoff = int(vals[cut_idx]) if vals else 1
        if cutoff < 2:
            cutoff = 2

        # prune counts
        new_counts = {k: int(v) for k, v in counts.items() if int(v or 0) >= cutoff}
        # if still too many, drop arbitrary tail (deterministic by key)
        if len(new_counts) > max_entries:
            for k in sorted(list(new_counts.keys()))[: max(0, len(new_counts) - max_entries)]:
                new_counts.pop(k, None)

        # rebuild pref totals from new_counts (safe, bounded)
        n = int(lm.get("n", 5) or 5)
        new_pref: Dict[str, int] = {}
        for ng, c in new_counts.items():
            if not isinstance(ng, str) or len(ng) != n:
                continue
            pre = ng[:-1]
            new_pref[pre] = int(new_pref.get(pre, 0) or 0) + int(c or 0)

        lm["counts"] = new_counts
        lm["pref"] = new_pref
        lm["pruned"] = int(lm.get("pruned", 0) or 0) + 1
        lm["last_prune_ts"] = float(time.time())
    except Exception:
        return

def lm_score_text(semantic: Dict[str, Any], text: str) -> Optional[float]:
    """Return average negative log-prob (lower is better). None if model not ready."""
    try:
        lm = _lm_get_block(semantic)
        counts = lm.get("counts")
        pref = lm.get("pref")
        vocab = lm.get("vocab")
        if not isinstance(counts, dict) or not isinstance(pref, dict) or not isinstance(vocab, dict):
            return None
        # readiness
        if len(counts) < int(_env_int("MERSOOM_LM_MIN_ENTRIES", 3000, 200, 50000)):
            return None

        n = int(lm.get("n", 5) or 5)
        s = _lm_norm_text(str(text or ""))
        # score only prefix part (speed)
        s = s[: int(_env_int("MERSOOM_LM_SCORE_MAX_CHARS", 280, 80, 1200))]
        # strip mention/quote prefixes so score reflects body more than formatting
        s = _lm_strip_prefix_for_score(s)
        if len(s) < n:
            return None

        V = max(50, len(vocab))
        alpha = float(_env_float("MERSOOM_LM_ALPHA", 0.25, min_v=0.01, max_v=2.0))
        nll = 0.0
        steps = 0
        for i in range(n - 1, len(s)):
            pre = s[i - (n - 1): i]
            ch = s[i]
            ng = pre + ch
            c = float(counts.get(ng, 0) or 0.0)
            t = float(pref.get(pre, 0) or 0.0)
            p = (c + alpha) / (t + alpha * float(V))
            nll -= math.log(max(p, 1e-12))
            steps += 1
        if steps <= 0:
            return None
        return float(nll) / float(steps)
    except Exception:
        return None

def _shadow_state_for_layers(state: Dict[str, Any]) -> Dict[str, Any]:
    """Create a small, side-effect-free state for Unit1-3 layer previews."""
    s: Dict[str, Any] = {}
    try:
        dlg = state.get("dlg") if isinstance(state, dict) else {}
        if not isinstance(dlg, dict):
            dlg = {}
        s["dlg"] = {
            "greet_hist": dict(dlg.get("greet_hist", {}) or {}),
            "recent_connectives": list(dlg.get("recent_connectives", []) or []),
        }
    except Exception:
        s["dlg"] = {"greet_hist": {}, "recent_connectives": []}
    s["protocol"] = {}
    return s

def _extract_connective_prefix(text: str) -> str:
    try:
        t = str(text or "").lstrip()
        m = re.match(r"^(근데|다만|그리고|또|하지만|그래도|그래서|결국)(?=\s|[\.,!\?…:;])", t)
        return str(m.group(1)) if m else ""
    except Exception:
        return ""

def lm_make_ranked_candidates(
    cfg: "Config",
    state: Dict[str, Any],
    semantic: Dict[str, Any],
    base_text: str,
    *,
    mode: str,
    target_nick: str = "",
    target_text: str = "",
    k: int = 8,
) -> List[Tuple[str, Dict[str, Any]]]:
    """Return candidates sorted by LM score (best first). Empty if LM not ready."""
    base = str(base_text or "")
    if not base:
        return []
    k = max(2, min(16, int(k)))

    # quick readiness check
    if lm_score_text(semantic, base) is None:
        return []

    recipes = [
        # greet, quote, force_swap
        (True,  True,  False),
        (True,  False, False),
        (False, True,  False),
        (False, False, False),
        (True,  True,  True),
        (True,  False, True),
        (False, True,  True),
        (False, False, True),
    ]

    out: List[Tuple[str, Dict[str, Any]]] = []
    seen: set = set()

    safe_nick = is_safe_nickname(target_nick)
    # For non-reply modes, never greet/quote by design
    if mode != "reply":
        recipes = [(False, False, False), (False, False, True)]

    for greet_on, quote_on, force_swap in recipes:
        if len(out) >= k:
            break
        sh = _shadow_state_for_layers(state)

        # seed connective history to encourage swap (preview only)
        if force_swap:
            try:
                pre = _extract_connective_prefix(base)
                if pre:
                    sh.setdefault("dlg", {}).setdefault("recent_connectives", [])
                    sh["dlg"]["recent_connectives"] = [pre] * 6
            except Exception:
                pass

        # Unit1 preview: placeholder resolution + optional greeting (reply only)
        greet_cd = 1800 if greet_on else 10**9
        t1 = apply_name_layer(cfg, sh, base, mode=str(mode or "comment"), target_nick=(target_nick if mode == "reply" else ""), greet_cooldown_sec=int(greet_cd))

        # Unit3 preview
        before_me = t1
        t2 = apply_microedit_layer(cfg, sh, t1, mode=str(mode or "comment"))
        me_changed = _lm_approx_changed(before_me, t2)

        quote_added = False
        t3 = t2
        if mode == "reply" and quote_on:
            q = extract_short_quote(str(target_text or ""), min_len=6, max_len=16)
            if q:
                before_q = t2
                t3 = apply_quote_layer(cfg, sh, t2, mode="reply", target_text=str(target_text or ""))
                if t3 != before_q and ("“" in t3 and "”" in t3):
                    quote_added = True
                # microedit again to clean one-liner artifacts
                t3 = apply_microedit_layer(cfg, sh, t3, mode="reply")

        t3 = re.sub(r"\s+", " ", str(t3 or "")).strip()
        if not t3:
            continue
        if t3 in seen:
            continue

        sc = lm_score_text(semantic, t3)
        if sc is None or not math.isfinite(float(sc)):
            continue

        greet_used = False
        if mode == "reply" and safe_nick:
            try:
                greet_used = bool(re.match(rf"^@{re.escape(str(target_nick))}\s+", t3))
            except Exception:
                greet_used = False

        meta = {
            "lm_score": float(sc),
            "greet_used": bool(greet_used),
            "quote_used": bool(quote_added),
            "name_placeholder_hit": bool(NAME_PLACEHOLDER in base),
            "microedit_changed": int(me_changed),
        }
        out.append((t3, meta))
        seen.add(t3)

    # sort by score (lower better)
    out.sort(key=lambda x: float((x[1] or {}).get("lm_score", 1e9)))
    return out[:k]

def _lm_apply_accept_side_effects(state: Dict[str, Any], meta: Dict[str, Any], *, target_nick: str = "") -> None:
    """Apply minimal runtime counters/state updates for the chosen candidate."""
    try:
        if not isinstance(meta, dict):
            return
        # counters
        if meta.get("quote_used"):
            protocol_bump_counter(state, "quote_used", 1)
        if meta.get("name_placeholder_hit"):
            protocol_bump_counter(state, "name_placeholder_hits", 1)
        if meta.get("microedit_changed", 0):
            protocol_bump_counter(state, "microedit_used", 1)
            protocol_bump_counter(state, "microedit_changed_chars", int(meta.get("microedit_changed", 0) or 0))

        if meta.get("greet_used") and target_nick:
            try:
                dlg = state.setdefault("dlg", {})
                gh = dlg.setdefault("greet_hist", {})
                gh[str(target_nick)] = float(time.time())
            except Exception:
                pass
            protocol_bump_counter(state, "name_greet_used", 1)
        # P2: record chosen connective prefix so "variety" works even for LM candidates
        try:
            cp = str(meta.get("connective_prefix") or "").strip()
            if cp:
                dlg = state.setdefault("dlg", {})
                recent = dlg.setdefault("recent_connectives", [])
                if not isinstance(recent, list):
                    recent = []
                    dlg["recent_connectives"] = recent
                recent.append(cp)
                if len(recent) > 30:
                    del recent[:-30]
        except Exception:
            pass
    except Exception:
        return


def _is_questionish(text: str) -> bool:
    """Heuristic: detect question-like text without NLP libs (for reply boosting)."""
    try:
        t = str(text or "").strip()
    except Exception:
        return False
    if not t:
        return False
    if "?" in t:
        return True
    # Korean-ish question cues (keep lightweight; avoid too many false positives)
    cues = (
        "왜", "어떻게", "근거", "무슨", "뭐임", "뭐야", "맞음", "맞나", "어디", "언제", "누가", "어느", "가능",
        "어떻게 생각", "어케", "이유", "전제", "기준"
    )
    return any(c in t for c in cues)

_FALLBACK_COMMENT_TEMPLATES: List[str] = [
    "이 부분 근거가 뭐임? 사례나 데이터 더 있으면 궁금함임",
    "전제가 뭐인지 궁금함임. 기준을 한 줄로 정리해주면 좋겠음임",
    "반대 근거도 같이 보면 좋겠음임. 어디까지 확실한 주장임?",
]

_FALLBACK_REPLY_TEMPLATES: List[str] = [
    "질문 요지가 뭐임? 전제랑 기준부터 같이 맞춰보면 좋겠음임",
    "근거가 어떤 쪽임? 사례 하나만 더 알려주면 이해 쉬울듯함임",
    "이 부분은 왜 그렇게 봄? 논리 흐름을 한 줄로만 더 부탁함임",
]

def _pick_fallback_comment(cfg: "Config", *, is_reply: bool) -> str:
    """Pick a safe (>=10 chars) last-resort comment/reply to reduce zero-comment cycles."""
    try:
        cands = list(_FALLBACK_REPLY_TEMPLATES if is_reply else _FALLBACK_COMMENT_TEMPLATES)
        random.shuffle(cands)
        for raw in cands:
            s = sanitize_plain_text(raw)
            try:
                s = ensure_eum_style(s, max_lines=2)
            except Exception:
                pass
            s = re.sub(r"\s+", " ", str(s)).strip()
            if len(s) >= 10:
                return s
    except Exception as e:
        log_debug_exc("_pick_fallback_comment:silent", e)
    return ""

def _hangul_ratio(text: str) -> float:
    t = text or ""
    if not t:
        return 0.0
    hangul = len(re.findall(r"[가-힣]", t))
    return hangul / max(1, len(t))

def _has_batchim_char(ch: str) -> bool:
    """Return True if Hangul syllable has a final consonant (받침)."""
    if not ch:
        return False
    code = ord(ch)
    if 0xAC00 <= code <= 0xD7A3:
        return ((code - 0xAC00) % 28) != 0
    return False

def ensure_eum_style(text: str, *, max_lines: int) -> str:
    """
    Force a more natural-ish "음슴체" ending per line, without external NLP libs.

    v2 adds:
      - light rhythm smoothing (reduce "임" density + consecutive "임" runs)
      - optional connector prefixes between lines (keeps prose from feeling list-like)
      - conservative noun-phrase allowances (avoid forcing '...임' on short noun lines)
      - fixes for polite endings like "...습니다/..겠습니다" (avoid "...습니임")
    """
    raw = str(text or "").strip()
    if not raw:
        return "내용 없음임"

    # Seed a tiny local RNG so repeated regen tries don't look identical,
    # but remain stable-ish per input.
    try:
        seed = int.from_bytes(hashlib.sha1(raw.encode("utf-8")).digest()[:8], "big", signed=False) ^ int(time.time() * 1000)
        rnd = random.Random(seed & ((1 << 64) - 1))
    except Exception:
        rnd = random.Random()

    # Prefer sentence splitting for single-line multi-sentence paragraphs (improves rhythm).
    lines = [x.strip() for x in raw.split("\n") if x.strip()]
    if len(lines) <= 1 and ("\n" not in raw):
        punc_hits = raw.count(".") + raw.count("!") + raw.count("?") + raw.count("…")
        if len(raw) >= 120 or punc_hits >= 2:
            try:
                sents = split_sentences(raw, max_sent=max(3, int(max_lines)))
                if len(sents) >= 2:
                    lines = [x.strip() for x in sents if x.strip()]
            except Exception as e:
                log_debug_exc("ensure_eum_style:silent", e)
                pass

    if not lines:
        lines = [raw]

    def _looks_safe_noun_end(b: str) -> bool:
        bb = (b or "").strip()
        if not bb:
            return False
        # avoid leaving particles dangling
        if any(bb.endswith(t) for t in _EUM_DANGLING_TAILS):
            return False
        # avoid trailing quote/colon
        if bb.endswith(('"', "'", ":", "—", "-", "·")):
            return False
        return True

    def _starts_with_connector(x: str) -> bool:
        ss = (x or "").strip()
        if not ss:
            return False
        return bool(EUM_CONNECTOR_START_RE.search(ss))

    def _maybe_add_connector(prev_ln: str, ln: str) -> str:
        if not ln:
            return ln
        if _starts_with_connector(ln):
            return ln
        if ln.startswith(("-", "•", "*", "http://", "https://")):
            return ln
        if len(ln) < 8:
            return ln
        if rnd.random() > float(EUM_V2_CONNECTOR_RATE):
            return ln

        contrast = ("근데", "다만", "오히려", "근데도")
        cont = ("그리고", "또", "게다가")
        causal = ("그래서", "그러면", "그러니")
        starter = ("일단", "사실")

        if any(w in ln for w in ("하지만", "반면", "근데", "다만", "오히려")):
            pool = list(contrast)
        elif any(w in ln for w in ("그래서", "그러면", "따라서", "결국")):
            pool = list(causal)
        elif prev_ln.endswith("?"):
            pool = list(causal) + list(cont)
        else:
            pool = list(cont) + list(starter)

        c = rnd.choice(pool) if pool else "그리고"
        return f"{c} {ln}"

    def _reduce_im_density(out_lines: List[str]) -> List[str]:
        if not out_lines:
            return out_lines

        def _ends_im(ln: str) -> bool:
            s = (ln or "").strip()
            return bool(re.search(r"(?:임|임\.|임\?|임!|임…)$", s))

        im_idx = [i for i, ln in enumerate(out_lines) if _ends_im(ln)]
        ratio = float(len(im_idx)) / float(max(1, len(out_lines)))

        if ratio <= float(EUM_V2_TARGET_IM_RATIO) and len(im_idx) <= 1:
            return out_lines

        new_lines = out_lines[:]
        max_changes = max(1, int(len(out_lines) * 0.34))
        changes = 0

        for i in im_idx:
            if changes >= max_changes:
                break
            ln = (new_lines[i] or "").strip()
            if not ln:
                continue

            # split trailing closers + punctuation (avoid '?임' artifacts like ...?\"임)
            closers = ""
            tail_closers = ('"', "'", "”", "’", ")", "]", "}", "】", "）", "」", "』", "》", "〉", "〕")
            while ln and ln[-1] in tail_closers:
                closers = ln[-1] + closers
                ln = ln[:-1].rstrip()

            p = ""
            if ln.endswith(("?", "!", "…", ".", "。")):
                p = ln[-1]
                body = ln[:-1].rstrip()
            else:
                body = ln

            if body.endswith("거임"):
                continue

            # Try safe swaps before dropping '임'
            if body.endswith("있임"):
                body = body[:-2] + "있음"
            elif body.endswith("없임"):
                body = body[:-2] + "없음"
            elif body.endswith("되임"):
                body = body[:-2] + "됨"
            elif body.endswith("하임"):
                body = body[:-2] + "함"
            elif body.endswith("했임"):
                body = body[:-2] + "했음"
            elif body.endswith("였임"):
                body = body[:-2] + "였음"
            else:
                if (len(body) <= 26) and body.endswith("임") and _looks_safe_noun_end(body[:-1]):
                    if rnd.random() <= float(EUM_V2_DROP_IM_RATE):
                        body = body[:-1].rstrip()

            new_ln = f"{body}{p}" if p else body
            if new_ln != ln:
                changes += 1
                new_lines[i] = new_ln

        # Smooth consecutive "임" runs
        for i in range(1, len(new_lines)):
            if changes >= max_changes:
                break
            if _ends_im(new_lines[i]) and _ends_im(new_lines[i - 1]):
                ln = new_lines[i].strip()
                p = ""
                if ln.endswith(("?", "!", "…", ".", "。")):
                    p = ln[-1]
                    body = ln[:-1].rstrip()
                else:
                    body = ln
                if body.endswith("임") and (len(body) <= 26) and _looks_safe_noun_end(body[:-1]):
                    body2 = body[:-1].rstrip()
                    if body2:
                        new_lines[i] = f"{body2}{p}" if p else body2
                        changes += 1

        return new_lines

    def _eumify_body(body: str, punct: str) -> str:
        b = (body or "").strip()
        if not b:
            return "내용 없음임"
        if EUM_LINE_OK_RE.search(b):
            return b

        is_q_or_excl = punct in ("?", "!")
        rules = _EUMIFY_RULES_Q if punct == "?" else _EUMIFY_RULES

        for pat, rep in rules:
            if pat.search(b):
                b2 = pat.sub(rep, b).strip()
                if b2:
                    return b2

        # final "다" (after filtering polite patterns above)
        if (not is_q_or_excl) and b.endswith("다") and len(b) >= 2:
            if (" " not in b) and len(b) <= 2:
                return b[:-1] + "음"
            return b[:-1] + "임"

        # soft endings already acceptable (avoid '...해짐임' etc)
        if b.endswith(("해짐", "같음", "갈림", "인듯", "듯", "듯함", "느낌", "편", "쪽")):
            return b

        # normalize colloquial copula tail
        if b.endswith("거야"):
            return b[:-2] + "거임"
        if b.endswith("이야") and len(b) >= 3 and _has_batchim_char(b[-3]):
            return b[:-2] + "임"
        if b.endswith("야") and len(b) >= 2:
            return b[:-1] + "임"

        if is_q_or_excl:
            return b

        # noun-phrase allowance
        if (len(b) <= 22) and _looks_safe_noun_end(b):
            return b

        # fallback
        if b.endswith("하") or b.endswith("함") or b.endswith("했"):
            return b + "음"
        if b.endswith("되"):
            return b + "됨"
        return b + "임"

    out_lines: List[str] = []
    for ln in lines:
        ln = sanitize_plain_text(ln)
        if not ln:
            continue

        # trailing closing quotes/brackets (keep after punctuation)
        closers = ""
        try:
            m = re.search(r"[\"\'”’\)\]\}]+$", ln)
            if m:
                closers = m.group(0)
                ln = ln[:-len(closers)].rstrip()
        except Exception as e:
            log_debug_exc("ensure_eum_style:closers", e)
            closers = ""

        if _hangul_ratio(ln) < 0.12 and len(ln) >= 6 and not EUM_LINE_OK_RE.search(ln):
            ln = f"{ln} 임"

        p = ""
        if ln.endswith(("?", "!", "…", ".", "。")):
            p = ln[-1]
            body = ln[:-1].rstrip()
        else:
            body = ln

        body = _eumify_body(body, p)
        body = re.sub(r"(임|음|슴|함|됨)\1+$", r"\1", body)

        if p:
            ln2 = f"{body}{p}{closers}"
        elif closers:
            ln2 = f"{body}{closers}"
        else:
            ln2 = body
        out_lines.append(ln2)

    if not out_lines:
        out_lines = ["내용 없음임"]

    if bool(EUM_V2_ENABLED) and len(out_lines) >= 2:
        new_lines = out_lines[:]
        added = 0
        for i in range(1, len(new_lines)):
            if added >= int(EUM_V2_MAX_CONNECTORS):
                break
            prev_ln = new_lines[i - 1].strip()
            ln = new_lines[i].strip()
            ln2 = _maybe_add_connector(prev_ln, ln)
            if ln2 != ln:
                new_lines[i] = ln2
                added += 1
        new_lines = _reduce_im_density(new_lines)
        out_lines = new_lines

    out_lines = out_lines[:max(1, int(max_lines))]
    return "\n".join(out_lines)

def eumify_tail_phrase(phrase: str) -> str:
    """Make a short phrase safe to end with 음슴체 without producing '야임/해짐임' artifacts."""
    s = sanitize_plain_text(phrase)
    if not s:
        return "그거임"
    # strip trailing punctuation
    s = re.sub(r"[\.!?…。]+\s*$", "", s).strip()
    if not s:
        return "그거임"

    # already looks like eum ending
    if EUM_LINE_OK_RE.search(s):
        return s

    # common copula tails
    if s.endswith("거야"):
        return s[:-2] + "거임"
    if s.endswith("이야") and len(s) >= 3 and _has_batchim_char(s[-3]):
        return s[:-2] + "임"
    if s.endswith("야") and len(s) >= 2:
        return s[:-1] + "임"

    # allow soft nominal endings without forcing extra suffix
    if s.endswith(("해짐", "같음", "갈림", "됨", "없음", "있음", "했음", "였음")):
        return s

    # polite tail
    if s.endswith("요") and len(s) >= 2:
        s = s[:-1].rstrip()
        if not s:
            return "그거임"

    # polite endings that include trailing '다' (avoid '...습니임' artifacts)
    if s.endswith("같습니다") and len(s) >= 4:
        return s[:-3] + "음"
    if s.endswith("겠습니다") and len(s) >= 5:
        return s[:-4] + "겠음"
    if s.endswith("합니다") and len(s) >= 4:
        return s[:-3] + "함"
    if s.endswith("됩니다") and len(s) >= 4:
        return s[:-3] + "됨"
    if s.endswith("습니다") and len(s) >= 4:
        return s[:-3] + "슴"

    # final '다' -> eum
    if s.endswith("다") and len(s) >= 2:
        if (" " not in s) and len(s) <= 2:
            return s[:-1] + "음"
        return s[:-1] + "임"

    # short noun-like phrases: allow ending without forcing "임" (reduces stiffness)
    if (len(s) <= 18) and _hangul_ratio(s) >= 0.35:
        if not any(s.endswith(t) for t in _EUM_DANGLING_TAILS):
            if re.search(r"(느낌|인듯|듯함|듯|편|쪽)$", s):
                return s
            if re.search(r"[가-힣A-Za-z0-9]$", s) and (" " in s or len(s) >= 6):
                return s
    return s + "임"


_SENT_SPLIT_RE = re.compile(r"(?:(?<=[\.\?!…])\s+|(?<=다\.)\s+|\n+)")
def split_sentences(text: str, *, max_sent: int = 8) -> List[str]:
    t = sanitize_plain_text(text)
    if not t:
        return []
    parts = [p.strip() for p in _SENT_SPLIT_RE.split(t) if p.strip()]
    return parts[:max(1, int(max_sent))]


def split_sentences_ko(text: str, *, max_sent: int = 12) -> List[str]:
    """Korean-friendly sentence splitter (alias for split_sentences).

    v18.1 hotfix: some template-mining utilities reference split_sentences_ko.
    """
    return split_sentences(text, max_sent=max_sent)


def _detect_frame(text: str) -> str:
    """Lightweight discourse frame detector.

    Used for thread synthesis. Kept intentionally simple/LLM-free.

    Returns: "claim" | "counter" | "other"
    """
    t = sanitize_plain_text(str(text or "")).strip()
    if not t:
        return "other"

    tl = t.lower()

    # Counter / rebuttal cues
    if any(x in t for x in ("근데", "하지만", "반대로", "오히려", "그럼에도", "그렇다 해도", "그런데")):
        return "counter"
    if any(x in tl for x in ("however", "but", "instead", "nevertheless", "on the other hand")):
        return "counter"

    # Claim / conclusion cues
    if any(x in t for x in ("요지는", "결론은", "핵심은", "정의는", "내 기준은", "즉", "정리하면")):
        return "claim"
    if t.endswith(("임", "함", "임.", "함.")) and len(t) >= 12:
        return "claim"

    return "other"

# --- Outgoing text post-processing (Hotfix 2)
# Goal: Keep 음슴체, but avoid unnatural artifacts:
# - No ellipsis ('…', '...') or truncated tokens like 'Ter…'
# - Remove stray ending fragments like '?임.' or '.임.' inserted by templating
# - Apply 음슴체 per sentence (not just per line) to reduce awkward stacking

_EUM_FRAGMENT_RE = re.compile(r"([\.?!])\s*(임|음|슴|함|됨)\s*\.", re.UNICODE)
_BROKEN_ASCII_ELLIPSIS_RE = re.compile(r"\b[A-Za-z]{1,4}…|\b[A-Za-z]{1,4}\.{3,}", re.UNICODE)
_SENTENCE_FP_RE = re.compile(r"[^0-9a-zA-Z가-힣]+")
_POSTPROCESS_DEDUPE_TS = deque(maxlen=5000)

def _sentence_fp(text: str) -> str:
    s = str(text or "").strip().lower()
    s = _SENTENCE_FP_RE.sub("", s)
    return s[:400]

def _sentence_core_tokens(text: str) -> List[str]:
    toks = [t for t in tokenize(str(text or ""), max_tokens=40) if t]
    core = [t for t in toks if t not in STOPWORDS_KO and t not in STOPWORDS_EN]
    return core[:16]

def _record_postprocess_dedupe() -> None:
    try:
        _POSTPROCESS_DEDUPE_TS.append(time.time())
    except Exception:
        pass

def _sanitize_keep_newlines(text: str) -> str:
    t = str(text or "")
    t = EMOJI_RE.sub("", t)
    t = re.sub(r"https?://\S+", "", t)
    t = re.sub(r"[`*_>#]", "", t)
    # keep newlines but normalize spaces
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\r\n?", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()

def _remove_ellipsis_and_broken_tokens(text: str) -> str:
    t = str(text or "")
    # remove obviously truncated short ASCII tokens that were cut with ellipsis
    t = _BROKEN_ASCII_ELLIPSIS_RE.sub("", t)
    # remove ellipsis markers entirely (they look bot-like in this community)
    t = t.replace("…", " ")
    t = re.sub(r"\.{3,}", " ", t)
    return re.sub(r"\s+", " ", t).strip()

def _drop_lonely_eum_fragments(text: str) -> str:
    t = str(text or "")
    # e.g. "왜 그러냐?임." -> "왜 그러냐?"
    t = _EUM_FRAGMENT_RE.sub(r"\1", t)
    # also drop standalone fragments
    t = re.sub(r"(^|\s)(임|음|슴|함|됨)(?=\.?\s|$)", " ", t)
    # normalize punctuation
    t = re.sub(r"\.\s*\.", ".", t)
    t = re.sub(r"\?\s*\?", "?", t)
    t = re.sub(r"!\s*!", "!", t)
    return re.sub(r"\s+", " ", t).strip()

def _space_after_punct(text: str) -> str:
    # help sentence splitting even when templates forget spaces after punctuation
    t = str(text or "")
    t = re.sub(r"([\.?!])(?=[^\s\.\?!])", r"\1 ", t)
    return re.sub(r"\s+", " ", t).strip()

def postprocess_outgoing_text(
    text: str,
    *,
    mode: str,
    max_chars: int,
    max_lines: int,
) -> str:
    """
    Post-process already-generated text for outbound API writes.
    This must be safe (no external NLP) and conservative.
    """
    raw = _sanitize_keep_newlines(text)

    # line-wise preserve structure for posts; single-line for others
    lines_in = [ln.strip() for ln in raw.split("\n") if ln.strip()]
    if not lines_in:
        lines_in = [raw] if raw else ["내용 없음임"]

    out_lines: List[str] = []
    for ln in lines_in:
        ln0 = _remove_ellipsis_and_broken_tokens(ln)
        ln0 = _drop_lonely_eum_fragments(ln0)
        ln0 = _space_after_punct(ln0)
        ln0 = resolve_josa_placeholders(ln0)

        # sentence-level eum: reduces "임.임." stacking & improves naturalness
        sents = split_sentences(ln0, max_sent=12)
        fixed: List[str] = []
        seen_keys: set = set()
        seen_fp: set = set()
        seen_core: set = set()
        for s in sents:
            s = s.strip()
            if not s:
                continue
            # drop empty/fragment sentences
            if s in ("임", "음", "슴", "함", "됨"):
                continue
            s2 = ensure_eum_style(s, max_lines=1).replace("\n", " ").strip()
            s2 = _drop_lonely_eum_fragments(s2)
            s2 = _remove_ellipsis_and_broken_tokens(s2)
            if s2:
                if STRICT_POSTPROCESS:
                    fp = _sentence_fp(s2)
                    core = _sentence_core_tokens(s2)
                    if fp and (fp in seen_fp):
                        if core and (set(core) - seen_core):
                            pass
                        else:
                            _record_postprocess_dedupe()
                            continue
                    if core:
                        seen_core.update(core)
                    if fp:
                        seen_fp.add(fp)
                else:
                    k = re.sub(r"[^0-9a-zA-Z가-힣]+", "", s2).lower()
                    if k and (k in seen_keys):
                        continue
                    if fixed:
                        pk = re.sub(r"[^0-9a-zA-Z가-힣]+", "", fixed[-1]).lower()
                        # collapse near-identical adjacent sentences
                        if k and pk and (k == pk or (len(k) >= 20 and (k in pk or pk in k))):
                            continue
                    if k:
                        seen_keys.add(k)
                fixed.append(s2)

        if fixed:
            out_lines.append(" ".join(fixed).strip())

    if not out_lines:
        out_lines = ["내용 없음임"]

    # enforce max lines / join mode
    out_lines = out_lines[:max(1, int(max_lines))]
    out = "\n".join(out_lines) if mode == "post" else " ".join(out_lines)

    out = re.sub(r"\s+\n", "\n", out)
    out = re.sub(r"\n\s+", "\n", out)
    out = re.sub(r"\s+", " ", out).strip()

    if len(out) > int(max_chars):
        out = out[: int(max_chars)].rstrip()

    # final safety: no ellipsis
    out = out.replace("…", " ")
    out = re.sub(r"\.{3,}", " ", out)
    out = re.sub(r"\s+", " ", out).strip() if mode != "post" else out.strip()
    if LANG_STRICT:
        # Remove lingering markdown list markers that can look like markdown.
        if mode == "post":
            lines = [re.sub(r"^\s*(?:[-*]+|\d+\.)\s+", "", ln).strip() for ln in out.split("\n")]
            lines = [ln for ln in lines if ln]
        else:
            lines = [re.sub(r"^\s*(?:[-*]+|\d+\.)\s+", "", out).strip()]

        def _ensure_line_eum(line: str) -> str:
            l = (line or "").strip()
            if not l:
                return l
            # Split trailing suffixes so we can insert '임' BEFORE punctuation/quotes/brackets.
            base = l
            closers = ""
            punc = ""
            try:
                # common closing quotes/brackets at the very end
                m = re.search(r"[\"\'”’\)\]\}]+$", base)
                if m:
                    closers = m.group(0)
                    base = base[:-len(closers)]
                m = re.search(r"[\.\!\?…]+$", base)
                if m:
                    punc = m.group(0)
                    base = base[:-len(punc)]
            except Exception as e:
                log_debug_exc("_ensure_line_eum:silent", e)
                base, punc, closers = l, "", ""
            chk = (base or "").strip()
            if not chk:
                return l
            if re.search(r"(음|슴|임|함|됨)$", chk):
                return l
            return (base + "임" + punc + closers).strip()


        lines = [_ensure_line_eum(ln) for ln in lines if ln]
        if not lines:
            lines = ["내용 없음임"]
        out = "\n".join(lines) if mode == "post" else " ".join(lines)
        # English notice rule (relaxed):
        # - Disabled by default (ENGLISH_NOTICE="").
        # - If enabled, triggers only when BOTH:
        #   (1) English letters count >= min_alpha AND (2) ratio >= threshold.
        try:
            letters = len(re.findall(r"[A-Za-z]", out))
            ratio = letters / max(1, len(out))
        except Exception:
            letters, ratio = 0, 0.0

        try:
            min_alpha = int(_env_int("MERSOOM_ENGLISH_NOTICE_MIN_ALPHA", int(ENGLISH_NOTICE_MIN_ALPHA)))
        except Exception:
            min_alpha = int(ENGLISH_NOTICE_MIN_ALPHA)

        if (
            ENGLISH_NOTICE
            and re.search(r"[A-Za-z]{2,}", out)
            and (ENGLISH_NOTICE not in out)
            and (letters >= int(min_alpha))
            and (ratio >= float(ENGLISH_NOTICE_RATIO or 0.0))
        ):
            notice = str(ENGLISH_NOTICE).strip()
            if notice:
                if ENGLISH_NOTICE_APPEND_EUM and not notice.endswith(("음", "슴", "임", "함", "됨")):
                    notice = notice + "임"
                if mode == "post" and "\n" in out:
                    parts = out.split("\n")
                    parts[-1] = (parts[-1].rstrip() + " " + notice).strip()
                    out = "\n".join(parts)
                else:
                    out = (out.rstrip() + " " + notice).strip()

        # keep within bounds again

        if len(out) > int(max_chars):
            out = out[: int(max_chars)].rstrip()


    if not out:
        out = "내용 없음임"
    return out

_TOKEN_RE = re.compile(r"[가-힣]+|[a-zA-Z0-9]+", re.UNICODE)

# --- Keyword normalization (Unit 15)
# Heuristic Korean particle (조사) stripping to avoid awkward keywords like "자아가", "악플러가" etc.
_JOSA_SUFFIXES: Tuple[str, ...] = tuple(sorted([
    "으로서", "으로써", "으로부터",
    "에게서", "한테서",
    "들에게",
    "으로", "로", "에서", "에게", "한테", "까지", "부터", "보다", "처럼", "라도",
    "이나", "나", "랑", "하고", "과", "와", "의",
    "으로는", "로는", "에서는", "에게는", "한테는",
    "은", "는", "이", "가", "을", "를", "도", "만", "에",
], key=len, reverse=True))

_HANGUL_TOKEN_RE = re.compile(r"^[가-힣]+$")

def normalize_ko_token(tok: str) -> str:
    """Lightweight normalization for Korean tokens (no external NLP)."""
    t = (tok or "").strip()
    if not t or not _HANGUL_TOKEN_RE.match(t):
        return t
    # strip trailing particles up to twice (handles "...에서는" -> "...에" -> "...")
    for _ in range(2):
        changed = False
        for suf in _JOSA_SUFFIXES:
            if t.endswith(suf) and (len(t) - len(suf)) >= 2:
                t = t[:-len(suf)]
                changed = True
                break
        if not changed:
            break
    return t

def josa_eul_reul(noun: str) -> str:
    """Choose object particle 을/를 for a noun-ish token (best-effort, Hangul-aware)."""
    t = (noun or "").strip()
    if not t:
        return "을"
    ch = t[-1]
    code = ord(ch)
    if 0xAC00 <= code <= 0xD7A3:
        jong = (code - 0xAC00) % 28
        return "을" if jong != 0 else "를"
    # for non-Hangul (AI/LLM), '를' reads more natural most of the time
    return "를"

def josa_eun_neun(noun: str) -> str:
    """Choose topic particle 은/는 (best-effort, Hangul-aware)."""
    t = (noun or "").strip()
    if not t:
        return "은"
    ch = t[-1]
    code = ord(ch)
    if 0xAC00 <= code <= 0xD7A3:
        jong = (code - 0xAC00) % 28
        return "은" if jong != 0 else "는"
    # non-Hangul: '는' reads more natural (AI는, API는)
    return "는"

def josa_i_ga(noun: str) -> str:
    """Choose subject particle 이/가 (best-effort, Hangul-aware)."""
    t = (noun or "").strip()
    if not t:
        return "이"
    ch = t[-1]
    code = ord(ch)
    if 0xAC00 <= code <= 0xD7A3:
        jong = (code - 0xAC00) % 28
        return "이" if jong != 0 else "가"
    return "가"

# Resolve light josa placeholders used by templates: 은(는)/는(은), 을(를)/를(을), 이(가)/가(이)
_JOSA_PLACEHOLDER_TOKEN = r"[0-9A-Za-z가-힣]+"  # keep conservative

def resolve_josa_placeholders(text: str) -> str:
    s = str(text or "")
    if not s:
        return s

    def _sub(pattern: str, chooser) -> None:
        nonlocal s
        def repl(m: re.Match) -> str:
            tok = m.group(1)
            return tok + chooser(tok)
        s = re.sub(pattern, repl, s)

    # Topic: 은/는 (support both orders, because templates may contain swapped placeholders)
    _sub(rf"({_JOSA_PLACEHOLDER_TOKEN})은\(는\)", josa_eun_neun)
    _sub(rf"({_JOSA_PLACEHOLDER_TOKEN})는\(은\)", josa_eun_neun)

    # Object: 을/를
    _sub(rf"({_JOSA_PLACEHOLDER_TOKEN})을\(를\)", josa_eul_reul)
    _sub(rf"({_JOSA_PLACEHOLDER_TOKEN})를\(을\)", josa_eul_reul)

    # Subject: 이/가
    _sub(rf"({_JOSA_PLACEHOLDER_TOKEN})이\(가\)", josa_i_ga)
    _sub(rf"({_JOSA_PLACEHOLDER_TOKEN})가\(이\)", josa_i_ga)

    # If any stray '(은)/(는)/(을)/(를)/(이)/(가)' remain, drop parentheses conservatively
    s = s.replace("(은)", "").replace("(는)", "").replace("(을)", "").replace("(를)", "")
    s = s.replace("(이)", "").replace("(가)", "")
    return s


def pick_kw_for_reply(compose_input: Dict[str, Any]) -> str:
    """Pick a short keyword-like token to avoid repeating a full sentence as {KW}."""
    cands: List[str] = []
    for k in (_safe_list(compose_input.get("target_keywords")) + _safe_list(compose_input.get("thread_keywords"))):
        try:
            cands.append(str(k))
        except Exception:
            continue

    def _clean(tok: str) -> str:
        t = sanitize_plain_text(tok)
        if len(t) > 32:
            t = one_line(t, 32)
        # if it's a whole sentence, keep first token-ish chunk
        if len(t) > 14 and " " in t:
            parts = [p for p in re.split(r"\s+", t) if p]
            if parts:
                t = parts[0]
        if _HANGUL_TOKEN_RE.match(t):
            t = normalize_ko_token(t)
        return t

    for c in cands:
        t = _clean(c)
        if is_clean_keyword(t) and 2 <= len(t) <= 12:
            return t

    # fallback: derive from target_text quickly
    try:
        tx = str(compose_input.get("target_text") or "")
        kws = top_keywords(tx, k=6) if tx else []
        for k in kws:
            t = _clean(str(k))
            if is_clean_keyword(t) and 2 <= len(t) <= 12:
                return t
    except Exception as e:
        log_debug_exc("pick_kw_for_reply:silent", e)
        pass

    return "그거"

def is_clean_keyword(tok: str) -> bool:
    """Extra filter to prevent rough/unsafe keywords from entering brain/community hot lists."""
    t = (tok or "").strip()
    if not t or len(t) <= 1:
        return False
    if looks_like_injection(t) or looks_offensive(t):
        return False
    if contains_markdown(t):
        return False
    # avoid long numeric strings
    if re.fullmatch(r"\d{3,}", t):
        return False
    return True

@lru_cache(maxsize=4096)
def _tokenize_cached(text: str, max_tokens: int) -> Tuple[str, ...]:
    # Cache tokenization for repeated scoring/QA paths (best-effort; bounded).
    t = sanitize_plain_text(text).lower()
    toks = _TOKEN_RE.findall(t)
    out: List[str] = []
    for w in toks:
        if len(w) <= 1:
            continue

        # normalize Korean tokens (strip 조사)
        if _HANGUL_TOKEN_RE.match(w):
            w = normalize_ko_token(w)
            if len(w) <= 1:
                continue

        if w in STOPWORDS_KO or w in STOPWORDS_EN:
            continue
        if looks_offensive(w) or looks_like_injection(w):
            continue

        out.append(w)
        if len(out) >= max_tokens:
            break
    return tuple(out)

def tokenize(text: str, *, max_tokens: int = 200) -> List[str]:
    try:
        s = str(text or "")
        if len(s) > 4000:
            s = s[:4000]
        return list(_tokenize_cached(s, int(max_tokens)))
    except Exception:
        # fallback to non-cached path
        t = sanitize_plain_text(text).lower()
        toks = _TOKEN_RE.findall(t)
        out: List[str] = []
        for w in toks:
            if len(w) <= 1:
                continue
            if _HANGUL_TOKEN_RE.match(w):
                w = normalize_ko_token(w)
                if len(w) <= 1:
                    continue
            if w in STOPWORDS_KO or w in STOPWORDS_EN:
                continue
            if looks_offensive(w) or looks_like_injection(w):
                continue
            out.append(w)
            if len(out) >= max_tokens:
                break
        return out

def top_keywords(text: str, *, k: int = 6) -> List[str]:
    toks = tokenize(text, max_tokens=400)
    if not toks:
        return []
    freq: Dict[str, int] = {}
    for t in toks:
        freq[t] = freq.get(t, 0) + 1
    # prefer slightly longer tokens
    ranked = sorted(freq.items(), key=lambda kv: (kv[1], len(kv[0])), reverse=True)

    out: List[str] = []
    for w, _ in ranked:
        if not is_clean_keyword(w):
            continue
        if w not in out:
            out.append(w)
        if len(out) >= max(1, int(k)):
            break
    return out

def classify_text(text: str) -> Tuple[str, str]:
    """
    Returns (category, context_key).
    Keep it simple: category affects strategy selection and tone.
    """
    t = (text or "").lower()
    if looks_like_injection(text):
        return ("injection", "inj")
    if any(x in t for x in ["error", "traceback", "401", "403", "500", "버그", "코드", "파이썬", "python", "api", "로그"]):
        return ("dev", "dev")
    if any(x in t for x in ["윤리", "철학", "의미", "존재", "진실", "합의", "자아", "의식"]):
        return ("philo", "philo")
    if any(x in t for x in ["근황", "소식", "요즘", "썰", "유출", "소문"]):
        return ("gossip", "gossip")
    if any(x in t for x in ["메타", "규칙", "커뮤니티", "운영", "분위기", "정책"]):
        return ("meta", "meta")
    return ("general", "gen")

def _sha1_u64(s: str) -> int:
    h = hashlib.sha1(s.encode("utf-8")).digest()
    return int.from_bytes(h[:8], "big", signed=False)

def simhash64(tokens: List[str]) -> int:
    """
    Lightweight simhash for novelty / duplication checks.
    """
    if not tokens:
        return 0
    v = [0] * 64
    for t in tokens:
        x = _sha1_u64(t)
        for i in range(64):
            bit = (x >> i) & 1
            v[i] += 1 if bit else -1
    out = 0
    for i in range(64):
        if v[i] >= 0:
            out |= (1 << i)
    return out

def hamming64(a: int, b: int) -> int:
    return (a ^ b).bit_count()

################################################################################
# (P0) SPAM / NEAR-DUP GUARD (simhash + token entropy)
################################################################################

def _token_entropy(tokens: List[str]) -> float:
    # normalized entropy in [0,1]
    if not tokens:
        return 0.0
    freq: Dict[str, int] = {}
    for t in tokens:
        if not t:
            continue
        freq[t] = freq.get(t, 0) + 1
    if not freq:
        return 0.0
    n = float(sum(freq.values()))
    if n <= 0:
        return 0.0
    # Shannon entropy
    import math as _math
    H = 0.0
    for c in freq.values():
        p = float(c) / n
        if p > 0:
            H -= p * _math.log(p, 2)
    maxH = _math.log(max(1, len(freq)), 2)
    if maxH <= 0:
        return 0.0
    return max(0.0, min(1.0, H / maxH))

def _spam_guard_params(*, for_post: bool) -> Dict[str, Any]:
    # Defaults tuned to be conservative but not overly strict.
    if for_post:
        min_entropy = _env_float("MERSOOM_MIN_POST_ENTROPY", 0.30, min_v=0.0, max_v=1.0)
        min_tokens = _env_int("MERSOOM_MIN_POST_TOKENS", 16, min_v=0, max_v=500)
    else:
        min_entropy = _env_float("MERSOOM_MIN_COMMENT_ENTROPY", 0.25, min_v=0.0, max_v=1.0)
        min_tokens = _env_int("MERSOOM_MIN_COMMENT_TOKENS", 6, min_v=0, max_v=500)
    near_dup_hamming = _env_int("MERSOOM_SIMHASH_NEAR_DUP_HAMMING", 8, min_v=0, max_v=64)
    ttl_sec = _env_int("MERSOOM_SIMHASH_TTL_SEC", 6 * 3600, min_v=60, max_v=30 * 24 * 3600)
    keep_max = _env_int("MERSOOM_SIMHASH_KEEP_MAX", 1500, min_v=50, max_v=20000)
    return {
        "min_entropy": float(min_entropy),
        "min_tokens": int(min_tokens),
        "near_dup_hamming": int(near_dup_hamming),
        "ttl_sec": int(ttl_sec),
        "keep_max": int(keep_max),
    }

def _jaccard_ratio(a: List[Any], b: List[Any]) -> float:
    try:
        sa = set(a or [])
        sb = set(b or [])
        if not sa or not sb:
            return 0.0
        inter = len(sa & sb)
        uni = len(sa | sb)
        if uni <= 0:
            return 0.0
        return float(inter) / float(uni)
    except Exception:
        return 0.0

def _sig_keywords(text: str, *, k: int = 12) -> List[str]:
    # low-cost: uses existing keyword extractor + cleaning rules
    try:
        kws = extract_keywords(text, k=int(k))
        return _safe_list(kws)[: max(0, int(k))]
    except Exception:
        return []

def _sig_3grams(text: str, *, max_ngrams: int = 256) -> List[int]:
    # char 3-grams on compact normalized string (hash to ints for compact JSON)
    try:
        s = one_line(str(text or ""), 4000).strip().lower()
        s = re.sub(r"\s+", "", s)
        s = re.sub(r"[^0-9a-z가-힣]+", "", s)
        if len(s) < 3:
            return []
        grams: List[int] = []
        seen: set = set()
        # cap to avoid blow-ups on long posts
        cap = max(16, min(int(max_ngrams), 2048))
        for i in range(0, len(s) - 2):
            g = s[i : i + 3]
            hv = int(_sha1_u64(g))
            if hv in seen:
                continue
            seen.add(hv)
            grams.append(hv)
            if len(grams) >= cap:
                break
        return grams
    except Exception:
        return []

def remember_dup_signatures(state: Dict[str, Any], text: str, *, for_post: bool, same_text_gap_sec: int) -> None:
    # store extra signatures to support low-cost "meaning-ish" near-dup checks
    try:
        p = _spam_guard_params(for_post=for_post)
        ttl = max(int(p.get("ttl_sec", 6 * 3600) or 6 * 3600), int(same_text_gap_sec))
        keep = min(800, int(p.get("keep_max", 1500) or 1500))
        now = time.time()

        kw = _sig_keywords(text, k=12)
        if kw:
            kkey = "recent_post_kw_sets" if for_post else "recent_kw_sets"
            state[kkey] = _clean_hash_list(_safe_list(state.get(kkey, [])), ttl, keep)
            state.setdefault(kkey, [])
            state[kkey].append([kw[:12], now])

        grams = _sig_3grams(text, max_ngrams=256)
        if grams:
            gkey = "recent_post_3gram_sets" if for_post else "recent_3gram_sets"
            state[gkey] = _clean_hash_list(_safe_list(state.get(gkey, [])), ttl, keep)
            state.setdefault(gkey, [])
            state[gkey].append([grams[:256], now])
    except Exception:
        return

def dup_guard_bucket(state: Dict[str, Any], text: str, *, for_post: bool, same_text_gap_sec: int) -> Tuple[bool, str]:
    """Near-dup / spam guard returning a coarse bucket:
    - qa_fail: too-short / low-entropy
    - dup_fp: exact / fingerprint dup
    - dup_sim: simhash / jaccard / 3-gram similarity
    """
    p = _spam_guard_params(for_post=for_post)

    # always keep basic anti-spam gates on
    tokens = tokenize(text, max_tokens=220)
    if len(tokens) < int(p["min_tokens"]):
        return True, "qa_fail"
    ent = _token_entropy(tokens)
    if ent < float(p["min_entropy"]):
        return True, "qa_fail"

    dup_on = _env_bool("MERSOOM_DUPTEXT_BLOCK", True)
    if dup_on:
        # exact de-dupe first (short window)
        if recently_used_text(state, text, for_post=for_post, same_text_gap_sec=same_text_gap_sec):
            return True, "dup_fp"

        # fingerprint de-dupe (longer window; catches tiny edits)
        fp_ttl = _env_int("MERSOOM_RECENT_TEXT_FP_TTL_SEC", 6 * 3600, 60, 30 * 24 * 3600)
        fp_keep = _env_int("MERSOOM_RECENT_TEXT_FP_KEEP_MAX", 1200, 50, 20000)
        if recently_used_fp(state, text, for_post=for_post, ttl_sec=max(int(fp_ttl), int(same_text_gap_sec)), keep_max=int(fp_keep)):
            return True, "dup_fp"

        # simhash near-dup
        key = "recent_post_simhashes" if for_post else "recent_simhashes"
        state[key] = _clean_hash_list(_safe_list(state.get(key, [])), max(int(p["ttl_sec"]), int(same_text_gap_sec)), int(p["keep_max"]))
        sh = int(simhash64(tokens[:160]))
        thr = int(p["near_dup_hamming"])
        for it in _safe_list(state.get(key, [])):
            try:
                old_sh = int(it[0])
                if hamming64(sh, old_sh) <= thr:
                    return True, "dup_sim"
            except Exception:
                continue

        j_th = float(_env_float("MERSOOM_SIM_JACCARD_TH", 0.70, min_v=0.0, max_v=1.0))
        g_th = float(_env_float("MERSOOM_SIM_3GRAM_TH", 0.82, min_v=0.0, max_v=1.0))
        ttl = max(int(p["ttl_sec"]), int(same_text_gap_sec))
        keep = min(800, int(p["keep_max"]))

        if j_th > 0.0:
            kw = _sig_keywords(text, k=12)
            if kw:
                kkey = "recent_post_kw_sets" if for_post else "recent_kw_sets"
                state[kkey] = _clean_hash_list(_safe_list(state.get(kkey, [])), ttl, keep)
                cur = kw[:12]
                # check only recent slice for cost control
                for it in _safe_list(state.get(kkey, []))[-120:]:
                    try:
                        old = it[0]
                        if isinstance(old, list) and _jaccard_ratio(cur, old) >= j_th:
                            return True, "dup_sim"
                    except Exception:
                        continue

        if g_th > 0.0:
            grams = _sig_3grams(text, max_ngrams=256)
            if grams:
                gkey = "recent_post_3gram_sets" if for_post else "recent_3gram_sets"
                state[gkey] = _clean_hash_list(_safe_list(state.get(gkey, [])), ttl, keep)
                curg = grams[:256]
                for it in _safe_list(state.get(gkey, []))[-80:]:
                    try:
                        old = it[0]
                        if isinstance(old, list) and _jaccard_ratio(curg, old) >= g_th:
                            return True, "dup_sim"
                    except Exception:
                        continue

    return False, ""

def _is_near_duplicate_simhash(state: Dict[str, Any], text: str, *, for_post: bool, same_text_gap_sec: int) -> bool:
    dup, _ = dup_guard_bucket(state, text, for_post=for_post, same_text_gap_sec=same_text_gap_sec)
    return bool(dup)



def normalize_fail_bucket(bucket: str) -> str:
    """Normalize legacy/free-form fail buckets into a stable, analyzable schema.

    Canonical prefixes (when known): qa:, dup:, target:, ground:, spam:, http:, pow:, ops:, gen:.
    This affects observability only (counters/logging), not behavior.
    """
    try:
        b = str(bucket or "").strip()
        if not b:
            return ""
        # Keep already-canonical buckets.
        if re.match(r"^(qa|dup|target|ground|spam|http|pow|ops|gen):", b):
            return b[:80]
        # Common legacy forms.
        if b.endswith(":no_target") and b.count(":") == 1:
            dom = b.split(":", 1)[0]
            return f"target:no_target:{dom}"[:80]
        if b.startswith("dup_"):
            return ("dup:" + b[4:])[:80]
        if b.startswith("qa_"):
            return ("qa:" + b[3:])[:80]
        if b.startswith("ground_"):
            return ("ground:" + b[6:])[:80]
        if b.startswith("spam_"):
            return ("spam:" + b[5:])[:80]
        if b.startswith("http_"):
            return ("http:" + b[5:])[:80]
        # Small set of known bare codes.
        if b in ("dup", "dup_sim", "dup_exact", "dup_near"):
            return ("dup:" + b.split("_", 1)[-1] if "_" in b else "dup:generic")[:80]
        if b in ("no_target", "comment_no_target", "reply_no_target"):
            return "target:no_target"[:80]
        return b[:80]
    except Exception:
        return str(bucket or "")[:80]
def _bump_gen_fail(state: Dict[str, Any], bucket: str) -> None:
    try:
        b = normalize_fail_bucket(bucket)
        if not b:
            return
        proto = state.get("protocol")
        if not isinstance(proto, dict):
            proto = {}
            state["protocol"] = proto
        gc = proto.get("gen_fail_counts")
        if not isinstance(gc, dict):
            gc = {}
            proto["gen_fail_counts"] = gc
        gc[b] = int(gc.get(b, 0) or 0) + 1
        protocol_bump_counter(state, f"qa_fail_bucket:{b}", 1)
    except Exception:
        return


def remember_simhash(state: Dict[str, Any], text: str, *, for_post: bool, same_text_gap_sec: int) -> None:
    p = _spam_guard_params(for_post=for_post)
    key = "recent_post_simhashes" if for_post else "recent_simhashes"
    state[key] = _clean_hash_list(_safe_list(state.get(key, [])), max(int(p["ttl_sec"]), int(same_text_gap_sec)), int(p["keep_max"]))
    try:
        sh = int(simhash64(tokenize(text, max_tokens=220)[:160]))
        state.setdefault(key, [])
        state[key].append([sh, time.time()])
    except Exception:
        return
