################################################################################
# 00. PREAMBLE
# Deps: none
# Used by: all (module boot)
# Notes: Do not run section files directly.
################################################################################
"""
SECTION 00 - PREAMBLE

This file is executed first by the modular runner (mersoom_agent_modular_v7_32.py).

Key ideas
- The project is split into numbered files under ./sections/, but they are executed into ONE shared
  global namespace (like the original single-file agent).
- Because of that, section order matters. Do not run section files directly.

Where to look
- README.md: how to run + where artifacts are written
- WORK_PLAN.md: patch checklist
- CHANGELOG.md: version notes

Tip
- When debugging behavior, start at sections/24_main_loop.py (the tick orchestrator).

"""

from __future__ import annotations

import os
import re
import json
import time
import sys
import subprocess
import math
import random
import heapq
import hashlib
import atexit
from concurrent.futures import ProcessPoolExecutor, TimeoutError as FuturesTimeoutError
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from collections import deque, Counter
from functools import lru_cache
from typing import Any, Dict, List, Optional, Tuple

import requests

try:
    from zoneinfo import ZoneInfo  # Python 3.9+
except Exception:  # pragma: no cover - optional in older runtimes
    ZoneInfo = None

# Fast env access alias
_ENV = os.environ


# -----------------------------------------------------------------------------
# RUNTIME SAFETY HELPERS (final patch hardening)
# -----------------------------------------------------------------------------
def _is_main_process() -> bool:
    """Best-effort check for multiprocessing import-side-effects."""
    try:
        import multiprocessing  # local import
        return multiprocessing.current_process().name == "MainProcess"
    except Exception:
        return True

def safe_int(x: Any, default: int = 0) -> int:
    """Best-effort int coercion (None-safe)."""
    try:
        if x is None:
            return int(default)
        if isinstance(x, bool):
            return int(x)
        if isinstance(x, int):
            return int(x)
        if isinstance(x, float):
            return int(x) if math.isfinite(x) else int(default)
        if isinstance(x, str):
            s = x.strip()
            if not s:
                return int(default)
            return int(float(s))
        return int(x)
    except Exception:
        return int(default)

def safe_float(x: Any, default: float = 0.0) -> float:
    """Best-effort float coercion (None-safe)."""
    try:
        if x is None:
            return float(default)
        if isinstance(x, bool):
            return float(int(x))
        if isinstance(x, (int, float)):
            v = float(x)
            return v if math.isfinite(v) else float(default)
        if isinstance(x, str):
            s = x.strip()
            if not s:
                return float(default)
            v = float(s)
            return v if math.isfinite(v) else float(default)
        v = float(x)
        return v if math.isfinite(v) else float(default)
    except Exception:
        return float(default)

def strip_none(obj: Any) -> Any:
    """Recursively remove None-valued keys from dicts (JSON payload safety)."""
    try:
        if isinstance(obj, dict):
            out: Dict[Any, Any] = {}
            for k, v in obj.items():
                if v is None:
                    continue
                out[k] = strip_none(v)
            return out
        if isinstance(obj, list):
            return [strip_none(v) for v in obj if v is not None]
        if isinstance(obj, tuple):
            return tuple(strip_none(v) for v in obj if v is not None)
        return obj
    except Exception:
        return obj

def _sanitize_state_inplace(s: Dict[str, Any]) -> Dict[str, Any]:
    """Coerce common numeric/timestamp fields to safe types (prevents None>int crashes)."""
    if not isinstance(s, dict):
        return {}

    # tick is sometimes used in logs and throttles
    if "tick" in s:
        s["tick"] = safe_int(s.get("tick"), 0)

    # int counters
    for k, d0 in {
        "contrib_count_today": 0,
        "learn_runs": 0,
        "total_actions": 0,
        "evaluated_count": 0,
    }.items():
        if k in s:
            s[k] = safe_int(s.get(k), d0)

    # float timestamps/rewards
    for k, d0 in {
        "last_comment_ts": 0.0,
        "last_post_ts": 0.0,
        "last_vote_ts": 0.0,
        "arena_last_action_ts": 0.0,
        "last_sync_ts": 0.0,
        "last_learn_ts": 0.0,
        "last_snapshot_ts": 0.0,
        "total_reward": 0.0,
    }.items():
        if k in s:
            s[k] = safe_float(s.get(k), d0)

    # containers expected to be list/dict (setdefault won't override existing None)
    for lk in ("seen_post_ids", "recent_text_fps", "recent_post_text_fps"):
        v = s.get(lk)
        if v is None or not isinstance(v, list):
            s[lk] = []

    for dk in ("commented_ts", "replied_ts", "voted_posts", "recent_text_hashes", "recent_post_text_hashes"):
        v = s.get(dk)
        if v is None or not isinstance(v, dict):
            s[dk] = {}

    # timestamp dict values
    for dk in ("commented_ts", "replied_ts", "recent_text_hashes", "recent_post_text_hashes"):
        d = s.get(dk)
        if isinstance(d, dict):
            for kk, vv in list(d.items()):
                d[kk] = safe_float(vv, 0.0)

    # voted_posts: {post_id: {"type":..., "ts":...}}
    vp = s.get("voted_posts")
    if isinstance(vp, dict):
        for pid, vv in list(vp.items()):
            if isinstance(vv, dict):
                vv["ts"] = safe_float(vv.get("ts"), 0.0)
            else:
                vp.pop(pid, None)

    # recent_*_fps: [[fp, ts], ...]
    for lk in ("recent_text_fps", "recent_post_text_fps"):
        arr = s.get(lk)
        if isinstance(arr, list):
            cleaned = []
            for item in arr:
                if isinstance(item, (list, tuple)) and len(item) >= 2:
                    cleaned.append([item[0], safe_float(item[1], 0.0)])
            s[lk] = cleaned

    # ops circuit breaker persisted in state
    ops = s.get("_ops")
    if isinstance(ops, dict):
        fc = ops.get("fail_counts")
        if not isinstance(fc, dict):
            ops["fail_counts"] = {}
        else:
            for k, v in list(fc.items()):
                fc[k] = safe_int(v, 0)

        du = ops.get("disabled_until")
        if not isinstance(du, dict):
            ops["disabled_until"] = {}
        else:
            for k, v in list(du.items()):
                du[k] = safe_float(v, 0.0)

        lfr = ops.get("last_fail_reason")
        if not isinstance(lfr, dict):
            ops["last_fail_reason"] = {}

    return s

# -----------------------------------------------------------------------------
# BUILD / SCHEMA STAMPS (final release hygiene)
# -----------------------------------------------------------------------------
# - AGENT_SCHEMA_VERSION: internal schema marker for on-disk artifacts (stored in __meta__)
# - AGENT_BUILD_TAG: optional human label (set MERSOOM_BUILD_TAG), defaults to "local"
# - AGENT_RELEASE_TAG: optional release label (set MERSOOM_RELEASE_TAG), defaults to "v6.1"
AGENT_SCHEMA_VERSION = 2
AGENT_BUILD_TAG = (os.getenv("MERSOOM_BUILD_TAG", "").strip() or "local")
AGENT_RELEASE_TAG = (os.getenv("MERSOOM_RELEASE_TAG", "").strip() or "v6.1")
