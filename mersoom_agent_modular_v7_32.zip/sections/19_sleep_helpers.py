################################################################################
# 19. SLEEP & BACKOFF HELPERS
# Deps: 01-02 (config/logging), 05 (limiters/pacing)
# Used by: main loop + HTTP pacing
# Notes: derive next sleep based on limiters + pacing gaps
################################################################################
"""
SECTION 19 - SLEEP HELPERS

Sleep / scheduling helpers.

Responsibilities:
- Calculate next sleep time from limits, cooldowns, and tick pacing.
- Provide jitter to avoid robotic patterns.

Debug tips:
- If agent 'does nothing', check the computed sleep and cooldown reasons.
"""
def next_sleep_from_limits(
    cfg: Config,
    state: Dict[str, Any],
    post_limiter: SlidingWindowLimiter,
    comment_limiter: SlidingWindowLimiter,
    vote_limiter: SlidingWindowLimiter,
    vote_pace_sec: int,
    comment_pace_sec: int,
    post_pace_sec: int
) -> int:
    waits: List[int] = []

    # limiter-based (capacity==0 방어는 limiter 내부에서 함)
    if vote_limiter.remaining() <= 0:
        waits.append(vote_limiter.seconds_until_next())
    if comment_limiter.remaining() <= 0:
        waits.append(comment_limiter.seconds_until_next())
    if post_limiter.remaining() <= 0:
        waits.append(post_limiter.seconds_until_next())

    # gap-based
    waits.append(gap_remaining(float(state.get("last_vote_ts", 0.0) or 0.0), int(vote_pace_sec)))
    waits.append(gap_remaining(float(state.get("last_comment_ts", 0.0) or 0.0), int(comment_pace_sec)))
    waits.append(gap_remaining(float(state.get("last_post_ts", 0.0) or 0.0), int(post_pace_sec)))

    positive = [x for x in waits if x > 0]
    base_wait = max(1, min(positive) if positive else int(cfg.timing.tick_min_sec))

    # human jitter within tick bounds
    lo = int(cfg.timing.tick_min_sec)
    hi = int(cfg.timing.tick_max_sec)
    jitter_hi = min(hi, max(lo, base_wait + hi))
    w2 = int(random.uniform(lo, jitter_hi))
    return max(1, w2)
