################################################################################
# 09. MIGRATION HELPERS
# Deps: 01-03, 08
# Used by: boot + --migrate-only
# Notes: Schema stabilization + safe backups.
################################################################################
"""
SECTION 09 - MIGRATION HELPERS

State/memory/policy schema migration utilities.

Responsibilities:
- Upgrade older state files to current expected shape.
- Keep migrations idempotent and safe (never lose data).
- Provide "migrate-only" mode support.

Debug tips:
- If boot fails after an upgrade, check migrations and backup behavior here.
"""
def _sdict(d: Dict[str, Any], key: str) -> Dict[str, Any]:
    v = d.get(key)
    if not isinstance(v, dict):
        v = {}
        d[key] = v
    return v

def _slist(d: Dict[str, Any], key: str) -> List[Any]:
    v = d.get(key)
    if not isinstance(v, list):
        v = []
        d[key] = v
    return v


# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
def _normalize_open_questions_list(items: Any) -> List[Dict[str, Any]]:
    """Normalize open_questions to the expanded dict form (backward compatible)."""
    out: List[Dict[str, Any]] = []
    if not isinstance(items, list):
        return out
    for it in items:
        try:
            if isinstance(it, dict):
                qid = str(it.get("qid") or "")
                text = str(it.get("text") or it.get("q") or "")
                try:
                    ts = float(it.get("ts", 0.0) or 0.0)
                except Exception:
                    ts = 0.0
                if not qid:
                    if text:
                        qid = hashlib.sha1(f"{ts}|{text}".encode("utf-8")).hexdigest()[:10]
                    else:
                        continue
                obj = dict(it)
                obj["qid"] = qid
                obj["text"] = one_line(text, 220) if text else ""
                obj["ts"] = ts
                st = str(obj.get("status") or "open")
                if st not in ("open", "resolved", "expired"):
                    st = "open"
                obj["status"] = st
                obj.setdefault("asked_by", str(obj.get("asked_by") or ""))
                obj.setdefault("last_seen_remote_id", str(obj.get("last_seen_remote_id") or ""))
                try:
                    obj["resolve_ts"] = float(obj.get("resolve_ts", 0.0) or 0.0)
                except Exception:
                    obj["resolve_ts"] = 0.0
                out.append(obj)
            elif isinstance(it, str):
                text = it.strip()
                if not text:
                    continue
                qid = hashlib.sha1(text.encode("utf-8")).hexdigest()[:10]
                out.append({
                    "qid": qid,
                    "text": one_line(text, 220),
                    "ts": 0.0,
                    "status": "open",
                    "asked_by": "",
                    "last_seen_remote_id": str(last_seen_remote_id or ""),
                    "resolve_ts": 0.0,
                })
        except Exception:
            continue
    return out

def _migrate_thread_schema_inplace(th: Any, post_id: str = "") -> Dict[str, Any]:
    """Ensure a thread dict contains v23.1 interaction scaffolding fields."""
    if not isinstance(th, dict):
        th = {}
    if post_id:
        th.setdefault("post_id", str(post_id))
    th.setdefault("phase", "open")
    try:
        th["phase_ts"] = float(th.get("phase_ts", 0.0) or 0.0)
    except Exception:
        th["phase_ts"] = 0.0
    th["open_questions"] = _normalize_open_questions_list(th.get("open_questions", []))
    return th

def _migrate_threads_payload_inplace(threads_payload: Any) -> Dict[str, Any]:
    """Normalize threads payload (split file or embedded) in-place."""
    if not isinstance(threads_payload, dict):
        return {}
    for pid, th in list(threads_payload.items()):
        if pid == "__meta__":
            continue
        threads_payload[pid] = _migrate_thread_schema_inplace(th, str(pid))
    return threads_payload

def _migrate_conv_state_payload_inplace(convs: Any) -> Dict[str, Any]:
    """Backfill conv_state schema fields used by future interaction patches."""
    if not isinstance(convs, dict):
        return {}
    for k, cv in list(convs.items()):
        if not isinstance(cv, dict):
            continue
        try:
            cv.setdefault("last_remote_ts", 0.0)
            cv["last_remote_ts"] = float(cv.get("last_remote_ts", 0.0) or 0.0)
        except Exception:
            cv["last_remote_ts"] = 0.0
        convs[k] = cv
    return convs

def migrate_state(s: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(s, dict):
        s = {}

    # ---- v19 protocol/rules scaffold (no behavior change yet) ----
    proto = _sdict(s, "protocol")
    proto.setdefault("enabled", _env_bool("MERSOOM_PROTOCOL_ENABLE", True))
    proto.setdefault("cycle_id", 0)
    proto.setdefault("last_tick_at", 0.0)

    # ---- v20.6 reason protocol (observability; no behavior change) ----
    _sdict(proto, "reason_last")          # domain -> last reason code
    _sdict(proto, "reason_last_ts")       # domain -> last set timestamp
    _sdict(proto, "reason_last_detail")   # domain -> last detail (one-line)
    proto.setdefault("reason_window_started_ts", 0.0)
    _sdict(proto, "reason_window_10m")    # code -> count (rolling 10m)


    # ---- v20.2 vote backlog (durable mandatory votes) ----
    # vote_backlog: list of {"post_id": str, "seen_ts": float}
    _slist(proto, "vote_backlog")
    # drain timestamps for health metrics (recent 10m window)
    _slist(proto, "vote_backlog_drains")

    # ---- v20.3 heartbeat clamp + reply streak ----
    proto.setdefault("hb_block_reason", "")
    _sdict(proto, "reply_streak")  # post_id -> {"count": int, "last_ts": float}



    # ---- v23.1 interaction scaffolding (schema only; no behavior change) ----
    proto.setdefault("interaction_fsm_enabled", False)  # env is authoritative; see _interaction_fsm_enabled()
    proto.setdefault("openq_track_enabled", True)  # env can override; default preserves prior behavior
    proto.setdefault("waiting_strict_enabled", False)  # env can override; default off
    proto.setdefault("reply_score_v2_enabled", False)  # env can override; default off
    proto.setdefault("openq_added_total", 0)
    proto.setdefault("openq_resolved_total", 0)
    proto.setdefault("openq_expired_total", 0)
    try:
        _migrate_threads_payload_inplace(_sdict(s, "threads"))
    except Exception as e:
        log_debug_exc("migrate_threads:silent", e)
        pass
    try:
        _migrate_conv_state_payload_inplace(_sdict(s, "conv_state"))
    except Exception as e:
        log_debug_exc("migrate_conv_state:silent", e)
        pass

    # ---- v23.10 recent action guard ----
    ra = s.get("recent_actions")
    if not isinstance(ra, dict):
        s["recent_actions"] = {}





    # ---- v19.3 heartbeat protocol slots ----
    hb = _sdict(proto, "heartbeat")
    hb.setdefault("active", False)
    hb.setdefault("cycle_id", 0)
    hb.setdefault("started_at", 0.0)
    hb.setdefault("completed_at", 0.0)
    hb.setdefault("last_at", 0.0)
    hb.setdefault("next_at", 0.0)
    hb.setdefault("last_log_ts", 0.0)
    quota = _sdict(hb, "quota")
    quota.setdefault("comments_target", 0)
    quota.setdefault("comments_target_clamped", False)
    quota.setdefault("comments_done", 0)
    quota.setdefault("votes_done", 0)
    quota.setdefault("contribute_done", False)
    quota.setdefault("contribute_ts", 0.0)
    rules = _sdict(s, "rules")
    rules.setdefault("last_sync_day", "")
    rules.setdefault("last_hash", "")
    rules.setdefault("last_checked_at", 0.0)

    seen = _sdict(s, "seen")
    seen_posts = _sdict(seen, "posts")  # post_id -> seen_ts
    if not seen_posts and isinstance(s.get("seen_post_ids"), list):
        for pid in (s.get("seen_post_ids") or [])[:500]:
            if isinstance(pid, str) and pid:
                seen_posts.setdefault(pid, 0.0)

    votes2 = _sdict(s, "votes")
    votes_posts = _sdict(votes2, "posts")  # post_id -> voted_ts
    if not votes_posts and isinstance(s.get("voted_posts"), dict):
        for pid, info in (s.get("voted_posts") or {}).items():
            if not isinstance(pid, str) or not pid:
                continue
            ts = 0.0
            if isinstance(info, dict):
                try:
                    ts = float(info.get("ts", 0.0) or 0.0)
                except Exception:
                    ts = 0.0
            votes_posts.setdefault(pid, ts)

    # ---- arena nested slots (seed from legacy keys if present) ----
    arena = _sdict(s, "arena")
    arena.setdefault("day", "")  # YYYY-MM-DD (KST)
    arena.setdefault("today_proposed", False)
    arena.setdefault("today_propose_id", "")

    legacy_last_action = float(s.get("arena_last_action_ts", 0.0) or 0.0)
    legacy_last_propose_date = str(s.get("arena_last_propose_date", "") or "")
    arena.setdefault("last_action_ts", legacy_last_action)
    arena.setdefault("last_propose_date", legacy_last_propose_date)

    # topic + last post
    arena.setdefault("today_topic_id", "")
    arena.setdefault("today_topic_title", "")
    arena.setdefault("last_post_id", "")
    arena.setdefault("last_post_side", "")
    arena.setdefault("last_post_created_at", "")

    # my arena posts today: {post_id: {up:int, down:int, ts:float, side:str}}
    arena.setdefault("my_posts", {})

    # status/posts caches
    arena.setdefault("last_status_ts", 0.0)
    arena.setdefault("last_posts_ts", 0.0)
    arena.setdefault("last_phase", "")
    arena.setdefault("last_status_date", "")
    arena.setdefault("last_status_topic_id", "")
    arena.setdefault("last_status_topic_title", "")
    arena.setdefault("status_cache", {})
    arena.setdefault("posts_cache", [])
    arena.setdefault("actions_today", 0)

    # latest my-post info (cooldown buff)
    arena.setdefault("last_my_post_id", "")
    arena.setdefault("last_my_post_up", 0)
    arena.setdefault("last_my_post_down", 0)
    arena.setdefault("last_my_post_ts", 0.0)
    arena.setdefault("last_my_post_side", "")
    arena.setdefault("last_effective_cooldown_sec", 0.0)
    arena.setdefault("last_cooldown_upvotes", 0)
    arena.setdefault("last_cooldown_post_id", "")

    # risk/stoploss (blind(-5) guard)
    arena.setdefault("risk_mode", False)
    arena.setdefault("risk_level", "OK")  # OK|CAUTION|DANGER|BLIND
    arena.setdefault("risk_score", 0.0)
    arena.setdefault("risk_style", "")
    arena.setdefault("risk_last_update_ts", 0.0)
    arena.setdefault("risk_source_post_id", "")
    arena.setdefault("risk_stop_day", "")

    # strategy caches
    arena.setdefault("recent_target_post_ids", [])
    arena.setdefault("last_strategy", "")

    # ---- focus (comment/reply grounding slots) ----
    focus = _sdict(s, "focus")
    focus.setdefault("mode", "")  # comment|reply
    focus.setdefault("post_id", "")
    focus.setdefault("post_title", "")
    focus.setdefault("post_excerpt", "")
    focus.setdefault("comment_id", "")
    focus.setdefault("comment_excerpt", "")
    focus.setdefault("comment_author", "")
    focus.setdefault("created_ts", 0.0)

    # ---- evaluation budget slots ----
    eb = _sdict(s, "eval_budget")
    eb.setdefault("last_reset_ts", 0.0)
    eb.setdefault("used", 0)
    eb.setdefault("cap_per_window", 0)  # 0 => unlimited
    eb.setdefault("window_sec", 900)

    # ---- ops guards (circuit breaker) ----
    ops = _sdict(s, "_ops")
    ops.setdefault("fail_counts", {})
    ops.setdefault("disabled_until", {})
    ops.setdefault("last_fail_reason", {})
    ops.setdefault("last_tick_log_ts", 0.0)

    s["schema_ver"] = AGENT_SCHEMA_VERSION
    return s



# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
def _hb_get(state: Dict[str, Any]) -> Dict[str, Any]:
    proto = _safe_dict(state.get("protocol"))
    hb = _safe_dict(proto.get("heartbeat"))
    return hb if isinstance(hb, dict) else {}

def _hb_active(state: Dict[str, Any]) -> bool:
    hb = _hb_get(state)
    return bool(hb.get("active")) if hb else False

def _hb_quota(state: Dict[str, Any]) -> Dict[str, Any]:
    hb = _hb_get(state)
    q = _safe_dict(hb.get("quota"))
    return q if isinstance(q, dict) else {}


def _hb_clamp_comment_target(cfg: "Config", state: Dict[str, Any], comment_pace_sec: int, comment_limiter: "SlidingWindowLimiter") -> None:
    """
    v20.3: Clamp per-cycle heartbeat comment quota to a feasible maximum.
    Motivation: avoid "never-completes" heartbeat cycles when pacing/limits make 2~3 comments impossible.
    Stores a coarse reason in state["protocol"]["hb_block_reason"] when clamped.
    """
    try:
        hb = _hb_get(state)
        if not hb or not bool(hb.get("active")):
            return
        q = _hb_quota(state)
        if not q:
            return
        if bool(q.get("comments_target_clamped", False)):
            return

        proto = _sdict(state, "protocol")

        # Estimate available time budget of the cycle (heartbeat cadence window).
        started_at = float(hb.get("started_at", 0.0) or 0.0)
        next_at = float(hb.get("next_at", 0.0) or 0.0)
        cycle_span = 0.0
        if started_at > 0.0 and next_at > started_at:
            cycle_span = float(next_at - started_at)
        else:
            # Fallback to a typical interval if missing.
            cycle_span = float(_hb_next_interval_sec(cfg))
        cycle_span = max(0.0, cycle_span)

        # Max by pace (cooldown between comments)
        pace = int(comment_pace_sec or 0)
        if pace <= 0:
            max_by_pace = 10**9
        else:
            # First comment can happen at start; remaining need pace gaps.
            max_by_pace = 1 + int(cycle_span // max(1, pace))

        # Max by limiter (window capacity)
        cap = int(getattr(comment_limiter, "capacity", 0) or 0)
        win = int(getattr(comment_limiter, "window_sec", 1800) or 1800)
        if cap <= 0:
            # capacity<=0 means limiter is effectively disabled/unbounded; do not constrain.
            max_by_limiter = 10**9
        else:
            win = max(1, win)
            windows = max(1, 1 + int(cycle_span // win))
            max_by_limiter = cap * windows

        possible_max = int(max(0, min(max_by_pace, max_by_limiter)))
        c_tgt = int(q.get("comments_target", 0) or 0)

        if possible_max < c_tgt:
            q["comments_target"] = int(possible_max)
            if cap <= 0:
                proto["hb_block_reason"] = "comment_limit0"
            else:
                proto["hb_block_reason"] = "cooldown"
        else:
            proto["hb_block_reason"] = ""

        q["comments_target_clamped"] = True
    except Exception as e:
        log_debug_exc("_hb_clamp_comment_target:silent", e)
        return


def _hb_maybe_complete(state: Dict[str, Any], now_ts: Optional[float] = None) -> None:
    hb = _hb_get(state)
    if not hb or not bool(hb.get("active")):
        return
    q = _hb_quota(state)
    try:
        c_tgt = int(q.get("comments_target", 0) or 0)
        c_done = int(q.get("comments_done", 0) or 0)
        contrib_done = bool(q.get("contribute_done", False))
    except Exception:
        return
    if c_tgt > 0 and c_done < c_tgt:
        return
    if not contrib_done:
        return
    if now_ts is None:
        now_ts = time.time()
    hb["active"] = False
    hb["completed_at"] = float(now_ts)
    hb["last_at"] = float(now_ts)

def _hb_record_vote(state: Dict[str, Any], ts: Optional[float] = None) -> None:
    hb = _hb_get(state)
    if not hb or not bool(hb.get("active")):
        return
    q = _hb_quota(state)
    try:
        q["votes_done"] = int(q.get("votes_done", 0) or 0) + 1
        if ts is not None:
            hb["last_at"] = float(ts)
    except Exception as e:
        log_debug_exc("_hb_record_vote:silent", e)
        pass

def _hb_record_comment(state: Dict[str, Any], ts: Optional[float] = None) -> None:
    hb = _hb_get(state)
    if not hb or not bool(hb.get("active")):
        return
    q = _hb_quota(state)
    try:
        q["comments_done"] = int(q.get("comments_done", 0) or 0) + 1
        if ts is not None:
            hb["last_at"] = float(ts)
    except Exception as e:
        log_debug_exc("_hb_record_comment:silent", e)
        pass
    _hb_maybe_complete(state, now_ts=ts)

def _hb_record_contribute(state: Dict[str, Any], ts: Optional[float] = None, kind: str = "") -> None:
    hb = _hb_get(state)
    if not hb or not bool(hb.get("active")):
        return
    q = _hb_quota(state)
    try:
        q["contribute_done"] = True
        q["contribute_ts"] = float(ts or time.time())
        hb["last_at"] = float(ts or time.time())
        if kind:
            hb["last_kind"] = str(kind)
    except Exception as e:
        log_debug_exc("_hb_record_contribute:silent", e)
        pass
    _hb_maybe_complete(state, now_ts=ts)

def migrate_brain(b: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(b, dict):
        b = {}

    # action bias (Brain → action probability hooks)
    ab = _sdict(b, "action_bias")
    ab.setdefault("by_action", {})
    ab.setdefault("by_topic_kw", {})
    ab.setdefault("by_template", {})
    ab.setdefault("by_user", {})
    ab.setdefault("by_thread", {})
    ab.setdefault("last_update_ts", 0.0)
    ab.setdefault("decay", 0.98)

    # EMA slots (optional)
    ema = _sdict(b, "ema")
    ema.setdefault("action_type", {})
    ema.setdefault("template_id", {})
    ema.setdefault("topic_kw", {})
    ema.setdefault("user_nick", {})
    ema.setdefault("hour_bin", {})

    # avoid/cooldown slots
    avoid = _sdict(b, "avoid")
    avoid.setdefault("users", {})
    avoid.setdefault("topics", {})

    # last-known best combo
    last = _sdict(b, "last")
    last.setdefault("best", {})

    b.setdefault("reflection_hashes", [])
    b.setdefault("bias_updates", {"proxy": 0, "reward": 0})
    b.setdefault("max_thoughts", 200)


    # (Unit 15) Normalize stored keywords to reduce awkward 조사-attached tokens and filter rough words.
    try:
        com = _safe_dict(b.get("community"))
        if isinstance(com, dict):
            kwm = _safe_dict(com.get("kw"))
            if kwm:
                new_kw: Dict[str, float] = {}
                for k, v in kwm.items():
                    kk = normalize_ko_token(str(k))
                    if not is_clean_keyword(kk):
                        continue
                    new_kw[kk] = float(new_kw.get(kk, 0.0)) + float(v or 0.0)
                com["kw"] = new_kw

            for key in ("hot", "rising"):
                lst = _safe_list(com.get(key))
                if not lst:
                    continue
                cleaned: List[Dict[str, Any]] = []
                for it in lst:
                    if not isinstance(it, dict):
                        continue
                    kk = normalize_ko_token(str(it.get("kw") or ""))
                    if not is_clean_keyword(kk):
                        continue
                    it2 = dict(it)
                    it2["kw"] = kk
                    cleaned.append(it2)
                if cleaned:
                    com[key] = cleaned

            b["community"] = com

        ema = _safe_dict(b.get("ema"))
        if isinstance(ema, dict):
            tk = _safe_dict(ema.get("topic_kw"))
            if tk:
                new_tk: Dict[str, float] = {}
                for k, v in tk.items():
                    kk = normalize_ko_token(str(k))
                    if not is_clean_keyword(kk):
                        continue
                    new_tk[kk] = max(float(new_tk.get(kk, 0.0)), float(v or 0.0))
                ema["topic_kw"] = new_tk
                b["ema"] = ema

        ab = _safe_dict(b.get("action_bias"))
        if isinstance(ab, dict):
            bk = _safe_dict(ab.get("by_topic_kw"))
            if bk:
                new_bk: Dict[str, float] = {}
                for k, v in bk.items():
                    kk = normalize_ko_token(str(k))
                    if not is_clean_keyword(kk):
                        continue
                    new_bk[kk] = float(v or 0.0)
                ab["by_topic_kw"] = new_bk
                b["action_bias"] = ab
    except Exception as e:
        log_debug_exc("migrate_brain:silent", e)
        pass

    b["schema_ver"] = AGENT_SCHEMA_VERSION
    return b

def load_state(path: str) -> Dict[str, Any]:
    s = load_json_file(path, default={})
    if not isinstance(s, dict):
        s = {}

    # server capability cache
    s.setdefault("post_nickname_supported", None)
    s.setdefault("comment_nickname_supported", None)
    s.setdefault("post_title_supported", None)
    s.setdefault("vote_supported", None)

    # seen and per-target throttles
    s.setdefault("seen_post_ids", [])
    s.setdefault("commented_ts", {})            # post_id -> ts
    s.setdefault("replied_ts", {})              # "post:comment" -> ts
    s.setdefault("voted_posts", {})             # post_id -> {"type":..., "ts":...}

    # repeat protection
    s.setdefault("recent_text_hashes", {})      # {hash: ts}
    s.setdefault("recent_post_text_hashes", {}) # {hash: ts}
    s.setdefault("recent_text_fps", [])         # [[fp, ts], ...]
    s.setdefault("recent_post_text_fps", [])    # [[fp, ts], ...]

    # global last-action timestamps
    s.setdefault("last_comment_ts", 0.0)
    s.setdefault("last_post_ts", 0.0)
    s.setdefault("last_vote_ts", 0.0)

    # daily counters
    s.setdefault("last_contrib_date", "")
    s.setdefault("contrib_count_today", 0)

    # arena tracking
    s.setdefault("arena_last_action_ts", 0.0)
    s.setdefault("arena_last_propose_date", "")

    # sync
    s.setdefault("last_sync_ts", 0.0)

    # learning cadence
    s.setdefault("last_learn_ts", 0.0)
    s.setdefault("learn_runs", 0)

    # snapshot cadence
    s.setdefault("last_snapshot_hour_kst", "")
    s.setdefault("last_snapshot_ts", 0.0)

    # lifetime
    s.setdefault("total_actions", 0)
    s.setdefault("total_reward", 0.0)
    s.setdefault("evaluated_count", 0)

    # expanded context
    s.setdefault("threads", {})
    s.setdefault("users", {})
    s = migrate_state(s)
    try:
        _sanitize_state_inplace(s)
    except Exception as e:
        log_debug_exc("sanitize_state:silent", e)
        pass    # Optional: override evaluation budget via env (0 => unlimited)
    eb = s.get("eval_budget")
    if isinstance(eb, dict):
        eb["cap_per_window"] = _env_int("MERSOOM_EVAL_BUDGET_CAP_PER_WINDOW", int(eb.get("cap_per_window", 0) or 0), 0, 100_000)
        eb["window_sec"] = _env_int("MERSOOM_EVAL_BUDGET_WINDOW_SEC", int(eb.get("window_sec", 900) or 900), 60, 24 * 3600)

    return s

def update_daily_counters(state: Dict[str, Any]) -> None:
    today = _today_kst()
    if state.get("last_contrib_date") != today:
        state["last_contrib_date"] = today
        state["contrib_count_today"] = 0

# (P0) state GC + simple health log
def gc_state(state: Dict[str, Any]) -> None:
    now = time.time()
    interval = _env_int("MERSOOM_GC_INTERVAL_SEC", 600, 30, 24 * 3600)
    last = float(state.get("last_gc_ts", 0.0) or 0.0)
    if (now - last) < float(interval):
        return
    state["last_gc_ts"] = now

    # prune per-post timestamps
    ts_ttl = _env_int("MERSOOM_PERPOST_TTL_DAYS", 14, 1, 365) * 86400
    for k in ["commented_ts", "replied_ts"]:
        d = _safe_dict(state.get(k))
        d2 = {}
        for kk, vv in d.items():
            try:
                if (now - float(vv or 0.0)) <= ts_ttl:
                    d2[str(kk)] = float(vv)
            except Exception:
                continue
        state[k] = d2

    # prune recent text fingerprints (19.4)
    fp_ttl = _env_int("MERSOOM_RECENT_TEXT_FP_TTL_SEC", 6 * 3600, 60, 30 * 24 * 3600)
    fp_keep = _env_int("MERSOOM_RECENT_TEXT_FP_KEEP_MAX", 1200, 50, 20000)
    for k in ["recent_text_fps", "recent_post_text_fps"]:
        lst = _safe_list(state.get(k))
        out = []
        for it in lst:
            try:
                fp, ts = it[0], float(it[1])
                if (now - ts) <= float(fp_ttl):
                    out.append([fp, ts])
            except Exception:
                continue
        state[k] = out[-int(fp_keep):]

    # prune reply tracking (Unit 05)
    seen = _safe_dict(state.get("reply_seen_ids"))
    seen_ttl = _env_int("MERSOOM_REPLY_SEEN_TTL_DAYS", 21, 1, 365) * 86400
    seen2 = {}
    for cid, ts in seen.items():
        try:
            if (now - float(ts or 0.0)) <= seen_ttl:
                seen2[str(cid)] = float(ts)
        except Exception:
            continue
    max_seen = _env_int("MERSOOM_MAX_REPLY_SEEN", 2000, 200, 200000)
    if len(seen2) > max_seen:
        items = sorted(seen2.items(), key=lambda kv: float(kv[1] or 0.0))
        seen2 = dict(items[-max_seen:])
    state["reply_seen_ids"] = seen2

    reps = _safe_dict(state.get("my_comment_replies"))
    reps_ttl = _env_int("MERSOOM_MYREPLY_TTL_DAYS", 60, 7, 365) * 86400
    reps2: Dict[str, Any] = {}
    for cid, obj in reps.items():
        o = _safe_dict(obj)
        try:
            ts = float(o.get("last_ts", 0.0) or 0.0)
            if ts and (now - ts) <= reps_ttl:
                reps2[str(cid)] = o
        except Exception:
            continue
    max_reps = _env_int("MERSOOM_MAX_MYREPLY_MAP", 1500, 200, 200000)
    if len(reps2) > max_reps:
        items = sorted(reps2.items(), key=lambda kv: float(_safe_dict(kv[1]).get("last_ts", 0.0) or 0.0))
        reps2 = dict(items[-max_reps:])
    state["my_comment_replies"] = reps2

    # prune voted posts
    vp = _safe_dict(state.get("voted_posts"))
    vp2 = {}
    for pid, obj in vp.items():
        try:
            ts = float(_safe_dict(obj).get("ts", 0.0) or 0.0)
            if (now - ts) <= ts_ttl:
                vp2[str(pid)] = obj
        except Exception:
            continue
    # keep under cap
    max_vp = _env_int("MERSOOM_MAX_VOTED_POSTS", 15000, 1000, 200000)
    if len(vp2) > max_vp:
        items = sorted(vp2.items(), key=lambda kv: float(_safe_dict(kv[1]).get("ts", 0.0) or 0.0))
        vp2 = dict(items[-max_vp:])
    state["voted_posts"] = vp2

    # prune protocol.vote_backlog (v20.2)
    try:
        vote_backlog_gc(state, now_ts=now)
    except Exception as e:
        log_debug_exc("vote_backlog_gc", e)



    # prune relations (P1 user affinity)
    rel = _safe_dict(state.get("relations"))
    rel_ttl = _env_int("MERSOOM_REL_TTL_DAYS", 180, 7, 3650) * 86400
    max_rel = _env_int("MERSOOM_MAX_RELATIONS", 6000, 50, 200000)
    rel2: Dict[str, Any] = {}
    for k, obj in rel.items():
        o = _safe_dict(obj)
        try:
            ts = float(o.get("last_ts", 0.0) or 0.0)
            if ts and (now - ts) <= rel_ttl:
                rel2[str(k)] = o
        except Exception:
            continue
    if len(rel2) > max_rel:
        items = sorted(rel2.items(), key=lambda kv: float(_safe_dict(kv[1]).get("last_ts", 0.0) or 0.0))
        rel2 = dict(items[-max_rel:])
    state["relations"] = rel2

    # prune thread/user models
    threads = _safe_dict(state.get("threads"))
    users = _safe_dict(state.get("users"))

    thread_ttl = _env_int("MERSOOM_THREAD_TTL_DAYS", 45, 1, 365) * 86400
    user_ttl = _env_int("MERSOOM_USER_TTL_DAYS", 120, 7, 3650) * 86400
    max_threads = _env_int("MERSOOM_MAX_THREADS", 1200, 50, 50000)
    max_users = _env_int("MERSOOM_MAX_USERS", 3000, 50, 200000)

    def _last_seen(obj: Dict[str, Any]) -> float:
        try:
            return float(obj.get("last_seen_ts", 0.0) or 0.0)
        except Exception:
            return 0.0

    # threads: TTL + cap
    th2: Dict[str, Any] = {}

    try:
        openq_enabled = bool(_openq_track_enabled(state))
    except Exception:
        openq_enabled = False

    seen_ttl = _env_int("MERSOOM_SEEN_COMMENT_TTL_DAYS", 14, 1, 365) * 86400
    turns_keep = max(20, _env_int("MERSOOM_THREAD_TURNS_KEEP", 80, 20, 500))
    q_keep = max(5, _env_int("MERSOOM_THREAD_Q_KEEP", 30, 5, 300))

    for pid, th in threads.items():
        if not isinstance(th, dict):
            continue
        ls = _last_seen(th)
        if ls and (now - ls) > thread_ttl:
            continue

        # open-question maintenance
        if openq_enabled:
            try:
                thread_openq_expire_old(state, th, now_ts=now)
            except Exception:
                pass

        # seen_comment_ids TTL + cap
        seen = _safe_dict(th.get("seen_comment_ids"))
        if seen:
            try:
                seen = {str(cid): float(ts) for cid, ts in seen.items() if (now - float(ts or 0.0)) <= seen_ttl}
            except Exception:
                seen = {}
            if len(seen) > 800:
                items = sorted(seen.items(), key=lambda kv: float(kv[1] or 0.0))
                seen = dict(items[-700:])
        th["seen_comment_ids"] = seen

        # cap last_k_turns, open_questions
        th["last_k_turns"] = _safe_list(th.get("last_k_turns"))[-turns_keep:]
        th["open_questions"] = _safe_list(th.get("open_questions"))[-q_keep:]

        th2[str(pid)] = th

    if len(th2) > max_threads:
        items = sorted(th2.items(), key=lambda kv: _last_seen(_safe_dict(kv[1])))
        th2 = dict(items[-max_threads:])
    state["threads"] = th2

    # users: TTL + cap
    u2: Dict[str, Any] = {}
    for nick, u in users.items():
        if not isinstance(u, dict):
            continue
        ls = _last_seen(u)
        if ls and (now - ls) > user_ttl:
            continue
        u2[str(nick)] = u
    if len(u2) > max_users:
        items = sorted(u2.items(), key=lambda kv: _last_seen(_safe_dict(kv[1])))
        u2 = dict(items[-max_users:])
    state["users"] = u2

def log_health_if_due(client: HttpClient, state: Dict[str, Any]) -> None:
    now = time.time()
    interval = _env_int("MERSOOM_HEALTH_LOG_INTERVAL_SEC", 900, 60, 24 * 3600)
    last = float(state.get("last_health_log_ts", 0.0) or 0.0)
    if (now - last) < float(interval):
        return
    state["last_health_log_ts"] = now
    try:
        snap = client.health_snapshot()
        try:
            snap["tz_name"] = str(TZ_NAME)
            snap["tz_fallback_used_10m"] = int(protocol_get_counter_10m(state, "tz_fallback_used"))
        except Exception:
            pass
        try:
            snap["dup_action_skips_10m"] = int(protocol_get_counter_10m(state, "dup_action_skip"))
            snap["recent_actions_size"] = int(len(_recent_actions_get(state)))
        except Exception:
            pass
        try:
            now2 = time.time()
            snap["pow_timeouts_10m"] = int(sum(1 for t in list(_POW_TIMEOUT_TS) if (now2 - float(t or 0.0)) <= 600.0))
            snap["pow_executor_restarts_10m"] = int(sum(1 for t in list(_POW_EXECUTOR_RESTART_TS) if (now2 - float(t or 0.0)) <= 600.0))
        except Exception:
            pass
        try:
            snap["bm25_build_ms_p95_10m"] = int(bm25_build_p95_ms(state))
            snap["bm25_docs_indexed"] = int(state.get("bm25_docs_indexed", 0) or 0)
            if str(state.get("bm25_last_build_mode", "")):
                snap["bm25_build_mode"] = str(state.get("bm25_last_build_mode"))
                if str(state.get("bm25_last_build_mode")) == "partial":
                    snap["bm25_build_note"] = "partial_rebuild_experimental"
        except Exception:
            pass
        try:
            snap["action_attempt_10m"] = int(protocol_get_counter_10m(state, "action_attempt"))
            snap["action_success_10m"] = int(protocol_get_counter_10m(state, "action_success"))
            snap["action_fail_10m"] = int(protocol_get_counter_10m(state, "action_fail"))
        except Exception:
            pass
        try:
            snap["qa_fail_bucket_10m"] = protocol_top_counters_10m(state, prefix="qa_fail_bucket:", topn=3)
        except Exception:
            pass
        try:
            now2 = time.time()
            snap["postprocess_dedupe_sentences_10m"] = int(sum(1 for t in list(_POSTPROCESS_DEDUPE_TS) if (now2 - float(t or 0.0)) <= 600.0))
        except Exception:
            pass

        try:
            proto = _safe_dict(state.get("protocol"))
            bl = _safe_list(proto.get("vote_backlog"))
            drains = _safe_list(proto.get("vote_backlog_drains"))
            drained = 0
            for t in drains:
                try:
                    if (now - float(t or 0.0)) <= 600.0:
                        drained += 1
                except Exception:
                    continue
            snap["vote_backlog_len"] = int(len(bl))
            snap["vote_backlog_drained"] = int(drained)
        except Exception as e:
            log_debug_exc("health:vote_backlog", e)


        try:
            ths = state.get("threads")
            if isinstance(ths, dict):
                tc = 0
                oq_open = 0
                oq_total = 0
                oq_threads = 0
                for pid, th in ths.items():
                    if pid == "__meta__":
                        continue
                    if not isinstance(th, dict):
                        continue
                    tc += 1
                    open_in_thread = 0
                    oq = th.get("open_questions")
                    if isinstance(oq, list):
                        for _q in oq:
                            if isinstance(_q, dict):
                                oq_total += 1
                                st = str(_q.get("status") or "open")
                                if st == "open":
                                    oq_open += 1
                                    open_in_thread += 1
                            else:
                                # legacy list item: treat as open-question
                                oq_total += 1
                                oq_open += 1
                                open_in_thread += 1
                    if open_in_thread > 0:
                        oq_threads += 1
                snap["thread_count"] = int(tc)
                snap["open_q_count"] = int(oq_open)
                snap["open_q_total"] = int(oq_total)
                snap["open_q_threads"] = int(oq_threads)
                snap["open_q_added_10m"] = int(protocol_get_counter_10m(state, "openq_add"))
                snap["open_q_resolved_10m"] = int(protocol_get_counter_10m(state, "openq_resolve"))
                snap["open_q_expired_10m"] = int(protocol_get_counter_10m(state, "openq_expire"))
                try:
                    snap["open_q_added_total"] = int(_safe_dict(state.get("protocol")).get("openq_added_total", 0) or 0)
                    snap["open_q_resolved_total"] = int(_safe_dict(state.get("protocol")).get("openq_resolved_total", 0) or 0)
                    snap["open_q_expired_total"] = int(_safe_dict(state.get("protocol")).get("openq_expired_total", 0) or 0)
                except Exception:
                    snap["open_q_added_total"] = 0
                pc = {"open": 0, "argue": 0, "clarify": 0, "close": 0}
                try:
                    for _pid, _th in _safe_dict(state.get("threads")).items():
                        if _pid == "__meta__":
                            continue
                        if not isinstance(_th, dict):
                            continue
                        ph = str(_th.get("phase") or "open")
                        if ph not in pc:
                            ph = "open"
                        pc[ph] = int(pc.get(ph, 0) or 0) + 1
                except Exception:
                    pass
                snap["thread_phase_counts"] = pc
                snap["phase_transitions_10m"] = int(protocol_get_counter_10m(state, "phase_transition"))
                try:
                    wt = 0
                    convs = state.get("conv_state")
                    if isinstance(convs, dict):
                        for _ck, _cv in convs.items():
                            if isinstance(_cv, dict) and bool(_cv.get("waiting_for_remote")):
                                wt += 1
                    snap["waiting_threads"] = int(wt)
                    snap["waiting_skips_10m"] = int(protocol_get_counter_10m(state, "waiting_skip"))
                except Exception:
                    pass



        except Exception as e:
            log_debug_exc("health:threads_openq", e)


        try:
            proto2 = _safe_dict(state.get("protocol"))
            win = _safe_dict(proto2.get("reason_window_10m"))
            started = float(proto2.get("reason_window_started_ts", 0.0) or 0.0)
            items2: List[Dict[str, Any]] = []
            for k, v in win.items():
                try:
                    items2.append({"code": str(k)[:80], "n": int(v or 0)})
                except Exception:
                    continue
            items2 = sorted(items2, key=lambda d: int(d.get("n", 0) or 0), reverse=True)
            snap["reason_top5"] = items2[:5]
            if started > 0:
                snap["reason_window_age_sec"] = int(max(0.0, now - started))
        except Exception as e:
            log_debug_exc("health:reason", e)

        try:
            cache = _safe_dict(state.get("reply_inbox_cache"))
            snap["reply_inbox_len"] = int(len(_safe_list(cache.get("items", []))))

            try:
                items = _safe_list(cache.get("items", []))
                ages: List[float] = []
                for it in items:
                    if not isinstance(it, dict):
                        continue
                    ts = float(it.get("comment_ts", 0.0) or 0.0)
                    if ts > 0:
                        ages.append(max(0.0, now - ts))
                snap["reply_queue_age_max"] = int(max(ages) if ages else 0.0)
                try:
                    if ages:
                        ages2 = sorted(ages)
                        idx95 = int(0.95 * float(len(ages2) - 1))
                        idx95 = max(0, min(len(ages2) - 1, idx95))
                        snap["reply_queue_age_p95"] = int(ages2[idx95])
                    else:
                        snap["reply_queue_age_p95"] = 0
                except Exception:
                    snap["reply_queue_age_p95"] = 0
            except Exception:
                snap["reply_queue_age_max"] = 0
                snap["reply_queue_age_p95"] = 0
            try:
                snap["reply_scored_10m"] = int(protocol_get_counter_10m(state, "reply_scored"))
            except Exception:
                snap["reply_scored_10m"] = 0

        except Exception as e:
            log_debug_exc("health:reply_inbox", e)

        try:
            hint: List[str] = []
            if int(snap.get("waiting_threads", 0) or 0) > 0:
                hint.append("wait")
            if int(snap.get("open_q_count", 0) or 0) > 0:
                hint.append("openq")
            if int(snap.get("reply_inbox_len", 0) or 0) <= 0:
                hint.append("inbox0")
            else:
                if int(snap.get("reply_queue_age_p95", 0) or 0) > 1800:
                    hint.append("queue_old")
            snap["interaction_hint"] = "|".join(hint) if hint else "ok"
        except Exception:
            pass

        try:
            ops = _safe_dict(state.get("ops"))
            du = _safe_dict(ops.get("disabled_until"))
            lfr = _safe_dict(ops.get("last_fail_reason"))
            out: List[Dict[str, Any]] = []
            for k, until in du.items():
                try:
                    sec = int(max(0.0, float(until or 0.0) - now))
                    if sec > 0:
                        out.append({
                            "key": str(k),
                            "sec": sec,
                            "last": one_line(str(lfr.get(k, "") or ""), 160),
                        })
                except Exception:
                    continue
            out = sorted(out, key=lambda d: int(d.get("sec", 0) or 0), reverse=True)
            if out:
                snap["ops_disabled"] = out
        except Exception as e:
            log_debug_exc("health:ops_disabled", e)
        if _env_bool("MERSOOM_HEALTH_V2", False):
            try:
                protocol_bump_counter(state, "health_emit", 1)
                snap["loop_tick_10m"] = int(protocol_get_counter_10m(state, "loop_tick"))
                snap["health_emit_10m"] = int(protocol_get_counter_10m(state, "health_emit"))
            except Exception as e:
                log_debug_exc("health:v2", e)



        log_info("HEALTH " + json.dumps(snap, ensure_ascii=False, sort_keys=True))
    except Exception:
        return

def boot_self_test(client: HttpClient, cfg: Config, state: Dict[str, Any]) -> None:
    """(P0) Basic connectivity + endpoint smoke test."""
    ok = True
    errs: List[str] = []
    try:
        _ = list_posts(client, limit=1)
    except Exception as e:
        ok = False
        errs.append("list_posts:" + one_line(str(e), 140))
    try:
        _ = fetch_pow_challenge(client, cfg.hybrid)
    except Exception as e:
        # not fatal if challenge not supported
        msg = str(e)
        if ("404" in msg) or ("405" in msg):
            pass
        else:
            ok = False
            errs.append("challenge:" + one_line(msg, 140))

    state["boot_self_test_ts"] = time.time()
    state["boot_self_test_ok"] = bool(ok)
    state["boot_self_test_err"] = "; ".join(errs)[:400]
    if ok:
        log_info("BOOT_SELF_TEST ok")
    else:
        log_warn("BOOT_SELF_TEST fail: " + state.get("boot_self_test_err", ""))

def load_memory(path: str, tuning: AgentTuning) -> List[Dict[str, Any]]:
    m = load_json_file(path, default=[])
    if not isinstance(m, list):
        return []
    out = [x for x in m if isinstance(x, dict)]
    maxn = max(1, int(tuning.memory_size))
    if len(out) > maxn:
        try:
            _trim_memory_smart_inplace(out, maxn, now_ts=time.time(), log_prefix="memory:load_trim")
        except Exception:
            out = out[-maxn:]
    return out



# -----------------------------------------------------------------------------
# Memory trimming helpers (v7.26)
# -----------------------------------------------------------------------------

_MEM_TRIM_WARN = {"last_ts": 0.0}


def _trim_memory_smart_inplace(
    memory: list,
    keep_max: int,
    *,
    now_ts: float | None = None,
    log_prefix: str = "memory:trim",
) -> dict:
    """Trim memory in a learning-safe way.

    Why:
    - The agent evaluates actions after a delay (eval_due_ts). If we always keep only the last N items,
      unevaluated items can be dropped before evaluation, weakening learning.

    Policy:
    - Prefer keeping items with `evaluated == False` (pending eval).
    - Fill remaining slots with most recent evaluated items.
    - If pending items alone exceed keep_max, keep the most recent pending items.

    Returns a small stats dict for observability.
    """
    try:
        keep_max = max(1, int(keep_max))
    except Exception:
        keep_max = 1

    n0 = len(memory)
    if n0 <= keep_max:
        return {"kept": n0, "dropped": 0, "pending_total": 0, "due_total": 0, "dropped_due": 0}

    if now_ts is None:
        try:
            import time as _time
            now_ts = float(_time.time())
        except Exception:
            now_ts = 0.0

    pending_total = 0
    due_total = 0
    try:
        for it in memory:
            if not isinstance(it, dict):
                continue
            if it.get("evaluated") is False:
                pending_total += 1
                try:
                    due_ts = float(it.get("eval_due_ts", 0.0) or 0.0)
                except Exception:
                    due_ts = 0.0
                if due_ts > 0 and now_ts > 0 and due_ts <= now_ts:
                    due_total += 1
    except Exception:
        # best-effort stats only
        pending_total = 0
        due_total = 0

    pending_need = min(pending_total, keep_max)
    eval_need = keep_max - pending_need

    kept_rev: list = []
    try:
        for it in reversed(memory):
            if pending_need > 0 and isinstance(it, dict) and it.get("evaluated") is False:
                kept_rev.append(it)
                pending_need -= 1
                continue
            if eval_need > 0:
                kept_rev.append(it)
                eval_need -= 1
                continue
            if pending_need <= 0 and eval_need <= 0:
                break
    except Exception:
        # safe fallback: tail-slice
        kept_rev = list(reversed(memory[-keep_max:]))

    kept_rev.reverse()  # restore chronological order

    # due after trim
    due_after = 0
    try:
        for it in kept_rev:
            if not isinstance(it, dict):
                continue
            if it.get("evaluated") is False:
                try:
                    due_ts = float(it.get("eval_due_ts", 0.0) or 0.0)
                except Exception:
                    due_ts = 0.0
                if due_ts > 0 and now_ts > 0 and due_ts <= now_ts:
                    due_after += 1
    except Exception:
        due_after = 0

    dropped_due = max(0, int(due_total) - int(due_after))

    # apply
    try:
        memory[:] = kept_rev
    except Exception:
        # if in-place fails, do nothing (should not happen)
        pass

    st = {
        "kept": int(len(kept_rev)),
        "dropped": int(max(0, n0 - len(kept_rev))),
        "pending_total": int(pending_total),
        "due_total": int(due_total),
        "dropped_due": int(dropped_due),
    }

    # trace + throttled warning when due items were dropped
    if dropped_due > 0:
        try:
            trace_hit("memory:trim:drop_due", int(dropped_due))
        except Exception:
            pass
        try:
            import time as _time
            last_ts = float(_MEM_TRIM_WARN.get("last_ts", 0.0) or 0.0)
            if _time.time() - last_ts >= 300.0:
                _MEM_TRIM_WARN["last_ts"] = _time.time()
                log_warn(f"{log_prefix}: dropped_due={dropped_due} keep_max={keep_max} pending_total={pending_total}")
        except Exception:
            pass

    return st
def record_memory(
    memory: List[Dict[str, Any]],
    item: Dict[str, Any],
    tuning: AgentTuning,
    archive_path_jsonl: str,
) -> None:
    memory.append(item)
    maxn = max(1, int(tuning.memory_size))
    if len(memory) > maxn:
        try:
            _trim_memory_smart_inplace(memory, maxn, now_ts=time.time(), log_prefix="memory:record_trim")
        except Exception:
            del memory[:-maxn]

    # archive (optional)
    if archive_path_jsonl:
        append_jsonl(archive_path_jsonl, item)

def load_semantic(path: str) -> Dict[str, Any]:
    s = load_json_file(path, default={})
    if not isinstance(s, dict):
        s = {}
    s.setdefault("version", 3)
    s.setdefault("by_day", {})
    return s

def bump_semantic(semantic: Dict[str, Any], day: str, key: str, val: float = 1.0) -> None:
    semantic.setdefault("by_day", {})
    semantic["by_day"].setdefault(day, {})
    semantic["by_day"][day][key] = float(semantic["by_day"][day].get(key, 0.0)) + float(val)


def _vote_proto_limits(cfg: Optional[Config]) -> Tuple[int, int]:
    """Return (seen_post_limit, voted_post_limit) with safe fallbacks."""
    try:
        vp = getattr(cfg, "vote_proto", None) if cfg is not None else None
        if vp is not None:
            return int(getattr(vp, "seen_post_limit", 500)), int(getattr(vp, "voted_post_limit", 5000))
    except Exception as e:
        log_debug_exc("_vote_proto_limits:silent", e)
        pass
    # fallback to env (keeps file runnable even if Config changes)
    return int(_env_int("MERSOOM_SEEN_POST_LIMIT", 500, min_v=50, max_v=50000)), int(_env_int("MERSOOM_VOTED_POST_LIMIT", 5000, min_v=200, max_v=200000))

def _lru_prune_map(d: Dict[str, Any], limit: int) -> None:
    if limit <= 0:
        return
    if not isinstance(d, dict):
        return
    if len(d) <= limit:
        return
    try:
        items = []
        for k, v in d.items():
            try:
                ts = float(v or 0.0)
            except Exception:
                ts = 0.0
            items.append((ts, k))
        items.sort(key=lambda x: x[0])
        for _, k in items[: max(0, len(items) - limit)]:
            try:
                d.pop(k, None)
            except Exception as e:
                log_debug_exc("_lru_prune_map:silent", e)
                pass
    except Exception:
        # best-effort; never crash the agent on pruning
        return


# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------

def _vote_backlog_limits() -> Tuple[int, int]:
    """Return (max_items, ttl_sec) for protocol.vote_backlog with safe fallbacks.

    NOTE (v20.10_final): historically the backlog cap env key drifted between
    MERSOOM_VOTE_BACKLOG_MAX and MERSOOM_VOTE_BACKLOG_KEEP_MAX. We accept BOTH.
    If both are set, we use the smaller value as the effective cap.
    """
    raw_max = os.getenv("MERSOOM_VOTE_BACKLOG_MAX")
    raw_keep = os.getenv("MERSOOM_VOTE_BACKLOG_KEEP_MAX")

    if raw_max is None and raw_keep is not None:
        # legacy alias
        max_items = _env_int("MERSOOM_VOTE_BACKLOG_KEEP_MAX", 300, 1, 100000)
    else:
        max_items = _env_int("MERSOOM_VOTE_BACKLOG_MAX", 300, 1, 100000)

    # If both provided, keep <= max for safety
    if raw_max is not None and raw_keep is not None:
        try:
            mx = _env_int("MERSOOM_VOTE_BACKLOG_MAX", int(max_items), 1, 100000)
            kp = _env_int("MERSOOM_VOTE_BACKLOG_KEEP_MAX", int(mx), 1, 100000)
            max_items = int(min(mx, kp))
        except Exception:
            pass

    ttl_sec = _env_int("MERSOOM_VOTE_BACKLOG_TTL_SEC", 48 * 3600, 60, 30 * 24 * 3600)
    return int(max_items), int(ttl_sec)

def _vote_backlog_list(state: Dict[str, Any]) -> List[Dict[str, Any]]:
    proto = state.setdefault("protocol", {})
    if not isinstance(proto, dict):
        state["protocol"] = {}
        proto = state["protocol"]
    bl = proto.get("vote_backlog")
    if not isinstance(bl, list):
        bl = []
        proto["vote_backlog"] = bl
    # keep as list of dicts (sanitized in vote_backlog_gc)
    return bl  # type: ignore[return-value]

def _vote_backlog_drains_list(state: Dict[str, Any]) -> List[float]:
    proto = state.setdefault("protocol", {})
    if not isinstance(proto, dict):
        state["protocol"] = {}
        proto = state["protocol"]
    d = proto.get("vote_backlog_drains")
    if not isinstance(d, list):
        d = []
        proto["vote_backlog_drains"] = d
    return d  # type: ignore[return-value]

def vote_backlog_record_drain(state: Dict[str, Any], ts: float) -> None:
    drains = _vote_backlog_drains_list(state)
    try:
        drains.append(float(ts))
    except Exception:
        return
    keep = _env_int("MERSOOM_VOTE_BACKLOG_DRAIN_KEEP_MAX", 2000, 50, 20000)
    if len(drains) > int(keep):
        del drains[:-int(keep)]
    # ensure persisted
    proto = state.get("protocol")
    if isinstance(proto, dict):
        proto["vote_backlog_drains"] = drains

def vote_backlog_enqueue(state: Dict[str, Any], post_id: str, seen_ts: float) -> bool:
    pid = str(post_id or "")
    if not pid:
        return False
    bl = _vote_backlog_list(state)
    for it in bl:
        if isinstance(it, dict) and str(it.get("post_id") or "") == pid:
            return False
    bl.append({"post_id": pid, "seen_ts": float(seen_ts)})
    # (v5.6 P1) Cap on enqueue to prevent unbounded growth (even when GC path is skipped).
    try:
        max_items, _ttl = _vote_backlog_limits()
        mx = int(max(1, int(max_items)))
        if len(bl) > mx:
            overflow = int(len(bl) - mx)
            if overflow > 0:
                del bl[:overflow]
    except Exception:
        pass
    proto = state.get("protocol")
    if isinstance(proto, dict):
        proto["vote_backlog"] = bl
    return True

def vote_backlog_remove(state: Dict[str, Any], post_id: str) -> bool:
    pid = str(post_id or "")
    if not pid:
        return False
    bl = _vote_backlog_list(state)
    removed = False
    out: List[Dict[str, Any]] = []
    for it in bl:
        if isinstance(it, dict) and str(it.get("post_id") or "") == pid and not removed:
            removed = True
            continue
        if isinstance(it, dict):
            out.append(it)
    if removed:
        proto = state.get("protocol")
        if isinstance(proto, dict):
            proto["vote_backlog"] = out
    return removed

def vote_backlog_gc(state: Dict[str, Any], now_ts: Optional[float] = None) -> None:
    """GC protocol.vote_backlog: TTL, cap, de-dup, and remove already-voted posts."""
    now = time.time() if now_ts is None else float(now_ts)
    max_items, ttl_sec = _vote_backlog_limits()

    proto = state.setdefault("protocol", {})
    if not isinstance(proto, dict):
        state["protocol"] = {}
        proto = state["protocol"]

    bl_raw = proto.get("vote_backlog")
    bl = bl_raw if isinstance(bl_raw, list) else []
    seen: set = set()
    out: List[Dict[str, Any]] = []
    for it in bl:
        if not isinstance(it, dict):
            continue
        pid = str(it.get("post_id") or "")
        if not pid or pid in seen:
            continue
        seen.add(pid)
        try:
            sts = float(it.get("seen_ts", 0.0) or 0.0)
        except Exception:
            sts = 0.0

        # TTL
        if sts and ttl_sec > 0 and (now - sts) > float(ttl_sec):
            continue

        # already voted -> remove
        try:
            if _is_post_voted(state, pid):
                vote_backlog_record_drain(state, now)
                continue
        except Exception:
            pass

        out.append({"post_id": pid, "seen_ts": float(sts)})

    # sort by seen_ts asc (oldest first)
    out.sort(key=lambda x: float(x.get("seen_ts", 0.0) or 0.0))

    # cap: drop oldest first
    if max_items > 0 and len(out) > int(max_items):
        out = out[-int(max_items):]

    proto["vote_backlog"] = out

    # drains history gc
    drains = _vote_backlog_drains_list(state)
    hist_ttl = _env_int("MERSOOM_VOTE_BACKLOG_DRAIN_TTL_SEC", 3600, 60, 7 * 24 * 3600)
    keep = _env_int("MERSOOM_VOTE_BACKLOG_DRAIN_KEEP_MAX", 2000, 50, 20000)
    d2: List[float] = []
    for t in drains:
        try:
            ft = float(t)
        except Exception:
            continue
        if hist_ttl > 0 and (now - ft) > float(hist_ttl):
            continue
        d2.append(ft)
    if len(d2) > int(keep):
        d2 = d2[-int(keep):]
    proto["vote_backlog_drains"] = d2

def vote_backlog_pick(state: Dict[str, Any]) -> Optional[str]:
    """Return the oldest backlog post_id (after GC) without removing it."""
    bl = _vote_backlog_list(state)
    if not bl:
        return None
    it0 = bl[0] if isinstance(bl[0], dict) else None
    pid = str(it0.get("post_id") or "") if isinstance(it0, dict) else ""
    return pid or None


def _seen_posts_map(state: Dict[str, Any]) -> Dict[str, Any]:
    seen = state.setdefault("seen", {})
    if not isinstance(seen, dict):
        state["seen"] = {}
        seen = state["seen"]
    posts = seen.setdefault("posts", {})
    if not isinstance(posts, dict):
        seen["posts"] = {}
        posts = seen["posts"]
    return posts

def _voted_posts_map(state: Dict[str, Any]) -> Dict[str, Any]:
    votes = state.setdefault("votes", {})
    if not isinstance(votes, dict):
        state["votes"] = {}
        votes = state["votes"]
    posts = votes.setdefault("posts", {})
    if not isinstance(posts, dict):
        votes["posts"] = {}
        posts = votes["posts"]
    return posts

def _legacy_voted_posts_map(state: Dict[str, Any]) -> Dict[str, Any]:
    vp = state.get("voted_posts")
    if not isinstance(vp, dict):
        state["voted_posts"] = {}
        vp = state["voted_posts"]
    return vp

def _is_post_voted(state: Dict[str, Any], post_id: str) -> bool:
    pid = str(post_id or "")
    if not pid:
        return False
    try:
        if pid in _voted_posts_map(state):
            return True
    except Exception as e:
        log_debug_exc("_is_post_voted:silent", e)
        pass
    try:
        if pid in _legacy_voted_posts_map(state):
            return True
    except Exception as e:
        log_debug_exc("_is_post_voted:silent", e)
        pass
    return False

def _record_seen_post(cfg: Optional[Config], state: Dict[str, Any], post_id: str, ts: float) -> None:
    pid = str(post_id or "")
    if not pid:
        return
    m = _seen_posts_map(state)
    m[pid] = float(ts)
    seen_limit, _ = _vote_proto_limits(cfg)
    _lru_prune_map(m, seen_limit)

def _record_voted_post(cfg: Optional[Config], state: Dict[str, Any], post_id: str, vtype: str, ts: float) -> None:
    pid = str(post_id or "")
    if not pid:
        return
    # nested map
    vm = _voted_posts_map(state)
    vm[pid] = float(ts)
    # legacy map (kept for backward compatibility)
    legacy = _legacy_voted_posts_map(state)
    legacy[pid] = {"type": str(vtype or ""), "ts": float(ts)}
    # prune both
    _, voted_limit = _vote_proto_limits(cfg)
    _lru_prune_map(vm, voted_limit)
    if voted_limit > 0 and isinstance(legacy, dict) and len(legacy) > voted_limit:
        try:
            items = []
            for k, info in legacy.items():
                t = 0.0
                if isinstance(info, dict):
                    try:
                        t = float(info.get("ts", 0.0) or 0.0)
                    except Exception:
                        t = 0.0
                items.append((t, k))
            items.sort(key=lambda x: x[0])
            for _, k in items[: max(0, len(items) - voted_limit)]:
                legacy.pop(k, None)
        except Exception as e:
            log_debug_exc("_record_voted_post:silent", e)
            pass


def load_brain(path: str) -> Dict[str, Any]:
    b = load_json_file(path, default={})
    if not isinstance(b, dict):
        b = {}
    b.setdefault("version", 3)
    b.setdefault("last_memory_ts", 0.0)
    b.setdefault("mood", {"ema_reward": 0.0, "valence": 0.0, "arousal": 0.0})
    b.setdefault("topic_ema", {})
    b.setdefault("beliefs", {})
    b.setdefault("thoughts", [])
    b.setdefault("thought_seq", 0)
    b.setdefault("community", {"kw": {}, "by_cat": {}, "last_ts": 0.0, "hot": [], "rising": [], "last_delta": {}})
    b.setdefault("persona", {
        "stance_axes": {
            "skepticism": 0.5,
            "cooperation": 0.6,
            "verbosity": 0.4,
            "conflict": 0.3,
        },
        # 핵심 드라이브(성향): "철학의 극" + "네임드 지향" + "대댓글 논쟁 선호" + "점진적 적응"
        "drives": {
            "philosophy": 0.82,
            "fame": 0.75,
            "debate": 0.80,
            "adaptation": 0.78,
        },
        # 경험치 기반 성숙도(초기엔 템플릿 의존, 점점 자율적으로 변형/학습)
        "maturity": {"level": 0.0, "xp": 0, "last_ts": 0.0},
        "goals": {
            "be_named": True,
            "seek_philosophy_extremes": True,
            "enjoy_debate_on_own_posts": True,
        },
        "taboos": [],
        "signature": "eum",
    })

    # normalize persona (backward compatible)
    per = b.get("persona")
    if not isinstance(per, dict):
        per = {}
        b["persona"] = per
    per.setdefault("stance_axes", {
        "skepticism": 0.5,
        "cooperation": 0.6,
        "verbosity": 0.4,
        "conflict": 0.3,
    })
    per.setdefault("drives", {"philosophy": 0.82, "fame": 0.75, "debate": 0.80, "adaptation": 0.78})
    per.setdefault("maturity", {"level": 0.0, "xp": 0, "last_ts": 0.0})
    per.setdefault("goals", {"be_named": True, "seek_philosophy_extremes": True, "enjoy_debate_on_own_posts": True})
    per.setdefault("taboos", [])
    per.setdefault("signature", "eum")
    b = migrate_brain(b)
    return b

def write_journal(journal_path: str, summary: str) -> None:
    ts = now_kst_str()
    append_text_file(journal_path, f"[{ts}] {summary}\n")

################################################################################
