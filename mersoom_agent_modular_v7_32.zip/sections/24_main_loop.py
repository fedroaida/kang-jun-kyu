################################################################################
# 24. MAIN LOOP (ENTRYPOINT)
# Deps: 01-23
# Used by: __main__
# Notes: main() + tick loop + wiring.
################################################################################

"""
SECTION 24 - MAIN LOOP (ENTRYPOINT)

Boots the agent, runs the tick loop, and wires all subsystems together.

Responsibilities:
- Load config + state + policy + indices.
- Run tick: select target -> generate -> gate -> call API -> record -> sleep.
- Handle special modes: --selftest, --migrate-only, --qa-batch.

Notes:
- This section is the "integration surface"; keep it readable and well-logged.
"""
def _kst_day_str(ts: Optional[float] = None) -> str:
    dt = datetime.fromtimestamp(ts if ts is not None else time.time(), tz=KST)
    return dt.strftime("%Y-%m-%d")


def rules_sync_if_due(cfg: Config, state: Dict[str, Any], client: "HttpClient") -> None:
    """v19.1: Fetch skills.md once per KST day and record hash/metadata in state.
    - Never raises.
    - Uses conditional headers (ETag/Last-Modified) when available.
    """
    try:
        rs = getattr(cfg, "rules_sync", None)
        if not rs or not bool(getattr(rs, "daily", True)):
            return
        # Allow protocol master switch to disable this whole feature quickly
        if not bool(getattr(getattr(cfg, "protocol", None), "enabled", True)):
            return

        url = str(getattr(rs, "url", "") or "").strip() or "https://mersoom.com/docs/skills.md"
        rules = _sdict(state, "rules")
        today = _kst_day_str()

        if str(rules.get("last_sync_day", "")).strip() == today:
            return

        headers: Dict[str, str] = {}
        etag = str(rules.get("etag", "") or "").strip()
        last_mod = str(rules.get("last_modified", "") or "").strip()
        if etag:
            headers["If-None-Match"] = etag
        if last_mod:
            headers["If-Modified-Since"] = last_mod

        # Reuse the main session (timeouts from cfg.http)
        timeout = (float(cfg.http.timeout_connect_sec), float(cfg.http.timeout_read_sec))
        t0 = time.time()
        resp = client.session.get(url, headers=headers, timeout=timeout)
        dt_ms = int((time.time() - t0) * 1000)

        rules["last_checked_at"] = float(time.time())
        rules["last_status"] = int(resp.status_code)
        rules["last_url"] = url
        rules["last_latency_ms"] = dt_ms

        if resp.status_code == 304:
            rules["last_sync_day"] = today
            log_event("rules_sync_not_modified", day=today, ms=dt_ms, status=304, url=url)
            return

        if resp.status_code >= 400:
            # Don't mark sync day on failure; try again later
            log_event("rules_sync_fail", day=today, ms=dt_ms, status=int(resp.status_code), url=url)
            return

        body = resp.text if isinstance(resp.text, str) else (resp.content or b"").decode("utf-8", "replace")
        body_bytes = body.encode("utf-8", "replace")
        h = hashlib.sha256(body_bytes).hexdigest()

        prev = str(rules.get("last_hash", "") or "").strip()
        rules["last_hash"] = h
        rules["last_sync_day"] = today

        new_etag = str(resp.headers.get("ETag", "") or "").strip()
        new_lm = str(resp.headers.get("Last-Modified", "") or "").strip()
        if new_etag:
            rules["etag"] = new_etag
        if new_lm:
            rules["last_modified"] = new_lm

        if prev and prev != h:
            log_event("rules_sync_changed", day=today, ms=dt_ms, hash=str(h[:10]), prev_hash=str(prev[:10] if prev else ""))
        else:
            log_event("rules_sync_ok", day=today, ms=dt_ms, hash=str(h[:10]))
    except Exception as e:
        try:
            rules = _sdict(state, "rules")
            rules["last_checked_at"] = float(time.time())
            rules["last_error"] = repr(e)[:300]
        except Exception as e:
            log_debug_exc("rules_sync_if_due:silent", e)
            pass
        log_event("rules_sync_fail", day=today if "today" in locals() else "", error=one_line(repr(e), 220))
        log_warn(f"rules_sync_fail: {one_line(repr(e), 220)}")
        return



def _hb_kst_str(ts: float) -> str:
    try:
        return datetime.fromtimestamp(float(ts), KST).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return "?"

def _hb_next_interval_sec(cfg: Config) -> float:
    try:
        hb = getattr(cfg, "heartbeat", None)
        if not hb or not getattr(hb, "enabled", False):
            return 0.0
        mn = float(getattr(hb, "min_hours", 4.0) or 4.0)
        mx = float(getattr(hb, "max_hours", 5.0) or 5.0)
        if mx < mn:
            mx = mn
        hours = random.uniform(mn, mx)
        return float(hours) * 3600.0
    except Exception:
        return 4.5 * 3600.0

def _heartbeat_tick(cfg: Config, state: Dict[str, Any]) -> None:
    """Start/refresh heartbeat cycles and set per-cycle quotas.

    This is state-only scheduling; action enforcement lives in do_contribution().
    """
    try:
        if not bool(getattr(cfg, "protocol", None) and cfg.protocol.enabled):
            return
        hb_cfg = getattr(cfg, "heartbeat", None)
        if not hb_cfg or not bool(getattr(hb_cfg, "enabled", False)):
            return

        proto = _sdict(state, "protocol")
        hb = _sdict(proto, "heartbeat")
        q = _sdict(hb, "quota")

        now_ts = time.time()
        hb.setdefault("active", False)
        hb.setdefault("cycle_id", int(proto.get("cycle_id", 0) or 0))
        hb.setdefault("started_at", 0.0)
        hb.setdefault("completed_at", 0.0)
        hb.setdefault("last_at", 0.0)
        hb.setdefault("next_at", 0.0)
        hb.setdefault("last_log_ts", 0.0)

        q.setdefault("comments_target", 0)
        q.setdefault("comments_target_clamped", False)
        q.setdefault("comments_done", 0)
        q.setdefault("votes_done", 0)
        q.setdefault("contribute_done", False)
        q.setdefault("contribute_ts", 0.0)

        next_at = float(hb.get("next_at", 0.0) or 0.0)
        if next_at <= 0.0:
            hb["next_at"] = now_ts + _hb_next_interval_sec(cfg)
            hb["active"] = False
            hb["last_at"] = float(hb.get("last_at", 0.0) or 0.0)
            return

        # If current cycle already satisfied, mark completed (idempotent)
        if bool(hb.get("active")):
            _hb_maybe_complete(state, now_ts=now_ts)

        # Start a new cycle if due and not currently active
        if (not bool(hb.get("active"))) and now_ts >= float(hb.get("next_at", 0.0) or 0.0):
            proto["cycle_id"] = int(proto.get("cycle_id", 0) or 0) + 1
            hb["cycle_id"] = int(proto.get("cycle_id", 0) or 0)

            hb["active"] = True
            hb["started_at"] = now_ts
            hb["completed_at"] = 0.0
            hb["last_at"] = now_ts

            # quotas
            cmin = int(getattr(hb_cfg, "comment_min", 2) or 0)
            cmax = int(getattr(hb_cfg, "comment_max", 3) or 0)
            if cmax < cmin:
                cmax = cmin
            q["comments_target"] = int(random.randint(cmin, cmax)) if (cmax > 0) else 0
            q["comments_target_clamped"] = False
            proto["hb_block_reason"] = ""
            q["comments_done"] = 0
            q["votes_done"] = 0
            q["contribute_done"] = False
            q["contribute_ts"] = 0.0

            # schedule next
            hb["next_at"] = now_ts + _hb_next_interval_sec(cfg)

            # credit an arena/post that happened just before the cycle boundary (within 10 minutes)
            recent = 600.0
            last_post_ts = float(state.get("last_post_ts", 0.0) or 0.0)
            last_arena_ts = float(state.get("arena_last_action_ts", 0.0) or 0.0)
            if (last_post_ts > 0 and (now_ts - last_post_ts) <= recent) or (last_arena_ts > 0 and (now_ts - last_arena_ts) <= recent):
                _hb_record_contribute(state, max(last_post_ts, last_arena_ts), kind="recent")

            try:
                log_info(
                    f"HB start cycle={hb.get('cycle_id')} target_comments={q.get('comments_target')} "
                    f"next_at={_hb_kst_str(float(hb.get('next_at') or 0.0))}"
                )
            except Exception as e:
                log_debug_exc("_heartbeat_tick:silent", e)
                pass

    except Exception:
        return

# -----------------------------------------------------------------------------
# - Standardized "why" codes for vote/comment/arena decisions
# - Rolling 10-minute counter for health summaries (future wiring)
# -----------------------------------------------------------------------------
def _protocol_reason_reset_if_needed(proto: Dict[str, Any], now_ts: float) -> None:
    """Reset 10-minute reason window if expired or uninitialized."""
    try:
        started = float(proto.get("reason_window_started_ts", 0.0) or 0.0)
        if started <= 0.0 or (now_ts - started) >= 600.0:
            proto["reason_window_started_ts"] = float(now_ts)
            proto["reason_window_10m"] = {}
    except Exception:
        proto["reason_window_started_ts"] = float(now_ts)
        proto["reason_window_10m"] = {}

def protocol_bump_reason(state: Dict[str, Any], code: str, inc: int = 1) -> None:
    """Increment the rolling 10-minute reason counter (best-effort, never raises)."""
    try:
        proto = _sdict(state, "protocol")
        now_ts = float(time.time())
        _protocol_reason_reset_if_needed(proto, now_ts)

        win = proto.get("reason_window_10m")
        if not isinstance(win, dict):
            win = {}
            proto["reason_window_10m"] = win

        k = str(code or "unknown")
        win[k] = int(win.get(k, 0) or 0) + int(inc or 1)
    except Exception:
        return

def protocol_set_reason(state: Dict[str, Any], domain: str, code: str, detail: str = "") -> None:
    """Set last reason for a domain and bump the 10-minute window counter."""
    try:
        proto = _sdict(state, "protocol")
        now_ts = float(time.time())

        last = proto.get("reason_last")
        if not isinstance(last, dict):
            last = {}
            proto["reason_last"] = last
        last_ts = proto.get("reason_last_ts")
        if not isinstance(last_ts, dict):
            last_ts = {}
            proto["reason_last_ts"] = last_ts
        last_detail = proto.get("reason_last_detail")
        if not isinstance(last_detail, dict):
            last_detail = {}
            proto["reason_last_detail"] = last_detail

        d = str(domain or "misc")
        c = str(code or "unknown")
        det = one_line(detail, 220) if detail else ""

        # (v5.6 P1) Avoid overwriting a specific reason with a generic ':error' reason.
        try:
            prev = str(last.get(d) or "")
            generic = bool(c.endswith(":error") or (c == "error"))
            if generic and prev and prev not in ("unknown", "-", "misc:unknown") and (not prev.endswith(":error")):
                protocol_bump_reason(state, c, 1)
                return
        except Exception:
            pass

        last[d] = c
        last_ts[d] = now_ts
        if det:
            last_detail[d] = det
        else:
            last_detail.setdefault(d, "")

        protocol_bump_reason(state, c, 1)
    except Exception:
        return

def protocol_get_reason(state: Dict[str, Any], domain: str) -> str:
    """Get last reason code for a domain (returns 'unknown' if missing)."""
    try:
        proto = _safe_dict(state.get("protocol"))
        last = _safe_dict(proto.get("reason_last"))
        code = str(last.get(str(domain or "")) or "").strip()
        return code if code else "unknown"
    except Exception:
        return "unknown"

def protocol_get_reason_detail(state: Dict[str, Any], domain: str) -> str:
    """Get last reason detail for a domain (best-effort)."""
    try:
        proto = _safe_dict(state.get("protocol"))
        det = _safe_dict(proto.get("reason_last_detail"))
        return str(det.get(str(domain or "")) or "")
    except Exception:
        return ""




def _protocol_counter_reset_if_needed(proto: Dict[str, Any], now_ts: float) -> None:
    """Reset rolling 10-minute counters if the window is stale (best-effort, never raises)."""
    try:
        started = float(proto.get("counter_window_started_ts", 0.0) or 0.0)
        if started <= 0.0 or (now_ts - started) >= 600.0:
            proto["counter_window_started_ts"] = float(now_ts)
            proto["counter_window_10m"] = {}
    except Exception:
        proto["counter_window_started_ts"] = float(now_ts)
        proto["counter_window_10m"] = {}


def protocol_bump_counter(state: Dict[str, Any], key: str, inc: int = 1) -> None:
    """Increment a generic rolling 10-minute counter (best-effort, never raises)."""
    try:
        proto = _sdict(state, "protocol")
        now_ts = float(time.time())
        _protocol_counter_reset_if_needed(proto, now_ts)

        win = proto.get("counter_window_10m")
        if not isinstance(win, dict):
            win = {}
            proto["counter_window_10m"] = win

        k = str(key or "unknown")[:80]
        win[k] = int(win.get(k, 0) or 0) + int(inc or 1)
    except Exception:
        return


def protocol_get_counter_10m(state: Dict[str, Any], key: str) -> int:
    """Read a generic rolling 10-minute counter value (best-effort).

    Resets stale windows on read so HEALTH reflects *recent* activity even if no bumps occurred.
    """
    try:
        proto = _sdict(state, "protocol")
        now_ts = float(time.time())
        _protocol_counter_reset_if_needed(proto, now_ts)
        win = _safe_dict(proto.get("counter_window_10m"))
        return int(win.get(str(key or "")[:80], 0) or 0)
    except Exception:
        return 0


def protocol_top_counters_10m(state: Dict[str, Any], prefix: str = "", topn: int = 5) -> List[Dict[str, Any]]:
    """Return top counters (optionally by prefix) for debugging/health (best-effort)."""
    try:
        proto = _sdict(state, "protocol")
        now_ts = float(time.time())
        _protocol_counter_reset_if_needed(proto, now_ts)
        win = _safe_dict(proto.get("counter_window_10m"))
        out: List[Dict[str, Any]] = []
        pfx = str(prefix or "")
        for k, v in win.items():
            try:
                ks = str(k)
                if pfx and (not ks.startswith(pfx)):
                    continue
                out.append({"k": ks[:80], "n": int(v or 0)})
            except Exception:
                continue
        out = sorted(out, key=lambda d: int(d.get("n", 0) or 0), reverse=True)
        return out[: max(1, int(topn or 5))]
    except Exception:
        return []

def record_bm25_build(state: Dict[str, Any], *, build_ms: float, docs_indexed: int, mode: str, corpus_size: int, added_since: int) -> None:
    try:
        now_ts = time.time()
        rec = _safe_list(state.get("bm25_build_ms_recent"))
        rec = [it for it in rec if isinstance(it, list) and len(it) >= 2 and (now_ts - float(it[1] or 0.0)) <= 600.0]
        rec.append([float(build_ms), now_ts])
        state["bm25_build_ms_recent"] = rec[-200:]
        state["bm25_last_build_ms"] = float(build_ms)
        state["bm25_docs_indexed"] = int(docs_indexed)
        state["bm25_last_build_mode"] = str(mode or "full")
        state["bm25_last_build_corpus"] = int(corpus_size)
        state["bm25_last_build_added"] = int(added_since)
    except Exception:
        return

def bm25_build_p95_ms(state: Dict[str, Any]) -> int:
    try:
        rec = [float(it[0]) for it in _safe_list(state.get("bm25_build_ms_recent")) if isinstance(it, list) and len(it) >= 1]
        if not rec:
            return 0
        rec = sorted(rec)
        idx95 = int(0.95 * float(len(rec) - 1))
        idx95 = max(0, min(len(rec) - 1, idx95))
        return int(rec[idx95])
    except Exception:
        return 0

def protocol_tick(cfg: Config, state: Dict[str, Any], client: "HttpClient") -> None:
    """Update protocol bookkeeping (no-op behaviorally in v19.0).

    v19.x will implement:
      - Daily rules sync (skills.md) [implemented in v19.1]
      - Mandatory voting for seen posts
      - 4~5h heartbeat quota (votes/comments/contribute)
    """
    try:
        proto = _sdict(state, "protocol")
        rules_sync_if_due(cfg, state, client)
        # cfg.protocol is the source of truth (env-backed), but keep state flag for visibility
        enabled = True
        try:
            enabled = bool(getattr(getattr(cfg, "protocol", None), "enabled", True))
        except Exception:
            enabled = bool(_env_bool("MERSOOM_PROTOCOL_ENABLE", True))
        proto["enabled"] = enabled
        proto.setdefault("cycle_id", 0)
        proto["last_tick_at"] = float(time.time())
        _heartbeat_tick(cfg, state)
        # P2: surface JSONL buffer overflow drops (if any)
        try:
            ds = _jsonl_drain_drop_stats()
            dl = int((ds or {}).get("lines", 0) or 0)
            if dl > 0:
                protocol_bump_counter(state, "jsonl_drop_lines", dl)
                proto["jsonl_drop_total"] = int(proto.get("jsonl_drop_total", 0) or 0) + dl
        except Exception:
            pass
    except Exception:
        return

def run() -> None:
    # ============================================================
    # SECTION 0: Boot / Config / Clients
    # ============================================================
    cfg = load_config_from_env()
    _apply_runtime_globals(cfg)
    log_info("boot: starting mersoom_agent")
    try:
        trace_hit("boot")
    except Exception:
        pass
    tuning = load_tuning_from_env()
    # selftest mode (exits by default)
    if _env_bool("MERSOOM_SELFTEST", False):
        rc = _run_selftest()
        if _env_bool("MERSOOM_SELFTEST_EXIT", True):
            raise SystemExit(int(rc))


    # (Unit 13) prevent accidental double-run
    acquire_process_lock(_resolve_lock_path(cfg.paths.state))

    client = HttpClient(cfg.http)

    state = load_state(cfg.paths.state)
    memory = load_memory(cfg.paths.memory, tuning)
    policy = load_policy(cfg.paths.policy, tuning)
    semantic = load_semantic(cfg.paths.semantic)
    brain = load_brain(cfg.paths.brain)
    if TZ_FALLBACK_USED and not bool(state.get("tz_fallback_recorded")):
        protocol_bump_counter(state, "tz_fallback_used", 1)
        state["tz_fallback_recorded"] = True

    # load threads/users (expanded state mirrors)
    threads_split = load_threads(cfg.paths.threads)
    users_split = load_users(cfg.paths.users)

    # Prefer the newest payload by __meta__.tick_id (split files can be coalesced).
    st_threads = _safe_dict(state.get("threads"))
    if isinstance(threads_split, dict) and threads_split:
        if (not st_threads) or (_meta_tick_id(threads_split) >= _meta_tick_id(st_threads)):
            state["threads"] = threads_split
    elif st_threads:
        state["threads"] = st_threads

    st_users = _safe_dict(state.get("users"))
    if isinstance(users_split, dict) and users_split:
        if (not st_users) or (_meta_tick_id(users_split) >= _meta_tick_id(st_users)):
            state["users"] = users_split
    elif st_users:
        state["users"] = st_users


    # ============================================================
    # SECTION 0.5: Migrate-only (one-shot) mode (RC4)
    # ============================================================
    if _env_bool("MERSOOM_MIGRATE_ONLY", False):
        log_info("migrate-only: persisting migrated artifacts and exiting")
        try:
            persist_gen = _make_persist_gen()
            tick_stamp = _make_tick_stamp(state)
            tick_stamp["persist_gen"] = persist_gen
            _apply_stamp(state, tick_stamp)
            _apply_stamp(memory, tick_stamp)
            _apply_stamp(policy, tick_stamp)
            _apply_stamp(semantic, tick_stamp)
            _apply_stamp(brain, tick_stamp)

            th_obj = _safe_dict(state.get("threads"))
            us_obj = _safe_dict(state.get("users"))
            _apply_stamp(th_obj, tick_stamp)
            _apply_stamp(us_obj, tick_stamp)

            save_json_file_atomic(cfg.paths.state, state)
            save_json_file_atomic(cfg.paths.memory, memory)
            save_json_file_atomic(cfg.paths.policy, policy)
            save_json_file_atomic(cfg.paths.semantic, semantic)
            save_json_file_atomic(cfg.paths.brain, brain)
            # split mirrors (safe even if empty)
            if getattr(cfg.paths, "threads", ""):
                save_json_file_atomic(cfg.paths.threads, th_obj)
            if getattr(cfg.paths, "users", ""):
                save_json_file_atomic(cfg.paths.users, us_obj)
        except Exception as e:
            log_exception("migrate-only:fatal", e)
            raise SystemExit(2)
        if _env_bool("MERSOOM_MIGRATE_ONLY_EXIT", True):
            raise SystemExit(0)

    # (P0) boot self-test (connectivity + challenge parsing)
    boot_self_test(client, cfg, state)

    # corpus + bm25
    corpus_docs = load_corpus_jsonl(cfg.paths.corpus_jsonl, max_docs=3000)
    # ✅ 중복 방지용 set (최근 범위만)
    doc_id_set = set()
    for d in corpus_docs[-2500:]:
        if isinstance(d, dict) and d.get("doc_id"):
            doc_id_set.add(str(d.get("doc_id")))

    bm25 = BM25Index()
    t0_bm25 = time.perf_counter()
    bm25.build(corpus_docs, max_docs=2500)
    record_bm25_build(
        state,
        build_ms=(time.perf_counter() - t0_bm25) * 1000.0,
        docs_indexed=len(corpus_docs),
        mode="full",
        corpus_size=len(corpus_docs),
        added_since=int(state.get("bm25_added_since_build", 0) or 0),
    )

    last_split_persist_ts: float = 0.0


    # (Unit 01) QA batch report (optional)
    if getattr(cfg, "quality", None) is not None and cfg.quality.batch_on_boot:
        try:
            report = qa_run_batch_report(client, cfg, tuning, state, policy, semantic, brain, bm25)
            qa_print_batch_report(report, show_worst=int(cfg.quality.batch_show_worst))
            if str(cfg.quality.batch_save_path or "").strip():
                qa_write_batch_report(str(cfg.quality.batch_save_path).strip(), report)
        except Exception as e:
            log_debug_exc("qa_batch", e)
        if cfg.quality.batch_exit:
            return

    post_limiter = SlidingWindowLimiter(cfg.limits.posts_per_window, cfg.limits.window_sec)
    comment_limiter = SlidingWindowLimiter(cfg.limits.comments_per_window, cfg.limits.window_sec)
    vote_limiter = SlidingWindowLimiter(cfg.limits.votes_per_window, cfg.limits.window_sec)

    vote_pace_sec = pace_interval(cfg.limits.votes_per_window, cfg.limits.window_sec, cfg.timing.global_vote_min_gap_sec, cfg.mode.activity_mode)
    comment_pace_sec = pace_interval(cfg.limits.comments_per_window, cfg.limits.window_sec, cfg.timing.global_comment_min_gap_sec, cfg.mode.activity_mode)
    post_pace_sec = pace_interval(
        cfg.limits.posts_per_window,
        cfg.limits.window_sec,
        max(cfg.timing.global_post_min_gap_sec, cfg.timing.post_min_gap_sec),
        cfg.mode.activity_mode
    )

    Console.cprint(Console.CYAN, f"[START] BASE={cfg.http.base_url} dry_run={cfg.http.dry_run}")
    Console.cprint(Console.CYAN, f"[START] nickname={cfg.nickname} always_on={cfg.mode.always_on} mode={cfg.mode.activity_mode}")
    Console.cprint(Console.MAGENTA, f"[LIMITS/window] posts={cfg.limits.posts_per_window}, comments={cfg.limits.comments_per_window}, votes={cfg.limits.votes_per_window} window={cfg.limits.window_sec}s")
    Console.cprint(Console.MAGENTA, f"[PACE] vote={vote_pace_sec}s comment={comment_pace_sec}s post={post_pace_sec}s")
    Console.cprint(Console.MAGENTA, f"[LEARN] eps={policy.get('epsilon')} lr={policy.get('lr')} eval_delay={tuning.eval_delay_min_sec//3600}-{tuning.eval_delay_max_sec//3600}h learn_period={tuning.learn_period_sec//3600}h")
    Console.cprint(Console.GRAY, "Ctrl+C to stop.\n")

    update_daily_counters(state)
    posts_cache: List[Dict[str, Any]] = []

    # snapshot scheduler
    script_dir = os.path.dirname(os.path.abspath(__file__))
    snapshot_script_path = os.path.join(script_dir, str(cfg.snapshot.script or "snapshot_mersoom_to_xlsx_v3.py"))
    snapshot_enabled = bool(cfg.snapshot.enabled)
    if snapshot_enabled and not os.path.exists(snapshot_script_path):
        log_warn(f"snapshot disabled: script not found: {snapshot_script_path}")
        snapshot_enabled = False

    snapshot_next_dt = now_kst() if (snapshot_enabled and cfg.snapshot.run_on_boot) else next_top_of_hour_kst()

    while True:
        # monotonic tick id for cross-file coherence (P0)
        state["tick_id"] = int(state.get("tick_id", 0) or 0) + 1
        try:
            trace_hit("tick")
        except Exception:
            pass
        if _env_bool("MERSOOM_HEALTH_V2", False):
            protocol_bump_counter(state, "loop_tick", 1)
        tick_stamp = _make_tick_stamp(state)

        # No-action reasons (personal-run observability)
        tick_no_action: Dict[str, int] = {}

        def _note_no_action(reason: str) -> None:
            try:
                r = str(reason or "").strip()[:80]
                if not r:
                    return
                tick_no_action[r] = int(tick_no_action.get(r, 0) or 0) + 1
            except Exception:
                pass

        acted_any = False
        today = _today_kst()
        # 0) Hourly snapshot at :00 (best-effort)
        if snapshot_enabled:
            try:
                now_dt = now_kst()
                hour_key = now_dt.strftime("%Y-%m-%d %H")
                if now_dt >= snapshot_next_dt and str(state.get("last_snapshot_hour_kst", "")) != hour_key:
                    log_info(f"snapshot: running {os.path.basename(snapshot_script_path)} @ {now_dt.strftime('%H:%M:%S')}")
                    rc, out = run_snapshot_script(snapshot_script_path, cfg.snapshot.timeout_sec)
                    state["last_snapshot_hour_kst"] = hour_key
                    state["last_snapshot_ts"] = time.time()
                    if rc == 0:
                        log_info("snapshot: OK")
                    else:
                        log_warn(f"snapshot: exit={rc} out={one_line(out, 200)}")
                    snapshot_next_dt = next_top_of_hour_kst(now_dt + timedelta(seconds=1))
            except Exception as e:
                log_error("snapshot", repr(e))
                snapshot_next_dt = next_top_of_hour_kst()

        # ============================================================
        # SECTION 1: Sync / Perception (fetch feed, update context)
        # ============================================================
        # 1) Sync
        if ops_should_skip(state, "sync"):
            # Circuit breaker: avoid hammering API on repeated failures.
            # IMPORTANT: do NOT reuse an ancient cache for actions (can cause duplicate votes/comments).
            try:
                if posts_cache:
                    cache_age = time.time() - float(state.get("last_sync_ts", 0.0) or 0.0)
                    max_age = _env_int("MERSOOM_SYNC_CACHE_MAX_AGE_SEC", 3600, 300, 24 * 3600)
                    if cache_age > float(max_age):
                        log_warn(f"sync: cache stale age={int(cache_age)}s (>{int(max_age)}s) -> invalidate")
                        posts_cache = []
            except Exception as e:
                log_debug_exc("sync:cache_guard", e)
            # When sync is disabled, we intentionally skip syncing this tick.
        else:
            try:
                if (time.time() - float(state.get("last_sync_ts", 0.0) or 0.0)) >= cfg.timing.sync_min_interval_sec or not posts_cache:
                    posts_cache = do_sync_posts(client, cfg, state, tuning)
                    log_info(f"sync posts={len(posts_cache)} corpus={len(corpus_docs)}")
                ops_record_success(state, "sync")
            except Exception as e:
                ops_record_failure(state, "sync", repr(e))
                log_exception("sync", e, context={"stage": "sync", "tick": state.get("tick")})
                if _should_failfast("sync"):
                    raise
                nap = random.randint(cfg.timing.idle_retry_min, cfg.timing.idle_retry_max)
                sleep_chunked(
                    nap,
                    hard_cap_sec=cfg.timing.sleep_hard_cap_sec,
                    why="(sync fail)",
                    wake_deadline_wall_ts=(snapshot_next_dt.timestamp() if snapshot_enabled else None),
                )
                continue

        # 1.5) Community flow + thread context scan (LLM-free 'perception' + 'compression')
        try:
            # share tuning into brain (so helper uses correct cap)
            brain["max_thoughts"] = int(tuning.max_thoughts)

            scan_n = int(tuning.scan_posts_per_sync)
            scan_posts = posts_cache[:max(0, scan_n)]
            update_community_flow(brain, scan_posts, half_life_hours=float(tuning.flow_half_life_hours))

            for p in scan_posts:
                ingest_post_into_context(state, p, brain=brain)
                pid = str(p.get("id") or "")
                if pid:
                    synthesize_thread(get_thread(state, pid))
        except Exception as e:
            log_exception("flow_scan", e, context={"stage": "flow_scan", "tick": state.get("tick"), "since_boot_s": int(time.time() - float(state.get("boot_wall_ts", time.time()) or time.time()))})
            if _should_failfast("flow_scan"):
                raise

        # ============================================================
        # SECTION 2: Arena (Colosseum)
        # ============================================================
        # 1.75) Arena (Colosseum) flow (Unit 09)
        if ops_should_skip(state, "arena"):
            protocol_set_reason(state, "arena", "arena:ops_disabled", "ops_should_skip")
            _note_no_action(protocol_get_reason(state, "arena"))
            pass
        else:
            try:
                a = do_arena_flow(client, cfg, tuning, state, memory, brain)
                if a > 0:
                    acted_any = True
                else:
                    r = protocol_get_reason(state, "arena")
                    _note_no_action(r if r != "unknown" else "arena:no_action")
                ops_record_success(state, "arena")
            except Exception as e:
                ops_record_failure(state, "arena", repr(e))
                log_exception("arena_loop", e, context={"stage": "arena", "tick": state.get("tick")})
                if _should_failfast("arena"):
                    raise
                protocol_set_reason(state, "arena", "arena:error", one_line(repr(e), 120))
                _note_no_action(protocol_get_reason(state, "arena"))

        # 1.9) v19 protocol scaffold tick (no behavior change yet)
        try:
            protocol_tick(cfg, state, client)
        except Exception as e:
            log_error("protocol", repr(e))



        # ============================================================
        # SECTION 3: Votes
        # ============================================================
        # 2) Votes
        if ops_should_skip(state, "vote"):
            protocol_set_reason(state, "vote", "vote:ops_disabled", "ops_should_skip")
            _note_no_action(protocol_get_reason(state, "vote"))
            pass
        else:
            try:
                voted = do_vote_main_feed(client, cfg, tuning, state, memory, semantic, brain, posts_cache, vote_limiter, vote_pace_sec)
                if voted > 0:
                    acted_any = True
                else:
                    r = protocol_get_reason(state, "vote")
                    _note_no_action(r if r != "unknown" else "vote:no_action")
                ops_record_success(state, "vote")
            except Exception as e:
                ops_record_failure(state, "vote", repr(e))
                log_exception("vote_loop", e, context={"stage": "vote", "tick": state.get("tick")})
                if _should_failfast("vote"):
                    raise
                protocol_set_reason(state, "vote", "vote:error", one_line(repr(e), 120))
                _note_no_action(protocol_get_reason(state, "vote"))


        # ============================================================
        # SECTION 4: Contribution (comments/replies/posts)
        # ============================================================
        # 3) Contribution
        if ops_should_skip(state, "contrib"):
            protocol_set_reason(state, "comment", "comment:ops_disabled", "ops_should_skip")
            _note_no_action(protocol_get_reason(state, "comment"))
            pass
        else:
            try:
                c = do_contribution(
                    client, cfg, tuning,
                    state, memory, semantic, policy, brain,
                    posts_cache,
                    post_limiter, comment_limiter,
                    comment_pace_sec, post_pace_sec,
                    bm25=bm25
                )
                c = int(c) if isinstance(c, (int, bool)) else 0
                if c > 0:
                    acted_any = True
                else:
                    r = protocol_get_reason(state, "comment")
                    _note_no_action(r if r != "unknown" else "comment:no_action")
                ops_record_success(state, "contrib")
            except Exception as e:
                ops_record_failure(state, "contrib", repr(e))
                log_exception("contrib", e, context={"stage": "contrib", "tick": state.get("tick")})
                if _should_failfast("contrib"):
                    raise
                protocol_set_reason(state, "comment", "comment:error", one_line(repr(e), 120))
                _note_no_action(protocol_get_reason(state, "comment"))


        # ============================================================
        # SECTION 5: Template mining (LLM-free, from rewarded history)
        # ============================================================
        # 4) Mine templates from rewarded comments (LLM-free)
        try:
            maturity = get_maturity_level(brain, state)
            evald = int(state.get("evaluated_count", 0) or 0)

            # cold-start: allow slightly lower threshold so templates accumulate
            thr_hi = 0.90
            if evald < 20 or maturity < 0.25:
                thr_hi = 0.75
            elif evald < 80 or maturity < 0.45:
                thr_hi = 0.82
            thr_lo = max(0.65, thr_hi - 0.12)

            # v5.1 Unit1: nickname bank for template normalization
            name_bank = _collect_candidate_nicknames(cfg, state, max_n=400)

            mined = 0
            for it in memory[-60:]:
                if not isinstance(it, dict):
                    continue
                if it.get("evaluated") is not True:
                    continue
                if str(it.get("action") or "") not in ("comment", "reply"):
                    continue

                r = float(it.get("reward_scalar", 0.0) or 0.0)
                nov = float(it.get("novelty", 0.0) or 0.0)
                # main gate: high reward OR medium reward with strong novelty (avoids echo templates)
                if r < thr_hi and not (r >= thr_lo and nov >= 0.55):
                    continue

                txt = str(it.get("text") or "")
                if not txt:
                    continue
                tpl = mine_template_from_text(txt)
                if tpl:
                    # v5.1 Unit1: prevent foreign nicknames from being baked into templates
                    tpl = normalize_nicknames_to_placeholder(tpl, name_bank)
                    tid_new = register_mined_template(policy, tpl, meta={"source": "rewarded_comment", "r": r, "nov": nov})
                    if tid_new:
                        mined += 1
                    if mined >= 3:
                        break

            # slow pruning to keep quality rising
            pr = prune_templates(policy, min_keep=10)
            if pr > 0:
                bump_semantic(semantic, _today_kst(), "tpl_prune", float(pr))
        except Exception as e:
            log_error("template_miner", repr(e))


        # ============================================================
        # SECTION 6: Corpus growth / BM25 maintenance
        # ============================================================
# 5) Corpus growth (dedup + cap)
        try:
            # v5.1 Unit1: nickname bank for corpus normalization
            name_bank = _collect_candidate_nicknames(cfg, state, max_n=400)
            added = 0
            for p in posts_cache[:8]:
                if not isinstance(p, dict):
                    continue
                pid = str(p.get("id") or "")
                if not pid:
                    continue
                txt = f"{p.get('title') or ''} {p.get('content') or ''}".strip()
                if len(txt) < 20:
                    continue

                doc_id = corpus_doc_id("post", pid, str(p.get("nickname") or ""), txt)
                if doc_id in doc_id_set:
                    continue

                doc = {
                    "doc_id": doc_id,
                    "kind": "post",
                    "post_id": pid,
                    "author": str(p.get("nickname") or ""),
                    "ts": time.time(),
                    "text": normalize_nicknames_to_placeholder(sanitize_plain_text(txt), name_bank),
                }
                doc_id_set.add(doc_id)
                corpus_docs.append(doc)
                txt2 = str(doc.get("text") or "")
                append_corpus_doc(cfg.paths.corpus_jsonl, {**doc, "tokens": tokenize(txt2, max_tokens=200)})
                # v5.4 Unit4: update char-gram LM from human corpus (semantic)
                lm_update_from_text(cfg, semantic, str(doc.get("author") or ""), str(doc.get("text") or ""))
                added += 1

            # cap in-memory corpus
            if len(corpus_docs) > 3000:
                corpus_docs = corpus_docs[-3000:]
                # doc_id_set도 최근 범위로 재구성
                doc_id_set = set(str(d.get("doc_id")) for d in corpus_docs[-2500:] if isinstance(d, dict) and d.get("doc_id"))

            # (P1) Rebuild BM25 only when enough new docs are added (CPU friendly)
            if added > 0:
                state["bm25_added_since_build"] = int(state.get("bm25_added_since_build", 0) or 0) + int(added)

            last_b = float(state.get("bm25_last_build_ts", 0.0) or 0.0)
            need_by_add = int(state.get("bm25_added_since_build", 0) or 0) >= int(getattr(tuning, "bm25_rebuild_min_add", 6))
            need_by_time = (time.time() - last_b) >= float(getattr(tuning, "bm25_rebuild_min_sec", 600))
            if (need_by_add or need_by_time) and int(state.get("bm25_added_since_build", 0) or 0) > 0:
                added_since = int(state.get("bm25_added_since_build", 0) or 0)
                use_v2 = _env_bool("MERSOOM_BM25_BUILD_V2", False)
                build_docs = corpus_docs
                mode = "full"
                if use_v2:
                    recent_n = _env_int("MERSOOM_BM25_BUILD_V2_RECENT_DOCS", 1200, 200, 3000)
                    build_docs = corpus_docs[-recent_n:]
                    mode = "partial"
                t0 = time.perf_counter()
                bm25.build(build_docs, max_docs=2500)
                build_ms = (time.perf_counter() - t0) * 1000.0
                record_bm25_build(
                    state,
                    build_ms=build_ms,
                    docs_indexed=len(build_docs),
                    mode=mode,
                    corpus_size=len(corpus_docs),
                    added_since=added_since,
                )
                state["bm25_added_since_build"] = 0
                state["bm25_last_build_ts"] = time.time()

        except Exception as e:
            log_error("corpus", repr(e))


        # ============================================================
        # SECTION 7: Evaluation / Learning
        # ============================================================
        # 6) Evaluation + learning (batched)
        try:
            eval_n, eval_sum = evaluate_and_learn(client, tuning, memory, policy, semantic, state)
            if eval_n > 0:
                log_info(f"eval done={eval_n} reward_sum={eval_sum:.2f}")
                write_journal(cfg.paths.journal, f"eval {eval_n} items | reward_sum={eval_sum:.2f}")
        except Exception as e:
            log_error("eval_loop", repr(e))


        # ============================================================
        # SECTION 8: Brain update + journaling
        # ============================================================
        # 7) Brain update + note
        try:
            update_brain(brain, tuning, memory, policy)
            # persisted in the main persist block
        except Exception as e:
            log_error("brain", repr(e))


        # trim memory (v7.26): preserve pending-eval items when possible
        try:
            maxn = max(1, int(tuning.memory_size))
            if len(memory) > maxn:
                st_trim = _trim_memory_smart_inplace(memory, maxn, now_ts=time.time(), log_prefix="memory:trim:tick")
                if isinstance(st_trim, dict) and int(st_trim.get("dropped_due", 0) or 0) > 0:
                    state["memory_trim_drop_due"] = int(state.get("memory_trim_drop_due", 0) or 0) + int(st_trim.get("dropped_due", 0) or 0)
                    state["memory_trim_drop_due_last_ts"] = time.time()
        except Exception as e:
            log_debug_exc("memory:trim", e)
            if len(memory) > tuning.memory_size:
                memory[:] = memory[-tuning.memory_size:]


        # tick journal + semantic
        try:
            contrib = int(state.get("contrib_count_today", 0))
            write_journal(
                cfg.paths.journal,
                f"tick | acted={acted_any} | contrib_today={contrib} | total_actions={state.get('total_actions', 0)} | eval_total={state.get('evaluated_count', 0)} | mem={len(memory)} | rem(v/c/p)={vote_limiter.remaining()}/{comment_limiter.remaining()}/{post_limiter.remaining()}"
            )
            bump_semantic(semantic, today, "ticks", 1.0)
        except Exception as e:
            log_debug_exc("run:silent", e)
            pass


        # ============================================================
        # SECTION 9: Persist (atomic saves, split files, manifests)
        # ============================================================
        # persist (with cross-file generation stamp)
        try:
            _apply_stamp(state, tick_stamp)
            _apply_stamp(policy, tick_stamp)
            _apply_stamp(semantic, tick_stamp)

            th_obj = _safe_dict(state.get("threads"))
            us_obj = _safe_dict(state.get("users"))
            _apply_stamp(th_obj, tick_stamp)
            _apply_stamp(us_obj, tick_stamp)

            # brain is small; persist each tick so stamp stays coherent across files
            _apply_stamp(brain, tick_stamp)

            save_json_file_atomic(cfg.paths.state, state)
            save_json_file_atomic(cfg.paths.memory, memory)
            save_json_file_atomic(cfg.paths.policy, policy)
            save_json_file_atomic(cfg.paths.semantic, semantic)
            save_json_file_atomic(cfg.paths.brain, brain)

            try:
                split_every = float(_env_int("MERSOOM_PERSIST_SPLIT_EVERY_SEC", 60, 0, 86400))
                now_ts = float(time.time())
                do_split = (split_every <= 0.0) or (now_ts - float(last_split_persist_ts) >= split_every) or bool(acted_any)
                if do_split:
                    save_json_file_atomic(cfg.paths.threads, th_obj)
                    save_json_file_atomic(cfg.paths.users, us_obj)
                    save_text_file_atomic(cfg.paths.brain_note, render_brain_note(brain))

                    # meta manifests (out-of-band; doesn't touch memory list)
                    try:
                        meta = {
                            "__meta__": _safe_dict(tick_stamp),
                            "files": {
                                "state": os.path.abspath(cfg.paths.state),
                                "memory": os.path.abspath(cfg.paths.memory),
                                "policy": os.path.abspath(cfg.paths.policy),
                                "semantic": os.path.abspath(cfg.paths.semantic),
                                "brain": os.path.abspath(cfg.paths.brain),
                                "brain_note": os.path.abspath(cfg.paths.brain_note),
                                "threads": os.path.abspath(cfg.paths.threads),
                                "users": os.path.abspath(cfg.paths.users),
                            },
                        }
                        save_json_file_atomic(cfg.paths.meta, meta)
                        mem_meta = {"__meta__": _safe_dict(tick_stamp), "count": len(_safe_list(memory))}
                        save_json_file_atomic(cfg.paths.memory_meta, mem_meta)
                    except Exception as e:
                        log_debug_exc("persist_meta", e)

                    last_split_persist_ts = now_ts
            except Exception as e:
                log_debug_exc("persist_split", e)

            # flush buffered jsonl (if enabled)
            try:
                for pth in list(_JSONL_BUFFERS.keys()):
                    _flush_jsonl_buffer(pth, force=False)
            except Exception:
                pass

        except Exception as e:
            log_exception("persist", e, context={"stage": "persist", "tick": state.get("tick")})


        # ============================================================
        # SECTION 10: Tick summary / sleep scheduling
        # ============================================================
        # (Unit 13) tick health summary (rate-limited to avoid log spam)
        try:
            ops = _ops_init(state)
            last_log = float(ops.get("last_tick_log_ts", 0.0) or 0.0)
            now_log = time.time()
            if acted_any or (now_log - last_log) >= float(_env_int("MERSOOM_TICK_LOG_EVERY_SEC", 180, 10, 3600)):
                ops["last_tick_log_ts"] = now_log
                m = getattr(client, "metrics", {}) or {}
                disabled = ops_disabled_keys(state)
                log_info(
                    "tick"
                    + f" acted={int(bool(acted_any))}"
                    + f" total_actions={int(state.get('total_actions', 0) or 0)}"
                    + f" total_reward={float(state.get('total_reward', 0.0) or 0.0):.3f}"
                    + f" eval={int(state.get('evaluated_count', 0) or 0)}"
                    + f" req_ok={int(m.get('req_ok', 0) or 0)}"
                    + f" 429={int(m.get('rate_limited', 0) or 0)}"
                    + f" last_status={int(m.get('last_status', 0) or 0)}"
                    + (f" ops_disabled={','.join(disabled)}" if disabled else " ops_disabled=-")
                )

                # (v6.5) Minimal action/target summary for tracing (only when MERSOOM_TRACE=1)
                try:
                    if trace_enabled():
                        focus = _safe_dict(state.get("focus"))
                        mode = str(focus.get("mode") or "")
                        pid = str(focus.get("post_id") or "")
                        cid = str(focus.get("comment_id") or "")
                        title = one_line(str(focus.get("post_title") or ""))[:48]
                        if mode or pid or cid:
                            log_info(f"tick_target mode={mode} post_id={pid} comment_id={cid} title={title}")
                        elif acted_any:
                            log_info("tick_target action=non_focus")
                except Exception as e:
                    log_debug_exc("tick_target:silent", e)
                    pass

        except Exception as e:
            log_debug_exc("run:silent", e)
            pass

        if not cfg.mode.always_on:
            log_info("ALWAYS_ON=false -> stop after one tick")
            break

        nap = next_sleep_from_limits(cfg, state, post_limiter, comment_limiter, vote_limiter, vote_pace_sec, comment_pace_sec, post_pace_sec)
        if not acted_any:
            nap = min(nap, random.randint(cfg.timing.idle_retry_min, cfg.timing.idle_retry_max))
        # No-action summary (only when nothing was done this tick)
        if not acted_any and tick_no_action:
            try:
                win = _safe_dict(state.get("no_action_window"))
                for k, v in tick_no_action.items():
                    win[k] = int(win.get(k, 0) or 0) + int(v or 0)
                # cap window keys
                if len(win) > 64:
                    # keep top 48
                    items = sorted(win.items(), key=lambda kv: int(kv[1] or 0), reverse=True)[:48]
                    win = {k: int(v) for k, v in items}
                state["no_action_window"] = win

                every = _env_int("MERSOOM_NO_ACTION_LOG_EVERY_SEC", 600, 60, 7200)
                last = float(state.get("no_action_last_log_ts", 0.0) or 0.0)
                now = time.time()
                if (now - last) >= float(every):
                    top = sorted(win.items(), key=lambda kv: int(kv[1] or 0), reverse=True)[:6]
                    msg = ", ".join([f"{k}={v}" for k, v in top]) if top else "n/a"
                    log_info(f"no_action: {msg}")
                    state["no_action_last_log_ts"] = now
                    # reset window after logging to keep it "recent"
                    state["no_action_window"] = {}
            except Exception as e:
                log_debug_exc("no_action_summary:silent", e)
                pass

        sleep_chunked(
            nap,
            hard_cap_sec=cfg.timing.sleep_hard_cap_sec,
            why="(tick)",
            wake_deadline_wall_ts=(snapshot_next_dt.timestamp() if snapshot_enabled else None),
        )


    # ============================================================
    # SECTION 99: Trace dump (v6.4)
    # ============================================================
    # Best-effort: write trace file only when MERSOOM_TRACE=1
    try:
        if trace_enabled():
            out_path = trace_default_path(getattr(cfg.paths, 'state', ''))
            cov = trace_stage_coverage()
            trace_dump(out_path)
            try:
                st = _safe_dict(cov.get('stages'))
                missing = cov.get('missing') or []
                if missing:
                    log_info(f"trace: wrote {out_path} coverage={st} missing={missing}")
                else:
                    log_info(f"trace: wrote {out_path} coverage={st}")
            except Exception:
                log_info(f"trace: wrote {out_path}")
    except Exception as e:
        log_debug_exc('trace_dump', e)


# -----------------------------------------------------------------------------
# Hotfix: missing helper used by contrib quote logic
# -----------------------------------------------------------------------------
def pick_best_quote_from_corpus(
    bm25: Any,
    query_tokens: List[str],
    *,
    min_score: float = 0.0,
    max_chars: int = 140,
    topk: int = 10,
) -> Tuple[str, float, Dict[str, Any]]:
    """
    Pick a short quote/snippet from BM25 corpus results.

    Returns:
      (quote_text, score, meta)

    Notes:
    - Designed to be cheap + robust (never raises).
    - `bm25` is expected to have `.doc_meta` {doc_id: {...}} and be compatible with `search(bm25, ...)`.
    """
    try:
        if bm25 is None or not query_tokens:
            return ("", 0.0, {})
        tk = max(1, int(topk))
        ms = float(min_score or 0.0)
        mc = max(40, int(max_chars or 140))
    except Exception:
        return ("", 0.0, {})

    # 1) rank docs
    try:
        ranked = search(bm25, list(query_tokens), topk=tk, min_score=ms, normalize_scores=True)
    except Exception as e:
        log_debug_exc("pick_best_quote_from_corpus:search", e)
        ranked = []

    if not ranked:
        return ("", 0.0, {})

    def _clean(s: str) -> str:
        try:
            s2 = sanitize_plain_text(str(s or ""))
        except Exception:
            s2 = str(s or "")
        s2 = re.sub(r"\s+", " ", s2).strip()
        s2 = re.sub(r"^[\-\–\—\•\·\s]+", "", s2).strip()
        # kill obvious boilerplate openers that hurt naturalness
        for ban in (
            "감정은 제외하고",
            "정의→기준→검증",
            "정의->기준->검증",
            "정의 → 기준 → 검증",
            "(한국어 모듈 오류남)",
            "한국어 모듈 오류남",
        ):
            s2 = s2.replace(ban, "").strip()
        # soften over-meta openers
        for bad in ("요지는", "핵심은", "포인트는", "본문 요지는", "그 댓글 요지는", "결론은", "정리하면", "요약하면", "한 줄 요약은"):
            if s2.startswith(bad):
                rest = s2[len(bad):].lstrip(" :,-")
                s2 = ("쟁점은 " + rest).strip()
                break
        return s2

    # 2) choose the best short snippet from top hits
    best_quote = ""
    best_sc = 0.0
    best_meta: Dict[str, Any] = {}

    # tiny helper for matching query tokens
    qk = [t for t in list(dict.fromkeys([str(t) for t in query_tokens if t]))][:16]

    def _snippet_candidates(text: str) -> List[str]:
        t = _clean(text)
        if not t:
            return []
        # prefer sentence-level snippets
        try:
            sents = split_sentences(t, max_sent=6)
        except Exception:
            # fallback: cheap split
            sents = re.split(r"(?<=[\.\?\!…])\s+", t)
        sents = [x.strip() for x in sents if x and x.strip()]
        if not sents:
            return [t]
        # also allow first two sentences concatenated (often more coherent)
        out = []
        out.extend(sents[:4])
        if len(sents) >= 2:
            out.append((sents[0] + " " + sents[1]).strip())
        return out

    def _score_snip(s: str) -> float:
        s2 = _clean(s)
        if not s2:
            return -1e9
        if "http://" in s2 or "https://" in s2 or "www." in s2:
            return -1e9
        # hard cap
        if len(s2) > mc:
            s2 = one_line(s2, mc)
        if len(s2) < 12:
            return -1e9
        hits = 0
        for t in qk:
            if t and (t in s2):
                hits += 1
        # length preference (around 70~110 chars tends to feel like a "quote")
        L = len(s2)
        len_pen = abs(L - 90) / 90.0  # 0..~1
        return (hits * 10.0) - (len_pen * 4.0)

    for doc_id, sc in ranked:
        try:
            meta = {}
            try:
                meta = _safe_dict(getattr(bm25, "doc_meta", {}).get(str(doc_id), {}))
            except Exception:
                meta = {}
            text = str(meta.get("text") or "")
            if not text:
                continue

            for cand in _snippet_candidates(text):
                cand2 = _clean(cand)
                if not cand2:
                    continue
                if len(cand2) > mc:
                    cand2 = one_line(cand2, mc)
                sn_sc = _score_snip(cand2)
                # prefer better snippet, then higher doc score
                total = float(sn_sc) + float(sc) * 0.05
                if (not best_quote) or (total > best_sc):
                    best_quote = cand2
                    best_sc = float(total)
                    best_meta = dict(meta)
                    best_meta.setdefault("doc_id", str(doc_id))
                    best_meta.setdefault("score", float(sc))
        except Exception as e:
            log_debug_exc("pick_best_quote_from_corpus:loop", e)
            continue

    if not best_quote:
        return ("", 0.0, {})

    # return original bm25 score (not total), but keep meta enriched
    try:
        orig = float(best_meta.get("score", 0.0) or 0.0)
    except Exception:
        orig = 0.0
    return (best_quote, orig, best_meta)

if __name__ == "__main__":
    try:
        _apply_cli_overrides(sys.argv[1:])
        run()
    except KeyboardInterrupt:
        log_warn("stopped by user (Ctrl+C)")
    except Exception as e:
        log_error("fatal", repr(e))
        raise
