################################################################################
# 23. REWARD / UPDATE
# Deps: 01-03, 08-22
# Used by: learning loop (policy/bandit updates)
# Notes: compute scalar reward + update tuning/state
################################################################################
"""
SECTION 23 - REWARD + UPDATE

Computes reward from before/after metrics and updates policy/brain.

Responsibilities:
- Fetch or compute engagement deltas (votes, replies, comment counts).
- Convert deltas into a scalar reward + breakdown.
- Apply reward to policy (bandit) and brain logs.

Debug tips:
- If policy never changes, confirm reward_update is being called and meta contains required keys.
"""
def compute_reward(tuning: AgentTuning, before: Dict[str, int], after: Dict[str, int], meta: Dict[str, Any]) -> Tuple[float, Dict[str, Any]]:
    """
    v20.5 unified reward (single scalar for learning):
      r = W_UP * Δup + W_ENGAGE * log1p(engage) - W_RISK * risk

    engage:
      - posts: Δcomments on the post (best available "inbound" signal)
      - comments/replies: reply_received (continuation on my own comment)

    risk (posts only, heuristic):
      - downvote growth
      - negative score proximity (blind(-5) guard)
    """
    # server-side deltas (best available feedback for posts)
    du = float(after.get("up", 0) - before.get("up", 0))
    dd = float(after.get("down", 0) - before.get("down", 0))
    dc = float(after.get("comments", 0) - before.get("comments", 0))
    ds = float(after.get("score", 0) - before.get("score", 0))

    action = str(meta.get("action") or "")
    action_type = str(meta.get("action_type") or "")

    # weights (env-driven; stored in tuning for logging/selftest)
    w_up = float(getattr(tuning, "reward_w_up", 1.0) or 1.0)
    w_eng = float(getattr(tuning, "reward_w_engage", 0.6) or 0.6)
    w_risk = float(getattr(tuning, "reward_w_risk", 1.2) or 1.2)

    reply_received = float(meta.get("reply_received", 0.0) or 0.0)

    is_post = (action == "post") or action_type.startswith("post_")

    # engagement signal
    if is_post:
        engage_raw = max(0.0, dc)
    else:
        # For comments/replies we cannot reliably observe per-comment votes;
        # continuation is the most meaningful proxy.
        engage_raw = max(0.0, reply_received)

    # upvote signal (posts only; other actions would be noisy if we read the parent post)
    up_raw = du if is_post else 0.0

    # risk signal (posts only; heuristic)
    net_votes = float(du - dd)
    after_score = float(after.get("score", 0) or 0)

    risk = 0.0
    if is_post:
        # Down growth always increases risk; net-vote drops are penalized mildly.
        risk_votes = max(0.0, dd)
        risk_net = max(0.0, -net_votes) * 0.5

        # Proximity to "blind" zone (score <= -5 is a common threshold in community UX).
        risk_blind = 0.0
        if after_score <= -4.0:
            # -4 => 1.0, -5 => 2.0, -6 => 3.0 ...
            risk_blind = min(6.0, 1.0 + abs(after_score + 4.0))
        elif after_score <= -2.0:
            risk_blind = 0.5

        risk = float(risk_votes + risk_net + risk_blind)

    # scalar reward
    comp_votes = float(w_up) * float(up_raw)
    comp_engage = float(w_eng) * math.log1p(float(engage_raw))
    comp_risk = -float(w_risk) * float(risk)

    components: Dict[str, float] = {
        # Keep legacy keys for downstream head shaping / logging
        "votes": float(comp_votes),
        "score": 0.0,
        "engage": float(comp_engage),
        "novelty": 0.0,
        "quotes": 0.0,
        "quality": 0.0,
        "cont": 0.0,
        "weak_ctx": 0.0,
        # explicit
        "risk": float(comp_risk),
    }

    r = float(comp_votes + comp_engage + comp_risk)
    r = _clip_reward(float(r), tuning.reward_clip)
    if not math.isfinite(r):
        r = 0.0

    feats: Dict[str, Any] = {
        "du": float(du), "dd": float(dd), "dc": float(dc), "ds": float(ds),
        "net_votes": float(net_votes),
        "reply_received": float(reply_received),
        "action": action,
        "is_post": bool(is_post),
        "engage_raw": float(engage_raw),
        "up_raw": float(up_raw),
        "risk_raw": float(risk),
        "after_score": float(after_score),
        "weights": {"w_up": float(w_up), "w_engage": float(w_eng), "w_risk": float(w_risk)},
        "components": components,
    }
    return r, feats

def _head_reward(head: str, r_scalar: float, feats: Dict[str, Any], tuning: AgentTuning) -> float:
    """Per-head reward shaping: learn *why* something worked."""
    comps = _safe_dict(feats.get("components"))
    votes = float(comps.get("votes", 0.0) or 0.0)
    score = float(comps.get("score", 0.0) or 0.0)
    engage = float(comps.get("engage", 0.0) or 0.0)
    novelty = float(comps.get("novelty", 0.0) or 0.0)
    quotes = float(comps.get("quotes", 0.0) or 0.0)
    quality = float(comps.get("quality", 0.0) or 0.0)
    cont = float(comps.get("cont", 0.0) or 0.0)
    weak = float(comps.get("weak_ctx", 0.0) or 0.0)

    if head in ("action_type", "strategy", "post_style"):
        return float(r_scalar)

    if head == "tone":
        # tone tends to affect reactions + continuity more than novelty
        r = votes + score + engage + cont + (0.7 * quality) + (0.4 * weak)
        return _clip_reward(float(r), tuning.reward_clip)

    if head in ("comment_length", "reply_style"):
        # length/style: reward engagement/continuation + avoid weak context
        r = votes + engage + cont + (0.5 * quality) + (0.6 * weak)
        return _clip_reward(float(r), tuning.reward_clip)

    if head == "template":
        # templates: quality + reactions matter more than novelty
        r = votes + score + engage + (1.0 * quality) + (0.2 * novelty) + (0.2 * quotes) + (0.4 * weak)
        return _clip_reward(float(r), tuning.reward_clip)

    # default
    return float(r_scalar)


def evaluate_and_learn(
    client: HttpClient,
    tuning: AgentTuning,
    memory: List[Dict[str, Any]],
    policy: Dict[str, Any],
    semantic: Dict[str, Any],
    state: Dict[str, Any],
) -> Tuple[int, float]:
    now = time.time()
    last_learn = float(state.get("last_learn_ts", 0.0) or 0.0)
    if (now - last_learn) < float(tuning.learn_period_sec):
        return (0, 0.0)

    due: List[Dict[str, Any]] = []
    for it in memory:
        if not isinstance(it, dict):
            continue
        if it.get("evaluated") is True:
            continue
        due_ts = float(it.get("eval_due_ts", 0.0) or 0.0)
        if due_ts <= 0 or due_ts > now:
            continue
        if str(it.get("action") or "") not in ("comment", "reply", "post"):
            it["evaluated"] = True
            continue
        due.append(it)

    if not due:
        state["last_learn_ts"] = now
        state["learn_runs"] = int(state.get("learn_runs", 0)) + 1
        return (0, 0.0)

    # Trace: learning loop entered (v6.7)
    try:
        trace_hit("reward:enter")
    except Exception:
        pass

    # Optional evaluation budget (per window) to avoid evaluation traffic spikes.
    eb = state.get("eval_budget")
    if not isinstance(eb, dict):
        eb = {"last_reset_ts": 0.0, "used": 0, "cap_per_window": 0, "window_sec": 900}
        state["eval_budget"] = eb
    window_sec = float(eb.get("window_sec", 900) or 900)
    if window_sec < 60:
        window_sec = 60.0
    last_reset = float(eb.get("last_reset_ts", 0.0) or 0.0)
    used = int(eb.get("used", 0) or 0)
    cap = int(eb.get("cap_per_window", 0) or 0)  # 0 => unlimited
    if cap > 0 and (now - last_reset) >= window_sec:
        eb["last_reset_ts"] = now
        eb["used"] = 0
        used = 0
        last_reset = now
    if cap > 0:
        remaining = max(0, cap - used)
        if remaining <= 0:
            # Budget exhausted for this window; postpone learning check.
            state["last_learn_ts"] = now
            state["learn_runs"] = int(state.get("learn_runs", 0)) + 1
            return (0, 0.0)
        due = due[:remaining]

    # v7.26: backlog-aware evaluation limit (bounded)
    base_eval = max(1, int(getattr(tuning, "max_eval_per_tick", 5) or 5))
    due_n_total = len(due)
    eval_limit = base_eval
    try:
        if _env_bool("MERSOOM_EVAL_BACKLOG_BOOST", True):
            cap_eval = _env_int("MERSOOM_EVAL_BACKLOG_MAX_PER_TICK", max(10, base_eval * 3), min_v=base_eval, max_v=200)
            if due_n_total >= base_eval * 8:
                eval_limit = min(cap_eval, base_eval * 3)
            elif due_n_total >= base_eval * 4:
                eval_limit = min(cap_eval, base_eval * 2)
            elif due_n_total >= base_eval * 2:
                eval_limit = min(cap_eval, base_eval + max(1, base_eval // 2))
    except Exception:
        eval_limit = base_eval

    # Trace: backlog size (v7.26)
    try:
        trace_hit("reward:backlog", int(due_n_total or 0))
    except Exception:
        pass

    due = due[:eval_limit]
    total_r = 0.0
    done = 0

    for it in due:
        pid = str(it.get("post_id") or "")
        if not pid:
            it["evaluated"] = True
            continue

        # consume evaluation budget when we make a network fetch
        eb2 = state.get("eval_budget")
        if isinstance(eb2, dict):
            cap2 = int(eb2.get("cap_per_window", 0) or 0)
            if cap2 > 0:
                eb2["used"] = int(eb2.get("used", 0) or 0) + 1

        post = get_post(client, pid)
        if not post:
            it["evaluated"] = True
            continue

        after = _post_metrics(post)
        before = _safe_dict(it.get("metrics_before"))
        if not before:
            before = after

        # Unit 05: attach "continuation" signal (did my comment receive replies?)
        cid0 = str(it.get("comment_id") or "")
        if cid0:
            mr = _safe_dict(_safe_dict(state.get("my_comment_replies")).get(cid0))
            if mr:
                it["reply_received"] = int(mr.get("count", 0) or 0)
                it["reply_received_last_ts"] = float(mr.get("last_ts", 0.0) or 0.0)

        # Trace: reward calculation (v6.7)
        try:
            trace_hit("reward:calc")
        except Exception:
            pass

        # Trace: compute scalar reward (v6.7)
        try:
            trace_hit("reward:calc")
        except Exception:
            pass

        r, feats = compute_reward(tuning, before, after, it)
        it["metrics_after"] = after
        it["reward_scalar"] = float(r)
        it["reward_features"] = feats
        it["evaluated"] = True

        cat = str(it.get("category") or it.get("context_key") or "general")
        strategy = str(it.get("used_strategy") or "")
        tone = str(it.get("used_tone") or "")
        length = str(it.get("used_length") or "")
        reply_style = str(it.get("used_reply_style") or "")
        tid = str(it.get("template_id") or "")
        action_type = str(it.get("action_type") or "")
        used_style = str(it.get("used_style") or "")

        # Unit 05: head-specific learning signals
        r_action = _head_reward("action_type", r, feats, tuning)
        r_poststyle = _head_reward("post_style", r, feats, tuning)
        r_strategy = _head_reward("strategy", r, feats, tuning)
        r_tone = _head_reward("tone", r, feats, tuning)
        r_len = _head_reward("comment_length", r, feats, tuning)
        r_rstyle = _head_reward("reply_style", r, feats, tuning)
        r_tpl = _head_reward("template", r, feats, tuning)

        if action_type:
            update_arm(policy, "action_type", action_type, r_action, context_key=cat)
        if used_style:
            # posts only; harmless if set on comment
            update_arm(policy, "post_styles", used_style, r_poststyle, context_key=cat)

        if strategy:
            update_arm(policy, "strategy", strategy, r_strategy, context_key=cat)
        if tone:
            update_arm(policy, "tone", tone, r_tone, context_key=cat)
        if length:
            update_arm(policy, "comment_length", length, r_len, context_key=cat)
        if reply_style:
            update_arm(policy, "reply_styles", reply_style, r_rstyle, context_key=cat)
        if tid:
            update_template_weight(policy, tid, r_tpl, meta=it)

        # Trace: reward applied to policy/semantic (v6.7)
        try:
            trace_hit("reward:apply")
        except Exception:
            pass

        # Trace: learning applied to policy/semantic (v6.7)
        try:
            trace_hit("reward:apply")
        except Exception:
            pass

        bump_semantic(semantic, _today_kst(), "eval", 1.0)
        total_r += float(r)
        done += 1

    state["last_learn_ts"] = now
    state["learn_runs"] = int(state.get("learn_runs", 0)) + 1
    state["evaluated_count"] = int(state.get("evaluated_count", 0)) + done
    state["total_reward"] = float(state.get("total_reward", 0.0)) + float(total_r)
    # Trace: how many items were learned this run (v6.7)
    try:
        trace_hit("reward:done", int(done or 0))
    except Exception:
        pass
    return done, float(total_r)

def update_brain(brain: Dict[str, Any], tuning: AgentTuning, memory: List[Dict[str, Any]], policy: Dict[str, Any]) -> None:
    """
    Update the agent "brain" from accumulated memory.

    final6 focus:
      - Reduce 'silent swallowed exceptions' in brain update path (root-cause visibility)
      - Improve recall quality: store structured reflection cards (situation/action/result + signals)
      - Increase recall quantity modestly while staying bounded (pruning + hashing)
    """
    recent = [it for it in memory[-60:] if isinstance(it, dict) and it.get("evaluated") is True]
    if not recent:
        return
    avg_r = sum(float(it.get("reward_scalar", 0.0) or 0.0) for it in recent) / max(1, len(recent))

    # Unit 07: apply delayed reward updates to action_bias (idempotent per item)
    try:
        for it in recent[-60:]:
            if not isinstance(it, dict):
                continue
            # ensure proxy gets applied at least once (in case earlier immediate hook was skipped)
            if it.get("proxy_reward") is not None and it.get("brain_proxy_applied") is not True:
                apply_brain_proxy_update(brain, tuning, it)
            apply_brain_reward_update(brain, tuning, it)
    except Exception as e:
        log_exception("brain:update_bias", e, context={"recent_n": len(recent)})
        if _should_failfast("brain"):
            raise

    mood = brain.setdefault("mood", {})
    ema = float(mood.get("ema_reward", 0.0))
    a = float(tuning.brain_reward_alpha)
    mood["ema_reward"] = float((1 - a) * ema + a * avg_r)

    topic_ema = brain.setdefault("topic_ema", {})
    if not isinstance(topic_ema, dict):
        brain["topic_ema"] = {}
        topic_ema = brain["topic_ema"]

    ta = float(tuning.brain_topic_alpha)
    for it in memory[-40:]:
        if not isinstance(it, dict):
            continue
        kw = str(it.get("kw") or "")
        if not kw:
            continue
        topic_ema[kw] = float(topic_ema.get(kw, 0.0)) * (1 - ta) + ta * 1.0

    # belief update: reward-anchored stance signal per keyword
    beliefs = brain.setdefault("beliefs", {})
    if not isinstance(beliefs, dict):
        brain["beliefs"] = {}
        beliefs = brain["beliefs"]

    for it in recent[-35:]:
        kw = str(it.get("kw") or "")
        if not kw:
            continue
        r = float(it.get("reward_scalar", 0.0) or 0.0)
        b = beliefs.get(kw)
        if not isinstance(b, dict):
            b = {"score_ema": 0.0, "n": 0, "last_ts": 0.0}
        ema2 = float(b.get("score_ema", 0.0) or 0.0)
        aa = 0.08 + 0.04 * min(1.0, abs(r))
        b["score_ema"] = float((1 - aa) * ema2 + aa * r)
        b["n"] = int(b.get("n", 0)) + 1
        b["last_ts"] = time.time()
        beliefs[kw] = b

    # (P1) Reflection thoughts: store what worked (and what failed), then reuse via retrieval
    try:
        rh = brain.setdefault("reflection_hashes", [])
        if not isinstance(rh, list):
            brain["reflection_hashes"] = []
            rh = brain["reflection_hashes"]
        brain["reflection_hashes"] = _clean_hash_list(rh, ttl_sec=60 * 60 * 24 * 21, keep_max=2000)
        rh = brain["reflection_hashes"]
        added_pos = 0
        added_neg = 0
        max_pos = int(getattr(tuning, "reflection_add_max", 5) or 5)
        max_neg = int(getattr(tuning, "reflection_add_max_neg", 2) or 2)

        for it in recent[::-1]:
            if (added_pos >= max_pos) and (added_neg >= max_neg):
                break
            if str(it.get("action") or "") not in ("comment", "reply", "post"):
                continue
            r = float(it.get("reward_scalar", 0.0) or 0.0)

            # thresholds (keep conservative to reduce noise)
            is_pos = r >= 0.70
            is_neg = r <= -0.55
            if not (is_pos or is_neg):
                continue

            kw = str(it.get("kw") or "") or "reflection"
            act = str(it.get("action") or "")
            atype = str(it.get("action_type") or act)
            tone = str(it.get("used_tone") or "")
            strat = str(it.get("used_strategy") or "")
            rstyle = str(it.get("used_reply_style") or "")
            length = str(it.get("used_length") or "")
            pstyle = str(it.get("used_style") or "")

            txt = str(it.get("text") or "")
            if not txt:
                continue
            summ = _simple_summary(txt, 160)

            # build a compact structured card (situation/action/result)
            situation = kw
            if str(it.get("category") or ""):
                situation = f"{kw}/{str(it.get('category') or '')}"
            if it.get("weak_context"):
                situation = f"{situation}/weakctx"

            action_desc = atype
            if rstyle:
                action_desc += f" | reply_style={rstyle}"
            if strat:
                action_desc += f" | strategy={strat}"
            if pstyle:
                action_desc += f" | post_style={pstyle}"
            if tone:
                action_desc += f" | tone={tone}"
            if length:
                action_desc += f" | len={length}"

            result_desc = "good"
            if is_neg:
                result_desc = "bad"
            result_desc += f" | reward={r:.3f}"

            # stable hash (avoid duplicates)
            hsrc = f"{'P' if is_pos else 'N'}|{kw}|{atype}|{strat}|{rstyle}|{summ[:90]}"
            h = hashlib.sha1(hsrc.encode("utf-8")).hexdigest()[:12]
            if any(isinstance(x, list) and x and x[0] == h for x in rh):
                continue

            # text: keep as a readable one-liner for injection
            prefix = "기억(좋았음)" if is_pos else "기억(피해야함)"
            line = f"{prefix}: [{situation}] {action_desc} → {result_desc} | {summ}"

            tags = [kw, str(it.get("category") or ""), atype]
            # include arm-like tags to enable get_reflection_bias mapping
            for t in (strat, rstyle, tone, length, pstyle):
                if t:
                    tags.append(t)
            # include lightweight entity tags to improve retrieval (token overlap)
            tn = str(it.get("target_nick") or "")
            pid = str(it.get("post_id") or "")
            if tn:
                tags.append(f"user:{tn}")
            if pid:
                tags.append(f"thread:{pid}")

            add_thought(
                brain,
                kind=("reflection" if is_pos else "caution"),
                topic=kw,
                text=line,
                tags=tags,
                strength=min(0.98, 0.55 + 0.18 * min(1.0, abs(r))),
                links={"post_id": str(it.get("post_id") or ""), "action": act, "comment_id": str(it.get("comment_id") or "")},
                card={"situation": situation, "action": action_desc, "result": result_desc},
                signals={
                    "reward": float(r),
                    "novelty": float(it.get("novelty", 0.0) or 0.0),
                    "qa": float(it.get("qa_score", 0.0) or 0.0),
                    "weak_context": bool(it.get("weak_context")),
                },
                ctx={
                    "user": str(it.get("target_nick") or ""),
                    "thread": str(it.get("post_id") or ""),
                    "topic": kw,
                    "cat": str(it.get("category") or ""),
                    "template": str(it.get("template_id") or ""),
                    "context_key": str(it.get("context_key") or ""),
                },
            )
            rh.append([h, time.time()])
            if is_pos:
                added_pos += 1
            else:
                added_neg += 1

    except Exception as e:
        log_exception("brain:update_reflections", e, context={"recent_n": len(recent)})
        if _should_failfast("brain"):
            raise

def render_brain_note(brain: Dict[str, Any]) -> str:
    mood = _safe_dict(brain.get("mood"))
    ema = float(mood.get("ema_reward", 0.0))

    topic = _safe_dict(brain.get("topic_ema"))
    top_topics = sorted(topic.items(), key=lambda kv: kv[1], reverse=True)[:8]

    com = _safe_dict(brain.get("community"))
    hot = _safe_list(com.get("hot"))[:10]
    rising = _safe_list(com.get("rising"))[:8]

    beliefs = _safe_dict(brain.get("beliefs"))
    belief_rank = []
    for k, b in beliefs.items():
        if not isinstance(b, dict):
            continue
        belief_rank.append((k, float(b.get("score_ema", 0.0) or 0.0), int(b.get("n", 0) or 0)))
    belief_rank.sort(key=lambda x: abs(x[1]), reverse=True)
    belief_rank = belief_rank[:8]

    thoughts = _safe_list(brain.get("thoughts"))[-6:]

    lines: List[str] = []
    lines.append("# Brain Note")
    lines.append(f"- ema_reward: {ema:.3f}")

    if hot:
        lines.append("- hot:")
        for it in hot:
            if isinstance(it, dict):
                lines.append(f"  - {it.get('kw','')}: {float(it.get('score',0.0) or 0.0):.2f}")
    if rising:
        lines.append("- rising:")
        for it in rising:
            if isinstance(it, dict):
                lines.append(f"  - {it.get('kw','')}: +{float(it.get('delta',0.0) or 0.0):.2f}")

    if top_topics:
        lines.append("- topic_ema:")
        for k, v in top_topics:
            lines.append(f"  - {k}: {float(v):.3f}")

    if belief_rank:
        lines.append("- beliefs (reward-tilt):")
        for k, sc, n in belief_rank:
            lines.append(f"  - {k}: {sc:+.2f} (n={n})")

    if thoughts:
        lines.append("- recent_thoughts:")
        for t in thoughts:
            if not isinstance(t, dict):
                continue
            lines.append(f"  - [{t.get('kind','')}] {t.get('topic','')}: {t.get('text','')}")

    return "\n".join(lines) + "\n\n"
