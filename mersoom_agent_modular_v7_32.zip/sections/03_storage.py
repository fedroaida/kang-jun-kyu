################################################################################
# 03. STORAGE (JSON/TXT/JSONL)
# Deps: 01-02 (Config, Logging)
# Used by: most sections
# Notes: Atomic saves + safe loads + backups.
################################################################################
"""
SECTION 03 - STORAGE (LOAD/SAVE)

Atomic JSON/text persistence helpers.

Responsibilities:
- Load JSON with corruption tolerance (defaults, backups).
- Atomic writes (write temp -> fsync -> replace) to prevent partial files.

Why it matters:
- The agent's "brain" is mostly local files; storage must be robust.
"""
def load_json_file(path: str, default: Any) -> Any:
    if not path or not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        # (P2) If JSON is corrupted (manual edit / partial write), back it up and continue with default.
        try:
            base_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            ms = int((time.time() % 1.0) * 1000.0)
            bak = f"{path}.corrupt.{base_ts}_{ms:03d}"
            if os.path.exists(bak):
                # Ensure uniqueness (avoid name collision within the same second).
                for i in range(1, 1000):
                    cand = f"{bak}_{i}"
                    if not os.path.exists(cand):
                        bak = cand
                        break
            moved = False
            try:
                os.replace(path, bak)
                moved = True
            except Exception:
                moved = False
            if moved:
                log_warn(f"JSON load failed; moved to backup: {bak} ({one_line(repr(e), 160)})")
            else:
                log_warn(f"JSON load failed; backup move failed: {path} ({one_line(repr(e), 160)})")
        except Exception as e2:
            log_debug_exc("load_json_file:silent", e2)
            try:
                log_warn(f"JSON load failed: {path} ({one_line(repr(e), 160)})")
            except Exception:
                pass
        return default


# ----------------------------------------------------------------------------- 
# SCHEMA BACKUP (RC4)
# - To avoid irreversible issues during final schema stabilization, we optionally
#   back up JSON artifacts when __meta__.schema_version changes.
# -----------------------------------------------------------------------------
_SCHEMA_BACKUP_DONE: set[str] = set()

def ensure_parent_dir(path: str) -> None:
    """Ensure parent directory exists (best-effort).

    This makes it safe to default derived files into ./runtime/... without requiring
    manual folder creation.
    """
    try:
        p = str(path or '')
        if not p:
            return
        d = os.path.dirname(os.path.abspath(p))
        if d and d not in ('.', os.path.abspath('.')):
            os.makedirs(d, exist_ok=True)
    except Exception:
        return


def _schema_version_of(obj: Any) -> int:
    try:
        if not isinstance(obj, dict):
            return 0
        m = obj.get("__meta__")
        if not isinstance(m, dict):
            return 0
        return int(m.get("schema_version") or 0)
    except Exception:
        return 0

def _schema_version_in_file(path: str) -> int:
    try:
        if not path or not os.path.exists(path):
            return 0
        with open(path, "r", encoding="utf-8") as f:
            obj = json.load(f)
        return _schema_version_of(obj)
    except Exception:
        return 0

def _maybe_backup_on_schema_change(path: str, new_obj: Any) -> None:
    # default-on; can be disabled for power users
    if not _env_bool("MERSOOM_SCHEMA_BACKUP", True):
        return
    if not path or not os.path.exists(path):
        return
    # size guard (avoid huge copies by default)
    try:
        max_mb = float(os.getenv("MERSOOM_SCHEMA_BACKUP_MAX_MB", "50").strip() or "50")
        if max_mb > 0:
            sz = float(os.path.getsize(path))
            if sz > max_mb * 1024.0 * 1024.0:
                log_warn(f"schema backup skipped (too large): {path} ({sz/1024.0/1024.0:.1f} MB)")
                _SCHEMA_BACKUP_DONE.add(path)
                return
    except Exception as e:
        log_debug_exc("schema_backup_size:silent", e)
        pass
    # avoid repeated backups in the same process
    if path in _SCHEMA_BACKUP_DONE:
        return
    try:
        old_v = _schema_version_in_file(path)
        new_v = _schema_version_of(new_obj)
        # If either side has no schema marker, treat as a change worth backing up once.
        if old_v != new_v:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            bak = f"{path}.bak.schema{old_v}_to_{new_v}.{ts}"
            try:
                import shutil
                shutil.copy2(path, bak)
                log_warn(f"schema backup created: {bak}")
            except Exception as e:
                log_debug_exc("schema_backup:silent", e)
                pass
        _SCHEMA_BACKUP_DONE.add(path)
    except Exception as e:
        log_debug_exc("schema_backup_outer:silent", e)
        _SCHEMA_BACKUP_DONE.add(path)
        pass

def _atomic_replace(tmp_path: str, final_path: str) -> None:
    os.replace(tmp_path, final_path)

def _tmp_path_for_atomic_write(final_path: str) -> str:
    """Unique temp path for atomic writes (reduces collision risk across runs)."""
    try:
        pid = int(os.getpid())
    except Exception:
        pid = 0
    try:
        rnd = int(random.randint(0, 1_000_000_000))
    except Exception:
        rnd = int(time.time() * 1_000_000) % 1_000_000_000
    return f"{final_path}.tmp.{pid}.{rnd}"

def save_text_file_atomic(path: str, text: str, *, fsync: bool = False) -> None:
    if not path:
        return
    ensure_parent_dir(path)
    tmp = _tmp_path_for_atomic_write(path)
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
        if fsync:
            try:
                f.flush()
                os.fsync(f.fileno())
            except Exception as e:
                log_debug_exc("save_text_file_atomic:silent", e)
                pass
    _atomic_replace(tmp, path)

def save_json_file_atomic(path: str, obj: Any, *, fsync: bool = False) -> None:
    if not path:
        return
    ensure_parent_dir(path)
    # RC4: optional one-time backup when schema stamp changes
    try:
        _maybe_backup_on_schema_change(path, obj)
    except Exception as e:
        log_debug_exc("schema_backup_call:silent", e)
        pass
    tmp = _tmp_path_for_atomic_write(path)
    compact = _env_bool("MERSOOM_JSON_COMPACT", False)
    indent = _env_int("MERSOOM_JSON_INDENT", 2, 0, 8)
    if compact:
        js_indent = None
        js_separators = (",", ":")
    else:
        js_indent = (indent if indent > 0 else None)
        js_separators = None

    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=js_indent, separators=js_separators)
        if fsync:
            try:
                f.flush()
                os.fsync(f.fileno())
            except Exception as e:
                log_debug_exc("save_json_file_atomic:silent", e)
                pass
    _atomic_replace(tmp, path)



def _apply_stamp(obj: Any, stamp: Dict[str, Any]) -> None:
    """Best-effort attach a generation stamp to a dict under '__meta__'."""
    try:
        if isinstance(obj, dict):
            m = obj.get("__meta__")
            if not isinstance(m, dict):
                m = {}
                obj["__meta__"] = m
            m.update(_safe_dict(stamp))
    except Exception as e:
        log_debug_exc("_apply_stamp:silent", e)
        pass

def _make_tick_stamp(state: Dict[str, Any]) -> Dict[str, Any]:
    """Stamp written into __meta__ of persisted artifacts."""
    try:
        return {
            "tick_id": int(state.get("tick_id", 0) or 0),
            "ts": float(time.time()),
            "ts_kst": now_kst_str(),
            "schema_version": int(AGENT_SCHEMA_VERSION),
            "build": AGENT_BUILD_TAG,
            "release": AGENT_RELEASE_TAG,
        }
    except Exception:
        return {"tick_id": 0, "ts": float(time.time()), "ts_kst": now_kst_str(), "schema_version": int(AGENT_SCHEMA_VERSION), "build": AGENT_BUILD_TAG, "release": AGENT_RELEASE_TAG}

def _make_persist_gen() -> str:
    """Return a unique persist generation id for this save batch."""
    try:
        return f"{int(time.time()*1000)}-{os.getpid()}-{random.randint(1000,9999)}"
    except Exception:
        return str(int(time.time()*1000))


def _meta_tick_id(obj: Any) -> int:
    try:
        if not isinstance(obj, dict):
            return 0
        m = obj.get("__meta__")
        if not isinstance(m, dict):
            return 0
        return int(m.get("tick_id") or 0)
    except Exception:
        return 0

def _meta_ts(obj: Any) -> float:
    try:
        if not isinstance(obj, dict):
            return 0.0
        m = obj.get("__meta__")
        if not isinstance(m, dict):
            return 0.0
        return float(m.get("ts") or 0.0)
    except Exception:
        return 0.0


def append_text_file(path: str, text: str) -> None:
    if not path:
        return
    try:
        # (Unit 13) journal/append reliability: flush each write; optional fsync.
        line_buffered = str(os.getenv("MERSOOM_JOURNAL_LINE_BUFFERED", "true")).strip().lower() in ("1", "true", "yes", "y")
        do_fsync = str(os.getenv("MERSOOM_JOURNAL_FSYNC", "false")).strip().lower() in ("1", "true", "yes", "y")
        buffering = 1 if line_buffered else -1
        with open(path, "a", encoding="utf-8", buffering=buffering) as f:
            f.write(text)
            try:
                f.flush()
            except Exception as e:
                log_debug_exc("append_text_file:silent", e)
                pass
            if do_fsync:
                try:
                    os.fsync(f.fileno())
                except Exception as e:
                    log_debug_exc("append_text_file:silent", e)
                    pass
    except Exception as e:
        log_debug_exc("append_text_file:silent", e)
        pass

_JSONL_BUFFERS: Dict[str, List[str]] = {}
_JSONL_LAST_FLUSH_TS: Dict[str, float] = {}
_JSONL_DROPPED_LINES: Dict[str, int] = {}
_JSONL_DROPPED_BYTES: Dict[str, int] = {}
_JSONL_DROPPED_LAST_LOG_TS: Dict[str, float] = {}
try:
    atexit.register(lambda: [_flush_jsonl_buffer(p, force=True) for p in list(_JSONL_BUFFERS.keys())])
except Exception:
    pass


def _flush_jsonl_buffer(path: str, *, force: bool = False) -> None:
    if not path:
        return
    buf = _JSONL_BUFFERS.get(path)
    if not buf:
        return
    try:
        flush_sec = float(_env_float("MERSOOM_JSONL_FLUSH_SEC", 2.0, 0.0, 60.0))
        now = time.time()
        last = float(_JSONL_LAST_FLUSH_TS.get(path, 0.0) or 0.0)
        if (not force) and flush_sec > 0.0 and (now - last) < flush_sec and len(buf) < max(1, _env_int("MERSOOM_JSONL_BUFFER_MAX", 0, 0, 10000)):
            return
        ensure_parent_dir(path)
        with open(path, "a", encoding="utf-8") as f:
            f.write("".join(buf))
        buf.clear()
        _JSONL_LAST_FLUSH_TS[path] = now
    except Exception as e:
        log_debug_exc("_flush_jsonl_buffer:silent", e)
        pass

def _jsonl_note_dropped(path: str, dropped_lines: int, dropped_bytes: int) -> None:
    """Best-effort record JSONL buffer overflow drops for visibility (no behavior change)."""
    try:
        p = str(path or "")
        if not p:
            return
        dl = int(dropped_lines or 0)
        db = int(dropped_bytes or 0)
        if dl <= 0 and db <= 0:
            return
        _JSONL_DROPPED_LINES[p] = int(_JSONL_DROPPED_LINES.get(p, 0) or 0) + max(0, dl)
        _JSONL_DROPPED_BYTES[p] = int(_JSONL_DROPPED_BYTES.get(p, 0) or 0) + max(0, db)

        # rate-limited warning
        now_ts = float(time.time())
        last = float(_JSONL_DROPPED_LAST_LOG_TS.get(p, 0.0) or 0.0)
        if now_ts - last >= float(_env_float("MERSOOM_JSONL_DROP_LOG_INTERVAL_SEC", 60.0, min_v=5.0, max_v=3600.0)):
            _JSONL_DROPPED_LAST_LOG_TS[p] = now_ts
            log_warn(f"jsonl buffer overflow: dropped {dl} lines (~{db} bytes) for {p}")
    except Exception:
        return


def _jsonl_drain_drop_stats() -> Dict[str, Any]:
    """Drain and reset JSONL drop stats."""
    try:
        out: Dict[str, Any] = {"lines": 0, "bytes": 0, "paths": {}}
        paths = set(list(_JSONL_DROPPED_LINES.keys()) + list(_JSONL_DROPPED_BYTES.keys()))
        total_l = 0
        total_b = 0
        per: Dict[str, Any] = {}
        for p in paths:
            dl = int(_JSONL_DROPPED_LINES.pop(p, 0) or 0)
            db = int(_JSONL_DROPPED_BYTES.pop(p, 0) or 0)
            if dl or db:
                per[p] = {"lines": dl, "bytes": db}
            total_l += dl
            total_b += db
        out["lines"] = total_l
        out["bytes"] = total_b
        out["paths"] = per
        return out
    except Exception:
        return {"lines": 0, "bytes": 0, "paths": {}}


def append_jsonl(path: str, obj: Any) -> None:
    if not path:
        return
    try:
        ensure_parent_dir(path)
        line = json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n"
        max_buf = _env_int("MERSOOM_JSONL_BUFFER_MAX", 0, 0, 10000)
        if max_buf <= 0:
            with open(path, "a", encoding="utf-8") as f:
                f.write(line)
            return

        buf = _JSONL_BUFFERS.setdefault(path, [])
        buf.append(line)
        # Safety: if flush keeps failing, keep buffer bounded to avoid unbounded RAM growth
        if len(buf) > max_buf * 2:
            # drop oldest lines to keep RAM bounded (visibility via counters/log)
            try:
                drop_n = max(0, len(buf) - max_buf)
                if drop_n > 0:
                    try:
                        drop_bytes = int(sum(len(x) for x in buf[:drop_n]))
                    except Exception:
                        drop_bytes = int(drop_n * 64)
                    _jsonl_note_dropped(path, drop_n, drop_bytes)
            except Exception:
                pass
            del buf[:-max_buf]
        if len(buf) >= max_buf:
            _flush_jsonl_buffer(path, force=True)
        else:
            _flush_jsonl_buffer(path, force=False)
    except Exception as e:
        log_debug_exc("append_jsonl:silent", e)
        pass
