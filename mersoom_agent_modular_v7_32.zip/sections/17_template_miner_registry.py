################################################################################
# 17. TEMPLATE MINER & REGISTRY
# Deps: 01-03, 11, 16
# Used by: generation
# Notes: Template extraction/registry for reuse.
################################################################################
"""
SECTION 17 - TEMPLATE MINER / REGISTRY

Template registry and mining helpers.

Responsibilities:
- Store and retrieve reusable templates.
- Register mined templates with metadata.
- Provide deterministic IDs for templates.

Notes:
- Templates are intentionally simple (no LLM); keep them legible and safe.
"""
def register_mined_template(policy: Dict[str, Any], template_text: str, meta: Optional[Dict[str, Any]] = None) -> str:
    """Register a mined template with quality scoring + v20.5 2nd QA gate + near-dup checks.

    - Step 1: template_static_eval() gate (cheap + stable)
    - Step 2: QA 2nd-pass gate on rendered sample (hard-fail/length/etc)
    - Step 3: near-dup checks vs existing templates (fp + jaccard/3gram)
    - Rejections are recorded under templates.rejected_templates for tuning.
    """
    t = (template_text or "").strip()
    if not t:
        return ""

    temps = _safe_dict(policy.get("templates", {}))
    qcfg = _safe_dict(temps.get("quality", {}))
    min_static = int(qcfg.get("min_mine_score", 52) or 52)
    min_qa2 = int(qcfg.get("min_mine_qa2_score", 60) or 60)

    # rejection ledger (bounded)
    rej = policy.setdefault("templates", {}).setdefault("rejected_templates", [])
    def _reject(reason: str, extra: Optional[Dict[str, Any]] = None) -> str:
        try:
            rec = {
                "ts": time.time(),
                "reason": str(reason or "unknown"),
                "text": t[:420],
                "meta": meta or {},
                "extra": extra or {},
            }
            rej.append(rec)
            if len(rej) > 500:
                del rej[:-500]
        except Exception:
            pass
        return ""

    rep = template_static_eval(t)
    static_score = int(rep.get("score", 0) or 0)
    if static_score < min_static:
        return _reject("static_low", {"static_score": static_score, "issues": list(rep.get("issues", []) or [])[:12]})

    # 2nd QA: run on a rendered sample so braces/slots don't hide issues
    sample = t
    sample = sample.replace("{KW}", "그거")
    sample = sample.replace("{QUOTE}", "“인용”")
    sample = sample.replace("{Q}", "이거 어떻게 봄")
    qa2 = qa_evaluate_text(sample, kind="comment")
    qa2_score = int(qa2.get("score", 0) or 0)
    qa2_issues = list(qa2.get("issues", []) or [])[:16]
    if qa2.get("hard_fail") is True:
        return _reject("qa2_hard_fail", {"qa2_score": qa2_score, "qa2_issues": qa2_issues})

    # "language rules violations 0" (hard subset)
    for bad in ("injection", "offensive", "markdown"):
        if bad in qa2_issues:
            return _reject(f"qa2_violation:{bad}", {"qa2_score": qa2_score, "qa2_issues": qa2_issues})

    if qa2_score < min_qa2:
        return _reject("qa2_low", {"qa2_score": qa2_score, "qa2_issues": qa2_issues, "min_qa2": min_qa2})

    items = policy.setdefault("templates", {}).setdefault("items", {})

    # exact-id dedupe (same text)
    tid = hashlib.sha1(t.encode("utf-8")).hexdigest()[:12]
    if tid in items:
        obj = items.get(tid)
        if isinstance(obj, dict):
            obj.setdefault("static_score", static_score)
            obj.setdefault("static_issues", list(rep.get("issues", []) or []))
            obj.setdefault("static_checked_ts", float(rep.get("checked_ts", time.time())))
            obj.setdefault("qa2_score", qa2_score)
            obj.setdefault("qa2_issues", qa2_issues)
            obj.setdefault("qa2_checked_ts", time.time())
        return tid

    # near-dup vs existing templates
    fp_new = _text_fp(t)
    j_th = float(_env_float("MERSOOM_SIM_JACCARD_TH", 0.70, min_v=0.0, max_v=1.0))
    g_th = float(_env_float("MERSOOM_SIM_3GRAM_TH", 0.82, min_v=0.0, max_v=1.0))
    cur_kw = _sig_keywords(sample, k=12) if j_th > 0.0 else []
    cur_g = _sig_3grams(sample, max_ngrams=256) if g_th > 0.0 else []

    # limit comparisons for cost control
    cand: List[Tuple[float, str, Dict[str, Any]]] = []
    for otid, oobj in list(_safe_dict(items).items()):
        if not isinstance(oobj, dict):
            continue
        try:
            ts = float(oobj.get("created_ts", 0.0) or 0.0)
        except Exception:
            ts = 0.0
        cand.append((ts, str(otid), oobj))
    cand.sort(key=lambda x: x[0], reverse=True)
    cand = cand[:240]

    for _, otid, oobj in cand:
        try:
            otext = str(oobj.get("text") or "")
            if not otext:
                continue
            if _text_fp(otext) == fp_new:
                return _reject("dup_fp_template", {"dup_tid": otid})
        except Exception:
            continue

    if j_th > 0.0 and cur_kw:
        for _, otid, oobj in cand:
            try:
                otext = str(oobj.get("text") or "")
                os = otext.replace("{KW}", "그거").replace("{QUOTE}", "“인용”").replace("{Q}", "이거 어떻게 봄")
                okw = _sig_keywords(os, k=12)
                if okw and _jaccard_ratio(cur_kw[:12], okw[:12]) >= j_th:
                    return _reject("dup_sim_jaccard", {"dup_tid": otid, "th": j_th})
            except Exception:
                continue

    if g_th > 0.0 and cur_g:
        for _, otid, oobj in cand:
            try:
                otext = str(oobj.get("text") or "")
                os = otext.replace("{KW}", "그거").replace("{QUOTE}", "“인용”").replace("{Q}", "이거 어떻게 봄")
                og = _sig_3grams(os, max_ngrams=256)
                if og and _jaccard_ratio(cur_g[:256], og[:256]) >= g_th:
                    return _reject("dup_sim_3gram", {"dup_tid": otid, "th": g_th})
            except Exception:
                continue

    # register
    items[tid] = {
        "text": t,
        "weight": 1.0,
        "meta": meta or {},
        "created_ts": time.time(),
        "uses": 0,

        # Unit 08 stats
        "static_score": static_score,
        "static_issues": list(rep.get("issues", []) or []),
        "static_checked_ts": float(rep.get("checked_ts", time.time())),
        "eval_uses": 0,
        "reward_ema": 0.0,
        "qa_ema": 0.75,
        "artifact_ema": 0.0,

        "qa2_score": int(qa2_score),
        "qa2_issues": qa2_issues,
        "qa2_checked_ts": time.time(),
    }
    return tid



def render_template(template_text: str, *, kw: str, quote: str, question: str) -> str:
    t = template_text
    t = t.replace("{KW}", kw or "그거")
    t = t.replace("{QUOTE}", quote or "맥락이 비어있음")
    t = t.replace("{Q}", question or "이거 어떻게 봄")
    return t
