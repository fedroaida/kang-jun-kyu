################################################################################
# 11. QUALITY GATE
# Deps: 01-03, 08
# Used by: generation + posting
# Notes: dup/ground/QA gates + text hygiene.
################################################################################
"""
SECTION 11 - QUALITY GATE (TEXT FILTERS)

Final quality checks for generated text.

Responsibilities:
- Detect banned phrases, excessive repetition, awkward formatting, over-ellipsis, etc.
- Produce a score + issues list used to decide accept/reject.
- Keep behavior conservative: prefer safe fallback rather than posting low-quality text.

Debug tips:
- If agent becomes silent, check whether gates are rejecting too aggressively.
"""
_QA_BANNED_PHRASES: Tuple[str, ...] = (
    "본문 요지는",
    "내쪽 생각은",
    "쪽임",
    "내 기준에선",
)

_QA_SOFT_BANNED_PATTERNS: Tuple[str, ...] = (
    r"\b전제\s*하나만\s*확인\b",
    r"\b여기서\s*정의부터\b",
)

def _regen_budget(cfg: Config) -> int:
    """Unified regen budget for text generation loops."""
    b = int(cfg.timing.max_text_regen_tries)
    try:
        if getattr(cfg, "quality", None) is not None and bool(cfg.quality.enabled):
            b = max(b, int(cfg.quality.max_tries))
    except Exception as e:
        log_debug_exc("_regen_budget:silent", e)
        pass
    return max(1, int(b))

def _qa_ngrams(tokens: List[str], n: int) -> List[Tuple[str, ...]]:
    if n <= 0 or len(tokens) < n:
        return []
    return [tuple(tokens[i:i+n]) for i in range(0, len(tokens) - n + 1)]

def _qa_ngram_repeat_ratio(tokens: List[str], n: int = 3) -> float:
    grams = _qa_ngrams(tokens, n)
    if not grams:
        return 0.0
    c = Counter(grams)
    most = max(c.values()) if c else 0
    return float(most) / float(len(grams))

def _qa_line_prefix_dup_ratio(lines: List[str], k: int = 12) -> float:
    if not lines:
        return 0.0
    pref = []
    for ln in lines:
        s = (ln or "").strip()
        if not s:
            continue
        pref.append(s[:k])
    if len(pref) <= 1:
        return 0.0
    c = Counter(pref)
    most = max(c.values()) if c else 0
    return float(most) / float(len(pref))

def _qa_im_ending_ratio(lines: List[str]) -> float:
    if not lines:
        return 0.0
    cnt = 0
    tot = 0
    for ln in lines:
        s = (ln or "").strip()
        if not s:
            continue
        tot += 1
        if re.search(r"(?:임|임\.|임\?|임!|임\…)$", s):
            cnt += 1
    if tot <= 0:
        return 0.0
    return float(cnt) / float(tot)

def qa_evaluate_text(text: str, *, kind: str, focus: Optional[Dict[str, Any]] = None, mode: str = "comment") -> Dict[str, Any]:
    """Return a QA report dict with score + issues.

    kind: "comment" | "reply" | "post_title" | "post_body"
    """
    t = (text or "").strip()
    issues: List[str] = []
    hard_fail = False

    if not t:
        return {"score": 0, "hard_fail": True, "issues": ["empty"], "len": 0}

    # Hard bans (reported here too)
    if looks_like_injection(t):
        hard_fail = True
        issues.append("injection")
    if looks_offensive(t):
        hard_fail = True
        issues.append("offensive")
    if contains_markdown(t):
        hard_fail = True
        issues.append("markdown")

    # Length heuristic (soft)
    L = len(t)
    if kind in ("comment", "reply"):
        if L < 20:
            issues.append("too_short")
        if L > 420:
            issues.append("too_long")
    elif kind == "post_title":
        if L < 4:
            issues.append("title_too_short")
        if L > 70:
            issues.append("title_too_long")
    elif kind == "post_body":
        if L < 80:
            issues.append("body_too_short")
        if L > 1600:
            issues.append("body_too_long")

    # Phrase artifacts (soft)
    lt = sanitize_plain_text(t).lower()
    for ph in _QA_BANNED_PHRASES:
        if ph and ph.lower() in lt:
            issues.append("banned_phrase")
            break

    for pat in _QA_SOFT_BANNED_PATTERNS:
        try:
            if re.search(pat, t):
                issues.append("overused_opener")
                break
        except re.error:
            pass

    if t.count("...") >= 1 or "……" in t or "…" in t:
        issues.append("ellipsis")

    # Repetition metrics
    toks = tokenize(t, max_tokens=220)
    uniq_ratio = (len(set(toks)) / float(len(toks))) if toks else 1.0
    rep3 = _qa_ngram_repeat_ratio(toks, 3)

    lines = [x for x in t.splitlines() if (x or "").strip()]
    im_ratio = _qa_im_ending_ratio(lines)
    pref_dup = _qa_line_prefix_dup_ratio(lines, 12)

    # Score (simple additive penalties)
    score = 100.0
    if hard_fail:
        score -= 60.0

    if "too_short" in issues:
        score -= 18.0
    if "too_long" in issues:
        score -= 10.0
    if "title_too_short" in issues:
        score -= 20.0
    if "title_too_long" in issues:
        score -= 8.0
    if "body_too_short" in issues:
        score -= 18.0
    if "body_too_long" in issues:
        score -= 12.0

    if "banned_phrase" in issues:
        score -= 25.0
    if "overused_opener" in issues:
        score -= 10.0
    if "ellipsis" in issues:
        score -= 6.0

    if uniq_ratio < 0.55 and len(toks) >= 30:
        issues.append("low_vocab_variety")
        score -= 14.0
    if rep3 >= 0.18 and len(toks) >= 35:
        issues.append("ngram_repeat")
        score -= 18.0
    if pref_dup >= 0.34 and len(lines) >= 3:
        issues.append("line_prefix_repeat")
        score -= 10.0
    if im_ratio >= 0.72 and len(lines) >= 3:
        issues.append("too_many_im_endings")
        score -= 12.0

    # Focus overlap (optional; mild)
    try:
        if isinstance(focus, dict) and focus:
            ok_g, _ = validate_grounding(t, focus, mode)
            if ok_g:
                score += 2.0
            else:
                score -= 6.0
                issues.append("weak_grounding")
    except Exception as e:
        log_debug_exc("qa_evaluate_text:silent", e)
        pass

    # Frequent-issue penalty boost (from QA batch stats; optional)
    boost_pen = 0.0
    try:
        if isinstance(focus, dict) and focus:
            qb = _safe_dict(focus.get("qa_issue_boost"))
            if qb:
                for iss in issues:
                    try:
                        boost_pen += float(qb.get(iss, 0.0) or 0.0)
                    except Exception:
                        continue
                if boost_pen:
                    score -= min(18.0, float(boost_pen))
    except Exception:
        boost_pen = 0.0

    score = max(0, min(100, score))
    return {
        "score": int(round(score)),
        "hard_fail": bool(hard_fail),
        "issues": issues,
        "len": L,
        "uniq_ratio": round(float(uniq_ratio), 3),
        "rep3": round(float(rep3), 3),
        "im_ratio": round(float(im_ratio), 3),
        "line_prefix_dup": round(float(pref_dup), 3),
        "boost_pen": round(float(boost_pen), 2),
    }

def qa_check_text(cfg: Config, text: str, *, kind: str, focus: Optional[Dict[str, Any]] = None, mode: str = "comment") -> Tuple[bool, Dict[str, Any]]:
    """Gate outgoing comment/reply text. If gate disabled, always ok."""
    if getattr(cfg, "quality", None) is None or not bool(cfg.quality.enabled):
        return True, {"score": 100, "hard_fail": False, "issues": []}
    rep = qa_evaluate_text(text, kind=kind, focus=focus, mode=mode)
    ok = (not rep.get("hard_fail")) and int(rep.get("score", 0)) >= int(cfg.quality.min_score)
    return bool(ok), rep

def qa_check_post(cfg: Config, title: str, body: str) -> Tuple[bool, Dict[str, Any]]:
    if getattr(cfg, "quality", None) is None or not bool(cfg.quality.enabled):
        return True, {"score": 100, "hard_fail": False, "issues": []}
    r1 = qa_evaluate_text(title, kind="post_title")
    r2 = qa_evaluate_text(body, kind="post_body")
    score = int(round(0.25 * int(r1.get("score", 0)) + 0.75 * int(r2.get("score", 0))))
    issues = list(dict.fromkeys(list(r1.get("issues", [])) + list(r2.get("issues", []))))
    hard_fail = bool(r1.get("hard_fail")) or bool(r2.get("hard_fail"))
    rep = {"score": score, "hard_fail": hard_fail, "issues": issues, "title": r1, "body": r2}
    ok = (not hard_fail) and score >= int(cfg.quality.min_score)
    return bool(ok), rep

def final_text_gate(
    cfg: Config,
    state: Dict[str, Any],
    text: str,
    *,
    mode: str,
    kind: str,
    focus: Optional[Dict[str, Any]] = None,
    same_text_gap_sec: int,
) -> Tuple[bool, str, str, str, Dict[str, Any]]:
    """Unified final gate for comment/reply text.

    Returns: (ok, bucket, detail, ground_reason, qrep)
    - bucket: 'dup_fp'/'dup_sim'/'qa_fail' (canonical; caller may normalize)
    - detail: short reason ('ground:...' or 'qa:score=... issues=...')
    - ground_reason: validate_grounding reason (useful for analytics)
    """
    t = str(text or "")
    trace_hit("gate:text:enter")
    # 1) dup/spam gate
    try:
        dup, db = dup_guard_bucket(state, t, for_post=False, same_text_gap_sec=int(same_text_gap_sec))
    except Exception as e:
        trace_hit("gate:text:fail:dup_exc")
        return (False, "qa_fail", f"dup_exc:{type(e).__name__}", "", {})
    if dup:
        b = str(db or "qa_fail")
        trace_hit(f"gate:text:fail:{b}")
        return (False, b, b, "", {})

    # 2) grounding gate (soft when focus is weak)
    focus_d = _safe_dict(focus or {})
    try:
        ok_g, reason = validate_grounding(t, focus_d, str(mode or "comment"))
    except Exception as e:
        trace_hit("gate:text:fail:ground_exc")
        return (False, "qa_fail", f"ground_exc:{type(e).__name__}", "", {})
    if not ok_g:
        r = str(reason or "fail")
        trace_hit("gate:text:fail:ground")
        return (False, "qa_fail", f"ground:{one_line(r, 120)}", r, {})

    # 3) QA gate
    try:
        ok_q, qrep = qa_check_text(cfg, t, kind=str(kind or mode or "comment"), focus=focus_d, mode=str(mode or "comment"))
    except Exception as e:
        trace_hit("gate:text:fail:qa_exc")
        return (False, "qa_fail", f"qa_exc:{type(e).__name__}", str(reason or ""), {})
    if not ok_q:
        trace_hit("gate:text:fail:qa")
        try:
            issues = (qrep.get("issues", []) or [])[:3]
            detail = f"qa:score={qrep.get('score')} issues={','.join(issues)}"
        except Exception:
            detail = "qa_fail"
        return (False, "qa_fail", detail, str(reason or ""), _safe_dict(qrep))

    trace_hit("gate:text:pass")
    return (True, "", "", str(reason or ""), _safe_dict(qrep))


def final_post_gate(
    cfg: Config,
    state: Dict[str, Any],
    title: str,
    body: str,
    combo: str,
    *,
    same_text_gap_sec: int,
) -> Tuple[bool, str, str, Dict[str, Any]]:
    """Unified final gate for post (title/body). Returns (ok, bucket, detail, qrep)."""
    c = str(combo or "")
    trace_hit("gate:post:enter")
    try:
        dup, db = dup_guard_bucket(state, c, for_post=True, same_text_gap_sec=int(same_text_gap_sec))
    except Exception as e:
        trace_hit("gate:post:fail:dup_exc")
        return (False, "qa_fail", f"dup_exc:{type(e).__name__}", {})
    if dup:
        b = str(db or "qa_fail")
        trace_hit(f"gate:post:fail:{b}")
        return (False, b, b, {})
    try:
        ok_q, qrep = qa_check_post(cfg, str(title or ""), str(body or ""))
    except Exception as e:
        trace_hit("gate:post:fail:qa_exc")
        return (False, "qa_fail", f"qa_exc:{type(e).__name__}", {})
    if not ok_q:
        trace_hit("gate:post:fail:qa")
        try:
            issues = (qrep.get("issues", []) or [])[:3]
            detail = f"qa:score={qrep.get('score')} issues={','.join(issues)}"
        except Exception:
            detail = "qa_fail"
        return (False, "qa_fail", detail, _safe_dict(qrep))
    trace_hit("gate:post:pass")
    return (True, "", "", _safe_dict(qrep))

def qa_run_batch_report(
    client: HttpClient,
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    policy: Dict[str, Any],
    semantic: Dict[str, Any],
    brain: Dict[str, Any],
    bm25: Optional["BM25Index"],
) -> Dict[str, Any]:
    """Run a lightweight QA batch: generate texts, score them, summarize stats."""
    n = int(getattr(cfg.quality, "batch_n", 50) if getattr(cfg, "quality", None) else 50)
    n = max(1, min(500, n))

    report: Dict[str, Any] = {
        "ts_kst": now_kst_str(),
        "n": n,
        "dry_run": bool(cfg.http.dry_run),
        "min_score": int(getattr(cfg.quality, "min_score", 72) if getattr(cfg, "quality", None) else 72),
        "samples": [],
    }

    posts: List[Dict[str, Any]] = []
    try:
        posts, _ = list_posts(client, limit=min(60, max(20, int(tuning.fetch_limit) * 3)))
    except Exception as e:
        log_debug_exc("qa:list_posts", e)

    n_post = max(1, int(round(n * 0.25)))
    n_comment = max(0, n - n_post)

    # 1) comment/reply samples from live posts
    for _i in range(n_comment):
        p = random.choice(posts) if posts else {}
        pid = str(p.get("id") or p.get("post_id") or p.get("_id") or "")
        if not pid:
            continue

        try:
            p_full = get_post(client, pid) or p
        except Exception:
            p_full = p

        comments: List[Dict[str, Any]] = []
        try:
            comments = list_comments(client, pid)
        except Exception:
            comments = []

        # pick comment vs reply
        parent_id = ""
        target_c: Optional[Dict[str, Any]] = None
        if comments and random.random() < 0.55:
            cand = [c for c in comments if isinstance(c, dict) and str(c.get("text") or "").strip()]
            target_c = random.choice(cand) if cand else random.choice(comments)
            parent_id = str(target_c.get("id") or "")

        ingest_post_into_context(state, p_full, brain=brain)
        ingest_comments_into_context(state, pid, comments, brain=brain, cfg=cfg)
        th = get_thread(state, pid)
        synthesize_thread(th)

        user_key = str((target_c or {}).get("nickname") or p_full.get("nickname") or "user")
        user = get_user(state, user_key)

        set_focus(state, mode=("reply" if parent_id else "comment"), post_id=pid, post=p_full, comment=target_c if parent_id else None)

        txt, meta = build_reply_text(
            cfg, tuning, state, policy, th, user,
            bm25=bm25,
            brain=brain,
            reply_to_own_post=False,
            is_reply=bool(parent_id),
        )
        mode2 = "reply" if bool(parent_id) else "comment"
        ok, rep = qa_check_text(cfg, txt, kind=mode2, focus=_safe_dict(state.get("focus")), mode=mode2)
        report["samples"].append({
            "kind": mode2,
            "ok": bool(ok),
            "score": int(rep.get("score", 0)),
            "issues": rep.get("issues", []),
            "meta": {"strategy": meta.get("strategy"), "cat": meta.get("cat")},
            "text": one_line(txt, 280),
        })

    # 2) post samples (title+body)
    for _i in range(n_post):
        title, body, meta = build_post_text(cfg, tuning, state, policy, semantic, brain, bm25)
        ok, rep = qa_check_post(cfg, title, body)
        report["samples"].append({
            "kind": "post",
            "ok": bool(ok),
            "score": int(rep.get("score", 0)),
            "issues": rep.get("issues", []),
            "meta": {"cat": meta.get("cat")},
            "text": one_line((title + " / " + body), 280),
        })

    # summarize
    scores = [int(s.get("score", 0)) for s in _safe_list(report.get("samples")) if isinstance(s, dict)]
    oks = [bool(s.get("ok")) for s in _safe_list(report.get("samples")) if isinstance(s, dict)]
    report["generated"] = len(scores)
    report["pass"] = int(sum(1 for x in oks if x))
    report["pass_rate"] = round(float(report["pass"]) / float(max(1, len(oks))), 3)
    report["avg_score"] = round(float(sum(scores)) / float(max(1, len(scores))), 2)
    report["min_score_observed"] = int(min(scores)) if scores else 0
    report["max_score_observed"] = int(max(scores)) if scores else 0

    ic = Counter()
    for s in _safe_list(report.get("samples")):
        if not isinstance(s, dict):
            continue
        for iss in _safe_list(s.get("issues")):
            if isinstance(iss, str) and iss:
                ic[iss] += 1
    report["issue_top"] = [{"issue": k, "count": int(v)} for k, v in ic.most_common(12)]

    # Convert frequent issues into a lightweight per-issue penalty map for future generations.
    issue_boost: Dict[str, float] = {}
    try:
        nn = float(max(1, int(report.get("n", 0) or 0)))
        for it in _safe_list(report.get("issue_top"))[:8]:
            if not isinstance(it, dict):
                continue
            iss = str(it.get("issue") or "")
            cnt = float(it.get("count") or 0.0)
            if not iss or cnt <= 0:
                continue
            # 0.8 ~ 4.0 penalty depending on how dominant the issue is in this batch
            pen = 0.8 + (cnt / nn) * 6.0
            issue_boost[iss] = round(float(min(4.0, max(0.8, pen))), 2)
    except Exception as e:
        log_debug_exc("qa_run_batch_report:silent", e)
        pass

    report["issue_boost"] = issue_boost
    if isinstance(state, dict):
        state["qa_issue_boost"] = issue_boost

    return report

def qa_print_batch_report(report: Dict[str, Any], *, show_worst: int = 5) -> None:
    try:
        n = int(report.get("generated", 0) or 0)
        Console.cprint(Console.CYAN, f"[QA] generated={n} pass={report.get('pass')} pass_rate={report.get('pass_rate')} avg={report.get('avg_score')} min={report.get('min_score_observed')} max={report.get('max_score_observed')}")
        top = _safe_list(report.get("issue_top"))[:8]
        if top:
            msg = ", ".join([f"{x.get('issue')}:{x.get('count')}" for x in top if isinstance(x, dict)])
            Console.cprint(Console.MAGENTA, f"[QA] issues: {msg}")

        show = max(0, min(50, int(show_worst)))
        if show:
            samples = [s for s in _safe_list(report.get("samples")) if isinstance(s, dict)]
            samples.sort(key=lambda x: int(x.get("score", 0)))
            for s in samples[:show]:
                Console.cprint(Console.YELLOW, f"[QA] worst kind={s.get('kind')} score={s.get('score')} issues={','.join(_safe_list(s.get('issues'))[:4])}")
                Console.cprint(Console.GRAY, f"      {s.get('text')}")
    except Exception as e:
        log_debug_exc("qa_print_batch_report:silent", e)
        pass

def qa_write_batch_report(path: str, report: Dict[str, Any]) -> None:
    p = (path or "").strip()
    if not p:
        return
    try:
        d = os.path.dirname(p)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log_debug_exc("qa:write_report", e)
