################################################################################
# 05. LIMITERS & PACING
# Deps: 01-02 (Config, Logging)
# Used by: HTTP + main loop
# Notes: Sliding window limiters + per-action pacing.
################################################################################
"""
SECTION 05 - LIMITERS + PACING

Rate limiters and pacing rules.

Responsibilities:
- Sliding window limiters (per action / per endpoint family).
- Sleep duration calculation to avoid bursts (human-ish pacing).
- Enforce cooldowns derived from server hints (Retry-After) and local policy.

Debug tips:
- If you see many 429s, inspect limiter configuration and pacing outputs.
"""
class SlidingWindowLimiter:
    """Sliding window limiter based on monotonic time (robust to wall clock skew)."""
    def __init__(self, capacity: int, window_sec: int):
        self.capacity = max(0, int(capacity))
        self.window_sec = max(1, int(window_sec))
        self.q: deque[float] = deque()

    def _gc(self) -> None:
        now = time.monotonic()
        while self.q and (now - self.q[0]) > self.window_sec:
            self.q.popleft()

    def remaining(self) -> int:
        self._gc()
        if self.capacity <= 0:
            return 0
        return max(0, self.capacity - len(self.q))

    def allow(self) -> bool:
        self._gc()
        if self.capacity <= 0:
            return False
        if len(self.q) < self.capacity:
            self.q.append(time.monotonic())
            return True
        return False

    def seconds_until_next(self) -> int:
        """
        Returns seconds until at least one slot is available.
        - capacity <= 0 => effectively blocked
        - empty queue => wait window_sec (defensive)
        """
        self._gc()
        if self.capacity <= 0:
            return 10**9
        if len(self.q) < self.capacity:
            return 0
        if not self.q:
            return self.window_sec
        oldest = self.q[0]
        wait = self.window_sec - (time.monotonic() - oldest)
        return max(0, int(math.ceil(wait)))

def pace_interval(capacity: int, window_sec: int, floor_sec: int, activity_mode: str) -> int:
    """
    paced: distribute evenly => ceil(window/capacity), but never below floor_sec
    burst: just obey floor_sec
    capacity<=0 => effectively disabled (returns a very large interval)
    """
    if capacity <= 0:
        return 10**9
    base = int(math.ceil(int(window_sec) / max(1, int(capacity))))
    if activity_mode == "burst":
        return max(0, int(floor_sec))
    return max(int(floor_sec), base)

def gap_remaining(last_ts_wall: float, min_gap_sec: int) -> int:
    """last_ts_wall is wall time (time.time()) stored in state."""
    if last_ts_wall <= 0 or min_gap_sec <= 0:
        return 0
    return max(0, int(min_gap_sec - (time.time() - float(last_ts_wall))))

def catchup_budget(last_ts_wall: float, pace_sec: int, max_per_tick: int) -> int:
    """If we've been idle longer than pace, allow limited catch-up within max_per_tick."""
    if max_per_tick <= 0:
        return 0
    if pace_sec <= 0:
        return max_per_tick
    if last_ts_wall <= 0:
        return max_per_tick
    lag = (time.time() - float(last_ts_wall)) / float(pace_sec)
    want = int(min(max_per_tick, max(1, math.floor(lag))))
    return max(1, want)
