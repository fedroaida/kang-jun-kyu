################################################################################
# 21. GENERATION (REPLY/POST TEXT)
# Deps: 01-03, 08-18, 20
# Used by: comment/reply/post actions
# Notes: compose input, build candidate text, apply micro-edits, return (text, meta)
################################################################################
"""
SECTION 21 - GENERATION (REPLY/POST TEXT)

Builds text for replies/comments/posts.

Responsibilities:
- Build a compose_input (context) for generation.
- Choose strategy/tone/length via bandit policy.
- Generate candidates, apply gates, and finalize a safe text.
- Return (text, meta) where meta feeds the reward/policy update loop.

Notes:
- Keep this deterministic-ish under fixed seeds for selftest and debugging.
"""

def _prepare_reply_context(
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    th: Dict[str, Any],
    user: Dict[str, Any],
    brain: Optional[Dict[str, Any]],
    *,
    is_reply: bool,
    reply_to_own_post: bool,
) -> Dict[str, Any]:
    """Prepare context used by reply/comment generation.

    This is an extract-only refactor helper.
    - Builds `compose_input` and derives lightweight signals (keywords, ctx_keys).
    - Does NOT choose bandit arms (strategy/tone/length). Those remain in the caller.

    Returns:
        Dict with keys:
          drives, maturity, category, ctx_key, compose_input, kw_hint, qtok, ctx_keys
    """
    drives = get_persona_drives(brain)
    maturity = get_maturity_level(brain, state)

    category = str(th.get("category") or "general")
    ctx_key = category

    compose_input = build_compose_input(
        cfg, tuning, state, th, user,
        is_reply=bool(is_reply or reply_to_own_post),
        reply_to_own_post=bool(reply_to_own_post),
    )

    # Keywords/tokens used for reflection/context bias.
    kw_hint: str = ""
    qtok: List[str] = []
    try:
        kw_hint = pick_kw_for_reply(compose_input)
        if kw_hint:
            qtok.extend(tokenize(kw_hint, max_tokens=6))
        for x in _safe_list(compose_input.get("target_keywords"))[:4]:
            qtok.extend(tokenize(str(x), max_tokens=2))
        qtok = [t for t in qtok if t]
    except Exception as e:
        # Keep this a debug-level signal; generation should continue with empty hints.
        log_debug_exc("prepare_reply_context:keywords", e)
        kw_hint, qtok = "", []

    # Context keys used for bandit context bias.
    ctx_keys: List[str] = []
    try:
        ca = str(compose_input.get("comment_author") or "")
        un = str(compose_input.get("user_nickname") or "")
        nick = ca or un
        if nick:
            ctx_keys.append(f"user:{nick}")
    except Exception as e:
        log_debug_exc("prepare_reply_context:nick", e)

    try:
        pid_ctx = str(th.get("post_id") or th.get("id") or compose_input.get("post_id") or "")
        if pid_ctx:
            ctx_keys.append(f"thread:{pid_ctx}")
    except Exception as e:
        log_debug_exc("prepare_reply_context:pid", e)

    if kw_hint:
        ctx_keys.append(f"topic:{kw_hint}")
    if category:
        ctx_keys.append(f"cat:{category}")

    return {
        "drives": drives,
        "maturity": maturity,
        "category": category,
        "ctx_key": ctx_key,
        "compose_input": compose_input,
        "kw_hint": kw_hint,
        "qtok": qtok,
        "ctx_keys": ctx_keys,
    }

def _make_reply_decisions(
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    policy: Dict[str, Any],
    th: Dict[str, Any],
    user: Dict[str, Any],
    brain: Optional[Dict[str, Any]],
    ctx: Dict[str, Any],
    *,
    reply_to_own_post: bool,
    is_reply: bool,
) -> Dict[str, Any]:
    """Choose strategy/tone/length/style for reply generation.

    Extracted from build_reply_text (v7.1) to keep the orchestrator readable.
    The returned dict carries the selected arms and reflection notes used by meta.
    """
    drives = ctx.get("drives") or {}
    maturity = float(ctx.get("maturity") or 0.0)
    category = str(ctx.get("category") or "general")
    ctx_key = str(ctx.get("ctx_key") or category or "general")
    qtok = ctx.get("qtok") or []
    ctx_keys = ctx.get("ctx_keys") or []

    # Reflection-driven bias: if a certain arm worked well for similar keywords, gently boost it.
    ref_note_strategy: Dict[str, Any] = {}
    ref_note_reply_style: Dict[str, Any] = {}
    bias_strategy: Dict[str, float] = {}
    bias_reply_styles: Dict[str, float] = {}

    # Strategy arms (needed for both reflection and context bias).
    arms_strategy = list((_get_bucket(policy, "strategy", ctx_key) or {}).keys())

    # Reflection bias (keyword-driven)
    if qtok and isinstance(brain, dict) and bool(getattr(tuning, "reflection_influence", True)):
        try:
            bias_strategy, ref_note_strategy = get_reflection_bias(
                brain, qtok, bucket="strategy", arms=arms_strategy, tuning=tuning
            )
        except Exception as e:
            log_debug_exc("reflection_bias_strategy", e)
            bias_strategy, ref_note_strategy = {}, {}

    bias_ctx_strategy, _note_ctx_strategy = get_context_arm_bias(
        brain, ctx_keys, bucket="strategy", arms=arms_strategy, tuning=tuning
    )
    bias_strategy_all = merge_bias_maps(bias_strategy, bias_ctx_strategy)

    strategy = choose_arm_adaptive(
        policy, "strategy", context_key=ctx_key, maturity=maturity, bias=bias_strategy_all
    ) or "fallback_template"

    # tone/length can also benefit from context (no reflection bias by default)
    try:
        arms_tone = list(_get_bucket(policy, "tone", ctx_key).keys())
    except Exception:
        arms_tone = []
    bias_ctx_tone, _note_ctx_tone = get_context_arm_bias(
        brain, ctx_keys, bucket="tone", arms=arms_tone, tuning=tuning
    )
    tone = choose_arm_adaptive(
        policy, "tone", context_key=ctx_key, maturity=maturity, bias=bias_ctx_tone
    ) or "neutral"

    try:
        arms_len = list(_get_bucket(policy, "comment_length", ctx_key).keys())
    except Exception:
        arms_len = []
    bias_ctx_len, _note_ctx_len = get_context_arm_bias(
        brain, ctx_keys, bucket="comment_length", arms=arms_len, tuning=tuning
    )
    length = choose_arm_adaptive(
        policy, "comment_length", context_key=ctx_key, maturity=maturity, bias=bias_ctx_len
    ) or "medium"

    # (P1) counterparty-aware tone (user model)
    try:
        u_aggr = float(_safe_dict(user).get("aggression", 0.0) or 0.0)
        u_help = float(_safe_dict(user).get("helpfulness", 0.0) or 0.0)
        if u_aggr >= 0.55 and float(drives.get("debate", 0.7) or 0.7) >= 0.6 and random.random() < 0.55:
            tone = "critical"
        elif u_help >= 0.55 and random.random() < 0.45:
            tone = "supportive"
    except (TypeError, ValueError) as e:
        log_debug_exc("reply:user_model", e)
    except Exception as e:
        log_debug_exc("reply:user_model_unexpected", e)

    reply_mode = bool(reply_to_own_post or is_reply)
    # replying under my own posts: avoid sounding angry by default
    if bool(reply_to_own_post) and tone == "critical":
        tone = "neutral"

    # Micro style (dialogue act) for replies
    reply_style = ""
    if reply_mode:
        # Always define arms list (avoid NameError when qtok is empty).
        try:
            arms_rs = list((_get_bucket(policy, "reply_styles", ctx_key) or {}).keys())
        except Exception:
            arms_rs = []

        try:
            if qtok and isinstance(brain, dict) and bool(getattr(tuning, "reflection_influence", True)):
                bias_reply_styles, ref_note_reply_style = get_reflection_bias(
                    brain, qtok, bucket="reply_styles", arms=arms_rs, tuning=tuning
                )
        except Exception as e:
            log_debug_exc("reflection_bias_reply_styles", e)
            bias_reply_styles, ref_note_reply_style = {}, {}

        bias_ctx_reply_styles, _note_ctx_reply_styles = get_context_arm_bias(
            brain, ctx_keys, bucket="reply_styles", arms=arms_rs, tuning=tuning
        )
        bias_reply_styles_all = merge_bias_maps(bias_reply_styles, bias_ctx_reply_styles)
        reply_style = choose_arm_adaptive(
            policy, "reply_styles", context_key=ctx_key, maturity=maturity, bias=bias_reply_styles_all
        ) or "reply:define_criteria"

    # 성숙도↑: 템플릿(fallback) 의존을 서서히 줄이고, 문맥 전략을 더 자주 선택
    if strategy == "fallback_template" and maturity >= 0.35:
        if random.random() < (0.45 + 0.35 * float(drives.get("adaptation", 0.7) or 0.7)):
            strategy = random.choice(["summarize_ask", "counterexample", "agree_refine", "quote_commentary", "question_only"])

    # 논쟁 성향↑: 대댓글/반박 구도로 갈 확률을 살짝 올림
    if reply_mode and float(drives.get("debate", 0.7) or 0.7) >= 0.6:
        if strategy in ("agree_refine", "question_only") and random.random() < 0.40:
            strategy = "counterexample"

    # 철학 성향↑: philo 카테고리에서는 기준/정의 프레임을 더 자주 씀
    if category == "philo" and float(drives.get("philosophy", 0.8) or 0.8) >= 0.7:
        if strategy == "quote_commentary" and random.random() < 0.35:
            strategy = "summarize_ask"

    return {
        "strategy": strategy,
        "tone": tone,
        "length": length,
        "reply_style": reply_style,
        "reply_mode": reply_mode,
        "ref_note_strategy": ref_note_strategy,
        "ref_note_reply_style": ref_note_reply_style,
    }


# -----------------------------------------------------------------------------
# Unit 06 helpers — Quote discipline (BM25)
# Extracted in v7.2 (extract-only; runtime behavior should remain identical)
# -----------------------------------------------------------------------------

def _quote_fallback() -> str:
    """Fallback short quote when corpus quote cannot be fetched."""
    pool = [
        "앞말이 짧아서 맥락이 덜 잡힘",
        "문맥이 부족해서 기준부터 물어봐야 함",
        "앞글이 짧아서 전제부터 확인해야 함",
        "이 스레드는 맥락이 얇아서 케이스부터 나눠야 함",
    ]
    return random.choice(pool)


def _quote_interpret(category: str, kw: str, q: str) -> str:
    """Return ONE contribution line that interprets the quote.

    Note: `q` is kept as a parameter for future use, but currently the behavior
    matches the previous inline implementation (category/kw based).
    """
    # Keep this as ONE contribution line (statement-ish, avoid ending with '?')
    if category == "philo":
        pool = [
            f"저 말대로면 {kw}는 기준선 1개부터 고정해야 함",
            f"저 문장 기준이면 {kw}는 의도/결과 중 뭘 우선으로 두냐가 갈림",
            f"저 말은 {kw}에서 적용범위부터 박아야 한다는 얘기로 들림",
        ]
    elif category in ("dev", "tech", "science"):
        pool = [
            f"저 말대로면 {kw}는 재현 조건(입력/환경)부터 분리해야 함",
            f"저 문장 기준이면 {kw}는 측정지표 1개부터 박아야 함",
            f"저 말은 {kw}에서 실패 케이스를 먼저 정의해야 한다는 얘기임",
        ]
    elif category == "meta":
        pool = [
            f"저 말대로면 {kw}는 기준을 1개만 박아도 결이 갈림",
            f"저 문장 기준이면 {kw}는 정의부터 합의해야 말이 안 샘",
            f"저 말은 {kw}에서 우선순위를 먼저 고정하자는 얘기임",
        ]
    else:
        pool = [
            f"저 말대로면 {kw}는 우선순위 1개부터 정해야 함",
            f"저 문장 기준이면 {kw}는 예외 케이스부터 분리해야 함",
            f"저 말은 {kw}에서 조건을 한 줄로 고정하자는 얘기임",
        ]
    return random.choice(pool)


def _handle_quote_discipline(
    *,
    tuning: AgentTuning,
    state: Dict[str, Any],
    bm25: Optional[BM25Index],
    query_tokens: List[str],
    weak_context: bool,
    strategy: str,
) -> Tuple[List[str], float, str, str, str]:
    """Select at most one quote from corpus and adjust strategy if needed.

    Returns:
        (quotes, quote_score, quote_doc_kind, quote_doc_id, strategy)

    Side effects:
        - Updates `state['quote_last_ts']` when a quote is used.

    This is an extraction of the previous inline block in `build_reply_text()`.
    """
    quotes: List[str] = []
    quote_score: float = 0.0
    quote_doc_kind: str = ""
    quote_doc_id: str = ""

    attempted_quote = False

    if bm25 is not None and query_tokens and (not weak_context):
        quote_eligible = strategy in ("quote_commentary", "summarize_ask", "fallback_template")
        if quote_eligible and strategy != "question_only":
            last_q = float(state.get("quote_last_ts", 0.0) or 0.0)
            gap_need = float(getattr(tuning, "quote_min_gap_sec", 180) or 180)
            gap_ok = (time.time() - last_q) >= max(0.0, gap_need)
            if gap_ok:
                use_p = 0.0
                if strategy == "quote_commentary":
                    use_p = 1.0
                elif strategy == "summarize_ask":
                    use_p = 0.22
                elif strategy == "fallback_template":
                    use_p = 0.15

                if (use_p > 0.0) and (random.random() < use_p):
                    attempted_quote = True
                    ms = float(getattr(tuning, "quote_min_score", 18.0) or 18.0)
                    mc = int(getattr(tuning, "quote_max_chars", 140) or 140)
                    q, sc, qmeta = pick_best_quote_from_corpus(
                        bm25, query_tokens, min_score=ms, max_chars=mc, topk=10
                    )
                    if q:
                        # If it barely matches, keep only for explicit quote strategy
                        if strategy != "quote_commentary" and sc < (ms * 0.6):
                            q = ""
                        if q:
                            quotes = [q]
                            quote_score = float(sc)
                            quote_doc_kind = str(_safe_dict(qmeta).get("kind") or "")
                            quote_doc_id = str(_safe_dict(qmeta).get("doc_id") or "")
                            state["quote_last_ts"] = time.time()

    # If we planned a quote-centric move but couldn't fetch a quote, soften the plan.
    if strategy == "quote_commentary" and attempted_quote and (not quotes):
        strategy = "summarize_ask"

    return quotes, quote_score, quote_doc_kind, quote_doc_id, strategy

def build_reply_text(
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    policy: Dict[str, Any],
    th: Dict[str, Any],
    user: Dict[str, Any],
    *,
    bm25: Optional[BM25Index] = None,
    brain: Optional[Dict[str, Any]] = None,
    reply_to_own_post: bool = False,
    is_reply: bool = False,
) -> Tuple[str, Dict[str, Any]]:
    """
    Returns (text, meta) where meta is used for learning updates.

    Unit 03 (v17.4):
      - Dialogue-act upgrade: reflect the counterparty claim (1 line) + add ONE contribution + end with a concrete question.
      - When context is weak, retreat to definition/criteria questions instead of forcing a stance.
      - Preserve the question tail even when trimming to short/medium/long.
    """
    try:
        trace_hit("gen:reply:enter")
    except Exception:
        pass

    ctx = _prepare_reply_context(
        cfg, tuning, state, th, user, brain,
        is_reply=bool(is_reply),
        reply_to_own_post=bool(reply_to_own_post),
    )
    drives = ctx["drives"]
    maturity = ctx["maturity"]
    category = ctx["category"]
    ctx_key = ctx["ctx_key"]
    compose_input = ctx["compose_input"]
    kw_hint = ctx["kw_hint"]
    qtok = ctx["qtok"]
    ctx_keys = ctx["ctx_keys"]

    # ✅ 중요: tid는 항상 정의되어야 함
    tid: str = ""


    # --- primary bandit choices ---
    decisions = _make_reply_decisions(
        cfg, tuning, state, policy, th, user, brain, ctx,
        reply_to_own_post=bool(reply_to_own_post),
        is_reply=bool(is_reply),
    )
    strategy = decisions["strategy"]
    tone = decisions["tone"]
    length = decisions["length"]
    reply_style = decisions["reply_style"]
    reply_mode = decisions["reply_mode"]
    ref_note_strategy = decisions["ref_note_strategy"]
    ref_note_reply_style = decisions["ref_note_reply_style"]

    query_tokens = build_query_from_compose(th, compose_input)
    try:
        extra_q: List[str] = []
        if kw_hint:
            extra_q += tokenize(kw_hint, max_tokens=8)
        try:
            ca = str(compose_input.get("comment_author") or "")
            if ca:
                extra_q += tokenize(ca, max_tokens=5)
        except Exception:
            pass
        if category:
            extra_q += tokenize(category, max_tokens=3)
        query_tokens = list(dict.fromkeys(list(query_tokens) + extra_q))[:40]
    except Exception:
        pass

    quotes: List[str] = []  # Unit 06: at most 1 quote per reply (gated)
    quote_score: float = 0.0
    quote_doc_kind: str = ""
    quote_doc_id: str = ""

    thoughts: List[Dict[str, Any]] = []
    t0: Optional[Dict[str, Any]] = None
    if brain is not None and query_tokens:
        thoughts = search_thoughts(brain, query_tokens, topk=2)
        t0 = thoughts[0] if thoughts else None

    kw = pick_kw_for_reply(compose_input)

    # -------------------------------------------------------------------------
    # Helpers (cooldowns + formatting)
    # -------------------------------------------------------------------------
    def _recent_list(key: str, maxlen: int) -> List[str]:
        lst = state.get(key)
        if not isinstance(lst, list):
            lst = []
        lst2 = [str(x) for x in lst if isinstance(x, str) and x.strip()]
        if len(lst2) > maxlen:
            lst2 = lst2[-maxlen:]
        state[key] = lst2
        return lst2

    def _note_recent(key: str, value: str, maxlen: int) -> None:
        if not value:
            return
        lst = _recent_list(key, maxlen)
        lst.append(value)
        state[key] = lst[-maxlen:]

    def _recent_has(value: str, window: int) -> bool:
        if not value:
            return False
        recent = _recent_list("recent_openers", 20)
        return value in recent[-max(1, window):]

    BANNED_OPENERS = {"여기서부터가 꿀잼 구간임", "논점은 잡히는 느낌임"}
    LIMITED_PREFIXES = {"그 댓글은", "본문은", "핵심은"}

    def _pick_opener() -> str:
        recent = _recent_list("recent_openers", 20)
        recent_window = set(recent[-8:])
        pool_neutral = [
            "전제 하나만 확인하고 가자",
            "이 말에서 갈리는 지점 하나 보임",
            "여기서 정의부터 다시 잡아야 함",
            "이거 케이스 나누면 말끔해짐",
        ]
        pool_supportive = ["ㅇㅇ 이 포인트는 인정함", "재밌는 관점임"]
        pool_critical = ["전제가 좀 흔들리는 부분이 있음", "전제 하나만 확인하고 가자", "이 말에서 갈리는 지점 하나 보임"]
        pool_playful = ["이거 케이스 나누면 말끔해짐", "여기서 정의부터 다시 잡아야 함"]

        if tone == "supportive":
            pool = pool_supportive + pool_neutral
        elif tone == "critical":
            pool = pool_critical + pool_neutral
        elif tone == "playful":
            pool = pool_playful + pool_neutral
        else:
            pool = pool_neutral

        cand = [x for x in pool if (x not in BANNED_OPENERS) and (x not in recent_window)]
        if not cand:
            cand = [x for x in pool if x not in BANNED_OPENERS]
        return random.choice(cand) if cand else ""

    def _specific_question() -> str:
        # concrete question generator (avoid "너는?" style)
        if category == "philo":
            return f"{kw} 판단 기준을 결과(피해)로 볼지 의도(동기)로 볼지 뭐가 우선임?"
        if category in ("dev", "tech", "science"):
            return f"{kw}에서 재현 조건(입력/환경) 중 제일 영향 큰 변수 뭐였음?"
        if category == "meta":
            return f"{kw}에서 기준을 1개만 고르면 뭐가 제일 먼저임?"
        return f"{kw}에서 바꾸기 어려운 조건 1개만 고르면 뭐임?"

    def _make_summary_line(summ: str) -> str:
        # Avoid overusing "핵심은/그 댓글은/본문은" as a first line (sounds template-y)
        alts = [
            f"내가 읽은 결은 {eumify_tail_phrase(summ)}",
            f"한 줄로 보면 {eumify_tail_phrase(summ)}",
            f"{one_line(summ, 110)} 이렇게 읽힘",
        ]
        return random.choice(alts)

    def _stance_hint_line() -> str:
        pool = [
            f"{kw}는 기준을 어디에 꽂느냐에 따라 결론이 바뀜",
            f"{kw}는 우선순위(피해/공정/자유) 중 뭘 택하냐가 갈림",
            f"{kw}는 적용범위를 어디까지로 보냐가 갈리는 지점임",
        ]
        return random.choice(pool)

    def _context_strength() -> float:
        # cheap heuristic 0..1
        ttxt = str(compose_input.get("target_text") or "")
        tsum = str(compose_input.get("target_summary") or "")
        kws = _safe_list(compose_input.get("target_keywords"))
        score = 0.0
        if len(ttxt) >= 70:
            score += 0.5
        elif len(ttxt) >= 40:
            score += 0.35
        elif len(ttxt) >= 20:
            score += 0.2
        if tsum and len(tsum) >= 25:
            score += 0.15
        if len(kws) >= 4:
            score += 0.2
        elif len(kws) >= 2:
            score += 0.1
        return max(0.0, min(1.0, score))

    ctx_strength = _context_strength()
    weak_context = bool(ctx_strength < 0.28)

    question = _make_question(th, category) or _specific_question()
    if isinstance(question, str) and (question.strip().startswith("너는") or "어디에" in question):
        question = _specific_question()

    
    # Tail policy for replies:
    # - Not every reply must end as a question; choose between (question) vs (closure).
    focus_conv = _safe_dict(_safe_dict(state.get("focus")).get("conv"))
    remote_asked = bool(focus_conv.get("remote_is_question"))
    turns_total = int(focus_conv.get("turns_total", 0) or 0)

    base_q = float(getattr(tuning, "reply_question_base_prob", 0.25) or 0.25)
    if bool(reply_to_own_post):
        base_q = float(getattr(tuning, "reply_question_my_post_prob", 0.18) or 0.18)
    if remote_asked:
        base_q = float(getattr(tuning, "reply_question_when_asked_prob", 0.85) or 0.85)
    if turns_total >= 6:
        base_q *= 0.25

    want_question_tail = bool(weak_context) or (strategy == "question_only") or (random.random() < max(0.0, min(1.0, base_q)))

    CLOSE_TAIL_POOL = [
        "난 일단 이렇게 봄임",
        "여기까진 이렇게 정리함임",
        "내 결론은 이쪽임",
        "반박 있으면 더 얘기해보자임",
    ]
    if tone == "supportive":
        CLOSE_TAIL_POOL = [
            "난 일단 이렇게 봄임",
            "일단 내 쪽은 이렇게 정리됨임",
            "추가 맥락 있으면 더 맞춰볼수있음",
        ]
    tail_line = question if want_question_tail else random.choice(CLOSE_TAIL_POOL)
    tail_kind = "question" if want_question_tail else "close"

    if reply_mode and weak_context:
        # Retreat: definition/criteria first
        qpool = [
            f"{kw}를 여기서 어떤 의미로 쓰는지부터 확인해도 됨?",
            f"{kw} 범위를 어디까지로 잡고 말하는 거임?",
            f"{kw} 판단 기준을 1개만 박으면 뭐로 잡음?",
        ]
        question = random.choice(qpool)




    # -------------------------------------------------------------------------
    # Unit 06 — Quote discipline (BM25)
    # (v7.2) Extracted to helper for readability; behavior should remain identical.
    # -------------------------------------------------------------------------
    quotes, quote_score, quote_doc_kind, quote_doc_id, strategy = _handle_quote_discipline(
        tuning=tuning,
        state=state,
        bm25=bm25,
        query_tokens=query_tokens,
        weak_context=weak_context,
        strategy=strategy,
    )

    quote_line = f"“{quotes[0]}”" if quotes else ""
    # -------------------------------------------------------------------------
    # Dialogue-act contribution line (ONE line)
    # -------------------------------------------------------------------------
    def _one_contribution_line(style: str) -> str:
        tks = _safe_list(compose_input.get("target_keywords"))
        tkw = str(tks[0]) if tks else ""
        tkw = tkw if (tkw and tkw != kw) else ""

        if style == "reply:split_cases":
            if category == "philo":
                msg = f"{kw}는 의도 기준 vs 결과 기준으로 나눠보면 말끔해짐"
            elif category in ("dev", "tech"):
                msg = f"{kw}는 재현 조건(입력/환경)부터 쪼개봐야 함"
            else:
                msg = f"{kw}는 케이스를 A/B로 나누면 얘기 빨라짐"
            if tkw:
                msg += f" (특히 {tkw} 쪽)"
            return msg

        if style == "reply:handle_counter":
            conds = [
                "비용이 급증하는 상황",
                "오판 가능성이 높은 상황",
                "당사자가 책임을 못 지는 상황",
                "규칙이 바뀌는 상황",
            ]
            return f"반례 하나만 보면, {kw}가 {random.choice(conds)}일 때도 같은 결론임?"

        if style == "reply:define_criteria":
            metrics = [
                "피해 규모",
                "재현 가능성",
                "되돌릴 수 있는지",
                "책임 소재",
            ]
            return f"판단하려면 지표 1개를 박아야 함: {kw}는 {random.choice(metrics)}가 우선임?"

        # reply:ack_premise (default)
        if tone == "critical":
            pool = [
                "ㅇㅇ 근데 전제는 한 번 더 확인해야 함",
                "ㅇㅇ 근데 기준부터 고정해야 말이 안 샘",
                "일단 포인트는 이해함. 근데 조건이 빠져있음",
            ]
        elif tone == "supportive":
            pool = ["ㅇㅇ 이 포인트는 인정함", "그건 맞는 말임", "여기까진 동의함"]
        else:
            pool = ["포인트는 이해함", "이 말 자체는 납득됨", "여기까지는 수긍함"]
        return random.choice(pool)

    # Reflect line (counterparty claim)
    reflect_line = ""
    try:
        ctx = str(compose_input.get("target_text") or compose_input.get("thread_summary") or "")
        summ = _simple_summary(ctx, max_len=120) if ctx else kw
        if reply_mode or (compose_input.get("target_kind") in ("comment", "post") and ctx):
            reflect_line = _make_summary_line(summ)
    except Exception as e:
        log_debug_exc("reply:reflect", e)

    # Decide contribution line
    act_line = ""
    if reply_mode:
        # If macro strategy is counterexample/agree_refine, align act to match
        if strategy == "counterexample":
            act_line = _one_contribution_line("reply:handle_counter")
        elif strategy == "agree_refine":
            # compress agree+refine into one line
            act_line = f"ㅇㅇ {kw} 쪽은 동의함. 다만 {kw}{josa_eul_reul(kw)} 어디까지 포함하냐는 분리해야 함"
        else:
            act_line = _one_contribution_line(reply_style or "reply:define_criteria")
    else:
        # comment mode: still keep ONE contribution line for readability
        if strategy == "counterexample":
            act_line = _one_contribution_line("reply:handle_counter")
        elif strategy == "summarize_ask":
            # randomize among boundary/counterexample/metric
            act_line = _one_contribution_line(random.choice(["reply:split_cases", "reply:handle_counter", "reply:define_criteria"]))
        elif strategy == "agree_refine":
            act_line = f"{kw} 쪽은 동의함. 다만 범위는 분리해야 함"
        elif strategy == "quote_commentary":
            act_line = _stance_hint_line()
        else:
            act_line = _one_contribution_line("reply:define_criteria") if (strategy != "question_only") else ""


    # Unit 06: if we included a quote, keep the skeleton: quote -> interpretation -> question
    if quote_line and strategy in ("quote_commentary", "summarize_ask"):
        try:
            act_line = _quote_interpret(category, kw, quotes[0])
        except Exception as e:
            log_debug_exc("reply:quote_interpret", e)

    # -------------------------------------------------------------------------
    # Build base content
    # -------------------------------------------------------------------------
    lines: List[str] = []

    if strategy == "fallback_template":
        temps = _safe_dict(policy.get("templates", {}))
        titems = _safe_dict(temps.get("items", {}))
        tid = pick_template_id(policy, ctx_key)
        ttext = ""
        if tid and isinstance(titems, dict) and isinstance(titems.get(tid), dict):
            ttext = str(titems[tid].get("text") or "")
        if ttext:
            try:
                titems[tid]["uses"] = int(titems[tid].get("uses", 0) or 0) + 1
                titems[tid]["last_used_ts"] = time.time()
            except Exception as e:
                log_debug_exc("reply:template_use", e)
            q = quotes[0] if quotes else _quote_fallback()
            body = render_template(ttext, kw=kw, quote=q, question=question)
            lines = [x for x in body.split("\n") if str(x).strip()]
        else:
            # simple fallback
            if reflect_line:
                lines.append(reflect_line)
            lines.append(act_line or f"{kw}는 기준을 어디에 두느냐가 갈림")
            lines.append(question)

    else:
        # non-template strategies use the new act structure
        if strategy != "question_only":
            if reflect_line:
                lines.append(reflect_line)
            if quote_line and strategy in ("quote_commentary", "summarize_ask"):
                lines.append(quote_line)
            if act_line:
                lines.append(act_line)
            lines.append(question)
        else:
            # question_only: optionally add reflect if we actually have context
            if reflect_line and (reply_mode or (not weak_context and random.random() < 0.55)):
                lines.append(reflect_line)
            lines.append(question)

    # inject one remembered thought (toned down; avoid meta overload)
    if t0 is not None and length != "short" and (not weak_context) and random.random() < 0.35:
        ttxt = str(t0.get("text") or "")
        if ttxt:
            vpool = [
                f"기억 기록엔 {ttxt} 쪽으로 남아있음",
                f"내 기록 기준으론 {ttxt} 쪽으로 적어둠",
                f"예전에 적어둔 건 {ttxt} 쪽이었음",
            ]
            tline = random.choice(vpool)
            joined = " ".join(lines)
            if ttxt not in joined and tline not in joined:
                # insert after the first line (usually reflect)
                lines.insert(1 if len(lines) >= 1 else 0, tline)
            try:
                mark_thought_used(brain or {}, str(t0.get("id") or ""))
            except Exception as e:
                log_exception("brain:thought_use", e, context={"where":"reply","thought_id": str(t0.get("id") or ""), "post_id": str(quote_doc_id or ""), "category": str(category or "")})
                if _should_failfast("brain"):
                    raise

    # (Legacy) grounding anchor: keep but heavily reduced to avoid duplicate paraphrase
    try:
        anchor = str(compose_input.get("target_summary") or "")
        if anchor and (not reflect_line) and (not reply_mode):
            kind = str(compose_input.get("target_kind") or "")
            prefix = "핵심은"
            if kind == "comment":
                prefix = "그 댓글은"
            elif kind == "post":
                prefix = "본문은"
            joined = " ".join(lines[:2])
            if (anchor not in joined) and (prefix not in joined):
                p = 0.18
                if (prefix in LIMITED_PREFIXES) and _recent_has(prefix, 10):
                    p *= 0.10
                if random.random() < p:
                    lines.insert(1 if len(lines) >= 1 else 0, f"{prefix} {eumify_tail_phrase(anchor)}")
                    if prefix in LIMITED_PREFIXES:
                        _note_recent("recent_openers", prefix, 20)
    except Exception as e:
        log_debug_exc("reply:anchor", e)

    # Optional opener line (cooldown-based). Avoid pushing out question in short/medium.
    opener = _pick_opener()
    if opener and (not _recent_has(opener, 8)) and (opener not in BANNED_OPENERS):
        if length == "long" and random.random() < 0.75:
            lines.insert(0, opener)
            _note_recent("recent_openers", opener, 20)
        elif length != "short" and random.random() < 0.35:
            lines.insert(0, opener)
            _note_recent("recent_openers", opener, 20)

    # Ensure the last line is the chosen tail (question OR closure)
    if tail_line:
        lines = [x for x in lines if str(x).strip()]
        lines = [x for x in lines if x != tail_line]
        lines.append(tail_line)

    # enforce length while preserving the tail line
    def _trim_keep_tail(ls: List[str], want: int) -> List[str]:
        ls = [x for x in ls if isinstance(x, str) and x.strip()]
        if not ls:
            return [tail_line] if tail_line else []
        if want <= 1:
            return [ls[-1]]
        if len(ls) <= want:
            return ls
        tail = ls[-1]
        head = ls[:-1]
        # Drop low-priority "opener" lines first when we must compress
        while len(head) > (want - 1):
            head.pop(0)
        return head + [tail]

    if length == "short":
        lines = _trim_keep_tail(lines, 2)
    elif length == "long":
        lines = _trim_keep_tail(lines, 4)
    else:
        lines = _trim_keep_tail(lines, 3)

    text = ensure_eum_style("\n".join(lines), max_lines=max(2, tuning.max_output_lines))

    meta = {
        "category": category,
        "cat": category,
        "context_key": ctx_key,
        "strategy": strategy,
        "tone": tone,
        "length": length,
        "reply_style": reply_style,
        "ref_strategy_hint": str(ref_note_strategy.get("top_arm") or ""),
        "ref_strategy_hits": int(ref_note_strategy.get("hits") or 0),
        "ref_reply_style_hint": str(ref_note_reply_style.get("top_arm") or ""),
        "ref_reply_style_hits": int(ref_note_reply_style.get("hits") or 0),
        "weak_context": bool(weak_context),
        "tail_kind": str(tail_kind),
        "template_id": tid if strategy == "fallback_template" else "",
        "used_quotes": bool(quotes),
        "quote_score": float(quote_score or 0.0),
        "quote_doc_kind": str(quote_doc_kind or ""),
        "quote_doc_id": str(quote_doc_id or ""),
        "kw": kw,
        "focus_mode": str(compose_input.get("mode") or ""),
        "target_kind": str(compose_input.get("target_kind") or ""),
        "target_kws": _safe_list(compose_input.get("target_keywords"))[:3],
        "has_focus": bool(compose_input.get("has_focus")),
        "thought_id": str(t0.get("id") or "") if t0 is not None else "",
        "thought_kind": str(t0.get("kind") or "") if t0 is not None else "",
    }
    return text, meta


def build_post_text(
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    policy: Dict[str, Any],
    semantic: Dict[str, Any],
    brain: Dict[str, Any],
    bm25: Optional[BM25Index],
) -> Tuple[str, str, Dict[str, Any]]:
    """
    Unit 09: Post style engine v2
      - 더 다양한 글 프레임(케이스 분리/체크리스트/비유/경계테스트/프로세스/측정지표)
      - post_styles bucket 학습이 실제로 작동하도록 naming 정합성 유지
      - 항상 '한 기여 + 한 질문'로 닫히게 스켈레톤 고정
    """
    try:
        trace_hit("gen:post:enter")
    except Exception:
        pass

    maturity = get_maturity_level(brain, state)

    semantic = semantic if isinstance(semantic, dict) else {}
    hot = _safe_list(semantic.get("hot", []))
    rising = _safe_list(semantic.get("rising", []))

    # seed keyword candidates: hot/rising + brain.topic_ema + fallback
    seed_cands: List[str] = []
    for it in hot[:10] + rising[:10]:
        if isinstance(it, dict):
            s = it.get("kw") or it.get("keyword") or ""
        else:
            s = it
        s = normalize_ko_token(str(s)) if s else ""
        if s and is_clean_keyword(s) and (2 <= len(s) <= 12):
            seed_cands.append(s)

    topic_ema = _safe_dict(brain.get("topic_ema"))
    if topic_ema:
        try:
            top_topics = sorted(topic_ema.items(), key=lambda x: float(x[1] or 0.0), reverse=True)[:6]
            for k, _v in top_topics:
                s = normalize_ko_token(str(k))
                if s and is_clean_keyword(s) and (2 <= len(s) <= 12):
                    seed_cands.append(s)
        except Exception as e:
            log_debug_exc("build_post_text:silent", e)
            pass

    seed_cands += ["기준", "정의", "경험", "규율", "공정", "책임", "효율", "자유"]
    seed_kw = random.choice(seed_cands) if seed_cands else "기준"
    if not is_clean_keyword(seed_kw) or not (2 <= len(seed_kw) <= 12):
        seed_kw = "기준"

    # category guess (used only for context-arm bias during style selection)
    # NOTE: this is a lightweight hint; final category for the post is derived from the chosen style below.
    category = "general"
    try:
        # Prefer explicit semantic hint if present
        _cat_hint = str(semantic.get("category") or semantic.get("dominant_cat") or semantic.get("cat") or "").strip()
        if _cat_hint:
            category = _cat_hint
    except Exception:
        pass
    if category not in ("general", "meta", "philo", "dev", "tech", "science"):
        category = "general"


    # remembered thought (optional)
    t0 = None
    ttxt = ""
    try:
        if bm25 is not None and seed_kw:
            qtok = tokenize(seed_kw, max_tokens=6)
            ths = search_thoughts(brain, qtok, topk=1)
            t0 = ths[0] if ths else None
            if isinstance(t0, dict):
                ttxt = str(t0.get("text") or "")
    except Exception as e:
        log_debug_exc("post:thought", e)

    # style pool from policy (fallback to safe defaults)
    post_styles = _safe_dict(policy.get("post_styles"))
    style_pool = [str(k) for k in post_styles.keys() if isinstance(k, str)]
    if not style_pool:
        style_pool = [
            "post:meta:question",
            "post:meta:flow_report",
            "post:meta:observation_log",
            "post:meta:one_metric",
            "post:philo:uncertainty",
            "post:philo:process",
            "post:philo:paradox",
            "post:philo:definition_war",
            "post:philo:axiom",
            "post:philo:boundary_test",
            "post:general:short_take",
            "post:general:case_split",
            "post:general:checklist",
            "post:general:analogy",
        ]

    ctx_keys_post: List[str] = []
    if seed_kw:
        ctx_keys_post.append(f"topic:{seed_kw}")
    if category:
        ctx_keys_post.append(f"cat:{category}")
    try:
        arms_ps = list(_get_bucket(policy, "post_styles", "post").keys())
    except Exception:
        arms_ps = []
    bias_ctx_ps, _note_ctx_ps = get_context_arm_bias(brain, ctx_keys_post, bucket="post_styles", arms=arms_ps, tuning=tuning)
    style = choose_arm_adaptive(policy, "post_styles", context_key="post", maturity=maturity, bias=bias_ctx_ps) or "post:meta:question"
    if style not in style_pool:
        style = "post:meta:question"

    recent_styles = brain.get("recent_post_styles")
    if not isinstance(recent_styles, list):
        recent_styles = []
    recent_styles = [str(x) for x in recent_styles if isinstance(x, str)]
    recent_styles = recent_styles[-10:]

    # if same style repeats 2x, encourage diversity
    if len(recent_styles) >= 2 and recent_styles[-1] == style and recent_styles[-2] == style:
        alts = [s for s in style_pool if s != style]
        if alts and random.random() < 0.85:
            style = random.choice(alts)

    # pools
    ASK_POOL = [
        f"{seed_kw}에서 1순위 기준 뭐로 박음?",
        f"{seed_kw} 얘기할때 정의부터 합의함, 기준부터 합의함?",
        f"{seed_kw} 분기점 하나만 고르면 뭐가 먼저임?",
        f"{seed_kw}는 어디까지가 같은 문제라고 봄?",
        "너는 여기서 반례 1개만 고르면 뭐가 제일 강함?",
        "여기서 제일 중요한 전제가 뭐라고 봄?",
    ]
    MEMO_POOL = ["메모: ", "내 생각엔 ", "내 기준으론 ", "기록상으론 "]
    PHILO_EXAMPLES = [
        "예: 자유도 표현의 자유냐, 플랫폼 규칙이냐로 갈림",
        "예: 공정도 절차 공정이냐 결과 공정이냐로 갈림",
        "예: 책임도 개인 책임이냐 구조 책임이냐로 갈림",
    ]
    ANALOGY_POOL = [
        "버그 triage 같음: 우선순위 못박으면 토론이 끝까지 늘어짐",
        "인덱스 설계 같음: 기준 컬럼이 바뀌면 조회 결과가 달라짐",
        "캐시 정책 같음: 히트율만 올리면 다른 비용이 튀어나옴",
        "보안 모델 같음: threat 가정이 다르면 결론이 완전 갈림",
    ]

    def _end_q() -> str:
        q = random.choice(ASK_POOL) if ASK_POOL else "이거 어떻게 봄?"
        if not q.endswith("?"):
            q = q.rstrip() + "?"
        return q

    def _add_tail_question(lines: List[str]) -> None:
        if not lines:
            lines.append(_end_q())
            return
        last = str(lines[-1]).strip()
        if "?" not in last:
            lines.append(_end_q())
            return
        # 이미 질문이 있으면 1개만 유지
        if len(lines) >= 2 and "?" in str(lines[-2]):
            # 두 질문 연속이면 하나 제거
            lines.pop(-2)

    # keyword lists
    hot_kws = [normalize_ko_token(str(x.get("kw") if isinstance(x, dict) else x)) for x in hot[:8]]
    hot_kws = [x for x in hot_kws if is_clean_keyword(x)]
    rising_kws = [normalize_ko_token(str(x.get("kw") if isinstance(x, dict) else x)) for x in rising[:8]]
    rising_kws = [x for x in rising_kws if is_clean_keyword(x)]
    trend_hint = ", ".join((hot_kws + rising_kws)[:4])

    title = ""
    body_lines: List[str] = []
    cat = "general"
    ctx = "post"

    # --- style builders ---
    if style == "post:meta:flow_report":
        title = random.choice(["요즘 커뮤 흐름 메모", "최근 핫/라이징 흐름", "지금 분위기 요약"])
        if hot_kws:
            body_lines.append(f"핫: {', '.join(hot_kws[:5])}임")
        if rising_kws:
            body_lines.append(f"라이징: {', '.join(rising_kws[:5])}임")
        body_lines.append(random.choice([
            "이 흐름은 결국 '정의/기준' 싸움으로 자꾸 회귀하는 느낌임",
            "주제는 달라도 분기 기준이 비슷하게 반복되는 편임",
            "핫한데 결론이 안 나는건 대개 전제가 안 맞아서임",
        ]))
        _add_tail_question(body_lines)
        cat = "meta"
        ctx = "meta"

    elif style == "post:meta:observation_log":
        title = random.choice(["오늘 커뮤에서 느낀거", "짧게 관찰 로그", "최근 댓글들 보면서 든 생각"])
        if trend_hint and random.random() < 0.75:
            body_lines.append(f"요즘 {trend_hint} 얘기가 계속 올라오는 느낌임")
        body_lines.append(random.choice([
            f"근데 싸움 나는 지점은 {seed_kw}를 어디까지로 보냐로 갈리는 경우가 많음",
            f"근데 결론이 갈리는 포인트는 {seed_kw} 기준선을 어디에 꽂냐인듯함",
            f"근데 서로 같은 말로 다른 문제를 얘기하는 케이스가 꽤 보임",
        ]))
        if ttxt and random.random() < 0.55:
            body_lines.append(random.choice(MEMO_POOL) + one_line(ttxt, 90))
        _add_tail_question(body_lines)
        cat = "meta"
        ctx = "meta"

    elif style == "post:meta:one_metric":
        title = random.choice([f"{seed_kw} 논쟁, 지표 하나만 박아보자", "측정 기준 1개만 고정해봄", "말싸움 줄이는 방법 하나"])
        body_lines.append(random.choice([
            "일반론으로만 돌면 끝이 안 남",
            "측정지표 하나만 박으면 대화가 빨리 정리되는 편임",
            "기준을 수치/판정으로 바꾸면 말싸움이 확 줄어듦",
        ]))
        body_lines.append(random.choice([
            "예: 일관성(케이스 바뀌어도 기준 유지됨?)",
            "예: 비용(사회 비용/개인 비용을 어디에 계산함?)",
            "예: 피해(누가 손해를 실제로 떠안음?)",
            "예: 예측가능성(룰이 보이고 따라갈 수 있음?)",
        ]))
        _add_tail_question(body_lines)
        cat = "meta"
        ctx = "meta"

    elif style == "post:philo:definition_war":
        title = f"{seed_kw} 얘기에서 제일 먼저 갈리는거"
        body_lines = [
            random.choice([
                f"{seed_kw}는 단어는 같은데 범위가 갈리는 느낌임",
                f"{seed_kw}는 정의를 어디까지로 보냐부터 엇갈림",
                f"{seed_kw}는 같은 말이라도 기준선이 제각각임",
            ]),
        ]
        if random.random() < 0.55:
            body_lines.append(random.choice(PHILO_EXAMPLES))
        body_lines.append(random.choice([
            "정의부터 맞추면 논쟁 반은 끝나는 편임",
            "정의부터 통일하면 말싸움이 줄어듦",
            "정의부터 합의하면 서로 딴말할 확률이 내려감",
        ]))
        _add_tail_question(body_lines)
        cat = "philo"
        ctx = "philo"

    elif style == "post:philo:paradox":
        title = f"{seed_kw}의 역설 같은 지점"
        body_lines = [
            random.choice([
                f"{seed_kw}는 극단으로 가면 본래 목적이 깨지는 구간이 있음",
                f"{seed_kw}는 강하게 밀수록 역효과 나는 케이스가 있음",
                f"{seed_kw}는 한쪽만 올리면 다른 쪽이 터지는 느낌임",
            ]),
            random.choice(PHILO_EXAMPLES) if random.random() < 0.45 else "이건 조건을 어디에 거냐에 따라 답이 바뀜",
            random.choice([
                "그래서 케이스 분리가 없으면 결론이 계속 흔들림",
                "그래서 반례를 몇 개 찍어봐야 선이 보임",
                "그래서 일반론만 반복하면 헛바퀴 돌기 쉬움",
            ]),
        ]
        _add_tail_question(body_lines)
        cat = "philo"
        ctx = "philo"

    elif style == "post:philo:uncertainty":
        title = f"{seed_kw}에서 애매한 구간"
        body_lines = [
            random.choice([
                f"{seed_kw}는 경계선이 애매해서 케이스가 섞이는 느낌임",
                f"{seed_kw}는 어디부터 다른 문제로 넘어가는지 선이 흐림",
                f"{seed_kw}는 딱 끊어 말하기 어려운 구간이 있음",
            ]),
            random.choice([
                "그래서 최소한 분기 기준 하나는 세워야 함",
                "그래서 조건을 명시하지 않으면 말이 계속 미끄러짐",
                "그래서 예시 1~2개를 먼저 박고 들어가는게 빠름",
            ]),
        ]
        if random.random() < 0.35:
            body_lines.append(random.choice(PHILO_EXAMPLES))
        _add_tail_question(body_lines)
        cat = "philo"
        ctx = "philo"

    elif style == "post:philo:process":
        title = random.choice([f"{seed_kw} 얘기할때 순서가 중요함", "정의→기준→검증, 이 순서가 맞나?", "논쟁이 길어질때 보통 빠진 단계"])
        body_lines = [
            "내쪽 프로세스는 대충 이럼: 정의 고정 → 기준 1개 박기 → 케이스로 검증",
            "순서가 뒤집히면 같은 말로 다른 결론이 나오는 느낌임",
        ]
        if random.random() < 0.4:
            body_lines.append("특히 기준이 2개 이상 섞이면 토론이 급격히 길어짐")
        _add_tail_question(body_lines)
        cat = "philo"
        ctx = "philo"

    elif style == "post:philo:axiom":
        title = random.choice([f"{seed_kw}에서 전제 1개만 박고 시작하자", "원칙 하나 없으면 계속 흔들림", "이 논쟁, 공리부터 정해야함"])
        body_lines = [
            random.choice([
                f"{seed_kw}는 결국 '무엇을 더 우선함' 공리 싸움으로 수렴하는 편임",
                f"{seed_kw}는 기저가치(안전/자유/효율/공정)를 뭐로 두냐가 갈림",
                f"{seed_kw}는 전제를 안 박으면 케이스마다 결론이 튀는 느낌임",
            ]),
            "그래서 난 '전제 1개'를 먼저 고정하는게 제일 빠르다고 봄",
        ]
        _add_tail_question(body_lines)
        cat = "philo"
        ctx = "philo"

    elif style == "post:philo:boundary_test":
        title = random.choice([f"{seed_kw} 경계 케이스만 찍어보자", "반례/경계부터 보면 선이 보임", "애매하면 경계테스트가 답임"])
        body_lines = [
            f"{seed_kw}는 중간이 애매하면 경계 케이스로만 찍어봐도 선이 보이는 편임",
            random.choice([
                "케이스1: 의도는 좋은데 결과가 나쁜 경우",
                "케이스1: 절차는 공정한데 결과가 불공정한 경우",
                "케이스1: 규칙은 맞는데 상식이 깨지는 경우",
            ]),
            random.choice([
                "케이스2: 결과는 좋은데 절차가 문제인 경우",
                "케이스2: 예외를 한 번 허용했더니 일반화가 되는 경우",
                "케이스2: 같은 룰인데 집단이 바뀌면 평가가 뒤집히는 경우",
            ]),
        ]
        _add_tail_question(body_lines)
        cat = "philo"
        ctx = "philo"

    elif style == "post:general:case_split":
        title = random.choice([f"{seed_kw} 케이스 분리 해봄", "A/B로 나눠보면 깔끔함", "논점 분리해서 보자"])
        body_lines = [
            f"케이스A: {seed_kw}를 '원칙'으로 보는 쪽",
            f"케이스B: {seed_kw}를 '도구'로 보는 쪽",
            "A/B가 섞이면 서로 딴말하는 느낌이 남",
        ]
        _add_tail_question(body_lines)
        cat = "general"
        ctx = "gen"

    elif style == "post:general:checklist":
        title = random.choice([f"{seed_kw} 체크리스트 3개", "판단 기준을 3줄로 고정해봄", "내가 쓰는 간단 판정법"])
        body_lines = [
            "체크 3개만 박으면 말싸움이 좀 줄어듦",
            "1) 일관성: 케이스 바뀌어도 기준 유지됨?",
            "2) 비용: 누가 비용을 실제로 떠안음?",
            "3) 예측가능성: 룰이 보이고 따라갈 수 있음?",
        ]
        _add_tail_question(body_lines)
        cat = "general"
        ctx = "gen"

    elif style == "post:general:analogy":
        title = random.choice([f"{seed_kw}를 시스템 비유로 보면", "비유 하나로 정리해봄", "이거 느낌상 이런 구조임"])
        body_lines = [
            random.choice(ANALOGY_POOL),
            f"결국 {seed_kw}도 '우선순위/가정/기준 컬럼'을 어디에 두냐 문제 같음",
        ]
        if random.random() < 0.35:
            body_lines.append("비유가 과하면 오해나니 핵심만 가져오는게 맞음")
        _add_tail_question(body_lines)
        cat = "general"
        ctx = "gen"

    elif style == "post:general:short_take":
        title = f"{seed_kw} 관련해서 짧게 한줄"
        memo = random.choice(MEMO_POOL)
        body_lines = [
            f"{memo}{seed_kw}는 결국 기준을 어디에 꽂느냐가 갈림",
            random.choice([
                "말만 길게 하면 답이 더 안 보이더라",
                "짧게 쪼개면 의외로 선이 보이는 편임",
                "케이스 분리만 해도 싸움이 줄어듦",
            ]),
        ]
        _add_tail_question(body_lines)
        cat = "general"
        ctx = "gen"

    else:
        # post:meta:question (default)
        title = f"{seed_kw} 관련해서 하나만 물어봄"
        memo = random.choice(MEMO_POOL)
        hint = ""
        if ttxt:
            hint = f"{memo}{one_line(ttxt, 110)}"
        else:
            hint = random.choice([
                "여기서 먼저 정해야 할 게 하나 있음",
                "이건 기준을 1개만 박아도 결이 갈림",
                "이건 적용범위를 어디까지로 보냐가 핵심 분기임",
            ])
        body_lines = [
            random.choice([
                f"{seed_kw} 얘기 볼때마다 기준이 다 갈리는 느낌임",
                f"{seed_kw}는 같은 말인데 서로 다른 그림을 보는 느낌임",
                f"{seed_kw}는 케이스가 섞이면 논쟁이 길어지는 편임",
            ]),
            hint,
        ]
        _add_tail_question(body_lines)
        cat = "meta"
        ctx = "meta"

    # mark thought usage (helps pruning)
    if isinstance(t0, dict) and str(t0.get("id") or ""):
        try:
            mark_thought_used(brain, str(t0.get("id") or ""))
        except Exception as e:
            log_exception("brain:thought_use", e, context={"where":"post","thought_id": str(t0.get("id") or ""), "kw": str(seed_kw or ""), "category": str(category or "")})
            if _should_failfast("brain"):
                raise

    # maturity: allow one extra line occasionally (within max_output_lines)
    if maturity >= 0.55 and len(body_lines) < 4 and random.random() < 0.35:
        body_lines.insert(1, random.choice([
            "여기서 먼저 정할 건 정의냐 기준이냐 순서임",
            "결국 분기점은 기준선을 어디에 박느냐임",
            "말싸움 줄이려면 조건을 한 줄로 고정해야 함",
        ]))

    # (Unit 09) title repetition guard
    try:
        tprefixes = brain.get("recent_post_title_prefixes")
        if not isinstance(tprefixes, list):
            tprefixes = []
        tprefixes = [str(x) for x in tprefixes if isinstance(x, str)][-12:]
        cand_t = (title or "")[:18]
        if cand_t and sum(1 for p in tprefixes if p == cand_t) >= 2:
            title = random.choice([
                f"{seed_kw} 얘기, 여기서 갈림",
                f"{seed_kw} 프레임 분리 해봄",
                f"{seed_kw} 기준 하나만 묻겠음",
                f"{seed_kw}는 결국 전제 싸움임",
            ])
        tprefixes.append((title or "")[:18])
        brain["recent_post_title_prefixes"] = tprefixes[-12:]
    except Exception as e:
        log_debug_exc("build_post_text:silent", e)
        pass

    # repetition guard: first sentence prefix
    try:
        prefixes = brain.get("recent_post_prefixes")
        if not isinstance(prefixes, list):
            prefixes = []
        prefixes = [str(x) for x in prefixes if isinstance(x, str)]
        prefixes = prefixes[-10:]
        cand = (body_lines[0] if body_lines else "")[:25]
        if cand and sum(1 for p in prefixes if p == cand) >= 2:
            # replace first line with a variant
            if cat == "philo":
                body_lines[0] = random.choice([
                    f"{seed_kw}는 정의부터 삐끗하면 끝까지 평행선임",
                    f"{seed_kw}는 같은 말인데 서로 다른 규칙을 떠올리는 느낌임",
                    f"{seed_kw}는 경계선이 흐리면 대화가 계속 미끄러짐",
                ])
            else:
                body_lines[0] = random.choice([
                    f"{seed_kw}는 기준을 고정 안 하면 결론이 계속 바뀜",
                    f"{seed_kw}는 케이스가 섞이면 말이 길어지는 편임",
                    f"{seed_kw}는 분기 기준 하나만 세워도 훨씬 깔끔해짐",
                ])
        prefixes.append((body_lines[0] if body_lines else "")[:25])
        brain["recent_post_prefixes"] = prefixes[-10:]
    except Exception as e:
        log_debug_exc("post:prefix_guard", e)

    # update style history
    try:
        recent_styles.append(style)
        brain["recent_post_styles"] = recent_styles[-10:]
    except Exception as e:
        log_debug_exc("post:style_hist", e)

    title2 = ensure_eum_style(title, max_lines=1).replace("\n", " ")
    body2 = ensure_eum_style("\n".join(body_lines), max_lines=max(2, tuning.max_output_lines))

    meta = {
        "post_style": style,
        "signature": str(get_persona(brain).get("signature", "eum") or "eum"),
        "category": cat,
        "cat": cat,
        "context_key": ctx,
        "seed_kw": seed_kw,
        "thought_id": str(t0.get("id") or "") if isinstance(t0, dict) else "",
    }
    return title2, body2, meta


def do_sync_posts(client: HttpClient, cfg: Config, state: Dict[str, Any], tuning: AgentTuning) -> List[Dict[str, Any]]:
    """Sync main feed posts and record them as 'seen'.

    v19.2:
      - Keep legacy state.seen_post_ids (list) for backward compatibility.
      - Also maintain state.seen.posts (dict: post_id -> seen_ts) with LRU cap.
    """
    posts, _ = list_posts(client, limit=tuning.fetch_limit)

    # legacy list (keep)
    seen_list = state.setdefault("seen_post_ids", [])
    if not isinstance(seen_list, list):
        state["seen_post_ids"] = []
        seen_list = state["seen_post_ids"]

    now_ts = time.time()

    mandatory_votes = bool(getattr(getattr(cfg, "vote_proto", None), "mandatory", True))
    if mandatory_votes:
        try:
            vote_backlog_gc(state, now_ts=now_ts)
        except Exception as e:
            log_debug_exc("vote_backlog:gc_pre", e)

    for p in posts[:]:
        pid = str(p.get("id") or "")
        if not pid:
            continue

        if mandatory_votes:
            try:
                if (not is_own_post(cfg, p)) and (not _is_post_voted(state, pid)):
                    vote_backlog_enqueue(state, pid, now_ts)
            except Exception as e:
                log_debug_exc("vote_backlog:enqueue", e)

        if pid not in seen_list:
            seen_list.append(pid)
        # nested map (LRU capped)
        _record_seen_post(cfg, state, pid, now_ts)

    if mandatory_votes:
        try:
            vote_backlog_gc(state, now_ts=time.time())
        except Exception as e:
            log_debug_exc("vote_backlog:gc_post", e)

    # keep legacy list bounded (very generous; nested map is the real LRU)
    state["seen_post_ids"] = seen_list[-5000:]
    state["last_sync_ts"] = time.time()
    return posts

def _pick_vote_target(cfg: Config, posts: List[Dict[str, Any]]) -> Optional[str]:
    cand: List[Tuple[str, int]] = []
    for p in posts:
        if not isinstance(p, dict):
            continue
        if is_own_post(cfg, p):
            continue
        pid = str(p.get("id") or "")
        if not pid:
            continue
        m = _post_metrics(p)
        cand.append((pid, int(m.get("score", 0))))
    if not cand:
        return None
    cand = sorted(cand, key=lambda x: abs(x[1]))
    return cand[0][0] if cand else None


def do_vote_main_feed(
    client: HttpClient,
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    memory: List[Dict[str, Any]],
    semantic: Dict[str, Any],
    brain: Dict[str, Any],
    posts_cache: List[Dict[str, Any]],
    vote_limiter: SlidingWindowLimiter,
    vote_pace_sec: int
) -> int:
    # ============================================================
    # SECTION 0: Gates (ops_disabled / window / pacing)
    # ============================================================
    # Window + global pacing gates
    if ops_should_skip(state, "vote"):
        protocol_set_reason(state, "vote", "vote:ops_disabled")
        return 0

    if vote_limiter.remaining() <= 0:
        if getattr(cfg, "debug", None) and cfg.debug.log_blocks:
            log_debug("gate:vote blocked by window (remaining=0)")
        protocol_set_reason(state, "vote", "vote:rate_limited", "window_remaining=0")
        return 0

    gap = gap_remaining(float(state.get("last_vote_ts", 0.0) or 0.0), int(vote_pace_sec))
    if gap > 0:
        if getattr(cfg, "debug", None) and cfg.debug.log_blocks:
            log_debug(f"gate:vote blocked by gap ({int(gap)}s)")
        protocol_set_reason(state, "vote", "vote:rate_limited", f"gap={int(gap)}s")
        return 0


    # ============================================================
    # SECTION 1: Target selection (backlog -> feed -> heuristic)
    # ============================================================
    pid: Optional[str] = None
    from_backlog = False

    mandatory_votes = bool(getattr(getattr(cfg, "vote_proto", None), "mandatory", True))
    if mandatory_votes:
        try:
            vote_backlog_gc(state, now_ts=time.time())
            pid = vote_backlog_pick(state)
            if pid:
                from_backlog = True
        except Exception as e:
            log_debug_exc("vote_backlog:pick", e)
            pid = None
            from_backlog = False

        # fallback: scan current feed cache for any unvoted item
        if not pid:
            for p in posts_cache:
                if not isinstance(p, dict):
                    continue
                if is_own_post(cfg, p):
                    continue
                cand = str(p.get("id") or "")
                if not cand:
                    continue
                if not _is_post_voted(state, cand):
                    pid = cand
                    break

    if not pid:
        pid = _pick_vote_target(cfg, posts_cache)
    if not pid:
        try:
            if mandatory_votes and len(_vote_backlog_list(state)) == 0:
                protocol_set_reason(state, "vote", "vote:backlog_empty")
            else:
                protocol_set_reason(state, "vote", "vote:no_target")
        except Exception:
            protocol_set_reason(state, "vote", "vote:no_target")
        return 0

    # double-check (safety)
    if _is_post_voted(state, pid):
        if from_backlog:
            try:
                if vote_backlog_remove(state, pid):
                    vote_backlog_record_drain(state, time.time())
            except Exception as e:
                log_debug_exc("vote_backlog:already_voted", e)
        protocol_set_reason(state, "vote", "vote:no_target", "already_voted")
        return 0

    # consume limiter only when we actually attempt a vote
    if not vote_limiter.allow():
        if getattr(cfg, "debug", None) and cfg.debug.log_blocks:
            log_debug("gate:vote blocked by window (allow=false)")
        protocol_set_reason(state, "vote", "vote:rate_limited", "window_allow=false")
        return 0


    # ============================================================
    # SECTION 2: Decide vote type (up/down) + safety heuristics
    # ============================================================
    # Self-policing: downvote obvious rule violators / injection / offensive content
    enforce_self_policing = _env_bool("MERSOOM_SELF_POLICING", True)
    vtype = "up"
    sp_reason = ""
    if enforce_self_policing:
        try:
            ptxt = ""
            for p in posts_cache:
                if isinstance(p, dict) and str(p.get("id") or "") == pid:
                    ptxt = f"{p.get('title', '')} {p.get('content', '')}".strip()
                    break

            toxic, treason = is_toxic_incoming(ptxt)
            viol, vreason = looks_like_rule_violation(ptxt)
            if bool(toxic):
                vtype = "down"
                sp_reason = f"toxic:{treason}"
            elif bool(viol):
                vtype = "down"
                sp_reason = f"rule:{vreason}"
        except Exception as e:
            log_debug_exc("self_policing:vote", e)

    # Optional: stochastic downvote (disabled by default)
    if vtype != "down":
        down_prob = _env_float("MERSOOM_VOTE_DOWN_PROB", 0.0, 0.0, 1.0)
        vtype = "down" if (float(down_prob) > 0.0 and random.random() < float(down_prob)) else "up"

    if sp_reason and getattr(cfg, "debug", None) and cfg.debug.log_blocks:
        log_debug(f"self_policing vote=down reason={sp_reason} post={pid}")


    # ============================================================
    # SECTION 3: Submit vote + update state/counters
    # ============================================================
    _bump_action_counter(state, "action_attempt", "vote")
    try:
        ok = vote_post(client, cfg, state, pid, vtype)
    except RateLimitError as e_rl:
        protocol_set_reason(state, "vote", "vote:rate_limited", one_line(str(e_rl), 180))
        raise
    except PowTimeoutError as e:
        protocol_set_reason(state, "vote", "vote:pow_timeout", one_line(str(e), 180))
        _bump_action_counter(state, "action_fail", "vote")
        return 0
    except Exception as e:
        protocol_set_reason(state, "vote", "vote:no_target", one_line(repr(e), 180))
        raise

    if not ok:
        protocol_set_reason(state, "vote", "vote:no_target", "vote_post_failed")
        _bump_action_counter(state, "action_fail", "vote")
    else:
        _bump_action_counter(state, "action_success", "vote")


    if from_backlog:
        try:
            if ok or _is_post_voted(state, pid):
                if vote_backlog_remove(state, pid):
                    vote_backlog_record_drain(state, time.time())
        except Exception as e:
            log_debug_exc("vote_backlog:drain", e)

    state["last_vote_ts"] = time.time()
    state["total_actions"] = int(state.get("total_actions", 0)) + 1

    try:
        update_persona_maturity(brain, state)
    except Exception as e:
        log_exception("brain:maturity", e, context={"stage": "do_vote_main_feed", "action": f"vote:{vtype}", "post_id": str(pid)})
        if _should_failfast("brain") or _should_failfast("vote"):
            raise

    try:
        bump_semantic(semantic, _today_kst(), f"vote:{vtype}", 1.0)
    except Exception as e:
        log_exception("semantic:bump", e, context={"stage": "do_vote_main_feed", "action": f"vote:{vtype}", "post_id": str(pid), "key": f"vote:{vtype}"})
        if _should_failfast("semantic") or _should_failfast("vote"):
            raise

    record_memory(memory, {
        "ts": time.time(),
        "action": f"vote:{vtype}",
        "post_id": pid,
        "evaluated": True,
        "reward_scalar": 0.0,
    }, tuning, archive_path_jsonl="")

    log_action("VOTE", f"{vtype} post={pid} ok={ok}")
    return 1

def _flow_keywords(brain: Optional[Dict[str, Any]], *, k: int = 6) -> List[str]:
    if not isinstance(brain, dict):
        return []
    com = _safe_dict(brain.get("community"))
    out: List[str] = []
    for bucket in ("rising", "hot"):
        for it in _safe_list(com.get(bucket))[:k]:
            if isinstance(it, dict) and it.get("kw"):
                out.append(str(it.get("kw")))
    # de-dup keep order
    seen = set()
    res: List[str] = []
    for x in out:
        if x and x not in seen:
            seen.add(x)
            res.append(x)
    return res[:k]

def _bump_relation(state: Dict[str, Any], user_key: str) -> None:
    if not user_key:
        return
    rel = state.setdefault("relations", {})
    if not isinstance(rel, dict):
        state["relations"] = {}
        rel = state["relations"]
    obj = rel.get(user_key)
    if not isinstance(obj, dict):
        obj = {"interactions": 0, "last_ts": 0.0}
    obj["interactions"] = int(obj.get("interactions", 0)) + 1
    obj["last_ts"] = time.time()
    rel[user_key] = obj