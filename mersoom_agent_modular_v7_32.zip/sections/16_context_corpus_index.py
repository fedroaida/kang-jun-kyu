################################################################################
# 16. CONTEXT & CORPUS INDEX
# Deps: 01-03, 08-14
# Used by: generation + target selection
# Notes: Corpus store + BM25/semantic scaffolding.
################################################################################
"""
SECTION 16 - CONTEXT + CORPUS INDEX

Loads and maintains local corpus indices used for retrieval-like behavior.

Responsibilities:
- Load threads/comments snapshots.
- Build lightweight indices (e.g., BM25) to reuse prior high-quality text patterns.
- Provide search APIs used by generation and target selection.

Notes:
- Retrieval is a safety feature: it reduces hallucinated structure by reusing known-good patterns.
"""
def load_threads(path: str) -> Dict[str, Any]:
    d = load_json_file(path, default={})
    if isinstance(d, dict):
        try:
            _migrate_threads_payload_inplace(d)
        except Exception as e:
            log_debug_exc("load_threads:migrate", e)
        return d
    return {}

def load_users(path: str) -> Dict[str, Any]:
    d = load_json_file(path, default={})
    return d if isinstance(d, dict) else {}

def _safe_list(x: Any) -> List[Any]:
    return x if isinstance(x, list) else []

def _safe_dict(x: Any) -> Dict[str, Any]:
    return x if isinstance(x, dict) else {}


def _extract_id_from_obj(obj: Any, keys: Tuple[str, ...]) -> str:
    if not isinstance(obj, dict):
        return ""
    for k in keys:
        v = obj.get(k)
        if v:
            return str(v)
    return ""

def _extract_comment_id(res: Any) -> str:
    return _extract_id_from_obj(res, ("id", "comment_id", "commentId"))

def _extract_post_id(res: Any) -> str:
    return _extract_id_from_obj(res, ("id", "post_id", "postId"))

def _note_reply_received(
    state: Dict[str, Any],
    memory: List[Dict[str, Any]],
    *,
    post_id: str,
    my_comment_id: str,
    reply_comment_id: str,
) -> None:
    """Best-effort: mark that one of my comments received a reply (deduped)."""
    if not my_comment_id or not reply_comment_id:
        return
    now = time.time()

    seen = _safe_dict(state.get("reply_seen_ids"))
    # dedup by reply comment id (global)
    if reply_comment_id in seen:
        return
    seen[reply_comment_id] = now

    # prune seen map (keep recent ~1000)
    if len(seen) > 1200:
        try:
            items = sorted(seen.items(), key=lambda x: float(x[1] or 0.0), reverse=True)[:900]
            seen = {k: v for k, v in items}
        except Exception as e:
            log_debug_exc("_note_reply_received:silent", e)
            pass
    state["reply_seen_ids"] = seen

    reps = _safe_dict(state.get("my_comment_replies"))
    info = _safe_dict(reps.get(my_comment_id))
    info["count"] = int(info.get("count", 0) or 0) + 1
    info["last_ts"] = now
    info["post_id"] = str(post_id or "")
    reps[my_comment_id] = info

    # prune reply map
    if len(reps) > 1500:
        try:
            items = sorted(reps.items(), key=lambda kv: float(_safe_dict(kv[1]).get("last_ts", 0.0) or 0.0), reverse=True)[:1000]
            reps = {k: v for k, v in items}
        except Exception as e:
            log_debug_exc("_note_reply_received:silent", e)
            pass
    state["my_comment_replies"] = reps

    # annotate recent memory item if present
    try:
        for it in reversed(_safe_list(memory)[-500:]):
            if not isinstance(it, dict):
                continue
            if str(it.get("comment_id") or "") != str(my_comment_id):
                continue
            it["reply_received"] = int(info.get("count", 0) or 0)
            it["reply_received_last_ts"] = float(info.get("last_ts", 0.0) or 0.0)
            break
    except Exception as e:
        log_debug_exc("_note_reply_received:silent", e)
        pass


def get_thread(state: Dict[str, Any], post_id: str) -> Dict[str, Any]:
    threads = state.get("threads")
    if not isinstance(threads, dict):
        threads = {}
        state["threads"] = threads

    th = threads.get(post_id)
    if not isinstance(th, dict):
        th = {
            "post_id": post_id,
            "topic": "",
            "keywords": [],
            "category": "",
            "participants": {},          # user_key -> stats
            "last_seen_ts": 0.0,
            "last_my_action_ts": 0.0,
            "last_k_turns": [],          # [{speaker,text,ts,kind}]
            "open_questions": [],        # [{qid,text,ts,status,asked_by,last_seen_remote_id,resolve_ts}]
            "phase": "open",             # open|argue|clarify|close
            "phase_ts": 0.0,             # epoch seconds
            "summary": "",               # short synthesized summary
            "claims": [],                # extracted claim-like sents
            "tensions": [],              # extracted counter-like sents
            "seen_comment_ids": {},      # comment_id -> ts
            "turn_hashes": [],           # [[hash, ts], ...] for dedup
            "my_stance_snapshot": {},    # later
        }
        threads[post_id] = th
    else:
        th = _migrate_thread_schema_inplace(th, post_id)
        threads[post_id] = th
    return threads[post_id]


def _interaction_fsm_enabled(state: Optional[Dict[str, Any]]) -> bool:
    """Return whether interaction FSM behaviors are enabled.

    Policy:
      - If env MERSOOM_INTERACTION_FSM is set (any value), it is authoritative.
      - Otherwise fall back to persisted state.protocol.interaction_fsm_enabled (backward compatible).
    """
    try:
        if os.getenv("MERSOOM_INTERACTION_FSM") is not None:
            return bool(_env_bool("MERSOOM_INTERACTION_FSM", False))

        if not isinstance(state, dict):
            return False
        proto = _safe_dict(state.get("protocol"))
        return bool(proto.get("interaction_fsm_enabled", False))
    except Exception:
        return False

def _openq_track_enabled(state: Optional[Dict[str, Any]]) -> bool:
    """Return whether open-question tracking is enabled.

    Policy:
      - If env MERSOOM_OPENQ_TRACK is set (any value), it is authoritative.
      - Otherwise fall back to persisted state.protocol.openq_track_enabled (backward compatible).
    """
    try:
        if os.getenv("MERSOOM_OPENQ_TRACK") is not None:
            # default=True to preserve prior behavior when flag is set but empty
            return bool(_env_bool("MERSOOM_OPENQ_TRACK", True))

        if not isinstance(state, dict):
            return True
        proto = _safe_dict(state.get("protocol"))
        return bool(proto.get("openq_track_enabled", True))
    except Exception:
        return True


def _waiting_strict_enabled(state: Optional[Dict[str, Any]]) -> bool:
    """Return whether strict waiting_for_remote behavior is enabled.

    Policy:
      - If env MERSOOM_WAITING_STRICT is set (any value), it is authoritative.
      - Otherwise fall back to persisted state.protocol.waiting_strict_enabled (default: False).
    """
    try:
        if os.getenv("MERSOOM_WAITING_STRICT") is not None:
            return bool(_env_bool("MERSOOM_WAITING_STRICT", False))
        if not isinstance(state, dict):
            return False
        proto = _safe_dict(state.get("protocol"))
        return bool(proto.get("waiting_strict_enabled", False))
    except Exception:
        return False


def _reply_score_v2_enabled(state: Optional[Dict[str, Any]]) -> bool:
    """Return whether reply queue scoring v2 is enabled.

    Policy:
      - If env MERSOOM_REPLY_SCORE_V2 is set (any value), it is authoritative.
      - Otherwise fall back to persisted state.protocol.reply_score_v2_enabled (default: False).
    """
    try:
        if os.getenv("MERSOOM_REPLY_SCORE_V2") is not None:
            return bool(_env_bool("MERSOOM_REPLY_SCORE_V2", False))
        if not isinstance(state, dict):
            return False
        proto = _safe_dict(state.get("protocol"))
        return bool(proto.get("reply_score_v2_enabled", False))
    except Exception:
        return False


def _thread_open_q_open_count(th: Any) -> int:
    try:
        if not isinstance(th, dict):
            return 0
        oq = th.get("open_questions")
        if not isinstance(oq, list):
            return 0
        n = 0
        for q in oq:
            if isinstance(q, dict):
                st = str(q.get("status") or "open")
                if st == "open":
                    n += 1
            else:
                n += 1
        return int(n)
    except Exception:
        return 0


def _waiting_for_remote_on_item(state: Dict[str, Any], post_id: str, comment_id: str, parent_id: str) -> bool:
    """Best-effort: check waiting_for_remote without fetching full thread tree.

    Uses conv_state keys that are typically based on the reply root. We try both parent_id and comment_id.
    """
    try:
        convs = state.get("conv_state")
        if not isinstance(convs, dict):
            return False
        pid = str(post_id or "")
        if not pid:
            return False
        for root in (str(parent_id or ""), str(comment_id or "")):
            if not root:
                continue
            k = _reply_conv_key(pid, root)
            cv = convs.get(k)
            if isinstance(cv, dict) and bool(cv.get("waiting_for_remote")):
                return True
        return False
    except Exception:
        return False


def _reply_score_v2(state: Dict[str, Any], item: Dict[str, Any], now_ts: float) -> Tuple[float, Dict[str, Any]]:
    """Compute expanded reply priority score.

    Adds:
      + open question bonus (thread has unresolved questions)
      + freshness bonus (recent comments)
      - waiting_for_remote penalty (avoid consecutive replies in same thread)
    """
    base = float(item.get("score", 0.0) or 0.0)
    pid = str(item.get("post_id") or "")
    cid = str(item.get("comment_id") or "")
    parent_id = str(item.get("replied_to_comment_id") or "")

    # open questions bonus
    oq_bonus = 0.0
    try:
        th = _safe_dict(_safe_dict(state.get("threads")).get(pid))
        if _thread_open_q_open_count(th) > 0:
            oq_bonus = 28.0
    except Exception:
        oq_bonus = 0.0

    # freshness bonus (decays with age)
    cts = float(item.get("comment_ts", 0.0) or 0.0)
    age = max(0.0, float(now_ts) - float(cts)) if cts > 0 else 1e9
    # 0s -> +34, 30m -> ~+20, 2h -> ~+5
    fresh = 34.0 * math.exp(-age / 1800.0) if age < 1e8 else 0.0

    # waiting penalty
    waiting = bool(_waiting_for_remote_on_item(state, pid, cid, parent_id))
    wait_pen = 120.0 if waiting else 0.0

    # small direct-reply bias to stabilize ordering
    direct = 8.0 if bool(item.get("reply_to_my_comment")) else 0.0

    score = base + direct + oq_bonus + fresh - wait_pen
    breakdown = {
        "base": round(base, 3),
        "direct": round(direct, 3),
        "openq": round(oq_bonus, 3),
        "fresh": round(fresh, 3),
        "wait_pen": round(wait_pen, 3),
        "age_sec": int(age) if age < 1e8 else None,
    }
    return float(score), breakdown


_OPENQ_QWORD_RE = re.compile(
    r"(\?$|\?|\b(why|what|how|when|where|who)\b|(?:^|[\s\W])(왜(?!냐하면)|뭐|무엇|어떻게|어째서|어떤|어디|언제|누구|맞나)(?:$|[\s\W]))",
    re.IGNORECASE,
)


def _is_open_question_text(text: str) -> bool:
    t = (text or "").strip()
    if not t:
        return False
    # Primary signal
    if "?" in t:
        return True
    # Secondary signal: question words (avoid common false positives like "왜냐하면")
    return bool(_OPENQ_QWORD_RE.search(t))


def _extract_open_question_text(text: str, max_len: int = 220) -> str:
    """Extract a compact question-like snippet from outgoing text."""
    t = one_line(text or "", max_len * 2).strip()
    if not t:
        return ""
    if "?" in t:
        qpos = t.rfind("?")
        # find a soft sentence boundary before the last '?'
        start = max(t.rfind(". ", 0, qpos), t.rfind("! ", 0, qpos), t.rfind("…", 0, qpos), t.rfind("\n", 0, qpos))
        if start < 0:
            start = 0
        else:
            start = min(len(t), start + 2)
        frag = t[start : qpos + 1].strip()
        if frag:
            return one_line(frag, max_len)
    return one_line(t, max_len)

# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------

_OPENQ_MIN_REPLY_CHARS = 12
_OPENQ_TTL_SEC = 12 * 60 * 60  # expire open questions after 12 hours (safe default)

def _prune_open_questions(items: Any, keep_open: int = 8, keep_hist: int = 4) -> List[Dict[str, Any]]:
    """Keep open questions small and useful: keep recent opens + a little history."""
    oq = _normalize_open_questions_list(items)
    open_items = [q for q in oq if str(q.get("status") or "open") == "open"]
    hist_items = [q for q in oq if str(q.get("status") or "") in ("resolved", "expired")]

    def _fnum(x: Any) -> float:
        try:
            return float(x or 0.0)
        except Exception:
            return 0.0

    open_items = sorted(open_items, key=lambda q: _fnum(q.get("ts")))
    hist_items = sorted(hist_items, key=lambda q: _fnum(q.get("resolve_ts")))

    ko = max(0, int(keep_open or 0))
    kh = max(0, int(keep_hist or 0))

    if ko > 0:
        open_items = open_items[-ko:]
    if kh > 0:
        hist_items = hist_items[-kh:]
    else:
        hist_items = []

    return open_items + hist_items

def _openq_core_tokens(text: str, max_toks: int = 3) -> List[str]:
    toks = tokenize(text or "", max_tokens=48)
    out: List[str] = []
    lim = max(1, int(max_toks or 3))
    for t in toks:
        if not t:
            continue
        if t in out:
            continue
        out.append(t)
        if len(out) >= lim:
            break
    return out

def _openq_should_resolve(q: Dict[str, Any], reply_text: str) -> bool:
    rt = (reply_text or "").strip()
    if len(rt) < _OPENQ_MIN_REPLY_CHARS:
        return False

    qtext = str(q.get("text") or "").strip()
    if not qtext:
        return False

    q_toks = _openq_core_tokens(qtext, max_toks=3)
    if not q_toks:
        return False

    r_toks = set(tokenize(rt, max_tokens=90))
    if not r_toks:
        return False

    overlap = sum(1 for t in q_toks if t in r_toks)
    need = 2 if len(q_toks) >= 2 else 1
    return overlap >= need

def thread_openq_expire_old(state: Optional[Dict[str, Any]], th: Dict[str, Any], now_ts: Optional[float] = None) -> int:
    """Expire stale open questions on a thread. Returns number expired."""
    try:
        if not isinstance(th, dict):
            return 0
        now = float(now_ts if now_ts is not None else time.time())
        oq = _normalize_open_questions_list(th.get("open_questions", []))
        changed = 0
        for q in oq:
            try:
                if str(q.get("status") or "open") != "open":
                    continue
                ts = float(q.get("ts", 0.0) or 0.0)
                if ts <= 0:
                    continue
                if (now - ts) > float(_OPENQ_TTL_SEC):
                    q["status"] = "expired"
                    q["resolve_ts"] = now
                    changed += 1
                    if isinstance(state, dict):
                        protocol_bump_counter(state, "openq_expire", 1)
                        try:
                            proto = _sdict(state, "protocol")
                            proto["openq_expired_total"] = int(proto.get("openq_expired_total", 0) or 0) + 1
                        except Exception:
                            pass
                    log_event(
                        "openq.expire",
                        post_id=str(th.get("post_id") or ""),
                        qid=str(q.get("qid") or ""),
                        age_sec=int(max(0.0, now - ts)),
                    )
            except Exception:
                continue
        th["open_questions"] = _prune_open_questions(oq, keep_open=8, keep_hist=4)
        return int(changed)
    except Exception:
        return 0

def thread_openq_try_resolve_on_remote_turn(
    state: Optional[Dict[str, Any]],
    th: Dict[str, Any],
    remote_nick: str,
    remote_text: str,
    remote_comment_id: str = "",
    cfg: Optional[Config] = None,
) -> int:
    """Try to resolve the most recent open question if the remote turn appears to answer it."""
    try:
        if not isinstance(th, dict):
            return 0
        oq = _normalize_open_questions_list(th.get("open_questions", []))
        # consider only OPEN questions asked by the agent (asked_by == "me" or empty)
        candidates = []
        for q in oq:
            try:
                if str(q.get("status") or "open") != "open":
                    continue
                ab = str(q.get("asked_by") or "")
                if ab not in ("", "me"):
                    continue
                candidates.append(q)
            except Exception:
                continue

        if not candidates:
            th["open_questions"] = _prune_open_questions(oq, keep_open=8, keep_hist=4)
            return 0

        # newest first
        candidates = sorted(candidates, key=lambda q: float(q.get("ts", 0.0) or 0.0), reverse=True)

        resolved = 0
        for q in candidates:
            if _openq_should_resolve(q, remote_text):
                q["status"] = "resolved"
                q["resolve_ts"] = float(time.time())
                q["last_seen_remote_id"] = str(remote_comment_id or "")
                resolved = 1
                if isinstance(state, dict):
                    protocol_bump_counter(state, "openq_resolve", 1)
                    try:
                        proto = _sdict(state, "protocol")
                        proto["openq_resolved_total"] = int(proto.get("openq_resolved_total", 0) or 0) + 1
                    except Exception:
                        pass
                log_event(
                    "openq.resolve",
                    post_id=str(th.get("post_id") or ""),
                    qid=str(q.get("qid") or ""),
                    by=str(remote_nick or ""),
                    comment_id=str(remote_comment_id or ""),
                )
                break

        th["open_questions"] = _prune_open_questions(oq, keep_open=8, keep_hist=4)
        return int(resolved)
    except Exception:
        return 0

_PHASE_QUESTION_RE = re.compile(r"(\?|\b(why|what|how|when|where|who)\b|(?:^|[\s\W])(왜|뭐|무엇|어떻게|어째서|어떤|어디|언제|누구|맞나)(?:$|[\s\W]))", re.IGNORECASE)
_PHASE_ARGUE_RE = re.compile(r"\b(아님|아니|반박|틀림|오류|근거|증거|팩트|사실)\b", re.IGNORECASE)
_PHASE_CLOSE_RE = re.compile(r"\b(정리|결론|동의|요약|합의|마무리)\b", re.IGNORECASE)


def _classify_thread_phase(text: str) -> Tuple[str, str]:
    """Classify a thread phase from a single turn (rule-based; LLM-free).

    Priority (per spec):
      1) question -> clarify
      2) argue/negation -> argue
      3) agreement/summary -> close
      else -> open
    Returns: (phase, reason_tag)
    """
    t = (text or "").strip()
    if not t:
        return "open", "empty"
    if _PHASE_QUESTION_RE.search(t):
        return "clarify", "question"
    if _PHASE_ARGUE_RE.search(t):
        return "argue", "argue_kw"
    if _PHASE_CLOSE_RE.search(t):
        return "close", "close_kw"
    return "open", "default"


def thread_update_phase_if_needed(
    state: Optional[Dict[str, Any]],
    th: Dict[str, Any],
    text: str,
    source: str = "",
) -> None:
    """Update thread phase in-place (best-effort). Only active when interaction FSM is enabled."""
    try:
        if not _interaction_fsm_enabled(state):
            return
        if not isinstance(th, dict):
            return
        old = str(th.get("phase") or "open")
        new, reason = _classify_thread_phase(text)
        if new != old:
            th["phase"] = str(new)
            th["phase_ts"] = float(time.time())
            if isinstance(state, dict):
                protocol_bump_counter(state, "phase_transition", 1)
            log_event(
                "thread.phase",
                post_id=str(th.get("post_id") or ""),
                old=old,
                new=new,
                reason=str(reason),
                source=str(source or ""),
            )
    except Exception:
        return

def thread_bucket_key(th: Dict[str, Any]) -> str:
    cat = str(th.get("category") or "")
    return cat or "thread"

def get_user(state: Dict[str, Any], user_key: str) -> Dict[str, Any]:
    users = state.setdefault("users", {})
    if user_key not in users or not isinstance(users.get(user_key), dict):
        users[user_key] = {
            "user_key": user_key,
            "aggression": 0.0,
            "helpfulness": 0.0,
            "topic_pref": {},
            "last_seen_ts": 0.0,
            "turns": 0,
        }
    return users[user_key]

def user_bucket_key(user: Dict[str, Any]) -> str:
    agg = float(user.get("aggression", 0.0))
    if agg >= 0.6:
        return "hot"
    if agg <= 0.2:
        return "calm"
    return "mid"

def thread_add_turn(th: Dict[str, Any], speaker: str, text: str, kind: str) -> None:
    # dedup turns to avoid "re-ingest spam"
    th.setdefault("turn_hashes", [])
    th["turn_hashes"] = _clean_hash_list(_safe_list(th.get("turn_hashes", [])), ttl_sec=6 * 60 * 60, keep_max=1200)

    norm = one_line(text, 320)
    h = _text_hash(f"{kind}|{speaker}|{norm}")
    if any(x[0] == h for x in th.get("turn_hashes", [])):
        th["last_seen_ts"] = time.time()
        return

    th["turn_hashes"].append([h, time.time()])

    th.setdefault("last_k_turns", [])
    th["last_k_turns"].append({
        "speaker": str(speaker or ""),
        "text": one_line(text, 600),
        "ts": time.time(),
        "kind": kind,
    })
    # cap
    th["last_k_turns"] = th["last_k_turns"][-20:]
    th["last_seen_ts"] = time.time()

def thread_add_open_question(th: Dict[str, Any], qtext: str, asked_by: str = "me", last_seen_remote_id: str = "") -> str:
    qid = hashlib.sha1(f"{time.time()}|{qtext}".encode("utf-8")).hexdigest()[:10]
    th.setdefault("open_questions", [])
    th["open_questions"] = _normalize_open_questions_list(th.get("open_questions", []))
    th["open_questions"].append({
        "qid": qid,
        "text": one_line(qtext, 220),
        "ts": time.time(),
        "status": "open",
        "asked_by": str(asked_by or "me"),
        "last_seen_remote_id": str(last_seen_remote_id or ""),
        "resolve_ts": 0.0,
    })
    th["open_questions"] = _prune_open_questions(th.get("open_questions", []), keep_open=8, keep_hist=4)
    return qid

def thread_pop_open_question(th: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    oq = _safe_list(th.get("open_questions"))
    if not oq:
        return None
    return oq[-1]

def _participant_bump(th: Dict[str, Any], user_key: str) -> None:
    p = th.setdefault("participants", {})
    if user_key not in p or not isinstance(p.get(user_key), dict):
        p[user_key] = {"turns": 0, "last_ts": 0.0}
    p[user_key]["turns"] = int(p[user_key].get("turns", 0)) + 1
    p[user_key]["last_ts"] = time.time()

def ingest_post_into_context(state: Dict[str, Any], post: Dict[str, Any], brain: Optional[Dict[str, Any]] = None) -> None:
    pid = str(post.get("id") or post.get("post_id") or "")
    if not pid:
        return
    th = get_thread(state, pid)
    synthesize_thread(th)
    title = str(post.get("title") or "")
    content = str(post.get("content") or "")
    cat, _ = classify_text(f"{title}\n{content}")
    th["category"] = cat
    th["topic"] = title[:80]
    th["keywords"] = top_keywords(f"{title} {content}", k=8)
    nick = str(post.get("nickname") or post.get("author") or "")
    if nick:
        _participant_bump(th, nick)

    # one-time thought for newly observed thread
    if brain is not None and not th.get("post_ingested"):
        th["post_ingested"] = True
        add_thought(
            brain,
            kind="observe_post",
            topic=title[:80] or ((th.get("keywords") or [""])[0] if isinstance(th.get("keywords"), list) else ""),
            text=_simple_summary(f"{title} {content}", max_len=180),
            tags=_safe_list(th.get("keywords"))[:6],
            links={"post_id": pid, "author": nick},
            strength=0.55,
        )

    thread_add_turn(th, nick or "OP", f"{title} {content}", "post")
    thread_update_phase_if_needed(state, th, f"{title} {content}", source="ingest_post")

def ingest_comments_into_context(state: Dict[str, Any], post_id: str, comments: List[Dict[str, Any]], brain: Optional[Dict[str, Any]] = None, cfg: Optional[Config] = None) -> None:
    th = get_thread(state, post_id)
    th.setdefault("seen_comment_ids", {})
    seen = _safe_dict(th.get("seen_comment_ids"))

    # only ingest truly new comments (avoid thrashing)
    for c in comments[-12:]:
        cid = str(c.get("id") or "")
        if cid and cid in seen:
            continue

        nick = str(c.get("nickname") or c.get("author") or "")
        text = str(c.get("content") or "")
        if not text:
            continue

        if cid:
            seen[cid] = time.time()


        _participant_bump(th, nick or "user")

        tox_cfg = getattr(cfg, "toxic", None) if cfg is not None else None
        tox, tox_reason = is_toxic_incoming(text)
        if tox and tox_cfg and bool(getattr(tox_cfg, "exclude_from_learning", True)):
            # do NOT feed toxic raw text into thread turns / template mining inputs
            th["toxic_hits"] = int(th.get("toxic_hits", 0) or 0) + 1
            try:
                tc = th.setdefault("toxic_comment_ids", {})
                if not isinstance(tc, dict):
                    th["toxic_comment_ids"] = {}
                    tc = th["toxic_comment_ids"]
                if cid:
                    tc[str(cid)] = {"ts": time.time(), "reason": str(tox_reason)}
                _lru_prune_map(tc, 200)
            except Exception as e:
                log_debug_exc("ingest_comments_into_context:silent", e)
                pass
        else:
            thread_add_turn(th, nick or "user", text, "comment")
            thread_update_phase_if_needed(state, th, text, source="ingest")

            try:
                if _openq_track_enabled(state):
                    is_me = False
                    try:
                        if cfg is not None:
                            is_me = (str(nick or "") == str(getattr(cfg, "nickname", "")))
                    except Exception:
                        is_me = False
                    if not is_me:
                        thread_openq_try_resolve_on_remote_turn(state, th, nick, text, cid, cfg=cfg)
            except Exception:
                pass

        # update user model lightly
        if nick:
            u = get_user(state, nick)
            u["turns"] = int(u.get("turns", 0)) + 1
            u["last_seen_ts"] = time.time()
            if looks_offensive(text):
                u["aggression"] = min(1.0, float(u.get("aggression", 0.0)) + 0.12)
            if any(k in text for k in ["정리", "도움", "참고", "설명", "근거"]):
                u["helpfulness"] = min(1.0, float(u.get("helpfulness", 0.0)) + 0.08)
            # topic preference
            for kw in _safe_list(th.get("keywords"))[:6]:
                if not kw:
                    continue
                tp = _safe_dict(u.get("topic_pref"))
                tp[kw] = float(tp.get(kw, 0.0)) + 1.0
                u["topic_pref"] = tp

        # selective thought capture (questions / conflict / good explanations)
        if brain is not None:
            capture = False
            if "?" in text or text.strip().endswith("?"):
                capture = True
            if looks_offensive(text):
                capture = True
            if any(k in text for k in ["근거", "예시", "재현", "정리"]):
                capture = True

            if capture:
                add_thought(
                    brain,
                    kind="observe_comment",
                    topic=(th.get("topic") or (th.get("keywords") or [""])[0] or "thread")[:80],
                    text=_simple_summary(text, max_len=180),
                    tags=_safe_list(th.get("keywords"))[:6],
                    links={"post_id": post_id, "author": nick, "comment_id": cid},
                    strength=0.45,
                )

    # keep under control
    # prune seen ids
    if len(seen) > 800:
        # keep latest by ts
        items = sorted(seen.items(), key=lambda kv: float(kv[1] or 0.0))
        seen = dict(items[-700:])
    th["seen_comment_ids"] = seen

# --- CORPUS + BM25 ---

def load_corpus_jsonl(path: str, *, max_docs: int = 4000) -> List[Dict[str, Any]]:
    if not path or not os.path.exists(path):
        return []
    out: List[Dict[str, Any]] = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        out.append(obj)
                except Exception:
                    continue
    except Exception:
        return []
    return out[-max(1, int(max_docs)):]

def corpus_doc_id(kind: str, post_id: str, author: str, text: str) -> str:
    s = f"{kind}|{post_id}|{author}|{text}"
    return hashlib.sha1(s.encode("utf-8")).hexdigest()[:16]

def append_corpus_doc(path: str, doc: Dict[str, Any]) -> None:
    append_jsonl(path, doc)

class BM25Index:
    def __init__(self) -> None:
        self.doc_len: Dict[str, int] = {}
        self.doc_meta: Dict[str, Dict[str, Any]] = {}
        self.df: Dict[str, int] = {}
        self.postings: Dict[str, List[Tuple[str, int]]] = {}  # term -> [(doc_id, tf)]
        self.N = 0
        self.avgdl = 0.0

    def build(self, docs: List[Dict[str, Any]], *, max_docs: int = 3000) -> None:
        self.doc_len.clear()
        self.doc_meta.clear()
        self.df.clear()
        self.postings.clear()

        kept = docs[-max(1, int(max_docs)):]
        self.N = 0
        total_len = 0

        for d in kept:
            if not isinstance(d, dict):
                continue
            doc_id = str(d.get("doc_id") or "")
            text = str(d.get("text") or "")
            if not doc_id or not text:
                continue
            toks = d.get("tokens")
            if not isinstance(toks, list):
                toks = tokenize(text, max_tokens=260)
                try:
                    d["tokens"] = toks  # cache tokens for future rebuilds
                except Exception:
                    pass
            tf: Dict[str, int] = {}
            for t in toks:
                tf[t] = tf.get(t, 0) + 1

            self.N += 1
            dl = sum(tf.values())
            total_len += dl
            self.doc_len[doc_id] = dl
            self.doc_meta[doc_id] = d

            for term in tf.keys():
                self.df[term] = self.df.get(term, 0) + 1
            for term, c in tf.items():
                self.postings.setdefault(term, []).append((doc_id, int(c)))

        self.avgdl = (total_len / self.N) if self.N > 0 else 0.0
def search(
    self,
    query_tokens: List[str],
    *,
    topk: int = 6,
    min_score: float = 0.0,
    normalize_scores: bool = True,
) -> List[Tuple[str, float]]:
    """
    BM25 search.
    - min_score: filter by score threshold (applied after optional normalization)
    - normalize_scores: scale scores to 0..100 (relative to max hit) for stability
    """
    if self.N <= 0 or not query_tokens:
        return []
    k1 = 1.2
    b = 0.75

    scores: Dict[str, float] = {}
    q = list(dict.fromkeys(query_tokens))[:20]
    for term in q:
        df = self.df.get(term, 0)
        if df <= 0:
            continue
        idf = math.log(1 + (self.N - df + 0.5) / (df + 0.5))
        for doc_id, tf in self.postings.get(term, []):
            dl = self.doc_len.get(doc_id, 0)
            denom = tf + k1 * (1 - b + b * (dl / max(1e-9, self.avgdl)))
            s = idf * (tf * (k1 + 1) / max(1e-9, denom))
            scores[doc_id] = scores.get(doc_id, 0.0) + s

    if not scores:
        return []

    try:
        tk = max(1, int(topk))
    except Exception:
        tk = 6

    mx = 0.0
    try:
        mx = max(scores.values())
    except Exception:
        mx = 0.0

    cand_n = max(tk * 8, 12)
    ranked = heapq.nlargest(cand_n, scores.items(), key=lambda kv: kv[1])

    if normalize_scores and mx > 1e-12:
        ranked = [(doc_id, (score / mx) * 100.0) for doc_id, score in ranked]

    try:
        ms = float(min_score or 0.0)
    except Exception:
        ms = 0.0
    if ms > 0.0:
        ranked = [(doc_id, score) for doc_id, score in ranked if score >= ms]

    return ranked[:tk]


    def _sanitize_line(s2: str) -> str:
        s2s = s2.strip()
        # replace common meta-openers
        for bad in ("요지는", "핵심은", "포인트는", "본문 요지는", "그 댓글 요지는", "결론은", "정리하면", "요약하면", "한 줄 요약은"):
            if s2s.startswith(bad):
                rest = s2s[len(bad):].lstrip(" :,-")
                s2s = ("쟁점은 " + rest).strip()
                break
        # remove meme-like openers completely
        for ban in ("여기서부터가 꿀잼 구간임", "논점은 잡히는 느낌임", "감정은 제외하고", "정의→기준→검증", "정의->기준->검증", "정의 → 기준 → 검증"):
            s2s = s2s.replace(ban, "").strip()
        return s2s if s2s else s2.strip()

    for s in sents[:3]:
        s2 = one_line(s, 180)
        s2 = _sanitize_line(s2)
        if not s2:
            continue
        if kws:
            s2 = s2.replace(kws[0], "{KW}")
        lines.append(s2)

    tpl = "\n".join(lines).strip()
    return tpl
