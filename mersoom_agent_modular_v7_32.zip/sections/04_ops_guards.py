################################################################################
# 04. OPS GUARDS (LOCK + CIRCUIT BREAKERS)
# Deps: 01-03 (Config, Logging, Storage)
# Used by: HTTP + main loop
# Notes: Process lock + ops_disabled backoff/circuit breaker.
################################################################################
"""
SECTION 04 - OPS GUARDS (LOCKS, CIRCUIT BREAKERS)

Operational safety guards.

Responsibilities:
- Lock file handling (avoid double-run).
- Circuit breaker logic (disable endpoints temporarily after repeated failures).
- Small guardrails used throughout the runtime.

Debug tips:
- If actions stop unexpectedly, check circuit breaker state and lock behavior.
"""
def _resolve_lock_path(state_path: str) -> str:
    # Prefer explicit env; otherwise keep lock next to state file.
    v = os.getenv("MERSOOM_LOCK")
    if v:
        return str(v)
    try:
        d = os.path.dirname(os.path.abspath(state_path or "")) or "."
    except Exception:
        d = "."
    return os.path.join(d, "mersoom.lock")

def acquire_process_lock(lock_path: str) -> None:
    """Single instance lock (safe by default).

    - Uses an exclusive-create lock file.
    - If lock exists, we try to read owner pid from file and detect staleness.
    - Stale cleanup requires BOTH:
        (a) lock age >= MERSOOM_LOCK_STALE_SEC (default 8h) AND
        (b) owner process is not running (best-effort).
    - If lock cannot be obtained, we abort by default to avoid concurrent runs.
      Set MERSOOM_LOCK_BEST_EFFORT=true to continue without a lock (not recommended).
    """
    if not lock_path:
        return
    # Ensure parent directory exists (first-run safety).
    # This prevents FileNotFoundError when lock is derived from runtime/state paths
    # but the runtime directory hasn't been created yet.
    try:
        fn = globals().get("ensure_parent_dir")
        if callable(fn):
            fn(lock_path)
        else:
            d = os.path.dirname(os.path.abspath(lock_path))
            if d and d not in (".", os.path.abspath(".")):
                os.makedirs(d, exist_ok=True)
    except Exception:
        pass

    force = str(os.getenv("MERSOOM_LOCK_FORCE", "false")).strip().lower() in ("1", "true", "yes", "y")
    best_effort = str(os.getenv("MERSOOM_LOCK_BEST_EFFORT", "false")).strip().lower() in ("1", "true", "yes", "y")
    stale_sec = _env_int("MERSOOM_LOCK_STALE_SEC", 8 * 3600, 60, 7 * 24 * 3600)

    def _read_lock_pid(p: str) -> Optional[int]:
        try:
            with open(p, "r", encoding="utf-8", errors="ignore") as f:
                for line in (f.read() or "").splitlines():
                    line = (line or "").strip()
                    if line.startswith("pid="):
                        v = line.split("=", 1)[-1].strip()
                        if v.isdigit():
                            return int(v)
        except Exception:
            pass
        return None

    def _pid_alive(pid: Optional[int]) -> Optional[bool]:
        if not pid or int(pid) <= 0:
            return None
        try:
            # POSIX/Windows: kill(pid, 0) checks existence (no signal sent).
            os.kill(int(pid), 0)
            return True
        except PermissionError:
            # Exists but we cannot signal it.
            return True
        except Exception:
            return False

    def _try_remove_stale() -> None:
        try:
            if stale_sec <= 0:
                return
            if not os.path.exists(lock_path):
                return
            age = time.time() - float(os.path.getmtime(lock_path))
            if age < float(stale_sec):
                return
            pid = _read_lock_pid(lock_path)
            alive = _pid_alive(pid)
            # Remove only when we are confident it's stale.
            if alive is False or pid is None:
                os.remove(lock_path)
        except Exception as e:
            log_debug_exc("acquire_process_lock:silent", e)
            pass

    if force:
        try:
            if os.path.exists(lock_path):
                os.remove(lock_path)
        except Exception as e:
            log_debug_exc("acquire_process_lock:silent", e)
            pass
    else:
        _try_remove_stale()

    flags = getattr(os, "O_CREAT", 0) | getattr(os, "O_EXCL", 0) | getattr(os, "O_WRONLY", 0)
    try:
        fd = os.open(lock_path, flags)
    except FileExistsError:
        pid = _read_lock_pid(lock_path)
        alive = _pid_alive(pid)
        pid_note = f" pid={pid}" if pid else ""
        Console.cprint(Console.RED, f"[LOCK] already running (lock exists): {lock_path}{pid_note}")
        if pid and alive is False:
            Console.cprint(Console.RED, "Lock owner process not found. If you are sure it's stale, set MERSOOM_LOCK_FORCE=true or delete the lock file.")
        else:
            Console.cprint(Console.RED, "If you are sure it's stale, set MERSOOM_LOCK_FORCE=true or delete the lock file.")
        raise SystemExit(2)
    except Exception as e:
        if best_effort:
            log_warn(f"lock unavailable (best-effort continue): {one_line(repr(e), 160)}")
            return
        Console.cprint(Console.RED, f"[LOCK] cannot acquire lock: {lock_path} ({one_line(repr(e), 160)})")
        Console.cprint(Console.RED, "To run anyway, set MERSOOM_LOCK_BEST_EFFORT=true (not recommended).")
        raise SystemExit(2)

    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(f"pid={os.getpid()}\n")
            f.write(f"started_kst={now_kst_str()}\n")
            try:
                f.flush()
            except Exception as e:
                log_debug_exc("acquire_process_lock:silent", e)
                pass
    except Exception as e:
        log_debug_exc("acquire_process_lock:silent", e)
        pass

    def _cleanup() -> None:
        try:
            if os.path.exists(lock_path):
                os.remove(lock_path)
        except Exception as e:
            log_debug_exc("acquire_process_lock:silent", e)
            pass

    atexit.register(_cleanup)

def _ops_init(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ops circuit-breaker state.

    Keys:
      - fail_counts: consecutive failures per ops key (used to trip)
      - disabled_until: unix ts per ops key
      - last_fail_reason: short string per ops key (for operators)
      - backoff_level: integer per ops key (exponential backoff level)
      - last_fail_meta: dict per ops key (endpoint/status/where)
    """
    ops = state.get("_ops")
    if not isinstance(ops, dict):
        ops = {}
        state["_ops"] = ops
    ops.setdefault("fail_counts", {})
    ops.setdefault("disabled_until", {})
    ops.setdefault("last_fail_reason", {})
    ops.setdefault("backoff_level", {})
    ops.setdefault("last_fail_meta", {})
    return ops


def _ops_key_from_path(path: str, *, default: str = "contrib") -> str:
    """Route an API path to an ops key (scope isolation; prevents cascade disables)."""
    p = str(path or "")
    p = p.split("?", 1)[0]
    # Arena family (can 401 independently)
    if p.startswith("/arena") or p.startswith("/colosseum"):
        return "arena"
    # Vote family
    if p.endswith("/vote") or "/vote?" in p or "/vote/" in p or p.startswith("/votes"):
        return "vote"
    # Posts / comments (contrib)
    if p.startswith("/posts") or "/comments" in p:
        return "contrib"
    # Sync / feed-ish (best-effort)
    if p.startswith("/feed") or p.startswith("/me") or p.startswith("/notifications"):
        return "sync"
    return str(default or "contrib")


def _ops_base_disable_sec_for_key(key: str, *, fallback: int) -> int:
    base_disable = _env_int("MERSOOM_OPS_DISABLE_SEC", int(fallback), 60, 24 * 3600)
    k = str(key or "")
    per_key = {
        "sync": _env_int("MERSOOM_OPS_DISABLE_SEC_SYNC", base_disable, 60, 24 * 3600),
        "vote": _env_int("MERSOOM_OPS_DISABLE_SEC_VOTE", base_disable, 60, 24 * 3600),
        "contrib": _env_int("MERSOOM_OPS_DISABLE_SEC_CONTRIB", base_disable, 60, 24 * 3600),
        "arena": _env_int("MERSOOM_OPS_DISABLE_SEC_ARENA", max(base_disable, 1800), 60, 24 * 3600),
    }
    return int(per_key.get(k, base_disable))


def _ops_cap_disable_sec_for_key(key: str, base_sec: int) -> int:
    # Global cap (operators can override per-key)
    cap_global = _env_int("MERSOOM_OPS_DISABLE_CAP_SEC", 6 * 3600, 60, 24 * 3600)
    k = str(key or "")
    per_key_cap = {
        "sync": _env_int("MERSOOM_OPS_DISABLE_CAP_SEC_SYNC", cap_global, 60, 24 * 3600),
        "vote": _env_int("MERSOOM_OPS_DISABLE_CAP_SEC_VOTE", cap_global, 60, 24 * 3600),
        "contrib": _env_int("MERSOOM_OPS_DISABLE_CAP_SEC_CONTRIB", cap_global, 60, 24 * 3600),
        "arena": _env_int("MERSOOM_OPS_DISABLE_CAP_SEC_ARENA", max(cap_global, 12 * 3600), 60, 24 * 3600),
    }
    cap = int(per_key_cap.get(k, cap_global))
    # Ensure cap is at least base (otherwise backoff is meaningless).
    return int(max(cap, int(base_sec)))


def _ops_compute_disable_sec(state: Dict[str, Any], key: str, base_sec: int) -> Tuple[int, int, int]:
    """
    Compute exponential backoff disable seconds for an ops key.

    Returns: (disable_sec, level_used, cap_sec)
      - level_used: current backoff level applied to this trip
    """
    ops = _ops_init(state)
    lvl_d = ops.get("backoff_level")
    if not isinstance(lvl_d, dict):
        lvl_d = {}
        ops["backoff_level"] = lvl_d
    lvl = int(lvl_d.get(str(key), 0) or 0)

    base_sec_i = max(60, int(base_sec))
    cap_sec = _ops_cap_disable_sec_for_key(str(key), base_sec_i)

    # Apply 2**lvl multiplier; cap clamps the max.
    try:
        mult = 2 ** max(0, int(lvl))
    except Exception:
        mult = 1
    disable = int(min(int(cap_sec), int(base_sec_i) * int(mult)))

    # Defensive floor/ceil
    disable = int(max(60, min(int(disable), int(cap_sec))))
    return disable, int(lvl), int(cap_sec)


def _ops_bump_backoff_level(state: Dict[str, Any], key: str, base_sec: int) -> int:
    """Increase backoff level by 1, bounded by what the cap can represent."""
    ops = _ops_init(state)
    lvl_d = ops.get("backoff_level")
    if not isinstance(lvl_d, dict):
        lvl_d = {}
        ops["backoff_level"] = lvl_d

    k = str(key or "")
    cur = int(lvl_d.get(k, 0) or 0)
    base_sec_i = max(60, int(base_sec))
    cap_sec = _ops_cap_disable_sec_for_key(k, base_sec_i)

    # Max level such that base * 2**level <= cap
    try:
        ratio = float(cap_sec) / float(base_sec_i)
        max_lvl = int(max(0, math.floor(math.log(ratio, 2)))) if ratio > 1.0 else 0
    except Exception:
        max_lvl = 0

    nxt = int(min(cur + 1, max_lvl))
    lvl_d[k] = int(nxt)
    return int(nxt)


def ops_should_skip(state: Dict[str, Any], key: str) -> bool:
    ops = _ops_init(state)
    du = ops.get("disabled_until")
    if not isinstance(du, dict):
        du = {}
        ops["disabled_until"] = du
    until = float(du.get(str(key), 0.0) or 0.0)
    now_ts = time.time()
    if until > 0.0 and now_ts >= until:
        # Expired -> clear and emit a single enable event
        try:
            du.pop(str(key), None)
        except Exception:
            pass
        try:
            # keep last_fail_reason/meta for post-mortem unless explicitly cleared elsewhere
            log_event("ops_enabled", key=str(key))
        except Exception:
            pass
        return False
    return now_ts < until


def ops_record_success(state: Dict[str, Any], key: str) -> None:
    ops = _ops_init(state)
    k = str(key or "")
    fc = ops.get("fail_counts")
    if isinstance(fc, dict):
        fc[k] = 0
    lfr = ops.get("last_fail_reason")
    if isinstance(lfr, dict):
        lfr.pop(k, None)
    # Backoff decay: each success decreases level by 1 (gentle recovery).
    lvl_d = ops.get("backoff_level")
    if isinstance(lvl_d, dict):
        try:
            cur = int(lvl_d.get(k, 0) or 0)
            lvl_d[k] = int(max(0, cur - 1))
        except Exception:
            pass


def _ops_trip_disable(
    state: Dict[str, Any],
    key: str,
    base_disable_sec: int,
    *,
    reason: str = "",
    endpoint: str = "",
    status_code: Optional[int] = None,
    where: str = "",
    forced: bool = False,
    threshold: Optional[int] = None,
) -> int:
    """Trip circuit breaker for a specific ops key with exponential backoff + cap."""
    ops = _ops_init(state)
    k = str(key or "")

    base_sec = int(max(60, int(base_disable_sec)))
    disable_sec, lvl_used, cap_sec = _ops_compute_disable_sec(state, k, base_sec)

    du = ops.get("disabled_until")
    if not isinstance(du, dict):
        du = {}
        ops["disabled_until"] = du
    du[k] = time.time() + float(int(disable_sec))

    # Update last reason/meta for operators
    lfr = ops.get("last_fail_reason")
    if not isinstance(lfr, dict):
        lfr = {}
        ops["last_fail_reason"] = lfr
    lfr[k] = one_line(reason or "", 220)

    meta = ops.get("last_fail_meta")
    if not isinstance(meta, dict):
        meta = {}
        ops["last_fail_meta"] = meta
    meta[k] = {
        "endpoint": one_line(str(endpoint or ""), 160),
        "status": int(status_code) if status_code is not None else None,
        "where": one_line(str(where or ""), 120),
        "ts": float(time.time()),
        "level": int(lvl_used),
        "base_sec": int(base_sec),
        "cap_sec": int(cap_sec),
        "forced": bool(forced),
        "threshold": int(threshold) if threshold is not None else None,
    }

    # Emit structured + human logs
    try:
        log_event(
            "ops_disabled",
            key=str(k),
            disable_sec=int(disable_sec),
            base_sec=int(base_sec),
            level=int(lvl_used),
            cap_sec=int(cap_sec),
            forced=bool(forced),
            threshold=int(threshold) if threshold is not None else None,
            endpoint=one_line(str(endpoint or ""), 160),
            status=int(status_code) if status_code is not None else None,
            where=one_line(str(where or ""), 120),
            reason=one_line(reason or "", 220),
        )
    except Exception:
        pass

    try:
        extra = ""
        if endpoint:
            extra += f" endpoint={one_line(str(endpoint), 90)}"
        if status_code is not None:
            extra += f" status={int(status_code)}"
        if where:
            extra += f" where={one_line(str(where), 60)}"
        log_warn(
            f"OPS: {k} disabled for {int(disable_sec)}s (base={int(base_sec)}s lvl={int(lvl_used)} cap={int(cap_sec)}s){extra}. "
            f"last={one_line(reason, 140)}"
        )
    except Exception:
        pass

    # Increase backoff for next trip
    _ops_bump_backoff_level(state, k, base_sec)

    return int(disable_sec)


def ops_record_failure(
    state: Dict[str, Any],
    key: str,
    reason: str,
    *,
    endpoint: str = "",
    status_code: Optional[int] = None,
    where: str = "",
) -> None:
    ops = _ops_init(state)
    k = str(key or "")
    thr = _env_int("MERSOOM_OPS_FAIL_THRESHOLD", 5, 1, 100)

    fc = ops.get("fail_counts")
    if not isinstance(fc, dict):
        fc = {}
        ops["fail_counts"] = fc
    fc[k] = int(fc.get(k, 0) or 0) + 1

    lfr = ops.get("last_fail_reason")
    if not isinstance(lfr, dict):
        lfr = {}
        ops["last_fail_reason"] = lfr
    lfr[k] = one_line(reason or "", 220)

    # Optional meta (helps post-mortem)
    meta = ops.get("last_fail_meta")
    if not isinstance(meta, dict):
        meta = {}
        ops["last_fail_meta"] = meta
    if endpoint or (status_code is not None) or where:
        try:
            meta[k] = {
                "endpoint": one_line(str(endpoint or ""), 160),
                "status": int(status_code) if status_code is not None else None,
                "where": one_line(str(where or ""), 120),
                "ts": float(time.time()),
                "forced": False,
                "threshold": int(thr),
            }
        except Exception:
            pass

    if int(fc.get(k, 0) or 0) >= int(thr):
        # Base disable sec derived per key; backoff is applied inside _ops_trip_disable.
        base_disable = _ops_base_disable_sec_for_key(k, fallback=_env_int("MERSOOM_OPS_DISABLE_SEC", 900, 60, 24 * 3600))
        _ops_trip_disable(
            state,
            k,
            int(base_disable),
            reason=reason,
            endpoint=endpoint,
            status_code=status_code,
            where=where,
            forced=False,
            threshold=int(thr),
        )
        fc[k] = 0  # reset after tripping


def ops_force_disable(
    state: Dict[str, Any],
    key: str,
    disable_sec: int,
    *,
    reason: str = "",
    endpoint: str = "",
    status_code: Optional[int] = None,
    where: str = "",
    apply_backoff: bool = True,
) -> None:
    """Immediately disable an ops key. By default, applies exponential backoff + cap."""
    if apply_backoff:
        _ops_trip_disable(
            state,
            str(key),
            int(disable_sec),
            reason=reason,
            endpoint=endpoint,
            status_code=status_code,
            where=where,
            forced=True,
            threshold=None,
        )
        return

    # Legacy behavior: set exact seconds without backoff.
    ops = _ops_init(state)
    du = ops.get("disabled_until")
    if not isinstance(du, dict):
        du = {}
        ops["disabled_until"] = du
    du[str(key)] = time.time() + float(int(disable_sec))

    lfr = ops.get("last_fail_reason")
    if not isinstance(lfr, dict):
        lfr = {}
        ops["last_fail_reason"] = lfr
    if reason:
        lfr[str(key)] = one_line(reason, 220)

    try:
        log_event("ops_disabled", key=str(key), disable_sec=int(disable_sec), forced=True, reason=one_line(reason, 220))
    except Exception:
        pass
    try:
        log_warn(f"OPS: {key} force-disabled for {int(disable_sec)}s. last={one_line(reason, 160)}")
    except Exception:
        pass


def _normalize_endpoint_key(path: str) -> str:
    """Normalize API path to a coarse key (replace ids) for auth-failure tracking."""
    p = str(path or "")
    p = p.split("?", 1)[0]
    parts = [x for x in p.split("/") if x]
    norm: List[str] = []
    for seg in parts:
        s = str(seg)
        if len(s) >= 8 and re.fullmatch(r"[A-Za-z0-9_-]+", s or "") and (any(c.isdigit() for c in s) or s.lower() != s):
            norm.append("{id}")
        else:
            norm.append(s)
    return "/" + "/".join(norm)


def record_auth401_and_maybe_trip(state: Dict[str, Any], path: str, *, where: str = "") -> bool:
    """Track repeated 401s per endpoint; trip ONLY the relevant ops key (prevents cascade)."""
    try:
        window = _env_int("MERSOOM_AUTH401_WINDOW_SEC", 900, 60, 24 * 3600)
        trip = _env_int("MERSOOM_AUTH401_TRIP_COUNT", 3, 1, 50)
        disable_default = _env_int("MERSOOM_AUTH401_DISABLE_SEC", 3600, 60, 24 * 3600)

        key = _normalize_endpoint_key(path)
        now = time.time()

        d = state.setdefault("auth401", {})
        if not isinstance(d, dict):
            d = {}
            state["auth401"] = d

        arr = _safe_list(d.get(key))
        arr2: List[float] = []
        for x in arr:
            try:
                t = float(x)
                if (now - t) <= float(window):
                    arr2.append(t)
            except Exception:
                continue
        arr2.append(now)
        d[key] = arr2[-60:]

        if len(arr2) >= int(trip):
            # Route by endpoint family (arena/vote/contrib) to avoid cascade disables.
            op_key = _ops_key_from_path(key, default="contrib")

            # Prefer per-op disable seconds if provided; default uses auth401 disable.
            if op_key == "arena":
                base_disable = _env_int("MERSOOM_OPS_DISABLE_SEC_ARENA", int(disable_default), 60, 24 * 3600)
            elif op_key == "vote":
                base_disable = _env_int("MERSOOM_OPS_DISABLE_SEC_VOTE", int(disable_default), 60, 24 * 3600)
            elif op_key == "sync":
                base_disable = _env_int("MERSOOM_OPS_DISABLE_SEC_SYNC", int(disable_default), 60, 24 * 3600)
            else:
                base_disable = _env_int("MERSOOM_OPS_DISABLE_SEC_CONTRIB", int(disable_default), 60, 24 * 3600)

            ops_force_disable(
                state,
                op_key,
                int(base_disable),
                reason=f"auth401 {key} x{len(arr2)} {where}".strip(),
                endpoint=str(key),
                status_code=401,
                where=str(where or "").strip(),
                apply_backoff=True,
            )
            d[key] = []  # reset window for this endpoint
            return True
    except Exception as e:
        log_debug_exc("record_auth401_and_maybe_trip:silent", e)
        pass
    return False


def ops_disabled_keys(state: Dict[str, Any]) -> List[str]:
    ops = _ops_init(state)
    du = ops.get("disabled_until")
    if not isinstance(du, dict):
        return []
    now = time.time()
    out = []
    for k, v in du.items():
        try:
            if float(v or 0.0) > now:
                out.append(str(k))
        except Exception:
            continue
    return sorted(out)