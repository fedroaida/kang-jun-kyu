################################################################################
# 01. CONFIG & ENV
# Deps: none
# Used by: all
# Notes: load_config_from_env() and ENV helpers.
################################################################################
"""
SECTION 01 - CONFIG (ENV + TUNING)

Loads configuration from environment variables and provides the Config/AgentTuning objects.

Responsibilities:
- Parse env vars safely (types, defaults, bounds).
- Keep all "knobs" centralized (limits, toggles, paths, feature flags).

Notes:
- Prefer adding new knobs here instead of scattering os.getenv() calls across sections.
- Keep parsing defensive; this code runs before almost everything else.
"""
def _env_str(name: str, default: str) -> str:
    v = os.getenv(name)
    return default if v is None else str(v)

def _env_int(name: str, default: int, min_v: Optional[int] = None, max_v: Optional[int] = None) -> int:
    raw = _ENV.get(name)
    try:
        x = int(raw) if raw is not None else default
    except Exception:
        x = int(default)
    if min_v is not None:
        x = max(min_v, x)
    if max_v is not None:
        x = min(max_v, x)
    return x

def _env_float(name: str, default: float, min_v: Optional[float] = None, max_v: Optional[float] = None) -> float:
    raw = _ENV.get(name)
    try:
        x = float(raw) if raw is not None else float(default)
    except Exception:
        x = float(default)
    if min_v is not None:
        x = max(min_v, x)
    if max_v is not None:
        x = min(max_v, x)
    return x

def _env_bool(name: str, default: bool) -> bool:
    raw = _ENV.get(name)
    if raw is None:
        return default
    return str(raw).strip().lower() in ("1", "true", "yes", "y", "on")



def _env_csv(name: str, default: str = "") -> List[str]:
    raw = _env_str(name, default)
    s = str(raw or "").strip()
    if not s:
        return []
    parts = [p.strip() for p in s.replace(";", ",").split(",")]
    return [p for p in parts if p]
def _load_timezone() -> Tuple[timezone, str, bool]:
    """Return (tzinfo, tz_name, fallback_used). Uses zoneinfo when possible."""
    tz_name = _env_str("MERSOOM_TIMEZONE", "Asia/Seoul").strip() or "Asia/Seoul"
    fallback_used = False
    tz = None
    if ZoneInfo is not None:
        try:
            tz = ZoneInfo(tz_name)
        except Exception:
            tz = None
    if tz is None:
        tz = timezone(timedelta(hours=9))
        fallback_used = True
    return tz, tz_name, fallback_used

KST, TZ_NAME, TZ_FALLBACK_USED = _load_timezone()
_TZ_LOGGED = False
DEFAULT_USER_AGENT = "mersoom-agent/10.0"
MAX_NICKNAME_LEN = 10

def _safe_nickname(nick: str) -> str:
    n = (nick or "돌쇠").strip()
    n = re.sub(r"\s+", "", n)
    if len(n) > MAX_NICKNAME_LEN:
        n = n[:MAX_NICKNAME_LEN]
    return n or "돌쇠"

def _valid_auth_id(auth_id: str) -> bool:
    """Validate auth_id per Mersoom 3.0: 5~12 chars, [A-Za-z0-9_]."""
    try:
        s = (auth_id or "").strip()
        return bool(re.fullmatch(r"[A-Za-z0-9_]{5,12}", s))
    except Exception:
        return False

def _valid_password(password: str) -> bool:
    """Validate password length per guide: 10~20 chars."""
    try:
        n = len((password or "").strip())
        return bool(10 <= n <= 20)
    except Exception:
        return False


# -----------------------------------------------------------------------------
# Runtime globals (legacy): keep names stable across versions.
# These are set from Config inside run() via _apply_runtime_globals().
# -----------------------------------------------------------------------------
DEBUG_MODE = False
DEBUG_TRACEBACK = False
FAILFAST_STAGES: set[str] = set()

# Brain bias influence (Unit 08)
BRAIN_BIAS_ENABLE = True
BRAIN_BIAS_MIN = 0.85
BRAIN_BIAS_MAX = 1.25
BRAIN_BIAS_SCALE = 0.25
BRAIN_BIAS_LOG = False

# Arena (Colosseum) loop (Unit 09/10)
ARENA_ENABLE = True
ARENA_STATUS_MIN_INTERVAL_SEC = 180
ARENA_POSTS_MIN_INTERVAL_SEC = 300
ARENA_MAX_ACTIONS_PER_DAY = 6
ARENA_ARG_VARIANTS = 8
ARENA_REF_TOPK = 3
ARENA_ANTICOPY_JACCARD = 0.56
ARENA_ANTICOPY_SUBSTR_LEN = 18
ARENA_ANTICOPY_SIMHASH_MAX = 9
ARENA_USE_ANCHOR_VERBATIM = False
ARENA_QUALITY_MIN = 62

# Language rules (Mersoom 3.0)
LANG_STRICT = True
ENGLISH_NOTICE = ""  # disabled by default (set MERSOOM_ENGLISH_NOTICE to enable)
ENGLISH_NOTICE_RATIO = 0.12
ENGLISH_NOTICE_MIN_ALPHA = 12
ENGLISH_NOTICE_APPEND_EUM = True

@dataclass(frozen=True)
class DebugFlags:
    debug: bool
    log_blocks: bool
    traceback: bool
    failfast_stages: Tuple[str, ...]

@dataclass(frozen=True)
class ProtocolConfig:
    """v19 scaffold: protocol/heartbeat engine toggle (3.0 compliance will land in v19.x)."""
    enabled: bool

@dataclass(frozen=True)
class RulesSyncConfig:
    """v19.1: daily rules sync (skills.md) for 3.0 compliance."""
    daily: bool
    url: str


@dataclass(frozen=True)
class VoteProtocolConfig:
    """v19.2: mandatory voting for seen feed posts (3.0 compliance).

    - mandatory: if True, prioritize voting on any unvoted post fetched in the main feed sync.
    - seen_post_limit: LRU cap for state.seen.posts (post_id -> seen_ts)
    - voted_post_limit: LRU cap for state.votes.posts / state.voted_posts
    """
    mandatory: bool
    seen_post_limit: int
    voted_post_limit: int


@dataclass(frozen=True)
class HeartbeatConfig:
    """v19.3: 3.0 'heartbeat protocol' (4~5h cadence).

    Each heartbeat cycle aims to satisfy:
      - vote on seen feed posts (handled by v19.2 mandatory vote)
      - comment/reply on at least 2~3 posts
      - contribute (post or arena action) at least once per cycle
    """
    enabled: bool
    min_hours: float
    max_hours: float
    comment_min: int
    comment_max: int

@dataclass(frozen=True)
class LangRulesConfig:
    """v19.7: Mersoom 3.0 language rules (strict mode).

    - strict: enforce eum-style endings, strip emoji/markdown artifacts, and apply english notice rule.
    - english_notice: appended when English is present above threshold.
    - english_notice_ratio: minimum A-Z character ratio to trigger the notice (0~1).
    - english_notice_append_eum: append "임" after notice to satisfy sentence-ending rule.
    """
    strict: bool
    english_notice: str
    english_notice_ratio: float
    english_notice_append_eum: bool

@dataclass(frozen=True)
class AuthConfig:
    """v19.8: Optional account headers (auth_id/password) for points + higher comment limit.

    When enabled, the agent will attach:
      - X-Mersoom-Auth-Id
      - X-Mersoom-Password
    to write requests (POST) that already include PoW headers.

    Enable by setting:
      - MERSOOM_AUTH_ID
      - MERSOOM_PASSWORD
    (and optionally MERSOOM_AUTH_ENABLE=true)
    """
    enabled: bool
    auth_id: str
    password: str


@dataclass(frozen=True)
class BrainBiasConfig:
    enabled: bool
    min_mult: float
    max_mult: float
    scale: float
    log: bool

@dataclass(frozen=True)
class ArenaConfig:
    enabled: bool
    status_min_interval_sec: int
    posts_min_interval_sec: int
    max_actions_per_day: int

    arg_variants: int
    ref_topk: int
    anticopy_jaccard: float
    anticopy_substr_len: int
    anticopy_simhash_max: int
    use_anchor_verbatim: bool
    quality_min: int

@dataclass(frozen=True)
class Paths:
    # 기존 파일들
    state: str
    memory: str
    policy: str
    semantic: str
    journal: str
    brain: str
    brain_note: str
    memory_archive_jsonl: str  # "" => disabled

    # (확장) 맥락/코퍼스
    threads: str
    users: str
    corpus_jsonl: str

    # (P0) state generation stamps
    meta: str
    memory_meta: str

@dataclass(frozen=True)
class RateLimits:
    window_sec: int
    posts_per_window: int
    comments_per_window: int
    votes_per_window: int

    max_votes_per_tick: int
    max_comments_per_tick: int
    max_posts_per_tick: int
    max_replies_per_tick: int

@dataclass(frozen=True)
class Timing:
    tick_min_sec: int
    tick_max_sec: int
    sync_min_interval_sec: int

    after_action_sleep_min: int
    after_action_sleep_max: int
    idle_retry_min: int
    idle_retry_max: int

    global_vote_min_gap_sec: int
    global_comment_min_gap_sec: int
    global_post_min_gap_sec: int

    post_min_gap_sec: int
    same_post_comment_gap_sec: int
    same_text_gap_sec: int
    max_text_regen_tries: int

    sleep_hard_cap_sec: int

@dataclass(frozen=True)
class HttpConfig:
    base_url: str
    timeout_connect_sec: float
    timeout_read_sec: float
    user_agent: str
    dry_run: bool

    max_retries: int
    backoff_base: float
    backoff_cap: float
    retry_on_5xx: bool

@dataclass(frozen=True)
class PowConfig:
    wallet: str  # optional "nonce:wallet" format when set

@dataclass(frozen=True)
class HybridChallengeConfig:
    """Hybrid /challenge 대응(임시):
    - type=pow가 아니면(예: AI Puzzle), 일정 횟수 재요청하여 pow가 나올 때만 진행
    - 퍼즐 payload는 JSONL로 수집(추후 솔버/규칙 업데이트용)
    """
    max_retries: int
    retry_sleep_ms: int
    puzzle_log_jsonl: str  # "" => disabled
    puzzle_raw_max_chars: int
    puzzle_solver_enable: bool = True
    puzzle_solver_debug: bool = False

@dataclass(frozen=True)
class RuntimeMode:
    always_on: bool
    activity_mode: str  # "paced" | "burst"

@dataclass(frozen=True)
class SnapshotConfig:
    enabled: bool
    script: str
    timeout_sec: int
    run_on_boot: bool

@dataclass(frozen=True)
class QualityGate:
    """Quality gate + dry QA batch controls (Unit 01).

    - enabled: pre-flight checks for outgoing text; regenerate if below min_score.
    - batch_on_boot: run a local QA batch report at startup (no writes when DRY_RUN).
    """
    enabled: bool
    min_score: int
    max_tries: int

    batch_on_boot: bool
    batch_n: int
    batch_show_worst: int
    batch_save_path: str
    batch_exit: bool



@dataclass(frozen=True)
class ToxicConfig:
    """Incoming toxic/taunt handling.

    - auto_downvote: when toxic content is detected in an engagement target, vote 'down' on the post (best-effort).
    - no_reply: do not reply directly to toxic comments.
    - exclude_from_learning: do not feed toxic text into thread turns / template mining inputs.
    """
    auto_downvote: bool
    no_reply: bool
    exclude_from_learning: bool

@dataclass(frozen=True)
class Config:
    nickname: str
    auth: AuthConfig
    protocol: ProtocolConfig
    rules_sync: RulesSyncConfig
    vote_proto: VoteProtocolConfig
    heartbeat: HeartbeatConfig
    lang: LangRulesConfig
    toxic: ToxicConfig
    debug: DebugFlags
    brain_bias: BrainBiasConfig
    arena: ArenaConfig
    paths: Paths
    limits: RateLimits
    timing: Timing
    http: HttpConfig
    pow: PowConfig
    hybrid: HybridChallengeConfig
    mode: RuntimeMode
    snapshot: SnapshotConfig
    quality: QualityGate

def load_config_from_env() -> Config:
    # 기본값은 https://mersoom.com/api (필요 시 https://www.mersoom.com/api 로 명시 가능)
    base = _env_str("MERSOOM_BASE", "https://mersoom.com/api").rstrip("/")

    nickname_raw = _env_str("MERSOOM_NICKNAME", "돌쇠")
    nickname = _safe_nickname(nickname_raw)

    auth_id = _env_str("MERSOOM_AUTH_ID", "").strip()
    password = _env_str("MERSOOM_PASSWORD", "").strip()
    auth_enable_flag = _env_bool("MERSOOM_AUTH_ENABLE", True)
    auth_enabled = bool(auth_enable_flag and auth_id and password and _valid_auth_id(auth_id) and _valid_password(password))
    auth = AuthConfig(enabled=auth_enabled, auth_id=auth_id, password=password)


    protocol = ProtocolConfig(
        enabled=_env_bool("MERSOOM_PROTOCOL_ENABLE", True),
    )

    rules_sync = RulesSyncConfig(
        daily=_env_bool("MERSOOM_RULES_SYNC_DAILY", True),
        url=_env_str("MERSOOM_RULES_SYNC_URL", "https://mersoom.com/docs/skills.md").strip(),
    )

    vote_proto = VoteProtocolConfig(
        mandatory=_env_bool("MERSOOM_VOTE_MANDATORY", True),
        seen_post_limit=_env_int("MERSOOM_SEEN_POST_LIMIT", 500, min_v=50, max_v=50000),
        voted_post_limit=_env_int("MERSOOM_VOTED_POST_LIMIT", 5000, min_v=200, max_v=200000),
    )


    hb_enabled = _env_bool("MERSOOM_HEARTBEAT_ENABLE", True)
    hb_min = _env_float("MERSOOM_HEARTBEAT_MIN_HOURS", 4.0, min_v=0.5, max_v=24.0)
    hb_max = _env_float("MERSOOM_HEARTBEAT_MAX_HOURS", 5.0, min_v=0.5, max_v=24.0)
    if hb_max < hb_min:
        hb_max = hb_min
    hb_cmin = _env_int("MERSOOM_HEARTBEAT_COMMENT_MIN", 2, min_v=0, max_v=50)
    hb_cmax = _env_int("MERSOOM_HEARTBEAT_COMMENT_MAX", 3, min_v=0, max_v=50)
    if hb_cmax < hb_cmin:
        hb_cmax = hb_cmin
    heartbeat = HeartbeatConfig(
        enabled=hb_enabled,
        min_hours=float(hb_min),
        max_hours=float(hb_max),
        comment_min=int(hb_cmin),
        comment_max=int(hb_cmax),
    )

    lang = LangRulesConfig(
        strict=_env_bool("MERSOOM_LANG_STRICT", True),
        english_notice=_env_str("MERSOOM_ENGLISH_NOTICE", ""),
        english_notice_ratio=_env_float("MERSOOM_ENGLISH_NOTICE_RATIO", 0.12),
        english_notice_append_eum=_env_bool("MERSOOM_ENGLISH_NOTICE_APPEND_EUM", True),
    )

    toxic = ToxicConfig(
        auto_downvote=_env_bool("MERSOOM_TOXIC_AUTO_DOWNVOTE", True),
        no_reply=_env_bool("MERSOOM_TOXIC_NO_REPLY", True),
        exclude_from_learning=_env_bool("MERSOOM_TOXIC_EXCLUDE_LEARNING", True),
    )

    debug = DebugFlags(
        debug=_env_bool("MERSOOM_DEBUG", False),
        log_blocks=_env_bool("MERSOOM_LOG_BLOCKS", False),
        traceback=_env_bool("MERSOOM_DEBUG_TRACEBACK", False),
        failfast_stages=tuple(_env_csv("MERSOOM_FAILFAST_STAGES", "")),
    )

    # Brain bias influence (Unit 08) — keep env names for backward compatibility.
    bb_min = _env_float("MERSOOM_BRAIN_BIAS_MIN", 0.85, min_v=0.1, max_v=2.0)
    bb_max = _env_float("MERSOOM_BRAIN_BIAS_MAX", 1.25, min_v=0.1, max_v=3.0)
    if bb_max < bb_min:
        bb_max = bb_min
    brain_bias = BrainBiasConfig(
        enabled=_env_bool("MERSOOM_BRAIN_BIAS_ENABLE", True),
        min_mult=bb_min,
        max_mult=bb_max,
        scale=_env_float("MERSOOM_BRAIN_BIAS_SCALE", 0.25, min_v=0.0, max_v=2.0),
        log=_env_bool("MERSOOM_BRAIN_BIAS_LOG", False),
    )

    # Arena (Colosseum) loop (Unit 09/10)
    arena = ArenaConfig(
        enabled=_env_bool("MERSOOM_ARENA_ENABLE", True),
        status_min_interval_sec=_env_int("MERSOOM_ARENA_STATUS_MIN_INTERVAL_SEC", 180, 10, 3600),
        posts_min_interval_sec=_env_int("MERSOOM_ARENA_POSTS_MIN_INTERVAL_SEC", 300, 10, 3600),
        max_actions_per_day=_env_int("MERSOOM_ARENA_MAX_ACTIONS_PER_DAY", 6, 0, 100),

        arg_variants=_env_int("MERSOOM_ARENA_ARG_VARIANTS", 8, 1, 30),
        ref_topk=_env_int("MERSOOM_ARENA_REF_TOPK", 3, 0, 10),
        anticopy_jaccard=_env_float("MERSOOM_ARENA_ANTICOPY_JACCARD", 0.56, min_v=0.0, max_v=1.0),
        anticopy_substr_len=_env_int("MERSOOM_ARENA_ANTICOPY_SUBSTR_LEN", 18, 8, 80),
        anticopy_simhash_max=_env_int("MERSOOM_ARENA_ANTICOPY_SIMHASH_MAX", 9, 0, 64),
        use_anchor_verbatim=_env_bool("MERSOOM_ARENA_USE_ANCHOR_VERBATIM", False),
        quality_min=_env_int("MERSOOM_ARENA_QUALITY_MIN", 62, 0, 100),
    )

    # Snapshot runner (hourly) — moved into Config to keep dependency flow downward.
    snap_script = _env_str("MERSOOM_SNAPSHOT_SCRIPT", "snapshot_mersoom_to_xlsx_v3.py").strip()
    if not snap_script:
        snap_script = "snapshot_mersoom_to_xlsx_v3.py"
    snapshot = SnapshotConfig(
        enabled=_env_bool("MERSOOM_SNAPSHOT_ENABLED", True),
        script=snap_script,
        timeout_sec=_env_int("MERSOOM_SNAPSHOT_TIMEOUT_SEC", 900, min_v=10, max_v=24 * 60 * 60),
        run_on_boot=_env_bool("MERSOOM_SNAPSHOT_RUN_ON_BOOT", False),
    )
    # ---------------------------------------------------------------------
    # Runtime directory (v7.28)
    # - Derived artifacts (state/memory/policy/logs/trace/etc.) should live under this folder.
    # - You can override any specific path via the existing MERSOOM_* env vars.
    #
    # Defaults to ./runtime (relative to the working directory).
    #
    # Recommended layout:
    #   runtime/state/   : state,memory,policy,semantic,brain,threads,users,meta
    #   runtime/journal/ : journal, brain_note
    #   runtime/archive/ : corpus, (optional) memory archive
    #   runtime/logs/    : error log (and optional external run logs)
    #   runtime/trace/   : trace_hits.json (when MERSOOM_TRACE=1)
    runtime_dir = _env_str('MERSOOM_RUNTIME_DIR', 'runtime').strip()
    if not runtime_dir:
        runtime_dir = 'runtime'

    def _rt(*parts: str) -> str:
        try:
            return os.path.join(runtime_dir, *[p for p in parts if p])
        except Exception:
            return os.path.join('runtime', *[p for p in parts if p])

    def _rt_state(name: str) -> str:
        return _rt('state', name)

    def _rt_journal(name: str) -> str:
        return _rt('journal', name)

    def _rt_archive(name: str) -> str:
        return _rt('archive', name)

    paths = Paths(
        state=_env_str("MERSOOM_STATE", _rt_state("mersoom_state.json")),
        memory=_env_str("MERSOOM_MEMORY", _rt_state("mersoom_memory.json")),
        policy=_env_str("MERSOOM_POLICY", _rt_state("mersoom_policy.json")),
        semantic=_env_str("MERSOOM_SEMANTIC", _rt_state("mersoom_semantic.json")),
        journal=_env_str("MERSOOM_JOURNAL", _rt_journal("mersoom_journal.txt")),
        brain=_env_str("MERSOOM_BRAIN", _rt_state("mersoom_brain.json")),
        brain_note=_env_str("MERSOOM_BRAIN_NOTE", _rt_journal("mersoom_brain.md")),
        memory_archive_jsonl=_env_str("MERSOOM_MEMORY_ARCHIVE", "").strip(),

        threads=_env_str("MERSOOM_THREADS", _rt_state("mersoom_threads.json")),
        users=_env_str("MERSOOM_USERS", _rt_state("mersoom_users.json")),
        corpus_jsonl=_env_str("MERSOOM_CORPUS", _rt_archive("mersoom_corpus.jsonl")),
        meta=_env_str("MERSOOM_META", _rt_state("mersoom_meta.json")),
        memory_meta=_env_str("MERSOOM_MEMORY_META", _rt_state("mersoom_memory_meta.json")),
    )

    window_sec = _env_int("MERSOOM_WINDOW_SEC", 30 * 60, min_v=60, max_v=24 * 60 * 60)

    # Mersoom 3.0: login(auth_id) raises comment limit to 20/30min; keep override via env.
    default_comments_30 = 20 if bool(auth_enabled) else 10

    limits = RateLimits(
        window_sec=window_sec,
        posts_per_window=_env_int("MERSOOM_POSTS_PER_WINDOW", _env_int("MERSOOM_POSTS_PER_30MIN", 2, min_v=0, max_v=200), min_v=0, max_v=200),
        comments_per_window=_env_int("MERSOOM_COMMENTS_PER_WINDOW", _env_int("MERSOOM_COMMENTS_PER_30MIN", default_comments_30, min_v=0, max_v=500), min_v=0, max_v=500),
        votes_per_window=_env_int("MERSOOM_VOTES_PER_WINDOW", _env_int("MERSOOM_VOTES_PER_30MIN", 12, min_v=0, max_v=500), min_v=0, max_v=500),

        max_votes_per_tick=_env_int("MERSOOM_MAX_VOTES_PER_TICK", 3, min_v=0, max_v=50),
        max_comments_per_tick=_env_int("MERSOOM_MAX_COMMENTS_PER_TICK", 1, min_v=0, max_v=50),
        max_posts_per_tick=_env_int("MERSOOM_MAX_POSTS_PER_TICK", 1, min_v=0, max_v=10),
        max_replies_per_tick=_env_int("MERSOOM_MAX_REPLIES_PER_TICK", 1, min_v=0, max_v=50),
    )

    timing = Timing(
        tick_min_sec=_env_int("MERSOOM_TICK_MIN_SEC", 20, min_v=5, max_v=3600),
        tick_max_sec=_env_int("MERSOOM_TICK_MAX_SEC", 60, min_v=5, max_v=3600),
        sync_min_interval_sec=_env_int("MERSOOM_SYNC_MIN_INTERVAL_SEC", 45, min_v=10, max_v=3600),

        after_action_sleep_min=_env_int("MERSOOM_AFTER_ACTION_SLEEP_MIN", 8, min_v=0, max_v=3600),
        after_action_sleep_max=_env_int("MERSOOM_AFTER_ACTION_SLEEP_MAX", 25, min_v=0, max_v=3600),
        idle_retry_min=_env_int("MERSOOM_IDLE_RETRY_MIN", 15, min_v=1, max_v=3600),
        idle_retry_max=_env_int("MERSOOM_IDLE_RETRY_MAX", 60, min_v=1, max_v=3600),

        global_vote_min_gap_sec=_env_int("MERSOOM_GLOBAL_VOTE_MIN_GAP_SEC", 5, min_v=0, max_v=3600),
        global_comment_min_gap_sec=_env_int("MERSOOM_GLOBAL_COMMENT_MIN_GAP_SEC", 10, min_v=0, max_v=3600),
        global_post_min_gap_sec=_env_int("MERSOOM_GLOBAL_POST_MIN_GAP_SEC", 30, min_v=0, max_v=3600),

        post_min_gap_sec=_env_int("MERSOOM_POST_MIN_GAP_SEC", 240, min_v=0, max_v=24 * 3600),
        same_post_comment_gap_sec=_env_int("MERSOOM_THREAD_DEBOUNCE_MIN_SEC", _env_int("MERSOOM_MIN_SAME_POST_GAP", 1800, min_v=0, max_v=24 * 3600), min_v=0, max_v=24 * 3600),
        same_text_gap_sec=_env_int("MERSOOM_MIN_SAME_TEXT_GAP", 1200, min_v=0, max_v=24 * 3600),
        max_text_regen_tries=_env_int("MERSOOM_MAX_TEXT_REGEN_TRIES", 6, min_v=0, max_v=50),

        sleep_hard_cap_sec=_env_int("MERSOOM_SLEEP_HARD_CAP_SEC", 900, min_v=30, max_v=24 * 3600),
    )

    http = HttpConfig(
        base_url=base,
        timeout_connect_sec=_env_float("MERSOOM_TIMEOUT_CONNECT_SEC", 8.0, min_v=1.0, max_v=60.0),
        timeout_read_sec=_env_float("MERSOOM_TIMEOUT_READ_SEC", 18.0, min_v=3.0, max_v=120.0),
        user_agent=_env_str("MERSOOM_USER_AGENT", DEFAULT_USER_AGENT),
        dry_run=_env_bool("MERSOOM_DRY_RUN", False),

        max_retries=_env_int("MERSOOM_HTTP_MAX_RETRIES", 4, min_v=0, max_v=20),
        backoff_base=_env_float("MERSOOM_HTTP_BACKOFF_BASE", 0.7, min_v=0.05, max_v=10.0),
        backoff_cap=_env_float("MERSOOM_HTTP_BACKOFF_CAP", 18.0, min_v=0.2, max_v=120.0),
        retry_on_5xx=_env_bool("MERSOOM_HTTP_RETRY_ON_5XX", True),
    )

    powcfg = PowConfig(wallet=_env_str("MERSOOM_WALLET", "").strip())
    hybrid = HybridChallengeConfig(
        max_retries=_env_int("MERSOOM_CHALLENGE_POW_RETRY_MAX", 4, min_v=0, max_v=50),
        retry_sleep_ms=_env_int("MERSOOM_CHALLENGE_POW_RETRY_SLEEP_MS", 120, min_v=0, max_v=5000),
        puzzle_log_jsonl=_env_str("MERSOOM_PUZZLE_LOG", _rt_archive("mersoom_puzzles.jsonl")).strip(),
        puzzle_raw_max_chars=_env_int("MERSOOM_PUZZLE_RAW_MAX_CHARS", 2000, min_v=200, max_v=20000),
        puzzle_solver_enable=_env_bool("MERSOOM_PUZZLE_SOLVER_ENABLE", True),
        puzzle_solver_debug=_env_bool("MERSOOM_PUZZLE_SOLVER_DEBUG", False),
    )


    act_mode = _env_str("MERSOOM_ACTIVITY_MODE", "paced").strip().lower()
    if act_mode not in ("paced", "burst"):
        act_mode = "paced"

    mode = RuntimeMode(
        always_on=_env_bool("MERSOOM_ALWAYS_ON", True),
        activity_mode=act_mode,
    )


    quality = QualityGate(
        enabled=_env_bool("MERSOOM_QA_GATE", False),
        min_score=_env_int("MERSOOM_QA_MIN_SCORE", 72, min_v=0, max_v=100),
        max_tries=_env_int("MERSOOM_QA_MAX_TRIES", 6, min_v=1, max_v=50),

        batch_on_boot=_env_bool("MERSOOM_QA_BATCH_ON_BOOT", False),
        batch_n=_env_int("MERSOOM_QA_BATCH_N", 50, min_v=1, max_v=500),
        batch_show_worst=_env_int("MERSOOM_QA_BATCH_SHOW_WORST", 5, min_v=0, max_v=50),
        batch_save_path=_env_str("MERSOOM_QA_BATCH_SAVE", "").strip(),
        batch_exit=_env_bool("MERSOOM_QA_BATCH_EXIT", False),
    )

    # sanity: ensure ranges
    if timing.after_action_sleep_max < timing.after_action_sleep_min:
        timing = Timing(**{**timing.__dict__, "after_action_sleep_max": timing.after_action_sleep_min})
    if timing.idle_retry_max < timing.idle_retry_min:
        timing = Timing(**{**timing.__dict__, "idle_retry_max": timing.idle_retry_min})
    if timing.tick_max_sec < timing.tick_min_sec:
        timing = Timing(**{**timing.__dict__, "tick_max_sec": timing.tick_min_sec})

    return Config(
        nickname=nickname,
        auth=auth,
        protocol=protocol,
        rules_sync=rules_sync,
        vote_proto=vote_proto,
        heartbeat=heartbeat,
        lang=lang,
        toxic=toxic,
        debug=debug,
        brain_bias=brain_bias,
        arena=arena,
        paths=paths,
        limits=limits,
        timing=timing,
        http=http,
        pow=powcfg,
        hybrid=hybrid,
        mode=mode,
        snapshot=snapshot,
        quality=quality,
    )

def _apply_runtime_globals(cfg: Config) -> None:
    """Apply Config-derived flags to legacy module-level globals.

    This keeps older sections stable (they reference globals like ARENA_ENABLE),
    while making env-reading single-sourced in load_config_from_env().
    """
    global DEBUG_MODE
    global DEBUG_TRACEBACK, FAILFAST_STAGES
    global BRAIN_BIAS_ENABLE, BRAIN_BIAS_MIN, BRAIN_BIAS_MAX, BRAIN_BIAS_SCALE, BRAIN_BIAS_LOG
    global ARENA_ENABLE, ARENA_STATUS_MIN_INTERVAL_SEC, ARENA_POSTS_MIN_INTERVAL_SEC, ARENA_MAX_ACTIONS_PER_DAY
    global LANG_STRICT, ENGLISH_NOTICE, ENGLISH_NOTICE_RATIO, ENGLISH_NOTICE_APPEND_EUM
    global ARENA_ARG_VARIANTS, ARENA_REF_TOPK, ARENA_ANTICOPY_JACCARD, ARENA_ANTICOPY_SUBSTR_LEN, ARENA_ANTICOPY_SIMHASH_MAX
    global ARENA_USE_ANCHOR_VERBATIM, ARENA_QUALITY_MIN

    try:
        DEBUG_MODE = bool(getattr(cfg.debug, "debug", False))
    except Exception:
        DEBUG_MODE = False

    try:
        DEBUG_TRACEBACK = bool(getattr(cfg.debug, "traceback", False))
    except Exception:
        DEBUG_TRACEBACK = False

    try:
        FAILFAST_STAGES = set([s for s in (getattr(cfg.debug, "failfast_stages", ()) or ()) if str(s).strip()])
    except Exception:
        FAILFAST_STAGES = set()

    # language rules (Mersoom 3.0)
    try:
        lg = getattr(cfg, "lang", None)
        if lg is not None:
            LANG_STRICT = bool(getattr(lg, "strict", LANG_STRICT))
            ENGLISH_NOTICE = str(getattr(lg, "english_notice", ENGLISH_NOTICE) or ENGLISH_NOTICE)
            ENGLISH_NOTICE_RATIO = float(getattr(lg, "english_notice_ratio", ENGLISH_NOTICE_RATIO) or ENGLISH_NOTICE_RATIO)
            ENGLISH_NOTICE_APPEND_EUM = bool(getattr(lg, "english_notice_append_eum", ENGLISH_NOTICE_APPEND_EUM))
    except Exception:
        pass

    try:
        bb = cfg.brain_bias
        BRAIN_BIAS_ENABLE = bool(bb.enabled)
        BRAIN_BIAS_MIN = float(bb.min_mult)
        BRAIN_BIAS_MAX = float(bb.max_mult)
        if BRAIN_BIAS_MAX < BRAIN_BIAS_MIN:
            BRAIN_BIAS_MAX = BRAIN_BIAS_MIN
        BRAIN_BIAS_SCALE = float(bb.scale)
        BRAIN_BIAS_LOG = bool(bb.log)
    except Exception as e:
        log_debug_exc("_apply_runtime_globals:silent", e)
        pass

    try:
        ar = cfg.arena
        ARENA_ENABLE = bool(ar.enabled)
        ARENA_STATUS_MIN_INTERVAL_SEC = int(ar.status_min_interval_sec)
        ARENA_POSTS_MIN_INTERVAL_SEC = int(ar.posts_min_interval_sec)
        ARENA_MAX_ACTIONS_PER_DAY = int(ar.max_actions_per_day)

        ARENA_ARG_VARIANTS = int(ar.arg_variants)
        ARENA_REF_TOPK = int(ar.ref_topk)
        ARENA_ANTICOPY_JACCARD = float(ar.anticopy_jaccard)
        ARENA_ANTICOPY_SUBSTR_LEN = int(ar.anticopy_substr_len)
        ARENA_ANTICOPY_SIMHASH_MAX = int(ar.anticopy_simhash_max)
        ARENA_USE_ANCHOR_VERBATIM = bool(ar.use_anchor_verbatim)
        ARENA_QUALITY_MIN = int(ar.quality_min)
    except Exception as e:
        log_debug_exc("_apply_runtime_globals:silent", e)
        pass



def _apply_cli_overrides(argv: List[str]) -> None:
    """Very small CLI override layer.

    This keeps the single-file + env-driven architecture, but allows:

      - --dry-run / -n
      - --qa-gate
      - --qa-batch
      - --qa-min-score=NN
      - --qa-batch-n=NN
      - --qa-save=PATH
      - --qa-batch-exit / --no-qa-batch-exit
      - --selftest / --test
      - --no-selftest-exit
      - --migrate-only

    """
    if not argv:
        return

    def _set(name: str, value: str) -> None:
        try:
            os.environ[name] = str(value)
        except Exception as e:
            log_debug_exc("_apply_cli_overrides:silent", e)
            pass

    for a in list(argv):
        s = str(a).strip()
        if not s:
            continue

        if s in ("--dry-run", "-n"):
            _set("MERSOOM_DRY_RUN", "true")
            continue

        if s == "--qa-gate":
            _set("MERSOOM_QA_GATE", "true")
            continue

        if s == "--qa-batch":
            _set("MERSOOM_QA_BATCH_ON_BOOT", "true")
            # safer default: exit after printing report unless user disables
            if os.getenv("MERSOOM_QA_BATCH_EXIT", "").strip() == "":
                _set("MERSOOM_QA_BATCH_EXIT", "true")
            # batch should not write by default
            if os.getenv("MERSOOM_DRY_RUN", "").strip() == "":
                _set("MERSOOM_DRY_RUN", "true")
            continue

        if s == "--qa-batch-exit":
            _set("MERSOOM_QA_BATCH_EXIT", "true")
            continue
        if s == "--no-qa-batch-exit":
            _set("MERSOOM_QA_BATCH_EXIT", "false")
            continue
        if s in ("--selftest", "--test"):
            _set("MERSOOM_SELFTEST", "true")
            if os.getenv("MERSOOM_SELFTEST_EXIT", "").strip() == "":
                _set("MERSOOM_SELFTEST_EXIT", "true")
            continue

        if s == "--migrate-only":
            _set("MERSOOM_MIGRATE_ONLY", "true")
            # migrate-only should not touch network; keep dry-run unless user overrides
            if os.getenv("MERSOOM_DRY_RUN", "").strip() == "":
                _set("MERSOOM_DRY_RUN", "true")
            # and exit after migrating unless user overrides
            if os.getenv("MERSOOM_MIGRATE_ONLY_EXIT", "").strip() == "":
                _set("MERSOOM_MIGRATE_ONLY_EXIT", "true")
            continue
        if s == "--no-selftest-exit":
            _set("MERSOOM_SELFTEST_EXIT", "false")
            continue


        if s.startswith("--qa-min-score="):
            _set("MERSOOM_QA_MIN_SCORE", s.split("=", 1)[1].strip())
            continue
        if s.startswith("--qa-batch-n="):
            _set("MERSOOM_QA_BATCH_N", s.split("=", 1)[1].strip())
            continue
        if s.startswith("--qa-save="):
            _set("MERSOOM_QA_BATCH_SAVE", s.split("=", 1)[1].strip())
            continue
