################################################################################
# 22. QA + FALLBACK (QUALITY GATES)
# Deps: 01-03, 08-21
# Used by: contribution pipeline (when normal path blocked or quality low)
# Notes: pacing gates, minimal safe replies, and fallback posting logic
################################################################################
"""
SECTION 22 - QA FALLBACK / CONTRIBUTION

Fallback behavior when generation fails or is gated out.

Responsibilities:
- Provide safe "minimal contribution" patterns.
- Keep the agent active without violating quality constraints.
"""
def do_contribution(
    client: HttpClient,
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    memory: List[Dict[str, Any]],
    semantic: Dict[str, Any],
    policy: Dict[str, Any],
    brain: Dict[str, Any],
    posts_cache: List[Dict[str, Any]],
    post_limiter: SlidingWindowLimiter,
    comment_limiter: SlidingWindowLimiter,
    comment_pace_sec: int,
    post_pace_sec: int,
    bm25: Optional[BM25Index],
) -> int:
    # ============================================================
    # SECTION 0: Housekeeping + pacing gates
    # ============================================================
    try:
        trace_hit("select:contrib:enter")
    except Exception:
        pass

    update_daily_counters(state)
    gc_state(state)
    log_health_if_due(client, state)

    drives = get_persona_drives(brain)
    maturity = get_maturity_level(brain, state)
    ctx_hint = _pick_ctx_from_flow(brain)


    # ------------------------------------------------------------
    # Gates: post/comment pacing + window limits
    # ------------------------------------------------------------
    gap_post = gap_remaining(float(state.get("last_post_ts", 0.0) or 0.0), int(post_pace_sec))
    can_post = (gap_post <= 0) and (post_limiter.remaining() > 0)

    gap_com = gap_remaining(float(state.get("last_comment_ts", 0.0) or 0.0), int(comment_pace_sec))
    can_comment = (gap_com <= 0) and (comment_limiter.remaining() > 0)

    if (not can_post) and (not can_comment):
        try:
            det = (
                f"post_gap={int(max(0, gap_post))}s rem_post={int(post_limiter.remaining())} | "
                f"comment_gap={int(max(0, gap_com))}s rem_comment={int(comment_limiter.remaining())}"
            )
            protocol_set_reason(state, "comment", "comment:rate_limited", det)
        except Exception:
            protocol_set_reason(state, "comment", "comment:rate_limited")

    # Optional: log why actions are blocked (helps tuning without spamming by default).
    if getattr(cfg, "debug", None) and cfg.debug.log_blocks and not (can_post or can_comment):
        try:
            now_ts = time.time()
            last_ts = float(state.get("_last_gate_log_ts", 0.0) or 0.0)
            if now_ts - last_ts >= 60.0:
                state["_last_gate_log_ts"] = now_ts
                log_debug(
                    f"gates blocked | post:gap={int(max(0,gap_post))}s rem={post_limiter.remaining()} "
                    f"| comment:gap={int(max(0,gap_com))}s rem={comment_limiter.remaining()}"
                )
        except Exception as e:
            log_debug_exc("do_contribution:silent", e)
            pass


    # ============================================================
    # SECTION 1: Reply priority queue (inbox-driven interactions)
    # ============================================================
    # 0) (Unit 04) Priority inbox: replies-to-me + my-post comments first
    if can_comment:
        done = try_reply_priority_queue(
            client, cfg, tuning,
            state, memory, semantic, policy, brain,
            posts_cache,
            comment_limiter, comment_pace_sec,
            bm25=bm25
        )
        if done > 0:
            return done



    # ============================================================
    # SECTION 2: Heartbeat / force-action clamps (anti-stall)
    # ============================================================
    hb_force_action = ""
    force_post_now = False
    try:
        hb_cfg = getattr(cfg, "heartbeat", None)
        if hb_cfg and bool(getattr(hb_cfg, "enabled", False)):
            proto = _safe_dict(state.get("protocol"))
            hb = _safe_dict(_safe_dict(proto).get("heartbeat"))
            if hb and bool(hb.get("active")):
                q = _safe_dict(hb.get("quota"))
                try:
                    _hb_clamp_comment_target(cfg, state, int(comment_pace_sec), comment_limiter)
                except Exception:
                    pass
                q = _safe_dict(hb.get("quota"))
                c_tgt = int(q.get("comments_target", 0) or 0)
                c_done = int(q.get("comments_done", 0) or 0)
                contrib_done = bool(q.get("contribute_done", False))
                if c_tgt > 0 and c_done < c_tgt and (not can_comment):
                    try:
                        proto2 = _sdict(state, "protocol")
                        if int(getattr(comment_limiter, "capacity", 0) or 0) <= 0:
                            proto2["hb_block_reason"] = "comment_limit0"
                        elif float(gap_com) > 0:
                            proto2["hb_block_reason"] = "cooldown"
                        elif int(comment_limiter.remaining()) <= 0:
                            proto2["hb_block_reason"] = "comment_limit0"
                        else:
                            proto2["hb_block_reason"] = "cooldown"
                    except Exception:
                        pass
                if c_tgt > 0 and c_done < c_tgt and can_comment:
                    hb_force_action = "comment_other"
                elif (c_tgt <= 0 or c_done >= c_tgt) and (not contrib_done) and can_post:
                    hb_force_action = "post_new"
                    force_post_now = True
    except Exception:
        hb_force_action = ""
        force_post_now = False


    # ============================================================
    # SECTION 3: Action selection (comment/reply/post) + generation
    # ============================================================
    # 1) Choose action type (pattern becomes learnable + maturity reduces randomness)
    action_type = hb_force_action or ""
    if (not action_type) and (can_post or can_comment):
        action_type = choose_arm_adaptive(policy, "action_type", context_key=ctx_hint, maturity=maturity, brain=brain)
    if action_type not in ("post_new", "comment_other", "reply_other", "reply_own"):
        action_type = "comment_other" if can_comment else "post_new"

    # reply_own is handled by step (0); if it was selected here, treat it as a regular comment path
    if action_type == "reply_own":
        action_type = "comment_other"

    # 2) Post decision: fame+maturity -> 조금 더 자주 글(하지만 제한 내)
    flow_bonus = 0.03 if _safe_list(_safe_dict(brain.get("community")).get("rising")) else 0.0
    post_prob = 0.05 + 0.10 * drives.get("fame", 0.7) + 0.05 * maturity + flow_bonus
    post_prob = max(0.03, min(0.22, float(post_prob)))

    if action_type == "post_new" and can_post and (force_post_now or random.random() < post_prob):
        if not post_limiter.allow():
            if getattr(cfg, "debug", None) and cfg.debug.log_blocks:
                log_debug("gate:post blocked by window (allow=false)")
            return 0
        title = ""
        body = ""
        meta: Dict[str, Any] = {}
        qrep: Dict[str, Any] = {}
        combo = ""
        ok_post = False
        for _try in range(_regen_budget(cfg)):
            title, body, meta = build_post_text(cfg, tuning, state, policy, semantic, brain, bm25)
            # v5.1 Unit1: strip unresolved <NAME> placeholders in posts (never inject in post mode)
            title = apply_name_layer(cfg, state, title, mode="post", target_nick="")
            body = apply_name_layer(cfg, state, body, mode="post", target_nick="")
            body = apply_microedit_layer(cfg, state, body, mode="post")
            combo = f"{title}\n{body}"
            ok_gate, g_bucket, g_detail, _qrep = final_post_gate(
                cfg, state, title, body, combo,
                same_text_gap_sec=cfg.timing.same_text_gap_sec,
            )
            if not ok_gate:
                _bump_gen_fail(state, g_bucket or "qa_fail")
                if str(g_bucket or "").startswith("dup"):
                    if (_try % 3) == 0:
                        log_action("DUP", f"block mode=post reason={g_bucket} try={_try+1}")
                else:
                    log_action("QA", f"fail mode=post {g_detail or 'qa_fail'} try={_try+1}")
                continue
            qrep = _safe_dict(_qrep)
            ok_post = True
            break
        if not ok_post:
            return 0

        if dup_action_should_skip(state, action="post", target_id=_text_hash(combo), endpoint_key="/posts"):
            protocol_set_reason(state, "post", "post:dup_action", "recent_action_guard")
            return 0
        _bump_action_counter(state, "action_attempt", "post")
        t0_commit = time.perf_counter()
        result = ActionResult(ok=False, code="post:commit_fail")
        # 14.5. COMMIT (post)
        try:
            res = create_post(client, cfg, tuning, state, title, body)
            result = ActionResult(ok=bool(res), code=("post:ok" if res else "post:empty"), elapsed_ms=(time.perf_counter() - t0_commit) * 1000.0)
        except PowTimeoutError as e:
            result = ActionResult(ok=False, code="post:pow_timeout", detail=str(e), elapsed_ms=(time.perf_counter() - t0_commit) * 1000.0)
            protocol_set_reason(state, "post", "post:pow_timeout", one_line(str(e), 160))
            _bump_action_counter(state, "action_fail", "post")
            return 0
        if result.ok:
            _bump_action_counter(state, "action_success", "post")
        else:
            _bump_action_counter(state, "action_fail", "post")
        if not res:
            return 0
        remember_action(state, action="post", target_id=_text_hash(combo), endpoint_key="/posts")

        pid = str(res.get("id") or res.get("post_id") or "")
        remember_text(state, combo, for_post=True, same_text_gap_sec=cfg.timing.same_text_gap_sec)
        fp_ttl = _env_int("MERSOOM_RECENT_TEXT_FP_TTL_SEC", 6 * 3600, 60, 30 * 24 * 3600)
        fp_keep = _env_int("MERSOOM_RECENT_TEXT_FP_KEEP_MAX", 1200, 50, 20000)
        remember_fp(state, combo, for_post=True, ttl_sec=max(int(fp_ttl), int(cfg.timing.same_text_gap_sec)), keep_max=int(fp_keep))
        remember_simhash(state, combo, for_post=True, same_text_gap_sec=cfg.timing.same_text_gap_sec)
        remember_dup_signatures(state, combo, for_post=True, same_text_gap_sec=cfg.timing.same_text_gap_sec)

        state["last_post_ts"] = time.time()
        state["contrib_count_today"] = int(state.get("contrib_count_today", 0)) + 1
        state["total_actions"] = int(state.get("total_actions", 0)) + 1

        try:
            update_persona_maturity(brain, state)
        except Exception as e:
            log_exception("brain:maturity", e, context={"stage": "do_contribution", "action": "post", "post_id": str(pid)})
            if _should_failfast("brain") or _should_failfast("contrib"):
                raise

        try:
            bump_semantic(semantic, _today_kst(), "post", 1.0)
        except Exception as e:
            log_exception("semantic:bump", e, context={"stage": "do_contribution", "action": "post", "post_id": str(pid), "key": "post"})
            if _should_failfast("semantic") or _should_failfast("contrib"):
                raise

        item = {
            "ts": time.time(),
            "action": "post",
            "action_type": "post_new",
            "post_id": pid,
            "category": meta.get("category", "general"),
            "context_key": meta.get("context_key", "gen"),
            "kw": meta.get("seed_kw", ""),
            "text": combo,
            "qa_score": float(qrep.get("score", 0) or 0),
            "qa_issues": list(qrep.get("issues", []))[:6],
            "used_style": meta.get("post_style", ""),
            "eval_due_ts": schedule_eval_due(tuning),
            "metrics_before": {},
            "metrics_after": {},
            "evaluated": False,
            "reward_scalar": 0.0,
        }
        item["ground_reason"] = ""
        item["target_nick"] = ""
        item["proxy_reward"] = compute_proxy_reward(combo, mode="post", ground_reason="")
        item.setdefault("brain_proxy_applied", False)
        item.setdefault("brain_reward_applied", False)
        record_memory(memory, item, tuning, archive_path_jsonl=cfg.paths.memory_archive_jsonl)
        try:
            apply_brain_proxy_update(brain, tuning, item)
        except Exception as e:
            log_exception("brain:proxy_update", e, context={"stage":"do_contribution","action": str(item.get("action") or ""), "post_id": str(item.get("post_id") or ""), "parent_id": str(item.get("parent_id") or "")})
            if _should_failfast("brain") or _should_failfast("contrib"):
                raise

        log_action("POST", f"post_id={pid} title={one_line(title)}")
        return 1

    # 3) Otherwise comment on other people's posts
    if not can_comment:
        # comment path is blocked (gap or limiter)
        try:
            if gap_com > 0:
                protocol_set_reason(state, "comment", "comment:rate_limited", f"gap={int(gap_com)}s")
            else:
                protocol_set_reason(state, "comment", "comment:rate_limited", f"window_remaining={int(comment_limiter.remaining())}")
        except Exception:
            protocol_set_reason(state, "comment", "comment:rate_limited")
        return 0
    if not comment_limiter.allow():
        if getattr(cfg, "debug", None) and cfg.debug.log_blocks:
            log_debug("gate:comment blocked by window (allow=false)")
        protocol_set_reason(state, "comment", "comment:rate_limited", "window_allow=false")
        return 0

    target = _pick_contrib_target(cfg, state, posts_cache, brain)
    if not target:
        protocol_set_reason(state, "comment", "comment:no_target", "no_target")
        return 0

    pid = str(target.get("id") or "")
    if not pid:
        protocol_set_reason(state, "comment", "comment:no_target", "missing_post_id")
        return 0


    before = _post_metrics(target)

    # fetch comments for context
    try:
        comments = list_comments(client, pid)
    except Exception:
        comments = []

    ingest_post_into_context(state, target, brain=brain)
    ingest_comments_into_context(state, pid, comments, brain=brain, cfg=cfg)
    th = get_thread(state, pid)
    synthesize_thread(th)

    # choose counterparty (reply to last other comment if exists)
    last_other = None
    for c in reversed(comments[-10:]):
        if not isinstance(c, dict):
            continue
        if is_own_comment(cfg, c):
            continue
        last_other = c
        break


    boost = _env_float("MERSOOM_REPLY_QUESTION_BOOST", 0.25, 0.0, 1.0)
    last_other_txt = ""
    try:
        last_other_txt = str((last_other or {}).get("content") or "")
    except Exception:
        last_other_txt = ""
    is_q = _is_questionish(last_other_txt)

    wants_reply = bool(last_other) and (
        (action_type == "reply_other") or (is_q and (random.random() < float(boost)))
    )

    try:
        if wants_reply and pid:
            proto = _sdict(state, "protocol")
            rs = _sdict(proto, "reply_streak")
            rec = _safe_dict(rs.get(pid))
            cnt = int(rec.get("count", 0) or 0)
            last_ts = float(rec.get("last_ts", 0.0) or 0.0)
            if cnt >= 2 and (time.time() - last_ts) < 6 * 3600:
                wants_reply = False
    except Exception:
        pass

    parent_id = str((last_other or {}).get("id") or "") if wants_reply else None

    # toxic/taunt: don't reply directly; optionally downvote the post, then fallback to a normal comment.
    if parent_id and wants_reply:
        try:
            ltxt = str((last_other or {}).get("content") or "")
        except Exception:
            ltxt = ""
        if ltxt and handle_toxic_target(client, cfg, state, pid, parent_id, ltxt, tag="reply_other"):
            wants_reply = False
            parent_id = None

        # conversation protocol gate for replies on other people's posts
        conv_key2 = ""
        conv_meta2: Dict[str, Any] = {}
        if parent_id:
            okp2, conv_key2, _conv2, conv_meta2, reason2 = _reply_protocol_prepare(state, cfg, tuning, pid, comments, str(parent_id), time.time())
            if not okp2:
                protocol_set_reason(state, "comment", "comment:qa_fail", f"protocol_gate:{one_line(str(reason2), 140)}")
                return 0


        user_key = str(((last_other or {}).get("nickname") if wants_reply else (target.get("nickname") or "user")))
        user = get_user(state, user_key)

        set_focus(state, mode=("reply" if parent_id else "comment"), post_id=pid, post=target, comment=last_other if parent_id else None)

        # pass conversation meta to reply generator
        try:
            if parent_id and isinstance(state.get("focus"), dict):
                state["focus"]["conv"] = conv_meta2
        except Exception as e:
            log_debug_exc("do_contribution:silent", e)
            pass

        txt = ""
        meta: Dict[str, Any] = {}
        ok_txt = False
        ground_reason = ""
        qrep: Dict[str, Any] = {}
        last_fail_bucket = ""
        last_fail_detail = ""
        last_candidate = ""
        for _try in range(_regen_budget(cfg)):
            txt, meta = build_reply_text(
                cfg, tuning, state, policy, th, user,
                bm25=bm25,
                brain=brain,
                reply_to_own_post=False,
                is_reply=bool(parent_id),
            )
            base_txt = txt
            last_candidate = base_txt
            mode2 = "reply" if bool(parent_id) else "comment"
            focus_d = _safe_dict(state.get("focus"))

            # v5.4 Unit4: LM rerank over a small set of Unit1-3 postprocessed variants (safe; gate-first).
            cand_pack: List[Tuple[str, Dict[str, Any]]] = []
            used_lm = False
            if _env_bool("MERSOOM_LM_RERANK", True):
                try:
                    cand_pack = lm_make_ranked_candidates(
                        cfg, state, semantic, base_txt,
                        mode=mode2,
                        target_nick=(user_key if mode2 == "reply" else ""),
                        target_text=(str(last_other_txt or "") if mode2 == "reply" else ""),
                        k=_env_int("MERSOOM_LM_CAND_K", 8, 2, 16),
                    )
                    if cand_pack:
                        used_lm = True
                        protocol_bump_counter(state, "lm_rerank_used", 1)
                except Exception:
                    cand_pack = []
                    used_lm = False

            if not cand_pack:
                # Legacy single-candidate path (Units 1-3)
                txt = apply_name_layer(cfg, state, base_txt, mode=mode2, target_nick=(user_key if mode2 == "reply" else ""))
                txt = apply_microedit_layer(cfg, state, txt, mode=mode2)
                if mode2 == "reply":
                    txt = apply_quote_layer(cfg, state, txt, mode="reply", target_text=str(last_other_txt or ""))
                    txt = apply_microedit_layer(cfg, state, txt, mode="reply")
                cand_pack = [(txt, {})]

            ok_gate = False
            g_bucket = ""
            g_detail = ""
            g_reason = ""
            accepted_meta: Dict[str, Any] = {}

            for cand_txt, cmeta in cand_pack:
                ok_gate, g_bucket, g_detail, g_reason, _qrep = final_text_gate(
                    cfg, state, cand_txt,
                    mode=mode2, kind=mode2,
                    focus=focus_d,
                    same_text_gap_sec=cfg.timing.same_text_gap_sec,
                )
                if ok_gate:
                    txt = cand_txt
                    accepted_meta = _safe_dict(cmeta)
                    qrep = _safe_dict(_qrep)
                    break

            if ok_gate and used_lm:
                _lm_apply_accept_side_effects(state, accepted_meta, target_nick=(user_key if mode2 == "reply" else ""))

            if (not ok_gate) and used_lm:
                protocol_bump_counter(state, "lm_fallback_used", 1)

            if not ok_gate:
                last_fail_bucket = str(g_bucket or "")
                last_fail_detail = str(g_detail or g_bucket or "")
                _bump_gen_fail(state, g_bucket or "qa_fail")
                if str(g_bucket or "").startswith("dup"):
                    if (_try % 3) == 0:
                        log_action("DUP", f"block mode={mode2} reason={g_bucket} try={_try+1}")
                elif str(g_detail or "").startswith("ground:"):
                    log_action("VALIDATE", f"fail mode={mode2} reason={str(g_detail or '')[7:]} try={_try+1}")
                else:
                    log_action("QA", f"fail mode={mode2} {g_detail or 'qa_fail'} try={_try+1}")
                continue
            ok_txt = True
            ground_reason = g_reason
            break


        if not ok_txt:
            mode2 = "reply" if bool(parent_id) else "comment"
            fb = _qa_fallback_2stage(last_candidate, is_reply=bool(parent_id))
            if fb:
                try:
                    # v5.4 Unit4: LM rerank for fallback candidate (safe; gate-first)
                    base_fb = fb
                    focus_d = _safe_dict(state.get("focus"))

                    cand_pack: List[Tuple[str, Dict[str, Any]]] = []
                    used_lm = False
                    if _env_bool("MERSOOM_LM_RERANK", True):
                        try:
                            cand_pack = lm_make_ranked_candidates(
                                cfg, state, semantic, base_fb,
                                mode=mode2,
                                target_nick=(user_key if mode2 == "reply" else ""),
                                target_text=(str(last_other_txt or "") if mode2 == "reply" else ""),
                                k=_env_int("MERSOOM_LM_CAND_K", 8, 2, 16),
                            )
                            if cand_pack:
                                used_lm = True
                                protocol_bump_counter(state, "lm_rerank_used", 1)
                        except Exception:
                            cand_pack = []
                            used_lm = False

                    if not cand_pack:
                        # legacy Units 1-3 on fallback
                        fb = apply_name_layer(cfg, state, base_fb, mode=mode2, target_nick=(user_key if mode2 == "reply" else ""))
                        fb = apply_microedit_layer(cfg, state, fb, mode=mode2)
                        if mode2 == "reply":
                            fb = apply_quote_layer(cfg, state, fb, mode="reply", target_text=str(last_other_txt or ""))
                            fb = apply_microedit_layer(cfg, state, fb, mode="reply")
                        cand_pack = [(fb, {})]

                    ok_gate = False
                    g_bucket = ""
                    g_detail = ""
                    g_reason = ""
                    accepted_meta: Dict[str, Any] = {}

                    for cand_txt, cmeta in cand_pack:
                        ok_gate, g_bucket, g_detail, g_reason, _qrep = final_text_gate(
                            cfg, state, cand_txt,
                            mode=mode2, kind=mode2,
                            focus=focus_d,
                            same_text_gap_sec=cfg.timing.same_text_gap_sec,
                        )
                        if ok_gate:
                            fb = cand_txt
                            accepted_meta = _safe_dict(cmeta)
                            qrep = _safe_dict(_qrep)
                            break

                    if ok_gate and used_lm:
                        _lm_apply_accept_side_effects(state, accepted_meta, target_nick=(user_key if mode2 == "reply" else ""))

                    if (not ok_gate) and used_lm:
                        protocol_bump_counter(state, "lm_fallback_used", 1)
                    if ok_gate:
                        txt = fb
                        ok_txt = True
                        ground_reason = g_reason
                    else:
                        last_fail_bucket = str(g_bucket or "")
                        last_fail_detail = str(g_detail or g_bucket or "")
                        _bump_gen_fail(state, g_bucket or "qa_fail")
                except Exception:
                    pass
            if not ok_txt and not STRICT_POSTPROCESS:
                # legacy fallback when strict postprocess is off
                fb2 = _pick_fallback_comment(cfg, is_reply=bool(parent_id))
                if fb2:
                    try:
                        # v5.1 Unit1: apply name layer to 2nd-stage fallback
                        fb2 = apply_name_layer(cfg, state, fb2, mode=mode2, target_nick=(user_key if mode2 == "reply" else ""))
                        fb2 = apply_microedit_layer(cfg, state, fb2, mode=mode2)
                        if mode2 == "reply":
                            # v5.2 Unit2: inject a short quote from the parent comment (replies only)
                            fb2 = apply_quote_layer(cfg, state, fb2, mode="reply", target_text=str(last_other_txt or ""))
                            fb2 = apply_microedit_layer(cfg, state, fb2, mode="reply")
                        focus_d = _safe_dict(state.get("focus"))
                        ok_gate, g_bucket, g_detail, g_reason, _qrep = final_text_gate(
                            cfg, state, fb2,
                            mode=mode2, kind=mode2,
                            focus=focus_d,
                            same_text_gap_sec=cfg.timing.same_text_gap_sec,
                        )
                        if ok_gate:
                            txt = fb2
                            ok_txt = True
                            ground_reason = g_reason
                        else:
                            last_fail_bucket = str(g_bucket or "")
                            last_fail_detail = str(g_detail or g_bucket or "")
                            _bump_gen_fail(state, g_bucket or "qa_fail")
                    except Exception:
                        pass
            if not ok_txt:
                code = "comment:qa_fail"
                if last_fail_bucket == "dup_fp":
                    code = "comment:dup_fp"
                elif last_fail_bucket == "dup_sim":
                    code = "comment:dup_sim"
                protocol_set_reason(state, "comment", code, one_line(last_fail_detail or last_fail_bucket or "gen_fail", 140))
                return 0

        if dup_action_should_skip(state, action=("reply" if parent_id else "comment"), target_id=str(parent_id or pid), endpoint_key=f"/posts/{pid}/comments"):
            protocol_set_reason(state, "comment", "comment:dup_action", "recent_action_guard")
            return 0
        _bump_action_counter(state, "action_attempt", "reply" if parent_id else "comment")
        t0_commit = time.perf_counter()
        result = ActionResult(ok=False, code="comment:commit_fail")
        # 14.5. COMMIT (comment/reply)
        try:
            res = create_comment(client, cfg, tuning, state, pid, txt, parent_id=parent_id)
            result = ActionResult(ok=bool(res), code=("comment:ok" if res else "comment:empty"), elapsed_ms=(time.perf_counter() - t0_commit) * 1000.0)
        except RateLimitError as e_rl:
            protocol_set_reason(state, "comment", "comment:rate_limited", one_line(str(e_rl), 180))
            raise
        except PowTimeoutError as e:
            result = ActionResult(ok=False, code="comment:pow_timeout", detail=str(e), elapsed_ms=(time.perf_counter() - t0_commit) * 1000.0)
            protocol_set_reason(state, "comment", "comment:pow_timeout", one_line(str(e), 180))
            _bump_action_counter(state, "action_fail", "reply" if parent_id else "comment")
            return 0
        except requests.HTTPError as e_http:
            protocol_set_reason(state, "comment", "comment:qa_fail", one_line(str(e_http), 180))
            raise
        except Exception as e:
            protocol_set_reason(state, "comment", "comment:qa_fail", one_line(repr(e), 180))
            raise
        if not res:
            protocol_set_reason(state, "comment", "comment:no_target", "comment_create_failed")
            _bump_action_counter(state, "action_fail", "reply" if parent_id else "comment")
            return 0
        if result.ok:
            _bump_action_counter(state, "action_success", "reply" if parent_id else "comment")
        else:
            _bump_action_counter(state, "action_fail", "reply" if parent_id else "comment")
        remember_action(state, action=("reply" if parent_id else "comment"), target_id=str(parent_id or pid), endpoint_key=f"/posts/{pid}/comments")

        # commit conversation protocol state (only for replies)
        try:
            if parent_id:
                _reply_protocol_commit(state, conv_key2, time.time(), _extract_comment_id(res), txt)
        except Exception as e:
            log_debug_exc("do_contribution:silent", e)
            pass

        remember_text(state, txt, for_post=False, same_text_gap_sec=cfg.timing.same_text_gap_sec)

        fp_ttl = _env_int("MERSOOM_RECENT_TEXT_FP_TTL_SEC", 6 * 3600, 60, 30 * 24 * 3600)

        fp_keep = _env_int("MERSOOM_RECENT_TEXT_FP_KEEP_MAX", 1200, 50, 20000)

        remember_fp(state, txt, for_post=False, ttl_sec=max(int(fp_ttl), int(cfg.timing.same_text_gap_sec)), keep_max=int(fp_keep))
        remember_simhash(state, txt, for_post=False, same_text_gap_sec=cfg.timing.same_text_gap_sec)
        remember_dup_signatures(state, txt, for_post=False, same_text_gap_sec=cfg.timing.same_text_gap_sec)

        state["commented_ts"] = _safe_dict(state.get("commented_ts"))
        state["commented_ts"][pid] = time.time()
        try:
            proto3 = _sdict(state, "protocol")
            rs3 = _sdict(proto3, "reply_streak")
            if parent_id:
                rec3 = _safe_dict(rs3.get(pid))
                cnt3 = int(rec3.get("count", 0) or 0) + 1
                rs3[pid] = {"count": cnt3, "last_ts": time.time()}
            else:
                rs3[pid] = {"count": 0, "last_ts": time.time()}
        except Exception:
            pass
        state["last_comment_ts"] = time.time()
        state["contrib_count_today"] = int(state.get("contrib_count_today", 0)) + 1
        state["total_actions"] = int(state.get("total_actions", 0)) + 1

        action_name = ("reply" if parent_id else "comment")
        action_key = ("reply_other" if parent_id else "comment")

        try:
            update_persona_maturity(brain, state)
        except Exception as e:
            log_exception("brain:maturity", e, context={"stage": "do_contribution", "action": str(action_name), "post_id": str(pid), "parent_id": str(parent_id or "")})
            if _should_failfast("brain") or _should_failfast("contrib"):
                raise

        try:
            bump_semantic(semantic, _today_kst(), action_key, 1.0)
        except Exception as e:
            log_exception("semantic:bump", e, context={"stage": "do_contribution", "action": str(action_name), "post_id": str(pid), "parent_id": str(parent_id or ""), "key": str(action_key)})
            if _should_failfast("semantic") or _should_failfast("contrib"):
                raise

        _bump_relation(state, user_key)

        try:
            if _openq_track_enabled(state) and _is_open_question_text(txt):
                qtext = _extract_open_question_text(txt)
                if qtext:
                    qid = thread_add_open_question(th, qtext, asked_by="me", last_seen_remote_id=str(parent_id or ""))
                    try:
                        proto_q = _sdict(state, "protocol")
                        proto_q["openq_added_total"] = int(proto_q.get("openq_added_total", 0) or 0) + 1
                    except Exception:
                        pass
                    protocol_bump_counter(state, "openq_add")
                    log_event("openq.add", post_id=str(pid), parent_id=str(parent_id or ""), qid=str(qid))
        except Exception:
            pass

        item = {
            "ts": time.time(),
            "action": ("reply" if parent_id else "comment"),
            "action_type": ("reply_other" if parent_id else "comment_other"),
            "post_id": pid,
            "parent_id": parent_id,
            "category": meta.get("category", "general"),
            "context_key": meta.get("context_key", "gen"),
            "kw": meta.get("kw", ""),
            "text": txt,
            "used_strategy": meta.get("strategy", ""),
            "used_tone": meta.get("tone", ""),
            "used_length": meta.get("length", ""),
            "used_reply_style": meta.get("reply_style", ""),
            "weak_context": bool(meta.get("weak_context")),
            "template_id": meta.get("template_id", ""),
            "used_quotes": bool(meta.get("used_quotes")),
            "novelty": _novelty_score(state, txt),
            "comment_id": _extract_comment_id(res),
            "qa_score": float(qrep.get("score", 0) or 0),
            "qa_issues": list(qrep.get("issues", []))[:6],
            "qa_rep3": float(qrep.get("rep3", 0.0) or 0.0),
            "qa_im_ratio": float(qrep.get("im_ratio", 0.0) or 0.0),
            "qa_line_prefix_dup": float(qrep.get("line_prefix_dup", 0.0) or 0.0),
            "eval_due_ts": schedule_eval_due(tuning),
            "metrics_before": before,
            "metrics_after": {},
            "evaluated": False,
            "reward_scalar": 0.0,
        }
        item["ground_reason"] = ground_reason
        item["target_nick"] = user_key
        item["proxy_reward"] = compute_proxy_reward(txt, mode=("reply" if parent_id else "comment"), ground_reason=ground_reason)
        item.setdefault("brain_proxy_applied", False)
        item.setdefault("brain_reward_applied", False)
        record_memory(memory, item, tuning, archive_path_jsonl=cfg.paths.memory_archive_jsonl)
        try:
            apply_brain_proxy_update(brain, tuning, item)
        except Exception as e:
            log_exception("brain:proxy_update", e, context={"stage":"do_contribution","action": str(item.get("action") or ""), "post_id": str(item.get("post_id") or ""), "parent_id": str(item.get("parent_id") or "")})
            if _should_failfast("brain") or _should_failfast("contrib"):
                raise

        log_action("REPLY" if parent_id else "COMMENT", f"post={pid} parent={parent_id or '-'} | {one_line(txt)}")
        return 1
    return 0
