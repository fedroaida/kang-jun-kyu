################################################################################
# 06. HTTP CLIENT
# Deps: 01-05
# Used by: API wrappers + agent actions
# Notes: Retry/backoff/jitter + error classification.
################################################################################
"""
SECTION 06 - HTTP CLIENT (RETRY/BACKOFF)

HTTP client wrapper around requests (or urllib) with retry/backoff and error normalization.

Responsibilities:
- Add headers/auth, standardize errors, parse status codes.
- Implement retries, backoff, and Retry-After handling.
- Provide one place to adjust network behavior.

Notes:
- Network code should be predictable: failures become structured error info, not crashes.
"""
@dataclass
class HttpResult:
    status_code: int
    json: Optional[Any]
    text: str

class RateLimitError(Exception):
    def __init__(self, message: str, retry_after_sec: Optional[float] = None):
        super().__init__(message)
        self.retry_after_sec = retry_after_sec

class PowTimeoutError(Exception):
    pass

def _parse_retry_after_sec(headers: Any) -> Optional[float]:
    """Parse Retry-After header (seconds or HTTP date). Returns seconds to wait."""
    try:
        if not headers:
            return None
        ra = None
        try:
            ra = headers.get("Retry-After")
        except Exception:
            ra = None
        if ra is None:
            return None
        s = str(ra).strip()
        if not s:
            return None
        # numeric seconds
        if re.fullmatch(r"\d+", s):
            return float(int(s))
        # HTTP-date format
        try:
            from email.utils import parsedate_to_datetime
            dt = parsedate_to_datetime(s)
            if dt is None:
                return None
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            now = datetime.now(timezone.utc)
            return max(0.0, (dt - now).total_seconds())
        except Exception:
            return None
    except Exception:
        return None

class HttpClient:
    def __init__(self, cfg: HttpConfig):
        self.cfg = cfg
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": cfg.user_agent,
            "Accept": "application/json",
        })

        try:
            from requests.adapters import HTTPAdapter
            pool_conns = _env_int("MERSOOM_HTTP_POOL_CONNS", 10, 1, 200)
            pool_max = _env_int("MERSOOM_HTTP_POOL_MAX", 20, 1, 500)
            adapter = HTTPAdapter(pool_connections=pool_conns, pool_maxsize=pool_max, max_retries=0)
            self.session.mount("http://", adapter)
            self.session.mount("https://", adapter)
        except Exception as e:
            log_debug_exc("http_adapter:silent", e)
            pass


        # (P0) minimal observability / health metrics
        self.metrics: Dict[str, Any] = {
            "req_total": 0,
            "req_ok": 0,
            "rate_limited": 0,
            "http_errors": 0,
            "net_errors": 0,
            "last_status": None,
            "last_error": "",
            "latency_ms_ema": 0.0,
            "latency_ms_last": 0.0,
            "last_ok_ts": 0.0,

        }

        self._recent_429_ts = deque(maxlen=4000)  # timestamps of 429 responses
        self._recent_retry_after_sleep_ts = deque(maxlen=4000)  # timestamps when we honored Retry-After sleeps
        self._recent_http_401_ts = deque(maxlen=2000)
        self._recent_http_5xx_ts = deque(maxlen=4000)
        self._last_retry_after_raw_sec: float = 0.0
        self._last_retry_after_sleep_sec: float = 0.0
        self._last_retry_after_basis: str = ""  # "retry-after" | "backoff" | ""


    def _timeout(self) -> Tuple[float, float]:
        return (float(self.cfg.timeout_connect_sec), float(self.cfg.timeout_read_sec))

    @staticmethod
    def _is_validation_status(code: int) -> bool:
        return code in (400, 409, 422)

    @staticmethod
    def _is_rate_limited(code: int) -> bool:
        return code == 429

    @staticmethod
    def _is_retryable_5xx(code: int) -> bool:
        return 500 <= code <= 599

    def _backoff_sleep(self, attempt: int) -> None:
        base = float(self.cfg.backoff_base)
        cap = float(self.cfg.backoff_cap)
        t = min(cap, base * (2 ** max(0, attempt - 1))) * random.uniform(0.7, 1.3)
        time.sleep(max(0.0, t))

    def request(
        self,
        method: str,
        path: str,
        *,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        json_payload: Optional[Dict[str, Any]] = None,
        allow_retry: bool = True,
    ) -> HttpResult:
        url = f"{self.cfg.base_url}{path}"

        if self.cfg.dry_run and method.upper() in ("POST", "PUT", "PATCH", "DELETE"):
            return HttpResult(
                status_code=200,
                json={"dry_run": True, "method": method, "url": url, "payload": json_payload},
                text="",
            )

        last_text = ""
        for attempt in range(1, int(self.cfg.max_retries) + 2):  # retries + 1 initial
            try:
                t0 = time.perf_counter()
                try:
                    self.metrics["req_total"] = int(self.metrics.get("req_total", 0)) + 1
                except Exception as e:
                    log_debug_exc("HttpClient.request:req_total", e)
                    pass
                r = self.session.request(
                    method=method.upper(),
                    url=url,
                    headers=headers or {},
                    params=params or {},
                    json=json_payload,
                    timeout=self._timeout(),
                    allow_redirects=True,
                )
                last_text = r.text or ""
                code = int(r.status_code)

                lat_ms = (time.perf_counter() - t0) * 1000.0
                try:
                    self.metrics["latency_ms_last"] = float(lat_ms)
                    ema = float(self.metrics.get("latency_ms_ema", 0.0) or 0.0)
                    self.metrics["latency_ms_ema"] = (0.2 * float(lat_ms)) + (0.8 * ema if ema > 0 else 0.8 * float(lat_ms))
                    self.metrics["last_status"] = int(code)
                except Exception as e:
                    log_debug_exc("HttpClient.request:latency_metrics", e)
                    pass

                if self._is_rate_limited(code):
                    ra = _parse_retry_after_sec(getattr(r, "headers", None))
                    try:
                        self._recent_429_ts.append(time.time())
                        if ra is not None:
                            self._last_retry_after_raw_sec = float(ra)
                    except Exception:
                        pass
                    raise RateLimitError(f"429 rate limited: {last_text[:200]}", retry_after_sec=ra)
                if code == 401:
                    try:
                        self._recent_http_401_ts.append(time.time())
                    except Exception:
                        pass
                if self._is_retryable_5xx(code):
                    try:
                        self._recent_http_5xx_ts.append(time.time())
                    except Exception:
                        pass

                if self._is_validation_status(code):
                    j = None
                    try:
                        j = r.json() if last_text else None
                    except Exception:
                        j = None
                    return HttpResult(status_code=code, json=j, text=last_text)

                if allow_retry and self.cfg.retry_on_5xx and self._is_retryable_5xx(code):
                    if attempt <= int(self.cfg.max_retries):
                        self._backoff_sleep(attempt)
                        continue

                r.raise_for_status()
                if code < 400:
                    try:
                        self.metrics["req_ok"] = int(self.metrics.get("req_ok", 0)) + 1
                        self.metrics["last_ok_ts"] = time.time()
                    except Exception as e:
                        log_debug_exc("HttpClient.request:req_ok", e)
                        pass
                if not last_text:
                    return HttpResult(status_code=code, json=None, text="")
                try:
                    return HttpResult(status_code=code, json=r.json(), text=last_text)
                except Exception:
                    return HttpResult(status_code=code, json=None, text=last_text)

            except RateLimitError as e_rl:
                try:
                    self.metrics["rate_limited"] = int(self.metrics.get("rate_limited", 0)) + 1
                    self.metrics["last_status"] = 429
                    self.metrics["last_error"] = one_line(str(e_rl), 200)
                except Exception as e:
                    log_debug_exc("HttpClient.request:req_ok", e)
                    pass
                if allow_retry and attempt <= int(self.cfg.max_retries):
                    ra = getattr(e_rl, 'retry_after_sec', None)
                    if ra is not None and float(ra) > 0:
                        cap_ra = 900.0
                        raw = float(ra)
                        t = min(raw, cap_ra)
                        t = t * random.uniform(0.95, 1.05)
                        t = min(t, cap_ra)
                        try:
                            self._last_retry_after_raw_sec = float(raw)
                            self._last_retry_after_sleep_sec = float(t)
                            self._last_retry_after_basis = "retry-after"
                            self._recent_retry_after_sleep_ts.append(time.time())
                        except Exception:
                            pass
                        # Record basis clearly for operators; keep it short.
                        try:
                            if raw > cap_ra:
                                log_warn(f"http.429 retry-after capped: raw={raw:.0f}s cap={cap_ra:.0f}s sleep={t:.0f}s attempt={attempt} path={path}")
                            else:
                                log_warn(f"http.429 retry-after: sleep={t:.0f}s attempt={attempt} path={path}")
                        except Exception:
                            pass
                        block_max = _env_float("MERSOOM_HTTP_429_BLOCK_MAX_SEC", 3.0, 0.0, 60.0)
                        if float(block_max) >= 0.0 and float(t) > float(block_max):
                            try:
                                log_warn(f"http.429 retry-after non-blocking: raw={raw:.0f}s sleep={t:.0f}s block_max={block_max:.1f}s attempt={attempt} path={path}")
                            except Exception:
                                pass
                            raise e_rl
                        time.sleep(max(0.0, t))
                    else:
                        try:
                            self._last_retry_after_basis = "backoff"
                        except Exception:
                            pass
                        self._backoff_sleep(attempt)
                    continue
                raise
            except (requests.Timeout, requests.ConnectionError, requests.exceptions.SSLError, requests.exceptions.ChunkedEncodingError, requests.exceptions.ProxyError) as e:
                try:
                    self.metrics["net_errors"] = int(self.metrics.get("net_errors", 0)) + 1
                    self.metrics["last_error"] = one_line(str(e), 200)
                except Exception as e:
                    log_debug_exc("_parse_retry_after_sec:silent", e)
                    pass
                if allow_retry and attempt <= int(self.cfg.max_retries):
                    self._backoff_sleep(attempt)
                    continue
                raise requests.RequestException(f"network failure after retries: {e}") from e
            except requests.HTTPError as e:
                # IMPORTANT: do NOT blindly retry 4xx (auth/validation/not found) — it creates loops.
                code2 = 0
                try:
                    resp = getattr(e, "response", None)
                    code2 = int(getattr(resp, "status_code", 0) or 0) if resp is not None else 0
                except Exception as e2:
                    log_debug_exc("HttpClient.request:http_status_parse", e2)
                    code2 = 0

                try:
                    self.metrics["http_errors"] = int(self.metrics.get("http_errors", 0)) + 1
                    if code2:
                        self.metrics["last_status"] = int(code2)
                    self.metrics["last_error"] = one_line(str(e), 200)
                except Exception as e2:
                    log_debug_exc("HttpClient.request:metrics_http_error", e2)
                    pass

                # Never retry auth failures (401/403) or general client errors (4xx).
                if 400 <= int(code2 or 0) <= 499:
                    if int(code2) == 408 and allow_retry and attempt <= int(self.cfg.max_retries):
                        self._backoff_sleep(attempt)
                        continue
                    raise

                # Retry 5xx only when enabled.
                if allow_retry and self.cfg.retry_on_5xx and self._is_retryable_5xx(int(code2 or 0)) and attempt <= int(self.cfg.max_retries):
                    self._backoff_sleep(attempt)
                    continue

                raise
        return HttpResult(status_code=0, json=None, text=last_text)

    def get_json(self, path: str, *, params: Optional[Dict[str, Any]] = None) -> Any:
        res = self.request("GET", path, params=params, allow_retry=True)
        if res.status_code >= 400:
            raise requests.HTTPError(f"{res.status_code} {res.text}")
        return res.json

    def post_json(self, path: str, payload: Dict[str, Any], *, headers: Optional[Dict[str, str]] = None) -> Any:
        res = self.request("POST", path, headers=headers, json_payload=payload, allow_retry=True)
        if res.status_code >= 400 and res.status_code not in (400, 409, 422):
            raise requests.HTTPError(f"{res.status_code} {res.text}")
        return res.json

    def health_snapshot(self) -> Dict[str, Any]:
        """(P0) lightweight runtime health/metrics snapshot for logging."""
        m = dict(self.metrics) if isinstance(getattr(self, "metrics", None), dict) else {}
        try:
            m["base_url"] = str(self.cfg.base_url)
            m["dry_run"] = bool(self.cfg.dry_run)
            if "latency_ms_ema" in m:
                m["latency_ms_ema"] = round(float(m.get("latency_ms_ema", 0.0) or 0.0), 1)
            if "latency_ms_last" in m:
                m["latency_ms_last"] = round(float(m.get("latency_ms_last", 0.0) or 0.0), 1)
            if "last_ok_ts" in m:
                m["last_ok_age_sec"] = round(max(0.0, time.time() - float(m.get("last_ok_ts") or 0.0)), 1)

            try:
                now2 = time.time()
                m["http_429_10m"] = int(sum(1 for t in list(getattr(self, "_recent_429_ts", [])) if (now2 - float(t or 0.0)) <= 600.0))
                m["retry_after_sleeps_10m"] = int(sum(1 for t in list(getattr(self, "_recent_retry_after_sleep_ts", [])) if (now2 - float(t or 0.0)) <= 600.0))
                m["http_401_10m"] = int(sum(1 for t in list(getattr(self, "_recent_http_401_ts", [])) if (now2 - float(t or 0.0)) <= 600.0))
                m["http_5xx_10m"] = int(sum(1 for t in list(getattr(self, "_recent_http_5xx_ts", [])) if (now2 - float(t or 0.0)) <= 600.0))
                if str(getattr(self, "_last_retry_after_basis", "") or ""):
                    m["last_429_sleep_basis"] = str(getattr(self, "_last_retry_after_basis", "") or "")
                if float(getattr(self, "_last_retry_after_sleep_sec", 0.0) or 0.0) > 0:
                    m["last_retry_after_sleep_sec"] = int(round(float(getattr(self, "_last_retry_after_sleep_sec", 0.0) or 0.0)))
            except Exception:
                pass
        except Exception as e:
            log_debug_exc("_parse_retry_after_sec:silent", e)
            pass
        return m
