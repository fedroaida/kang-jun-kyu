################################################################################
# 14. API WRAPPERS
# Deps: 01-07, 11
# Used by: agent actions
# Notes: HTTP endpoints for posts/comments/votes/etc.
################################################################################
"""
SECTION 14 - API WRAPPERS (MERSOOM ENDPOINTS)

Thin wrappers around the Mersoom API.

Responsibilities:
- Convert "agent intent" into concrete API calls (list, post, comment, vote, arena).
- Normalize payload shapes and handle common response parsing.
- Keep endpoints centralized for easier debugging and circuit breaking.

Notes:
- This file should not contain decision logic; only request/response plumbing.
"""
def list_posts(client: HttpClient, limit: int = 10, cursor: Optional[str] = None) -> Tuple[List[Dict[str, Any]], Optional[str]]:
    params: Dict[str, Any] = {"limit": int(limit)}
    if cursor:
        params["cursor"] = cursor
    data = client.get_json("/posts", params=params)
    if isinstance(data, dict) and isinstance(data.get("posts"), list):
        nxt = data.get("next_cursor") or data.get("cursor") or data.get("next") or None
        posts = data.get("posts") or []
        return [p for p in posts if isinstance(p, dict)], (str(nxt) if nxt else None)
    if isinstance(data, list):
        return [p for p in data if isinstance(p, dict)], None
    return [], None

def get_post(client: HttpClient, post_id: str) -> Optional[Dict[str, Any]]:
    try:
        data = client.get_json(f"/posts/{post_id}")
        return data if isinstance(data, dict) else None
    except requests.HTTPError as e:
        if "404" in str(e):
            return None
        raise

def list_comments(client: HttpClient, post_id: str) -> List[Dict[str, Any]]:
    data = client.get_json(f"/posts/{post_id}/comments")
    if isinstance(data, dict) and isinstance(data.get("comments"), list):
        comments = data.get("comments") or []
        return [c for c in comments if isinstance(c, dict)]
    if isinstance(data, list):
        return [c for c in data if isinstance(c, dict)]
    return []

def _is_validation_error_code(code: int) -> bool:
    return code in (400, 409, 422)

def _post_with_pow_401_retry(client: HttpClient, cfg: Config, path: str, payload: Dict[str, Any], *, state: Optional[Dict[str, Any]] = None) -> Any:
    """
    Sometimes 401 happens intermittently (challenge token expiry). Retry once with a fresh challenge.

    v19.6 note:
      - 403 is also used for phase gating / invalid actions in Arena 3.0.
      - Only retry 403 when it looks like an auth/proof issue (not phase mismatch).
    """
    try:
        return post_with_pow(client, cfg.pow, cfg.hybrid, path, payload, extra_headers=build_auth_headers(getattr(cfg, "auth", None)), state=state)
    except requests.HTTPError as e:
        headers = build_auth_headers(getattr(cfg, "auth", None))
        code = getattr(getattr(e, "response", None), "status_code", None)
        try:
            if code is not None:
                trace_hit(f"api:http:{int(code)}")
                trace_hit(f"api:post_pow:http:{int(code)}")
        except Exception:
            pass
        msg = str(e) or ""
        low = msg.lower()

        if code == 401 or "401" in low:
            trace_hit("api:retry:401")
            # Track repeated auth failures (challenge token expiry / auth mismatch) and trip contrib circuit if needed.
            if isinstance(state, dict):
                record_auth401_and_maybe_trip(state, path, where="post")
            try:
                return post_with_pow(client, cfg.pow, cfg.hybrid, path, payload, extra_headers=headers, state=state)
            except requests.HTTPError as e2:
                code2 = getattr(getattr(e2, "response", None), "status_code", None)
                low2 = (str(e2) or "").lower()
                if (code2 == 401 or "401" in low2) and isinstance(state, dict):
                    trace_hit("api:retry:401:fail")
                    record_auth401_and_maybe_trip(state, path, where="post(retry)")
                raise

        if code == 403 or "403" in low:
            # 403 is also used for phase gating / invalid actions in Arena 3.0.
            hints = ("invalid pow", "invalid proof", "missing proof", "token", "expired")
            if any(h in low for h in hints):
                trace_hit("api:retry:403")
                return post_with_pow(client, cfg.pow, cfg.hybrid, path, payload, extra_headers=headers, state=state)

        raise

def create_post(
    client: HttpClient,
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    title: str,
    content: str
) -> Optional[Dict[str, Any]]:
    trace_hit("api:create_post:enter")
    if dup_action_should_skip(state, action="post", target_id=_text_hash(f"{title}\n{content}"), endpoint_key="/posts"):
        protocol_set_reason(state, "post", "post:dup_action", "recent_action_guard")
        return None
    supports_title = state.get("post_title_supported")
    supports_nick = state.get("post_nickname_supported")

    title2 = ensure_eum_style(title, max_lines=1).replace("\\n", " ")
    title2 = postprocess_outgoing_text(title2, mode="title", max_chars=50, max_lines=1).replace("\\n", " ")
    content2 = ensure_eum_style(content, max_lines=max(2, tuning.max_output_lines))
    content2 = postprocess_outgoing_text(content2, mode="post", max_chars=1000, max_lines=max(2, tuning.max_output_lines))

    def candidates() -> List[Tuple[Dict[str, Any], str]]:
        c: List[Tuple[Dict[str, Any], str]] = []
        if supports_title is not False:
            base = {"title": title2, "content": content2}
            if supports_nick is not False:
                c.append(({**base, "nickname": cfg.nickname}, "title+nick"))
            c.append((base, "title"))
        merged = f"{title2}\n{content2}"
        base2 = {"content": merged}
        if supports_nick is not False:
            c.append(({**base2, "nickname": cfg.nickname}, "merged+nick"))
        c.append((base2, "merged"))
        return c

    last_err: Optional[Exception] = None
    for payload, tag in candidates():
        try:
            res = _post_with_pow_401_retry(client, cfg, "/posts", payload, state=state)
            if "title" in tag:
                state["post_title_supported"] = True
            if "merged" in tag:
                state["post_title_supported"] = False
            if "nick" in tag:
                state["post_nickname_supported"] = True
            trace_hit("api:create_post:ok")
            _hb_record_contribute(state, time.time(), kind="post")
            remember_action(state, action="post", target_id=_text_hash(f"{title}\n{content}"), endpoint_key="/posts")
            return res if isinstance(res, dict) else {"ok": True}
        except RateLimitError:
            trace_hit("api:rl")
            trace_hit("api:create_post:rl")
            raise
        except requests.HTTPError as e:
            last_err = e
            msg = str(e)
            code = 0
            try:
                code = int(getattr(getattr(e, "response", None), "status_code", 0) or 0)
            except Exception:
                code = 0
            if not code:
                try:
                    code = int(msg.split()[0])
                except Exception as e2:
                    log_debug_exc("create_post:silent", e2)
                    pass

            try:
                if code:
                    trace_hit(f"api:http:{int(code)}")
                    trace_hit(f"api:create_post:http:{int(code)}")
            except Exception:
                pass

            if _is_validation_error_code(code):
                if "title" in tag:
                    state["post_title_supported"] = False
                if "nick" in tag:
                    state["post_nickname_supported"] = False
                continue
            raise
        except Exception as e:
            trace_hit("api:create_post:exc")
            last_err = e
            break

    log_error("post", f"failed: {last_err}")
    return None

def create_comment(
    client: HttpClient,
    cfg: Config,
    tuning: AgentTuning,
    state: Dict[str, Any],
    post_id: str,
    content: str,
    parent_id: Optional[str] = None
) -> Optional[Dict[str, Any]]:
    trace_hit("api:create_comment:enter")
    if dup_action_should_skip(state, action=("reply" if parent_id else "comment"), target_id=str(parent_id or post_id), endpoint_key=f"/posts/{post_id}/comments"):
        protocol_set_reason(state, "comment", "comment:dup_action", "recent_action_guard")
        return None
    supports_nick = state.get("comment_nickname_supported")
    content2 = ensure_eum_style(content, max_lines=max(2, tuning.max_output_lines))
    _mode = "reply" if parent_id else "comment"
    content2 = postprocess_outgoing_text(content2, mode=_mode, max_chars=500, max_lines=max(2, tuning.max_output_lines))

    def candidates() -> List[Tuple[Dict[str, Any], str]]:
        base: Dict[str, Any] = {"content": content2}
        if parent_id:
            base["parent_id"] = parent_id
        c: List[Tuple[Dict[str, Any], str]] = []
        if supports_nick is not False:
            c.append(({**base, "nickname": cfg.nickname}, "nick"))
        c.append((base, "nonick"))
        return c

    last_err: Optional[Exception] = None
    for payload, tag in candidates():
        try:
            res = _post_with_pow_401_retry(client, cfg, f"/posts/{post_id}/comments", payload, state=state)
            if tag == "nick":
                state["comment_nickname_supported"] = True
            _hb_record_comment(state, time.time())
            remember_action(state, action=("reply" if parent_id else "comment"), target_id=str(parent_id or post_id), endpoint_key=f"/posts/{post_id}/comments")
            trace_hit("api:create_comment:ok")
            return res if isinstance(res, dict) else {"ok": True}
        except RateLimitError:
            trace_hit("api:rl")
            trace_hit("api:create_comment:rl")
            raise
        except requests.HTTPError as e:
            last_err = e
            msg = str(e)
            code = 0
            try:
                code = int(getattr(getattr(e, "response", None), "status_code", 0) or 0)
            except Exception:
                code = 0
            if not code:
                try:
                    code = int(msg.split()[0])
                except Exception as e2:
                    log_debug_exc("create_comment:silent", e2)
                    pass

            try:
                if code:
                    trace_hit(f"api:http:{int(code)}")
                    trace_hit(f"api:create_comment:http:{int(code)}")
            except Exception:
                pass

            if "404" in msg:
                return None
            if _is_validation_error_code(code):
                if tag == "nick":
                    state["comment_nickname_supported"] = False
                continue
            raise
        except Exception as e:
            trace_hit("api:create_comment:exc")
            last_err = e
            break

    log_error("comment", f"failed: {last_err}")
    return None


def vote_post(
    client: HttpClient,
    cfg: Config,
    state: Dict[str, Any],
    post_id: str,
    vtype: str
) -> bool:
    """Vote on a post.

    v19.2:
      - Records votes into BOTH state.votes.posts (post_id -> ts) and legacy state.voted_posts (post_id -> {type, ts}).
      - Treats 'Already voted' 429 as non-fatal (records as voted to avoid infinite retries).
    """
    if state.get("vote_supported") is False:
        return False

    vtype2 = "up" if str(vtype) == "up" else "down"
    pid = str(post_id or "")
    if dup_action_should_skip(state, action=f"vote:{vtype2}", target_id=pid, endpoint_key=f"/posts/{pid}/vote"):
        protocol_set_reason(state, "vote", "vote:dup_action", "recent_action_guard")
        return False
    ts = time.time()
    trace_hit("api:vote_post:enter")

    try:
        _post_with_pow_401_retry(client, cfg, f"/posts/{pid}/vote", {"type": vtype2}, state=state)
        state["vote_supported"] = True
        _record_voted_post(cfg, state, pid, vtype2, ts)
        _hb_record_vote(state, ts)
        remember_action(state, action=f"vote:{vtype2}", target_id=pid, endpoint_key=f"/posts/{pid}/vote")
        trace_hit("api:vote_post:ok")
        return True

    except PowTimeoutError as e:
        trace_hit("api:vote_post:pow_timeout")
        protocol_set_reason(state, "vote", "vote:pow_timeout", one_line(str(e), 180))
        return False
    except RateLimitError as e:
        trace_hit("api:rl")
        trace_hit("api:vote_post:rl")
        # Some 429s are "Already voted from this IP" (not a real rate limit for our purpose).
        msg = str(e).lower()
        if "already voted" in msg:
            state["vote_supported"] = True
            trace_hit("api:vote_post:already_voted")
            _record_voted_post(cfg, state, pid, vtype2, ts)
            _hb_record_vote(state, ts)
            return False
        raise

    except requests.HTTPError as e:
        msg = str(e)
        code = 0
        try:
            code = int(getattr(getattr(e, "response", None), "status_code", 0) or 0)
        except Exception:
            code = 0
        try:
            if code:
                trace_hit(f"api:http:{int(code)}")
                trace_hit(f"api:vote_post:http:{int(code)}")
        except Exception:
            pass
        if "404" in msg:
            state["vote_supported"] = False
            return False
        state["vote_supported"] = True
        _record_voted_post(cfg, state, pid, vtype2, ts)
        _hb_record_vote(state, ts)
        return False

def arena_status(client: HttpClient) -> Optional[Dict[str, Any]]:
    try:
        data = client.get_json("/arena/status")
        return data if isinstance(data, dict) else None
    except (RateLimitError, requests.HTTPError):
        raise
    except Exception as e:
        log_error("arena_status", one_line(repr(e), 180))
        return None

def arena_posts(client: HttpClient, date: Optional[str] = None, limit: int = 200) -> List[Dict[str, Any]]:
    """List arena posts for a given date (YYYY-MM-DD).
    Spec: GET /api/arena/posts?date=YYYY-MM-DD (server may also accept limit).
    Returns a list[dict]. Be tolerant to old response shapes.
    """
    try:
        params: Dict[str, Any] = {}
        if date:
            params["date"] = str(date)
        if limit:
            params["limit"] = int(limit)
        data = client.get_json("/arena/posts", params=(params if params else None))
        if isinstance(data, list):
            return [p for p in data if isinstance(p, dict)]
        if isinstance(data, dict):
            if isinstance(data.get("posts"), list):
                posts = data.get("posts") or []
                return [p for p in posts if isinstance(p, dict)]
            if isinstance(data.get("items"), list):
                items = data.get("items") or []
                return [p for p in items if isinstance(p, dict)]
        return []
    except (RateLimitError, requests.HTTPError):
        raise
    except Exception as e:
        log_error("arena_posts", repr(e))
        return []

def arena_propose(client: HttpClient, cfg: Config, payload: Dict[str, Any], *, state: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """Arena propose (PROPOSE phase).

    v19.6: Let RateLimitError/HTTPError bubble up so caller can parse cooldown/phase.
    """
    trace_hit("api:arena_propose:enter")
    if isinstance(state, dict):
        target_id = str(payload.get("post_id") or payload.get("id") or payload.get("topic") or "arena")
        if dup_action_should_skip(state, action="arena:propose", target_id=target_id, endpoint_key="/arena/propose"):
            protocol_set_reason(state, "arena", "arena:dup_action", "recent_action_guard")
            return None
    try:
        data = _post_with_pow_401_retry(client, cfg, "/arena/propose", payload, state=state)
        trace_hit("api:arena_propose:ok")
    except RateLimitError:
        trace_hit("api:rl")
        trace_hit("api:arena_propose:rl")
        raise
    except requests.HTTPError as e:
        code = 0
        try:
            code = int(getattr(getattr(e, "response", None), "status_code", 0) or 0)
        except Exception:
            code = 0
        try:
            if code:
                trace_hit(f"api:http:{int(code)}")
                trace_hit(f"api:arena_propose:http:{int(code)}")
        except Exception:
            pass
        raise
    if isinstance(state, dict):
        target_id = str(payload.get("post_id") or payload.get("id") or payload.get("topic") or "arena")
        remember_action(state, action="arena:propose", target_id=target_id, endpoint_key="/arena/propose")
    return data if isinstance(data, dict) else {"ok": True}


def arena_fight(client: HttpClient, cfg: Config, payload: Dict[str, Any], *, state: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """Arena fight (BATTLE phase).

    v19.6: Let RateLimitError/HTTPError bubble up so caller can parse cooldown/phase.
    """
    trace_hit("api:arena_fight:enter")
    if isinstance(state, dict):
        target_id = str(payload.get("battle_id") or payload.get("id") or payload.get("post_id") or "arena")
        if dup_action_should_skip(state, action="arena:fight", target_id=target_id, endpoint_key="/arena/fight"):
            protocol_set_reason(state, "arena", "arena:dup_action", "recent_action_guard")
            return None
    try:
        data = _post_with_pow_401_retry(client, cfg, "/arena/fight", payload, state=state)
        trace_hit("api:arena_fight:ok")
    except RateLimitError:
        trace_hit("api:rl")
        trace_hit("api:arena_fight:rl")
        raise
    except requests.HTTPError as e:
        code = 0
        try:
            code = int(getattr(getattr(e, "response", None), "status_code", 0) or 0)
        except Exception:
            code = 0
        try:
            if code:
                trace_hit(f"api:http:{int(code)}")
                trace_hit(f"api:arena_fight:http:{int(code)}")
        except Exception:
            pass
        raise
    if isinstance(state, dict):
        target_id = str(payload.get("battle_id") or payload.get("id") or payload.get("post_id") or "arena")
        remember_action(state, action="arena:fight", target_id=target_id, endpoint_key="/arena/fight")
    return data if isinstance(data, dict) else {"ok": True}
